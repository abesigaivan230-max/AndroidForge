package com.veotag.app.data.repository

import android.content.Context
import android.net.Uri
import com.veotag.app.data.model.AdminUser
import com.veotag.app.data.model.CategoryRow
import com.veotag.app.data.model.PublishRow
import com.veotag.app.data.model.Project
import com.veotag.app.data.model.ProjectInsert
import com.veotag.app.data.remote.SupabaseProvider
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.io.DataInputStream
import java.util.UUID

class ProjectRepository {

    private val client get() = SupabaseProvider.client

    /** PostgREST `or(...)` filters are comma/parenthesis delimited, so those characters must not reach the query. */
    private fun sanitizeSearch(raw: String?): String? =
        raw?.replace(Regex("[,()*%\\\\]"), " ")?.replace(Regex("\\s+"), " ")?.trim()?.takeIf { it.isNotEmpty() }

    suspend fun getPublishedProjects(
        limit: Int = 20,
        offset: Int = 0,
        category: String? = null,
        search: String? = null
    ): Result<List<Project>> = withContext(Dispatchers.IO) {
        runCatching {
            val term = sanitizeSearch(search)
            val query = client.from("projects")
                .select(Columns.ALL) {
                    filter {
                        eq("is_published", true)
                        if (!category.isNullOrBlank()) {
                            eq("category", category)
                        }
                        if (term != null) {
                            or {
                                ilike("title", "%$term%")
                                ilike("short_description", "%$term%")
                                ilike("category", "%$term%")
                                ilike("school_organization", "%$term%")
                                ilike("creators_names", "%$term%")
                            }
                        }
                    }
                    order("created_at", Order.DESCENDING)
                    range(offset.toLong(), (offset + limit - 1).toLong())
                }
            query.decodeList<Project>()
        }
    }

    suspend fun getProjectById(id: String, publishedOnly: Boolean = true): Result<Project?> =
        withContext(Dispatchers.IO) {
            runCatching {
                val list = client.from("projects")
                    .select(Columns.ALL) {
                        filter {
                            eq("id", id)
                            if (publishedOnly) {
                                eq("is_published", true)
                            }
                        }
                    }
                    .decodeList<Project>()
                list.firstOrNull()
            }
        }

    suspend fun getAllProjectsAdmin(): Result<List<Project>> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .select(Columns.ALL) {
                    order("created_at", Order.DESCENDING)
                }
                .decodeList<Project>()
        }
    }

    suspend fun getProjectCounts(): Result<Triple<Int, Int, Int>> = withContext(Dispatchers.IO) {
        runCatching {
            val all = client.from("projects")
                .select(Columns.list("is_published"))
                .decodeList<PublishRow>()
            val total = all.size
            val published = all.count { it.isPublished }
            Triple(total, published, total - published)
        }
    }

    suspend fun createProject(insert: ProjectInsert): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .insert(insert) {
                    select()
                }
                .decodeSingle<Project>()
        }
    }

    suspend fun setPublished(id: String, published: Boolean): Result<Project> =
        updateProjectFields(id, buildJsonObject { put("is_published", published) })

    /** Sends exactly the fields in [fields]. A JSON null clears an optional column; omitted keys are left untouched. */
    suspend fun updateProjectFields(id: String, fields: JsonObject): Result<Project> =
        withContext(Dispatchers.IO) {
            runCatching {
                client.from("projects")
                    .update(fields) {
                        filter { eq("id", id) }
                        select()
                    }
                    .decodeSingle<Project>()
            }
        }

    suspend fun deleteProject(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .delete {
                    filter { eq("id", id) }
                }
            Unit
        }
    }

    suspend fun uploadVideo(context: Context, uri: Uri, projectId: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val info = com.veotag.app.util.VideoUtils.inspect(context, uri)
                if (info.sizeBytes > com.veotag.app.util.VideoUtils.MAX_BYTES) {
                    throw IllegalStateException("Video must be 100 MB or smaller.")
                }
                if (info.durationMs != null && info.durationMs > com.veotag.app.util.VideoUtils.MAX_DURATION_MS) {
                    throw IllegalStateException("Video must be 5 minutes or shorter.")
                }
                // Read straight into an exactly-sized array (peak memory = file size) instead of growing a buffer.
                val bytes: ByteArray = if (info.sizeBytes > 0) {
                    val buffer = ByteArray(info.sizeBytes.toInt())
                    (resolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open video file"))
                        .use { DataInputStream(it).readFully(buffer) }
                    buffer
                } else {
                    (resolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open video file"))
                        .use { it.readBytes() }
                }
                if (bytes.size > com.veotag.app.util.VideoUtils.MAX_BYTES) {
                    throw IllegalStateException("Video must be 100 MB or smaller.")
                }
                val mime = resolver.getType(uri) ?: "video/mp4"
                val ext = if (mime.contains("webm")) "webm" else "mp4"
                val path = "$projectId/${UUID.randomUUID()}.$ext"
                client.storage.from(SupabaseProvider.BUCKET)
                    .upload(path, bytes) {
                        upsert = false
                    }
                path
            }
        }

    suspend fun deleteVideo(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.storage.from(SupabaseProvider.BUCKET).delete(path)
            Unit
        }
    }

    suspend fun signIn(email: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            Unit
        }
    }

    suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.auth.signOut()
            Unit
        }
    }

    suspend fun currentUserId(): String? = withContext(Dispatchers.IO) {
        client.auth.awaitInitialization()
        client.auth.currentUserOrNull()?.id
    }

    suspend fun isAuthorizedAdmin(): Boolean = withContext(Dispatchers.IO) {
        // Without this, a restored session isn't loaded yet after an app restart and the admin is bounced to login.
        client.auth.awaitInitialization()
        val userId = client.auth.currentUserOrNull()?.id ?: return@withContext false
        try {
            val admins = client.from("admin_users")
                .select(Columns.ALL) {
                    filter { eq("user_id", userId) }
                }
                .decodeList<AdminUser>()
            admins.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getDistinctCategories(): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .select(Columns.list("category")) {
                    filter { eq("is_published", true) }
                }
                .decodeList<CategoryRow>()
                .map { it.category.trim() }
                .filter { it.isNotEmpty() }
                .distinct()
                .sortedBy { it.lowercase() }
        }
    }
}
