package com.veotag.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.ui.draw.scale
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.veotag.app.ui.screens.admin.AdminDashboardScreen
import com.veotag.app.ui.screens.admin.AdminLoginScreen
import com.veotag.app.ui.screens.admin.ManageProjectsScreen
import com.veotag.app.ui.screens.admin.ProjectFormScreen
import com.veotag.app.ui.screens.explore.ExploreScreen
import com.veotag.app.ui.screens.home.HomeScreen
import com.veotag.app.ui.screens.project.ProjectDetailScreen
import com.veotag.app.ui.screens.scan.ScanScreen

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Explore : Screen("explore")
    data object Scan : Screen("scan")
    data object ProjectDetail : Screen("project/{projectId}") {
        fun create(id: String) = "project/$id"
    }
    data object AdminLogin : Screen("admin/login")
    data object AdminDashboard : Screen("admin/dashboard")
    data object ManageProjects : Screen("admin/manage")
    data object AddProject : Screen("admin/add")
    data object EditProject : Screen("admin/edit/{projectId}") {
        fun create(id: String) = "admin/edit/$id"
    }
}

data class BottomNavItem(
    val screen: Screen,
    val label: String,
    val icon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home, "Home", Icons.Default.Home),
    BottomNavItem(Screen.Explore, "Explore", Icons.Default.Explore),
    BottomNavItem(Screen.Scan, "Scan", Icons.Default.QrCodeScanner)
)

private val tabRoutes = setOf(Screen.Home.route, Screen.Explore.route, Screen.Scan.route)
private fun isTab(route: String?) = route in tabRoutes

@Composable
fun VeoTagNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val showBottomBar = isTab(currentDestination?.route)

    Scaffold(
        // Screens own their insets (TopAppBar handles the status bar; the bar below handles the nav bar).
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            AnimatedVisibility(
                visible = showBottomBar,
                enter = slideInVertically(tween(260)) { it } + fadeIn(tween(260)),
                exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(160))
            ) {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 3.dp) {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any {
                            it.route == item.screen.route
                        } == true
                        val iconScale by animateFloatAsState(
                            targetValue = if (selected) 1.18f else 1f,
                            animationSpec = spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium),
                            label = "tabIcon"
                        )
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = {
                                Icon(item.icon, contentDescription = item.label, modifier = Modifier.scale(iconScale))
                            },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier
                .padding(padding)
                .then(if (showBottomBar) Modifier else Modifier.navigationBarsPadding()),
            // Tab <-> tab: calm cross-fade with a tiny scale. Anything deeper: directional slide.
            enterTransition = {
                if (isTab(initialState.destination.route) && isTab(targetState.destination.route))
                    fadeIn(tween(260, delayMillis = 60)) + scaleIn(tween(260, delayMillis = 60), initialScale = 0.96f)
                else
                    fadeIn(tween(280)) + slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(320)) { it / 4 }
            },
            exitTransition = {
                if (isTab(initialState.destination.route) && isTab(targetState.destination.route))
                    fadeOut(tween(120))
                else
                    fadeOut(tween(200)) + slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.Start, tween(320)) { it / 6 }
            },
            popEnterTransition = {
                if (isTab(initialState.destination.route) && isTab(targetState.destination.route))
                    fadeIn(tween(260, delayMillis = 60)) + scaleIn(tween(260, delayMillis = 60), initialScale = 0.96f)
                else
                    fadeIn(tween(280)) + slideIntoContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(320)) { it / 6 }
            },
            popExitTransition = {
                if (isTab(initialState.destination.route) && isTab(targetState.destination.route))
                    fadeOut(tween(120))
                else
                    fadeOut(tween(200)) + slideOutOfContainer(AnimatedContentTransitionScope.SlideDirection.End, tween(320)) { it / 4 }
            }
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onScanClick = {
                        navController.navigate(Screen.Scan.route) {
                            launchSingleTop = true
                        }
                    },
                    onProjectClick = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id))
                    },
                    onSearchClick = {
                        navController.navigate(Screen.Explore.route) {
                            launchSingleTop = true
                        }
                    },
                    onAdminShortcut = {
                        navController.navigate(Screen.AdminLogin.route)
                    }
                )
            }
            composable(Screen.Explore.route) {
                ExploreScreen(
                    onProjectClick = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id))
                    }
                )
            }
            composable(Screen.Scan.route) {
                ScanScreen(
                    onProjectScanned = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id)) {
                            launchSingleTop = true
                        }
                    },
                    onAdminShortcut = {
                        navController.navigate(Screen.AdminLogin.route)
                    }
                )
            }
            composable(
                route = Screen.ProjectDetail.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("projectId") ?: return@composable
                ProjectDetailScreen(
                    projectId = id,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AdminLogin.route) {
                AdminLoginScreen(
                    onLoginSuccess = {
                        navController.navigate(Screen.AdminDashboard.route) {
                            popUpTo(Screen.AdminLogin.route) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AdminDashboard.route) {
                AdminDashboardScreen(
                    onAddProject = { navController.navigate(Screen.AddProject.route) },
                    onManageProjects = { navController.navigate(Screen.ManageProjects.route) },
                    onLogout = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.ManageProjects.route) {
                ManageProjectsScreen(
                    onEdit = { id -> navController.navigate(Screen.EditProject.create(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AddProject.route) {
                ProjectFormScreen(
                    projectId = null,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = Screen.EditProject.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("projectId")
                ProjectFormScreen(
                    projectId = id,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
