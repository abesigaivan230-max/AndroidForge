package com.veotag.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand
val BrandBlue = Color(0xFF2563EB)
val BrandIndigo = Color(0xFF4F46E5)
val BrandViolet = Color(0xFF7C3AED)
val BrandOrange = Color(0xFFF97316)
val BrandOrangeSoft = Color(0xFFFB923C)

// Light scheme
val LightBackground = Color(0xFFF6F7FB)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFE8EAF4)
val LightOnSurface = Color(0xFF0F172A)
val LightOnSurfaceVariant = Color(0xFF5B6478)
val LightOutline = Color(0xFFC9CEDF)
val LightOutlineVariant = Color(0xFFE3E6F1)

// Dark scheme
val DarkBackground = Color(0xFF0B1020)
val DarkSurface = Color(0xFF141B33)
val DarkSurfaceVariant = Color(0xFF1E2747)
val DarkOnSurface = Color(0xFFF1F4FF)
val DarkOnSurfaceVariant = Color(0xFFA3ADC8)
val DarkOutline = Color(0xFF4A5578)
val DarkOutlineVariant = Color(0xFF2A3354)

// Semantics
val SuccessGreen = Color(0xFF16A34A)
val SuccessGreenSoft = Color(0xFF4ADE80)
val ErrorRed = Color(0xFFDC2626)
val ErrorRedSoft = Color(0xFFF87171)

// Legacy aliases kept so older screens resolve; prefer MaterialTheme.colorScheme in new code.
val BluePrimary = BrandIndigo
val PurpleAccent = BrandViolet
val OrangeAccent = BrandOrange
