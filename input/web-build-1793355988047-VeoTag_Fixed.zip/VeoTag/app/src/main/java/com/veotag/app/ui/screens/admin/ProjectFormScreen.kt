package com.veotag.app.ui.screens.admin

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.veotag.app.data.model.ProjectInsert
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import com.veotag.app.data.repository.ProjectRepository
import kotlinx.coroutines.launch
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectFormScreen(
    projectId: String?,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    val repo = remember { ProjectRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val isEdit = projectId != null

    var title by remember { mutableStateOf("") }
    var shortDescription by remember { mutableStateOf("") }
    var creatorsNames by remember { mutableStateOf("") }
    var schoolOrganization by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var additionalDetails by remember { mutableStateOf("") }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoLabel by remember { mutableStateOf<String?>(null) }
    var existingVideoPath by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            videoUri = uri
            videoLabel = uri.lastPathSegment ?: "Selected video"
        }
    }

    LaunchedEffect(projectId) {
        if (projectId != null) {
            repo.getProjectById(projectId, publishedOnly = false).onSuccess { p ->
                if (p != null) {
                    title = p.title
                    shortDescription = p.shortDescription
                    creatorsNames = p.creatorsNames.orEmpty()
                    schoolOrganization = p.schoolOrganization.orEmpty()
                    category = p.category
                    additionalDetails = p.additionalDetails.orEmpty()
                    existingVideoPath = p.videoPath
                    videoLabel = "Current video (select to replace)"
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text(if (isEdit) "Edit Project" else "Add Project") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("Title *") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = shortDescription,
                onValueChange = { shortDescription = it },
                label = { Text("Short description *") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = category,
                onValueChange = { category = it },
                label = { Text("Category *") },
                singleLine = true,
                placeholder = { Text("e.g. Robotics, Science Fair, Agriculture") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = creatorsNames,
                onValueChange = { creatorsNames = it },
                label = { Text("Creators' names") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = schoolOrganization,
                onValueChange = { schoolOrganization = it },
                label = { Text("School / Organization") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = additionalDetails,
                onValueChange = { additionalDetails = it },
                label = { Text("Additional details") },
                minLines = 3,
                maxLines = 6,
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = { videoPicker.launch(arrayOf("video/*")) },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (videoLabel != null) "Change Video" else "Select Video *")
            }
            videoLabel?.let {
                Spacer(Modifier.height(4.dp))
                Text(it, style = MaterialTheme.typography.bodySmall)
            }
            error?.let {
                Spacer(Modifier.height(12.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
            Spacer(Modifier.height(24.dp))
            Button(
                onClick = {
                    when {
                        title.isBlank() -> error = "Title is required"
                        shortDescription.isBlank() -> error = "Short description is required"
                        category.isBlank() -> error = "Category is required"
                        !isEdit && videoUri == null -> error = "Video is required"
                        else -> {
                            scope.launch {
                                loading = true
                                error = null
                                try {
                                    if (!repo.isAuthorizedAdmin()) {
                                        error = "Not authorized"
                                        loading = false
                                        return@launch
                                    }
                                    if (isEdit && projectId != null) {
                                        var newPath: String? = null
                                        if (videoUri != null) {
                                            val upload = repo.uploadVideo(context, videoUri!!, projectId)
                                            if (upload.isFailure) {
                                                error = upload.exceptionOrNull()?.message ?: "Upload failed"
                                                loading = false
                                                return@launch
                                            }
                                            newPath = upload.getOrThrow()
                                        }
                                        val update = buildJsonObject {
                                            put("title", title.trim())
                                            put("short_description", shortDescription.trim())
                                            put("creators_names", creatorsNames.trim().ifBlank { null })
                                            put("school_organization", schoolOrganization.trim().ifBlank { null })
                                            put("category", category.trim())
                                            put("additional_details", additionalDetails.trim().ifBlank { null })
                                            if (newPath != null) put("video_path", newPath)
                                        }
                                        val result = repo.updateProjectFields(projectId, update)
                                        if (result.isSuccess) {
                                            if (newPath != null && existingVideoPath != null && existingVideoPath != newPath) {
                                                repo.deleteVideo(existingVideoPath!!)
                                            }
                                            onSaved()
                                        } else {
                                            if (newPath != null) repo.deleteVideo(newPath)
                                            error = "Failed to update project"
                                        }
                                    } else {
                                        val newId = UUID.randomUUID().toString()
                                        val upload = repo.uploadVideo(context, videoUri!!, newId)
                                        if (upload.isFailure) {
                                            error = upload.exceptionOrNull()?.message ?: "Upload failed"
                                            loading = false
                                            return@launch
                                        }
                                        val path = upload.getOrThrow()
                                        val insert = ProjectInsert(
                                            title = title.trim(),
                                            videoPath = path,
                                            shortDescription = shortDescription.trim(),
                                            creatorsNames = creatorsNames.trim().ifBlank { null },
                                            schoolOrganization = schoolOrganization.trim().ifBlank { null },
                                            category = category.trim(),
                                            additionalDetails = additionalDetails.trim().ifBlank { null },
                                            isPublished = false
                                        )
                                        // Note: id is generated by DB. We used newId only for storage path prefix.
                                        // After insert we get real UUID. For path we used random prefix which is fine.
                                        val result = repo.createProject(insert)
                                        if (result.isSuccess) {
                                            onSaved()
                                        } else {
                                            repo.deleteVideo(path)
                                            error = "Failed to create project: ${result.exceptionOrNull()?.message}"
                                        }
                                    }
                                } catch (e: Exception) {
                                    error = e.message ?: "Unexpected error"
                                }
                                loading = false
                            }
                        }
                    }
                },
                enabled = !loading,
                modifier = Modifier.fillMaxWidth()
            ) {
                if (loading) {
                    CircularProgressIndicator(
                        modifier = Modifier.height(20.dp),
                        color = MaterialTheme.colorScheme.onPrimary,
                        strokeWidth = 2.dp
                    )
                } else {
                    Text(if (isEdit) "Save Changes" else "Create Project")
                }
            }
        }
    }
}
