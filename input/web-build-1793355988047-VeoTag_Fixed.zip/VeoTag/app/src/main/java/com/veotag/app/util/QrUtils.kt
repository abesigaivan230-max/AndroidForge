package com.veotag.app.util

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import com.google.zxing.qrcode.decoder.ErrorCorrectionLevel
import java.util.UUID

object QrUtils {
    private const val PREFIX = "VEOTAG:"

    fun formatPayload(projectId: String): String = "$PREFIX$projectId"

    fun parsePayload(raw: String): String? {
        val trimmed = raw.trim()
        if (!trimmed.startsWith(PREFIX, ignoreCase = true)) return null
        val id = trimmed.substring(PREFIX.length).trim()
        return try {
            UUID.fromString(id)
            id
        } catch (_: Exception) {
            null
        }
    }

    fun generateQrBitmap(
        projectId: String,
        size: Int = 1024,
        withLabel: Boolean = true
    ): Bitmap {
        val content = formatPayload(projectId)
        val hints = mapOf(
            EncodeHintType.ERROR_CORRECTION to ErrorCorrectionLevel.H,
            EncodeHintType.MARGIN to 2,
            EncodeHintType.CHARACTER_SET to "UTF-8"
        )
        val matrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, size, size, hints)
        val w = matrix.width
        val h = matrix.height
        val pixels = IntArray(w * h)
        for (y in 0 until h) {
            val row = y * w
            for (x in 0 until w) {
                pixels[row + x] = if (matrix[x, y]) Color.BLACK else Color.WHITE
            }
        }
        val qrBitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        qrBitmap.setPixels(pixels, 0, w, 0, 0, w, h)
        if (!withLabel) return qrBitmap

        val labelHeight = (size * 0.12f).toInt()
        val result = Bitmap.createBitmap(size, size + labelHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        canvas.drawColor(Color.WHITE)
        canvas.drawBitmap(qrBitmap, 0f, 0f, null)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#4F46E5")
            textSize = size * 0.06f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("VeoTag", size / 2f, size + labelHeight * 0.7f, paint)
        return result
    }

    fun generatePrintableLabel(
        projectId: String,
        title: String,
        size: Int = 1200
    ): Bitmap {
        val qrSize = (size * 0.55f).toInt()
        val qr = generateQrBitmap(projectId, qrSize, withLabel = false)
        val height = (size * 1.15f).toInt()
        val bitmap = Bitmap.createBitmap(size, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)

        val primary = Color.parseColor("#4F46E5")
        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Header bar
        paint.color = primary
        canvas.drawRect(0f, 0f, size.toFloat(), size * 0.08f, paint)

        paint.color = Color.WHITE
        paint.textSize = size * 0.045f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("VeoTag", size / 2f, size * 0.055f, paint)

        // Title
        paint.color = Color.parseColor("#1A1A1A")
        paint.textSize = size * 0.05f
        val titleY = size * 0.14f
        val maxWidth = size * 0.9f
        val truncated = if (paint.measureText(title) > maxWidth) {
            var t = title
            while (paint.measureText("$t…") > maxWidth && t.isNotEmpty()) {
                t = t.dropLast(1)
            }
            "$t…"
        } else title
        canvas.drawText(truncated, size / 2f, titleY, paint)

        // QR centered
        val qrLeft = (size - qrSize) / 2f
        val qrTop = size * 0.2f
        canvas.drawBitmap(qr, qrLeft, qrTop, null)

        // Instruction
        paint.color = primary
        paint.textSize = size * 0.038f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText(
            "Scan with VeoTag to explore",
            size / 2f,
            qrTop + qrSize + size * 0.08f,
            paint
        )

        // Footer line
        paint.color = Color.parseColor("#E0E0E0")
        paint.strokeWidth = 2f
        canvas.drawLine(
            size * 0.1f,
            height - size * 0.06f,
            size * 0.9f,
            height - size * 0.06f,
            paint
        )

        return bitmap
    }
}
