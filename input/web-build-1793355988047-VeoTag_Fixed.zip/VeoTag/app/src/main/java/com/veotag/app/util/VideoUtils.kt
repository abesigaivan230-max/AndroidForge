package com.veotag.app.util

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VideoInfo(val displayName: String, val sizeBytes: Long, val durationMs: Long?)

object VideoUtils {
    const val MAX_BYTES = 100L * 1024 * 1024
    const val MAX_DURATION_MS = 5L * 60 * 1000

    /** Reads name, size and duration of a picked video without loading it into memory. */
    suspend fun inspectAsync(context: Context, uri: Uri): VideoInfo =
        withContext(Dispatchers.IO) { inspect(context, uri) }

    fun inspect(context: Context, uri: Uri): VideoInfo {
        var name = uri.lastPathSegment ?: "Selected video"
        var size = -1L
        try {
            context.contentResolver
                .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE), null, null, null)
                ?.use { c ->
                    if (c.moveToFirst()) {
                        val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        val s = c.getColumnIndex(OpenableColumns.SIZE)
                        if (n >= 0 && !c.isNull(n)) name = c.getString(n)
                        if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
                    }
                }
        } catch (_: Exception) {
        }
        var duration: Long? = null
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(context, uri)
            duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
        } catch (_: Exception) {
        } finally {
            try {
                retriever.release()
            } catch (_: Exception) {
            }
        }
        return VideoInfo(name, size, duration)
    }

    fun formatSize(bytes: Long): String = when {
        bytes < 0 -> "unknown size"
        bytes >= 1024 * 1024 -> String.format("%.1f MB", bytes / (1024.0 * 1024.0))
        else -> String.format("%d KB", bytes / 1024)
    }

    fun formatDuration(ms: Long?): String {
        if (ms == null) return ""
        val total = ms / 1000
        return String.format("%d:%02d", total / 60, total % 60)
    }
}
