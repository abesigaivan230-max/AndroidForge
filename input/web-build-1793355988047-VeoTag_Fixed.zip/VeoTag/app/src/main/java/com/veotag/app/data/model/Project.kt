package com.veotag.app.data.model

import kotlinx.serialization.EncodeDefault
import kotlinx.serialization.ExperimentalSerializationApi
import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Project(
    val id: String,
    val title: String,
    @SerialName("video_path") val videoPath: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("creators_names") val creatorsNames: String? = null,
    @SerialName("school_organization") val schoolOrganization: String? = null,
    val category: String,
    @SerialName("additional_details") val additionalDetails: String? = null,
    @SerialName("thumbnail_path") val thumbnailPath: String? = null,
    @SerialName("is_published") val isPublished: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null
)

@OptIn(ExperimentalSerializationApi::class)
@Serializable
data class ProjectInsert(
    val title: String,
    @SerialName("video_path") val videoPath: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("creators_names") val creatorsNames: String? = null,
    @SerialName("school_organization") val schoolOrganization: String? = null,
    val category: String,
    @SerialName("additional_details") val additionalDetails: String? = null,
    @SerialName("thumbnail_path") val thumbnailPath: String? = null,
    @EncodeDefault @SerialName("is_published") val isPublished: Boolean = false
)

@Serializable
data class AdminUser(
    @SerialName("user_id") val userId: String,
    @SerialName("created_at") val createdAt: String? = null
)

/** Lightweight row used only to read the distinct categories (the full [Project] has required fields). */
@Serializable
data class CategoryRow(val category: String)

/** Lightweight row used only to count published vs draft projects. */
@Serializable
data class PublishRow(@SerialName("is_published") val isPublished: Boolean = false)

data class ProjectFormState(
    val title: String = "",
    val shortDescription: String = "",
    val creatorsNames: String = "",
    val schoolOrganization: String = "",
    val category: String = "",
    val additionalDetails: String = "",
    val videoUri: String? = null,
    val videoFileName: String? = null,
    val thumbnailUri: String? = null
)
