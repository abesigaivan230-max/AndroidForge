# VeoTag

Kotlin + Jetpack Compose + Supabase. QR-code project showcase with an admin area. Package `com.veotag.app`.

## What changed in this version
- **Icon**: adaptive icon (gradient background, bracket + play foreground, monochrome layer for themed icons), legacy PNG mipmaps, 512px Play Store icon, matching splash mark.
- **Theme**: new light/dark palettes (indigo/violet/orange), shapes, type scale. Edge-to-edge with the Android 12+ splash screen API.
- **Motion**: staggered list entrances, shimmer skeleton loading, spring press on cards and tab icons, fade-through between tabs, directional slides for deeper screens, animated bottom bar.
- **Fixes**: removed dead SearchScreen (bad import), ScanScreen `clip` recursion, `@OptIn` clash, `ImageProxy.image` opt-in, BlendMode.Clear without offscreen layer, deprecated LocalLifecycleOwner, partial selects decoding into full `Project` (crash), unsanitised PostgREST search filter, admin session check before auth init (bounced admins to login after restart), memory-heavy video upload, fake `gradlew`, unneeded storage permission and FileProvider.

## Supabase config
Resolution order for URL/key: Gradle property -> `local.properties` -> environment -> baked default. Put `SUPABASE_URL` / `SUPABASE_ANON_KEY` in `local.properties` (git-ignored). Only ever ship the anon key; protect data with RLS.

## Verification status (honest)
Not built with Gradle: Maven/Google/Gradle hosts were unreachable in the authoring sandbox. Checked only: Kotlin syntax via kotlinc, XML well-formedness, resource references. Expect the first AndroidForge run may surface small compile errors; send me the log.
