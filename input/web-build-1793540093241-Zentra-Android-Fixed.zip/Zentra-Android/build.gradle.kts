// Top-level build file. Versions are pinned here on purpose: this is a known-compatible set
// (AGP 8.7.3 + Gradle 8.10.2 + Kotlin 2.0.21 + KSP 2.0.21-1.0.28 + Compose BOM 2024.12.01).
plugins {
    id("com.android.application") version "8.7.3" apply false
    id("org.jetbrains.kotlin.android") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.compose") version "2.0.21" apply false
    id("org.jetbrains.kotlin.plugin.serialization") version "2.0.21" apply false
    id("com.google.devtools.ksp") version "2.0.21-1.0.28" apply false
}
