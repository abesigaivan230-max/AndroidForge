package com.zentra.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.NotificationsNone
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.navigation.NavHostController
import com.zentra.app.AppViewModel
import com.zentra.app.BuildConfig
import com.zentra.app.data.User
import com.zentra.app.data.errMsg
import com.zentra.app.net.Phase
import com.zentra.app.util.ImageUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

// ------------------------------------------------------------------------------------------ people (new chat)

@Composable
fun PeopleScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val onlineIds by core.onlineIds.collectAsState()
    var q by remember { mutableStateOf("") }
    var users by remember { mutableStateOf<List<User>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var starting by remember { mutableStateOf<Long?>(null) }

    LaunchedEffect(q) {
        delay(250)
        loading = true
        try {
            users = core.searchUsers(q)
            error = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            error = errMsg(e)
        }
        loading = false
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("New message", { nav.popBackStack() })
        ZField(q, { q = it }, "Search people", Modifier.padding(horizontal = 20.dp), leading = Icons.Rounded.Search, imeAction = ImeAction.Search)
        ErrorBanner(error, Modifier.padding(horizontal = 20.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp)) {
            if (loading && users.isEmpty()) items(5) { SkeletonRow() }
            else if (users.isEmpty()) item {
                EmptyState(Icons.Rounded.Search, "No one found", "Only people registered on this Zentra server can be messaged.")
            }
            items(users, key = { it.id }) { u ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(enabled = starting == null) {
                        starting = u.id
                        var convo = 0L
                        vm.run(onDone = { err ->
                            starting = null
                            if (err != null) error = err
                            else nav.navigate("chat/dm/$convo") { popUpTo("people") { inclusive = true } }
                        }) { convo = core.startDm(u.id).id }
                    }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Avatar(u.fullName, u.avatar, 48.dp, onlineIds.contains(u.id))
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(u.fullName, color = Z.c.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text("@${u.username}" + if (onlineIds.contains(u.id)) " · online" else "", color = Z.c.textDim, fontSize = 13.sp)
                    }
                    if (starting == u.id) androidx.compose.material3.CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ notifications

@Composable
fun NotificationsScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val items by core.notifications.collectAsState()
    val pending by core.pending.collectAsState()
    LaunchedEffect(Unit) { core.refreshNotifications(); core.refreshLists() }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("Notifications", { nav.popBackStack() }) {
            if (items.any { !it.read }) IconButton({ vm.run { core.markNotificationsRead() } }) { Icon(Icons.Rounded.DoneAll, "Mark all read", tint = Z.c.accentText) }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (pending.isNotEmpty()) {
                item { SectionHeader("Waiting for your approval") }
                items(pending, key = { "p${it.id}" }) { r ->
                    ZCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("manage/${r.channelId}") }) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Avatar(r.user.fullName, r.user.avatar, 44.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(r.user.fullName, color = Z.c.text, fontWeight = FontWeight.SemiBold)
                                Text("wants to join ${r.channelName}", color = Z.c.textDim, fontSize = 13.sp)
                            }
                            Text("Review", color = Z.c.accentText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
                item { SectionHeader("Earlier") }
            }
            if (items.isEmpty() && pending.isEmpty()) item {
                EmptyState(Icons.Rounded.NotificationsNone, "You're all caught up", "Join requests, approvals and new conversations will appear here.")
            }
            items(items, key = { it.id }) { n ->
                val cid = n.data?.get("channel_id")?.let { (it as? kotlinx.serialization.json.JsonPrimitive)?.content?.toLongOrNull() }
                val conv = n.data?.get("conversation_id")?.let { (it as? kotlinx.serialization.json.JsonPrimitive)?.content?.toLongOrNull() }
                ZCard(
                    Modifier.fillMaxWidth(),
                    onClick = {
                        when {
                            n.type == "join_request" && cid != null -> nav.navigate("manage/$cid")
                            n.type == "request_approved" && cid != null -> nav.openChat("channel", cid)
                            n.type == "new_dm" && conv != null -> nav.openChat("dm", conv)
                        }
                    },
                ) {
                    Row(verticalAlignment = Alignment.Top) {
                        Box(Modifier.padding(top = 6.dp).size(9.dp).clip(CircleShape).background(if (n.read) Color.Transparent else Z.c.accent))
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(n.title, color = Z.c.text, fontWeight = FontWeight.SemiBold)
                            if (n.body.isNotBlank()) Text(n.body, color = Z.c.textDim, fontSize = 14.sp)
                            Text(timeLabel(n.createdAt), color = Z.c.textDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------------------------------ edit profile

@Composable
fun EditProfileScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val me by core.me.collectAsState()
    var name by remember { mutableStateOf(me?.fullName ?: "") }
    var newAvatar by remember { mutableStateOf<String?>(null) }
    var removeAvatar by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b64 = withContext(Dispatchers.Default) { ImageUtil.avatarBase64(ctx, uri) }
            if (b64 == null) core.toasts.tryEmit("Couldn't read that picture.") else {
                newAvatar = b64
                removeAvatar = false
            }
        }
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("Edit profile", { nav.popBackStack() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            Box(Modifier.clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                Avatar(name.ifBlank { me?.fullName ?: "" }, if (removeAvatar) null else newAvatar ?: me?.avatar, 112.dp)
                Box(
                    Modifier.align(Alignment.BottomEnd).size(34.dp).clip(CircleShape).background(Z.c.accent).border(2.dp, Z.c.bg, CircleShape),
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.PhotoCamera, "Change picture", tint = Color.White, modifier = Modifier.size(18.dp)) }
            }
            if (me?.avatar != null || newAvatar != null) {
                Text(
                    "Remove picture", color = Z.c.error, fontSize = 14.sp,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { removeAvatar = true; newAvatar = null }.padding(8.dp),
                )
            }
            Spacer(Modifier.height(4.dp))
            ZField(name, { name = it }, "Full name", leading = Icons.Rounded.Badge, maxLength = 40)
            ZField("@${me?.username ?: ""}", {}, "Username (can't be changed)", leading = Icons.Rounded.Lock, maxLength = 40)
            ErrorBanner(error)
        }
        Box(Modifier.padding(20.dp).navigationBarsPadding()) {
            PrimaryButton("Save", {
                if (name.trim().length !in 2..40) {
                    error = "Enter your name (2 to 40 characters)."
                } else {
                    saving = true
                    error = null
                    vm.run(onDone = { err ->
                        saving = false
                        if (err != null) error = err else {
                            core.toasts.tryEmit("Profile updated")
                            nav.popBackStack()
                        }
                    }) { core.updateProfile(name, newAvatar, removeAvatar) }
                }
            }, loading = saving)
        }
    }
}

// ------------------------------------------------------------------------------------------ settings

@Composable
private fun SwitchRow(title: String, subtitle: String, checked: Boolean, enabled: Boolean = true, onChecked: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Z.c.text, fontWeight = FontWeight.Medium, fontSize = 15.sp)
            Text(subtitle, color = Z.c.textDim, fontSize = 13.sp)
        }
        Switch(checked, onChecked, enabled = enabled, colors = SwitchDefaults.colors(checkedTrackColor = Z.c.accent))
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val ctx = LocalContext.current
    val s by core.settings.collectAsState()
    val conn by core.conn.state.collectAsState()
    val health by core.health.collectAsState()
    var notifOk by remember {
        mutableStateOf(Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)
    }
    var pendingStay by remember { mutableStateOf(false) }
    var showPassword by remember { mutableStateOf(false) }
    var confirmLogout by remember { mutableStateOf(false) }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        notifOk = ok
        if (pendingStay) {
            pendingStay = false
            // "Stay connected" works without the permission too, but then Android hides its notification.
            vm.run { core.setStayConnected(true) }
        }
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("Settings", { nav.popBackStack() })
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            SectionHeader("Appearance")
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Z.c.surface).border(1.dp, Z.c.border, RoundedCornerShape(14.dp)).padding(4.dp)) {
                for ((label, key) in listOf("System" to "system", "Dark" to "dark", "Light" to "light")) {
                    val sel = s.theme == key
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(11.dp)).background(if (sel) Z.c.accent else Z.c.surface)
                            .clickable { vm.run { core.store.setTheme(key) } },
                        contentAlignment = Alignment.Center,
                    ) { Text(label, color = if (sel) Color.White else Z.c.textDim, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
                }
            }

            SectionHeader("Notifications")
            ZCard(Modifier.fillMaxWidth()) {
                if (!notifOk) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Notifications are turned off for Zentra in Android.", color = Z.c.warning, fontSize = 13.sp, modifier = Modifier.weight(1f))
                        TextButton({ if (Build.VERSION.SDK_INT >= 33) permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }) { Text("Allow", color = Z.c.accentText) }
                    }
                }
                SwitchRow("Channel messages", "New messages in your channels", s.notifMessages) { v -> vm.run { core.store.setNotifMessages(v) } }
                SwitchRow("Direct messages", "Private messages and new conversations", s.notifDms) { v -> vm.run { core.store.setNotifDms(v) } }
                SwitchRow("Requests and membership", "Join requests, approvals and removals", s.notifRequests) { v -> vm.run { core.store.setNotifRequests(v) } }
                SwitchRow("Connection problems", "Only while Stay connected is on", s.notifConnection) { v -> vm.run { core.store.setNotifConnection(v) } }
            }
            ZCard(Modifier.fillMaxWidth()) {
                SwitchRow(
                    "Stay connected",
                    "Keeps Zentra connected in the background so alerts arrive when the app is closed. Shows a permanent notification and uses more battery. Off by default.",
                    s.stayConnected,
                ) { v ->
                    if (v && !notifOk && Build.VERSION.SDK_INT >= 33) {
                        pendingStay = true
                        permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else vm.run { core.setStayConnected(v) }
                }
                Text(
                    "Without it, Zentra stays connected while the app is open and for about a minute after you leave. Android may pause it after that, so alerts can be delayed until you open it again.",
                    color = Z.c.textDim, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp),
                )
            }

            SectionHeader("Server connection")
            ZCard(Modifier.fillMaxWidth()) {
                InfoRow("Address", s.address?.display ?: "Not set")
                InfoRow("Status", when (conn.phase) {
                    Phase.Connected -> "Connected"
                    Phase.Interrupted -> "Interrupted"
                    Phase.Unavailable -> "Unavailable"
                    Phase.Idle -> "Offline"
                    else -> "Connecting"
                })
                InfoRow("Server version", health?.version?.ifEmpty { "—" } ?: "—", last = true)
            }
            SecondaryButton("Reconnect", { core.conn.kick(); core.updateWanted(); core.toasts.tryEmit("Reconnecting…") })
            SecondaryButton("Change server", { nav.navigate("connect/change") })

            SectionHeader("Privacy and security")
            ZCard(Modifier.fillMaxWidth()) {
                Text(
                    "Your account, channels and messages are stored only on your neighbourhood's Zentra server, never in the cloud. " +
                        "Messages are not end-to-end encrypted, and traffic on the local Wi-Fi is not encrypted in this version, " +
                        "so the person who runs the server, or someone who can capture traffic on the Wi-Fi, could read them. " +
                        "Do not share passwords or sensitive details over Zentra.",
                    color = Z.c.textDim, fontSize = 13.sp, lineHeight = 19.sp,
                )
            }
            SecondaryButton("Change password", { showPassword = true }, icon = Icons.Rounded.VpnKey)

            SectionHeader("About Zentra")
            ZCard(Modifier.fillMaxWidth()) {
                InfoRow("Version", BuildConfig.VERSION_NAME)
                InfoRow("Tagline", "Your Neighbourhood. Connected.", last = true)
            }
            SecondaryButton("Log out", { confirmLogout = true }, danger = true)
            Spacer(Modifier.height(24.dp))
        }
    }

    if (showPassword) PasswordDialog(vm) { showPassword = false }
    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            containerColor = Z.c.surface,
            title = { Text("Log out?", color = Z.c.text) },
            text = { Text("Saved messages on this phone will be removed.", color = Z.c.textDim) },
            confirmButton = { TextButton({ confirmLogout = false; vm.run { core.logout() } }) { Text("Log out", color = Z.c.error) } },
            dismissButton = { TextButton({ confirmLogout = false }) { Text("Cancel", color = Z.c.textDim) } },
        )
    }
}

@Composable
private fun PasswordDialog(vm: AppViewModel, onClose: () -> Unit) {
    var cur by remember { mutableStateOf("") }
    var new by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(false) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = Z.c.surface,
        title = { Text("Change password", color = Z.c.text) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ZField(cur, { cur = it }, "Current password", password = true)
                ZField(new, { new = it }, "New password", password = true, hint = "8+ characters with a letter and a number", imeAction = ImeAction.Done)
                ErrorBanner(error)
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val problem = passwordProblem(new)
                if (problem != null) error = problem else {
                    loading = true
                    vm.run(onDone = { err ->
                        loading = false
                        if (err != null) error = err else {
                            vm.core.toasts.tryEmit("Password changed. Other devices were signed out.")
                            onClose()
                        }
                    }) { vm.core.changePassword(cur, new) }
                }
            }, enabled = !loading && cur.isNotEmpty()) { Text(if (loading) "Saving…" else "Save", color = Z.c.accentText) }
        },
        dismissButton = { TextButton(onClose) { Text("Cancel", color = Z.c.textDim) } },
    )
}
