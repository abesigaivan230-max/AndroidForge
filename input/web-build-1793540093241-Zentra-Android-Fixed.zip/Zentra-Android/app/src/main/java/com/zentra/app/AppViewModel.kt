package com.zentra.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.zentra.app.data.Core
import com.zentra.app.data.errMsg
import kotlinx.coroutines.launch

/** The UI talks to the app only through this ViewModel; [core] is the shared repository layer. */
class AppViewModel(app: Application) : AndroidViewModel(app) {
    val core: Core = (app as ZentraApp).core

    /** Runs [block] and reports a user-readable error message (or null on success). */
    fun run(onDone: (String?) -> Unit = {}, block: suspend () -> Unit) {
        viewModelScope.launch {
            val err = try {
                block()
                null
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (e: Exception) {
                errMsg(e)
            }
            onDone(err)
        }
    }
}
