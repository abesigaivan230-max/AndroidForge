package com.zentra.app

import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import kotlinx.coroutines.launch

/**
 * Optional "Stay connected" mode. It only exists so Android does not freeze the app while the user wants
 * notifications in the background. It is started only from the Settings switch and shows a permanent notification.
 */
class ConnectionService : Service() {
    companion object {
        const val ACTION_STOP = "com.zentra.app.STOP"
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val core = (application as ZentraApp).core
        if (intent?.action == ACTION_STOP) {
            core.scope.launch { core.setStayConnected(false) }
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val n = core.notifier.serviceNotification()
            if (Build.VERSION.SDK_INT >= 34) {
                startForeground(Notifier.SERVICE_NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
            } else {
                startForeground(Notifier.SERVICE_NOTIFICATION_ID, n)
            }
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        core.updateWanted()
        return START_STICKY
    }
}
