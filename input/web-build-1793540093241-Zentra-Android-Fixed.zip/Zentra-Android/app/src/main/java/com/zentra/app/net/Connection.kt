package com.zentra.app.net

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import com.zentra.app.data.Api
import com.zentra.app.data.ServerAddress
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import java.net.Inet4Address
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.coroutines.resume
import kotlin.random.Random

enum class Phase { Idle, Searching, Found, Connecting, Connected, Interrupted, Unavailable }

/** What the user sees on the connection screen and in the status chips. Only [Phase.Connected] means the server answered. */
data class ConnState(
    val phase: Phase = Phase.Idle,
    val address: ServerAddress? = null,
    val message: String = "",
)

/**
 * Owns the authenticated WebSocket. It reconnects with exponential backoff + jitter, and reports
 * "Connected" only after the server has sent its `hello` frame.
 */
class ConnectionManager(
    private val api: Api,
    private val scope: CoroutineScope,
) {
    val state = MutableStateFlow(ConnState())

    /** All callbacks are invoked from OkHttp threads; the receiver must hop to its own dispatcher. */
    @Volatile var onEvent: (JsonObject) -> Unit = {}
    @Volatile var onReady: () -> Unit = {}
    @Volatile var onAuthExpired: () -> Unit = {}

    private val wsClient: OkHttpClient = api.http.newBuilder()
        .pingInterval(25, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile private var socket: WebSocket? = null
    @Volatile private var open = false
    private var job: Job? = null
    private val wake = Channel<Unit>(Channel.CONFLATED)

    fun set(s: ConnState) {
        state.value = s
    }

    val isOpen: Boolean get() = open

    fun send(frame: String): Boolean = open && (socket?.send(frame) == true)

    /** Wi-Fi came back or the user pressed Retry: skip the backoff wait. */
    fun kick() {
        wake.trySend(Unit)
    }

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { loop() }
    }

    fun stop() {
        job?.cancel()
        job = null
        socket?.cancel()
        socket = null
        open = false
        val s = state.value
        if (s.phase == Phase.Connected || s.phase == Phase.Interrupted || s.phase == Phase.Connecting) {
            state.value = s.copy(phase = Phase.Idle, message = "Offline")
        }
    }

    private suspend fun loop() {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            val addr = api.address
            val token = api.token
            if (addr == null || token == null) return

            if (state.value.phase != Phase.Interrupted && state.value.phase != Phase.Unavailable) {
                state.value = ConnState(Phase.Connecting, addr, "Connecting…")
            }
            val outcome = CompletableDeferred<Int>()
            val hello = AtomicBoolean(false)
            val req = Request.Builder().url(addr.wsUrl).header("Authorization", "Bearer $token").build()
            val ws = wsClient.newWebSocket(req, object : WebSocketListener() {
                override fun onMessage(webSocket: WebSocket, text: String) {
                    val obj = try {
                        api.json.parseToJsonElement(text).jsonObject
                    } catch (e: Exception) {
                        return
                    }
                    if (obj["type"]?.jsonPrimitive?.contentOrNull == "hello") {
                        hello.set(true)
                        open = true
                        state.value = ConnState(Phase.Connected, addr, "Connected")
                        onReady()
                    }
                    onEvent(obj)
                }

                override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                    webSocket.close(1000, null)
                    outcome.complete(code)
                }

                override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                    outcome.complete(code)
                }

                override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                    outcome.complete(response?.code ?: -1)
                }
            })
            socket = ws
            val code = try {
                outcome.await()
            } finally {
                open = false
                ws.cancel()
                if (socket === ws) socket = null
            }

            if (code == 4401 || code == 401) {
                onAuthExpired()
                return
            }
            attempt = if (hello.get()) 1 else attempt + 1
            val up = attempt < 3 || serverAnswers(addr)
            state.value = if (up) {
                ConnState(Phase.Interrupted, addr, "Connection interrupted. Reconnecting…")
            } else {
                ConnState(Phase.Unavailable, addr, "The Zentra server is not answering. It may be off or restarting.")
            }
            val backoff = minOf(30_000L, 1_000L shl minOf(attempt - 1, 5)) + Random.nextLong(0, 600)
            withTimeoutOrNull(backoff) { wake.receive() }
        }
    }

    private suspend fun serverAnswers(addr: ServerAddress): Boolean =
        try {
            api.raw("GET", "/api/health", auth = false, address = addr, timeoutMs = 3000)
            true
        } catch (e: Exception) {
            false
        }
}

/**
 * Many Wi-Fi networks for a neighbourhood have no internet. Android would then quietly send our traffic
 * over mobile data, where 192.168.x.x does not exist. Asking for the Wi-Fi network and binding the process
 * to it keeps Zentra on the local Wi-Fi.
 */
class WifiBinder(ctx: Context, private val onWifiAvailable: () -> Unit) {
    private val cm = ctx.applicationContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    val wifiUp = MutableStateFlow(false)
    private var started = false

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) {
            wifiUp.value = true
            try {
                cm.bindProcessToNetwork(network)
            } catch (_: Exception) {
            }
            onWifiAvailable()
        }

        override fun onLost(network: Network) {
            wifiUp.value = false
            try {
                cm.bindProcessToNetwork(null)
            } catch (_: Exception) {
            }
        }
    }

    fun start() {
        if (started) return
        started = true
        // Match ordinary Wi-Fi networks whether or not they also have internet access.
        // Removing NET_CAPABILITY_INTERNET here would exclude most home, school and public
        // Wi-Fi networks, making local-only Zentra connections fail on otherwise valid Wi-Fi.
        val req = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()
        try {
            cm.requestNetwork(req, callback)
        } catch (e: Exception) {
            try {
                cm.registerNetworkCallback(req, callback)
            } catch (_: Exception) {
                started = false
            }
        }
    }
}

/** Finds a Zentra server advertised as `_zentra._tcp` on the local network (mDNS / Bonjour). */
class Discovery(ctx: Context) {
    private val appCtx = ctx.applicationContext
    private val nsd = appCtx.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val wifi = appCtx.getSystemService(Context.WIFI_SERVICE) as WifiManager

    suspend fun findFirst(timeoutMs: Long = 8000): ServerAddress? = withTimeoutOrNull(timeoutMs) {
        suspendCancellableCoroutine<ServerAddress?> { cont ->
            val lock = wifi.createMulticastLock("zentra-discovery").apply {
                setReferenceCounted(false)
                try {
                    acquire()
                } catch (_: Exception) {
                }
            }
            val resolving = AtomicBoolean(false)
            var listener: NsdManager.DiscoveryListener? = null

            fun cleanup() {
                try {
                    listener?.let { nsd.stopServiceDiscovery(it) }
                } catch (_: Exception) {
                }
                try {
                    if (lock.isHeld) lock.release()
                } catch (_: Exception) {
                }
            }

            @Suppress("DEPRECATION")
            fun tryResolve(info: NsdServiceInfo) {
                if (!resolving.compareAndSet(false, true)) return
                nsd.resolveService(info, object : NsdManager.ResolveListener {
                    override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                        resolving.set(false)
                    }

                    override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                        @Suppress("DEPRECATION")
                        val host = serviceInfo.host
                        if (host is Inet4Address && serviceInfo.port > 0 && cont.isActive) {
                            cleanup()
                            cont.resume(ServerAddress(host.hostAddress ?: return, serviceInfo.port))
                        } else {
                            resolving.set(false)
                        }
                    }
                })
            }

            listener = object : NsdManager.DiscoveryListener {
                override fun onDiscoveryStarted(serviceType: String) {}
                override fun onServiceFound(serviceInfo: NsdServiceInfo) {
                    if (serviceInfo.serviceType.contains("_zentra")) tryResolve(serviceInfo)
                }

                override fun onServiceLost(serviceInfo: NsdServiceInfo) {}
                override fun onDiscoveryStopped(serviceType: String) {}
                override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                    cleanup()
                    if (cont.isActive) cont.resume(null)
                }

                override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
            }
            cont.invokeOnCancellation { cleanup() }
            try {
                nsd.discoverServices("_zentra._tcp", NsdManager.PROTOCOL_DNS_SD, listener)
            } catch (e: Exception) {
                cleanup()
                if (cont.isActive) cont.resume(null)
            }
        }
    }
}
