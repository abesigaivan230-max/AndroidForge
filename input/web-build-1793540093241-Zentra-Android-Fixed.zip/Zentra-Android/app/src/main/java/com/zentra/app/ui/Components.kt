package com.zentra.app.ui

import android.graphics.BitmapFactory
import android.text.format.DateUtils
import android.util.Base64
import android.util.LruCache
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Build
import androidx.compose.material.icons.rounded.Event
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Phone
import androidx.compose.material.icons.rounded.Place
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material.icons.rounded.Storefront
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.VisibilityOff
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathMeasure
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zentra.app.data.Channel
import com.zentra.app.net.ConnState
import com.zentra.app.net.Phase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// ---------------------------------------------------------------------------------------------- helpers

fun iconFor(key: String): ImageVector = when (key) {
    "home" -> Icons.Rounded.Home
    "shield" -> Icons.Rounded.Shield
    "store" -> Icons.Rounded.Storefront
    "build" -> Icons.Rounded.Build
    "event" -> Icons.Rounded.Event
    "heart" -> Icons.Rounded.Favorite
    "alert" -> Icons.Rounded.Warning
    "phone" -> Icons.Rounded.Phone
    "place" -> Icons.Rounded.Place
    "person" -> Icons.Rounded.Groups
    "star" -> Icons.Rounded.Star
    else -> Icons.Rounded.Forum
}

fun initials(name: String): String =
    name.trim().split(" ").filter { it.isNotEmpty() }.take(2).joinToString("") { it.first().uppercase() }.ifEmpty { "?" }

/** "14:05" today, "Yesterday", otherwise "12 Oct". */
fun timeLabel(ms: Long): String {
    if (ms <= 0) return ""
    return when {
        DateUtils.isToday(ms) -> SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))
        DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
        else -> SimpleDateFormat("d MMM", Locale.getDefault()).format(Date(ms))
    }
}

fun clockLabel(ms: Long): String = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(ms))

fun dayLabel(ms: Long): String = when {
    DateUtils.isToday(ms) -> "Today"
    DateUtils.isToday(ms + DateUtils.DAY_IN_MILLIS) -> "Yesterday"
    else -> SimpleDateFormat("EEE, d MMM yyyy", Locale.getDefault()).format(Date(ms))
}

fun sameDay(a: Long, b: Long): Boolean {
    val f = SimpleDateFormat("yyyyDDD", Locale.US)
    return f.format(Date(a)) == f.format(Date(b))
}

fun Channel.stateLabel(): String = when (myStatus) {
    "member" -> if (myRole == "owner") "Owner" else "Joined"
    "pending" -> "Pending"
    else -> if (isPrivate) "Request" else "Join"
}

// ---------------------------------------------------------------------------------------------- buttons & fields

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
    icon: ImageVector? = null,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "press")
    val shape = RoundedCornerShape(16.dp)
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .scale(scale)
            .clip(shape)
            .background(if (enabled) AccentGradient else SolidColor(Z.c.border))
            .clickable(interactionSource = src, indication = null, enabled = enabled && !loading, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        if (loading) {
            CircularProgressIndicator(Modifier.size(22.dp), color = Color.White, strokeWidth = 2.5.dp)
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(20.dp))
                Text(text, color = if (enabled) Color.White else Z.c.textDim, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            }
        }
    }
}

@Composable
fun SecondaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    danger: Boolean = false,
    enabled: Boolean = true,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "press2")
    val shape = RoundedCornerShape(16.dp)
    val tint = if (danger) Z.c.error else Z.c.text
    Box(
        modifier
            .fillMaxWidth()
            .height(52.dp)
            .scale(scale)
            .clip(shape)
            .background(Z.c.surface)
            .border(1.dp, if (danger) Z.c.error.copy(alpha = 0.5f) else Z.c.border, shape)
            .clickable(interactionSource = src, indication = null, enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (icon != null) Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
            Text(text, color = if (enabled) tint else Z.c.textDim, fontWeight = FontWeight.Medium, fontSize = 15.sp)
        }
    }
}

@Composable
fun ZField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    singleLine: Boolean = true,
    password: Boolean = false,
    keyboardType: KeyboardType = KeyboardType.Text,
    imeAction: ImeAction = ImeAction.Next,
    leading: ImageVector? = null,
    error: String? = null,
    hint: String? = null,
    maxLength: Int? = null,
    minLines: Int = 1,
    onDone: (() -> Unit)? = null,
) {
    var visible by remember { mutableStateOf(false) }
    val c = Z.c
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onValueChange(if (maxLength != null) v.take(maxLength) else v) },
        modifier = modifier.fillMaxWidth(),
        label = { Text(label) },
        singleLine = singleLine,
        minLines = minLines,
        isError = error != null,
        supportingText = {
            val t = error ?: hint
            if (t != null) Text(t, color = if (error != null) c.error else c.textDim)
        },
        leadingIcon = if (leading != null) ({ Icon(leading, null) }) else null,
        trailingIcon = if (password) ({
            IconButton(onClick = { visible = !visible }) {
                Icon(if (visible) Icons.Rounded.VisibilityOff else Icons.Rounded.Visibility, if (visible) "Hide password" else "Show password")
            }
        }) else null,
        visualTransformation = if (password && !visible) PasswordVisualTransformation() else VisualTransformation.None,
        keyboardOptions = KeyboardOptions(keyboardType = if (password) KeyboardType.Password else keyboardType, imeAction = imeAction),
        keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }, onSend = { onDone?.invoke() }, onGo = { onDone?.invoke() }),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = c.text, unfocusedTextColor = c.text,
            focusedContainerColor = c.surface, unfocusedContainerColor = c.surface,
            focusedBorderColor = c.accent, unfocusedBorderColor = c.border, errorBorderColor = c.error,
            focusedLabelColor = c.accentText, unfocusedLabelColor = c.textDim,
            cursorColor = c.accent, focusedLeadingIconColor = c.accentText, unfocusedLeadingIconColor = c.textDim,
            focusedTrailingIconColor = c.textDim, unfocusedTrailingIconColor = c.textDim,
            errorContainerColor = c.surface,
        ),
    )
}

// ---------------------------------------------------------------------------------------------- cards & layout

@Composable
fun ZCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    padding: Dp = 16.dp,
    content: @Composable ColumnScope.() -> Unit,
) {
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed && onClick != null) 0.98f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "card")
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .scale(scale)
            .clip(shape)
            .background(Z.c.surface)
            .border(1.dp, Z.c.border, shape)
            .then(if (onClick != null) Modifier.clickable(interactionSource = src, indication = null, onClick = onClick) else Modifier)
            .padding(padding),
        content = content,
    )
}

@Composable
fun ScreenTitleBar(title: String, onBack: (() -> Unit)?, actions: @Composable () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().statusBarsPadding().height(60.dp).padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Z.c.text) }
        } else Spacer(Modifier.width(12.dp))
        Text(
            title, color = Z.c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f),
        )
        actions()
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier, action: String? = null, onAction: (() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Z.c.text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (action != null && onAction != null) {
            Text(
                action, color = Z.c.accentText, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(horizontal = 8.dp, vertical = 4.dp),
            )
        }
    }
}

@Composable
fun EmptyState(icon: ImageVector, title: String, text: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Box(Modifier.size(64.dp).clip(CircleShape).background(Z.c.surfaceHi), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Z.c.accentText, modifier = Modifier.size(30.dp))
        }
        Spacer(Modifier.height(4.dp))
        Text(title, color = Z.c.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp)
        Text(text, color = Z.c.textDim, fontSize = 14.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(8.dp))
            action()
        }
    }
}

@Composable
fun ErrorBanner(message: String?, modifier: Modifier = Modifier) {
    AnimatedVisibility(
        visible = message != null,
        enter = fadeIn(tween(200)) + expandVertically(),
        exit = fadeOut(tween(150)) + shrinkVertically(),
        modifier = modifier,
    ) {
        var last by remember { mutableStateOf("") }
        if (message != null) last = message
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                .background(Z.c.error.copy(alpha = 0.12f))
                .border(1.dp, Z.c.error.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Icon(Icons.Rounded.Warning, null, tint = Z.c.error, modifier = Modifier.size(20.dp))
            Text(last, color = Z.c.text, fontSize = 14.sp)
        }
    }
}

// ---------------------------------------------------------------------------------------------- avatar

private val avatarCache = LruCache<String, androidx.compose.ui.graphics.ImageBitmap>(48)

@Composable
fun Avatar(name: String, avatar: String?, size: Dp = 44.dp, online: Boolean? = null, modifier: Modifier = Modifier) {
    val key = avatar?.let { "${it.length}:${it.hashCode()}" }
    val bmp by produceState(initialValue = key?.let { avatarCache.get(it) }, key) {
        value = if (avatar == null || key == null) null else avatarCache.get(key) ?: withContext(Dispatchers.Default) {
            try {
                val bytes = Base64.decode(avatar, Base64.DEFAULT)
                BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.asImageBitmap()?.also { avatarCache.put(key, it) }
            } catch (e: Exception) {
                null
            }
        }
    }
    Box(modifier.size(size)) {
        val b = bmp
        if (b != null) {
            Image(b, name, Modifier.size(size).clip(CircleShape), contentScale = ContentScale.Crop)
        } else {
            Box(
                Modifier.size(size).clip(CircleShape).background(Brush.linearGradient(listOf(Color(0xFF0A8CFF), Color(0xFF4B7DFD)))),
                contentAlignment = Alignment.Center,
            ) {
                Text(initials(name), color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = (size.value * 0.36f).sp)
            }
        }
        if (online == true) {
            Box(
                Modifier.align(Alignment.BottomEnd).offset(1.dp, 1.dp).size((size.value * 0.3f).dp.coerceAtLeast(9.dp))
                    .clip(CircleShape).background(Z.c.success).border(2.dp, Z.c.bg, CircleShape)
            )
        }
    }
}

// ---------------------------------------------------------------------------------------------- connection chip & animation

@Composable
fun ConnChip(state: ConnState, onlineCount: Int, modifier: Modifier = Modifier) {
    val c = Z.c
    val (color, label) = when (state.phase) {
        Phase.Connected -> c.success to (if (onlineCount > 0) "Online · $onlineCount here" else "Online")
        Phase.Searching, Phase.Found, Phase.Connecting -> c.warning to "Connecting…"
        Phase.Interrupted -> c.warning to "Reconnecting…"
        Phase.Unavailable -> c.error to "Server unavailable"
        Phase.Idle -> c.textDim to "Offline"
    }
    val animating = state.phase == Phase.Searching || state.phase == Phase.Connecting || state.phase == Phase.Interrupted || state.phase == Phase.Found
    val t = rememberInfiniteTransition(label = "chip")
    val a by t.animateFloat(1f, 0.35f, infiniteRepeatable(tween(800, easing = LinearEasing), RepeatMode.Reverse), label = "chipA")
    val animColor by animateColorAsState(color, tween(300), label = "chipC")
    Row(
        modifier.clip(RoundedCornerShape(50)).background(animColor.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp),
    ) {
        Box(Modifier.size(8.dp).alpha(if (animating) a else 1f).clip(CircleShape).background(animColor))
        Text(label, color = animColor, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

/** Expanding rings: the "wireless" feel of the logo, used while searching or connecting. */
@Composable
fun RadarPulse(modifier: Modifier = Modifier, color: Color = Z.c.signal, rings: Int = 3) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "radarP")
    Canvas(modifier) {
        val maxR = size.minDimension / 2f
        for (i in 0 until rings) {
            val q = (p + i / rings.toFloat()) % 1f
            drawCircle(color.copy(alpha = (1f - q) * 0.45f), radius = maxR * (0.25f + 0.75f * q), style = Stroke(width = 2.dp.toPx()))
        }
    }
}

@Composable
fun SuccessCheck(modifier: Modifier = Modifier, color: Color = Z.c.success, strokeWidth: Dp = 4.dp) {
    val p = remember { Animatable(0f) }
    LaunchedEffect(Unit) { p.animateTo(1f, tween(700)) }
    Canvas(modifier) {
        val sw = strokeWidth.toPx()
        val inset = sw
        val arcSize = Size(size.width - inset * 2, size.height - inset * 2)
        drawArc(
            color, -90f, 360f * minOf(1f, p.value * 1.6f), false, Offset(inset, inset), arcSize,
            style = Stroke(sw, cap = StrokeCap.Round),
        )
        val cp = ((p.value - 0.55f) / 0.45f).coerceIn(0f, 1f)
        if (cp > 0f) {
            val path = Path().apply {
                moveTo(size.width * 0.28f, size.height * 0.52f)
                lineTo(size.width * 0.44f, size.height * 0.68f)
                lineTo(size.width * 0.74f, size.height * 0.36f)
            }
            val pm = PathMeasure()
            pm.setPath(path, false)
            val seg = Path()
            pm.getSegment(0f, pm.length * cp, seg, true)
            drawPath(seg, color, style = Stroke(sw, cap = StrokeCap.Round))
        }
    }
}

/** Quick horizontal shake, replayed whenever [trigger] changes (used for errors). */
fun Modifier.shake(trigger: Int): Modifier = composed {
    val off = remember { Animatable(0f) }
    LaunchedEffect(trigger) {
        if (trigger > 0) {
            for (x in listOf(-14f, 12f, -9f, 6f, -3f, 0f)) off.animateTo(x, tween(55))
        }
    }
    this.offset { IntOffset(off.value.roundToInt(), 0) }
}

fun Modifier.shimmer(): Modifier = composed {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-300f, 1000f, infiniteRepeatable(tween(1100, easing = LinearEasing)), label = "shimmerX")
    val c = Z.c
    this.background(
        Brush.linearGradient(
            listOf(c.surface, c.surfaceHi, c.surface),
            start = Offset(x, 0f), end = Offset(x + 300f, 0f),
        )
    )
}

@Composable
fun SkeletonRow(modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).shimmer())
        Spacer(Modifier.width(12.dp))
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(Modifier.width(150.dp).height(14.dp).clip(RoundedCornerShape(6.dp)).shimmer())
            Box(Modifier.width(220.dp).height(12.dp).clip(RoundedCornerShape(6.dp)).shimmer())
        }
    }
}

@Composable
fun Badge(count: Int, modifier: Modifier = Modifier) {
    if (count <= 0) return
    Box(
        modifier.clip(CircleShape).background(Z.c.accent).padding(horizontal = 6.dp, vertical = 1.dp).defaultMinSize(minWidth = 18.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(if (count > 99) "99+" else count.toString(), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun LockTag() {
    Row(
        Modifier.clip(RoundedCornerShape(50)).background(Z.c.surfaceHi).padding(horizontal = 8.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Icon(Icons.Rounded.Lock, null, tint = Z.c.textDim, modifier = Modifier.size(12.dp))
        Text("Private", color = Z.c.textDim, fontSize = 11.sp)
    }
}

@Composable
fun ChannelIcon(icon: String, size: Dp = 48.dp) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size / 3)).background(Z.c.accent.copy(alpha = 0.14f)),
        contentAlignment = Alignment.Center,
    ) {
        Icon(iconFor(icon), null, tint = Z.c.accentText, modifier = Modifier.size(size * 0.5f))
    }
}
