package com.zentra.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.zentra.app.AppViewModel
import com.zentra.app.data.Settings
import kotlinx.coroutines.delay

@Composable
fun ZentraRoot(vm: AppViewModel) {
    val core = vm.core
    val settings by core.settings.collectAsState()
    ZentraTheme(settings.theme) {
        Box(Modifier.fillMaxSize().background(Z.c.bg)) {
            if (settings.loaded) AppNav(vm, settings)
            ToastHost(vm)
        }
    }
}

@Composable
private fun ToastHost(vm: AppViewModel) {
    var text by remember { mutableStateOf<String?>(null) }
    var last by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        vm.core.toasts.collect {
            last = it
            text = it
            delay(3500)
            text = null
        }
    }
    Box(Modifier.fillMaxSize().statusBarsPadding().padding(top = 8.dp, start = 16.dp, end = 16.dp), contentAlignment = Alignment.TopCenter) {
        AnimatedVisibility(
            visible = text != null,
            enter = slideInVertically(tween(250)) { -it } + fadeIn(tween(250)),
            exit = slideOutVertically(tween(200)) { -it } + fadeOut(tween(200)),
        ) {
            Text(
                last, color = Z.c.text, fontSize = 14.sp,
                modifier = Modifier.clip(RoundedCornerShape(14.dp)).background(Z.c.surfaceHi)
                    .border(1.dp, Z.c.border, RoundedCornerShape(14.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
            )
        }
    }
}

@Composable
private fun AppNav(vm: AppViewModel, settings: Settings) {
    val core = vm.core
    val nav = rememberNavController()
    val entry by nav.currentBackStackEntryAsState()
    val currentRoute = entry?.destination?.route

    fun go(route: String) { nav.navigate(route) { launchSingleTop = true } }
    fun back() { nav.popBackStack() }

    // Signing out (or an expired session) always lands on the connection screen.
    var wasLoggedIn by remember { mutableStateOf(settings.loggedIn) }
    LaunchedEffect(settings.loggedIn) {
        if (wasLoggedIn && !settings.loggedIn) {
            nav.navigate("connect/setup") { popUpTo(nav.graph.id) { inclusive = true } }
        }
        wasLoggedIn = settings.loggedIn
    }

    // A tapped notification asks us to open a particular screen.
    val pending by core.pendingRoute.collectAsState()
    LaunchedEffect(pending, currentRoute, settings.loggedIn) {
        val r = pending
        if (r != null && settings.loggedIn && currentRoute != null && currentRoute != "splash" && currentRoute != "onboarding") {
            core.pendingRoute.value = null
            if (currentRoute != "main") nav.navigate("main") { popUpTo("main") { inclusive = false } }
            go(r)
        }
    }

    NavHost(
        navController = nav,
        startDestination = "splash",
        enterTransition = { fadeIn(tween(260)) + slideInHorizontally(tween(260)) { it / 12 } },
        exitTransition = { fadeOut(tween(160)) },
        popEnterTransition = { fadeIn(tween(220)) },
        popExitTransition = { fadeOut(tween(160)) + slideOutHorizontally(tween(220)) { it / 12 } },
    ) {
        composable("splash") {
            SplashScreen(returning = settings.onboarded) {
                val next = when {
                    !settings.onboarded -> "onboarding"
                    !settings.loggedIn -> "connect/setup"
                    else -> "main"
                }
                nav.navigate(next) { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("onboarding") {
            OnboardingScreen {
                vm.run { core.store.setOnboarded() }
                nav.navigate("connect/setup") { popUpTo("onboarding") { inclusive = true } }
            }
        }
        composable("connect/{mode}", arguments = listOf(navArgument("mode") { type = NavType.StringType })) { e ->
            val mode = e.arguments?.getString("mode") ?: "setup"
            ConnectScreen(
                vm, mode,
                onScan = { go("scan") },
                onBack = { back() },
                onDone = {
                    if (mode == "change") back()
                    else nav.navigate(if (core.settings.value.loggedIn) "main" else "auth") {
                        popUpTo("connect/{mode}") { inclusive = true }
                    }
                },
            )
        }
        composable("scan") { ScanScreen(vm, onBack = { back() }) }
        composable("auth") {
            AuthScreen(
                vm,
                onChangeServer = { go("connect/change") },
                onDone = { nav.navigate("main") { popUpTo("auth") { inclusive = true } } },
            )
        }
        composable("main") { MainScreen(vm, nav) }
        composable("channel/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            ChannelDetailScreen(vm, e.arguments?.getLong("id") ?: 0L, nav)
        }
        composable("chat/{target}/{id}", arguments = listOf(
            navArgument("target") { type = NavType.StringType },
            navArgument("id") { type = NavType.LongType },
        )) { e ->
            ChatScreen(vm, e.arguments?.getString("target") ?: "channel", e.arguments?.getLong("id") ?: 0L, nav)
        }
        composable("create") { CreateChannelScreen(vm, nav) }
        composable("manage/{id}", arguments = listOf(navArgument("id") { type = NavType.LongType })) { e ->
            ManageChannelScreen(vm, e.arguments?.getLong("id") ?: 0L, nav)
        }
        composable("notifications") { NotificationsScreen(vm, nav) }
        composable("settings") { SettingsScreen(vm, nav) }
        composable("editprofile") { EditProfileScreen(vm, nav) }
        composable("people") { PeopleScreen(vm, nav) }
    }
}
