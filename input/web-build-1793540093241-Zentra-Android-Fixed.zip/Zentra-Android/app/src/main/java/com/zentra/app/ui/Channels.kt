package com.zentra.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.PersonRemove
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.SwapHoriz
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Tag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.zentra.app.AppViewModel
import com.zentra.app.data.Channel
import com.zentra.app.data.JoinRequest
import com.zentra.app.data.User
import com.zentra.app.data.errMsg
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ------------------------------------------------------------------------------------------ channel detail

@Composable
fun ChannelDetailScreen(vm: AppViewModel, id: Long, nav: NavHostController) {
    val core = vm.core
    val mine by core.myChannels.collectAsState()
    var channel by remember { mutableStateOf<Channel?>(mine.firstOrNull { it.id == id }) }
    var error by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var reload by remember { mutableIntStateOf(0) }
    var confirmLeave by remember { mutableStateOf(false) }

    LaunchedEffect(id, reload) {
        try {
            channel = core.channelDetail(id)
            error = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            error = errMsg(e)
        }
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("Channel", { nav.popBackStack() })
        val ch = channel
        if (ch == null) {
            if (error != null) {
                EmptyState(Icons.Rounded.Forum, "Can't open this channel", error ?: "", Modifier.weight(1f)) {
                    PrimaryButton("Try again", { reload++ })
                }
            } else Column(Modifier.padding(20.dp)) { SkeletonRow(); SkeletonRow() }
        } else {
            Column(
                Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Spacer(Modifier.height(8.dp))
                ChannelIcon(ch.icon, 88.dp)
                Spacer(Modifier.height(14.dp))
                Text(ch.name, color = Z.c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(6.dp))
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (ch.isPrivate) LockTag() else Row(
                        Modifier.clip(RoundedCornerShape(50)).background(Z.c.surfaceHi).padding(horizontal = 8.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp),
                    ) {
                        Icon(Icons.Rounded.Public, null, tint = Z.c.textDim, modifier = Modifier.size(12.dp))
                        Text("Public", color = Z.c.textDim, fontSize = 11.sp)
                    }
                    Text(ch.category, color = Z.c.textDim, fontSize = 13.sp)
                }
                if (ch.description.isNotBlank()) {
                    Spacer(Modifier.height(14.dp))
                    Text(ch.description, color = Z.c.text, fontSize = 15.sp, textAlign = TextAlign.Center, lineHeight = 22.sp)
                }
                Spacer(Modifier.height(20.dp))
                ZCard(Modifier.fillMaxWidth()) {
                    InfoRow("Owner", ch.owner.fullName.ifEmpty { ch.owner.username })
                    InfoRow("Members", ch.memberCount.toString())
                    InfoRow("Online now", ch.onlineCount.toString(), last = true)
                }
                Spacer(Modifier.height(12.dp))
                if (ch.isPrivate && !ch.isMember) {
                    Text(
                        "Messages in private channels are only visible to members. The owner decides who can join.",
                        color = Z.c.textDim, fontSize = 13.sp, textAlign = TextAlign.Center,
                    )
                }
                Spacer(Modifier.height(12.dp))
                ErrorBanner(error)
            }
            Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                fun act(block: suspend () -> Unit) {
                    busy = true
                    error = null
                    vm.run(onDone = { err -> busy = false; error = err; reload++ }) { block() }
                }
                val retryAt = ch.retryAt
                when (ch.myStatus) {
                    "member" -> {
                        PrimaryButton("Open chat", { nav.openChat("channel", ch.id) }, icon = Icons.Rounded.Forum)
                        if (ch.myRole == "owner") SecondaryButton("Manage channel", { nav.navigate("manage/${ch.id}") }, icon = Icons.Rounded.Settings)
                        else SecondaryButton("Leave channel", { confirmLeave = true }, danger = true)
                    }
                    "pending" -> {
                        PrimaryButton("Request sent. Waiting for the owner", {}, enabled = false)
                        SecondaryButton("Cancel request", { act { core.cancelJoin(ch.id) } })
                    }
                    else -> {
                        val wait = retryAt != null && retryAt > System.currentTimeMillis()
                        if (wait) Text(
                            "The owner declined your last request. You can ask again after " +
                                SimpleDateFormat("d MMM, HH:mm", Locale.getDefault()).format(Date(retryAt ?: 0)) + ".",
                            color = Z.c.textDim, fontSize = 13.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                        )
                        PrimaryButton(
                            if (ch.isPrivate) "Request to join" else "Join channel",
                            {
                                act {
                                    val r = core.join(ch.id)
                                    if (r.status == "member") core.toasts.tryEmit("You joined ${ch.name}")
                                    else core.toasts.tryEmit("Request sent to the channel owner")
                                }
                            },
                            enabled = !wait, loading = busy,
                        )
                    }
                }
            }
        }
    }
    if (confirmLeave) {
        AlertDialog(
            onDismissRequest = { confirmLeave = false },
            containerColor = Z.c.surface,
            title = { Text("Leave this channel?", color = Z.c.text) },
            text = { Text("You will stop receiving its messages. ${if (channel?.isPrivate == true) "To come back you will need the owner's approval again." else ""}", color = Z.c.textDim) },
            confirmButton = {
                TextButton({
                    confirmLeave = false
                    vm.run(onDone = { e -> if (e == null) nav.popBackStack() else core.toasts.tryEmit(e) }) { core.leave(id) }
                }) { Text("Leave", color = Z.c.error) }
            },
            dismissButton = { TextButton({ confirmLeave = false }) { Text("Stay", color = Z.c.textDim) } },
        )
    }
}

// ------------------------------------------------------------------------------------------ create channel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun CreateChannelScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val meta by core.meta.collectAsState()
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("General") }
    var icon by remember { mutableStateOf("chat") }
    var priv by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var submitted by remember { mutableStateOf(false) }
    val nameErr = if (submitted && name.trim().length !in 2..40) "Give the channel a name (2 to 40 characters)." else null

    fun create() {
        submitted = true
        if (name.trim().length !in 2..40) return
        loading = true
        error = null
        var created: Channel? = null
        vm.run(onDone = { err ->
            loading = false
            error = err
            created?.let { ch ->
                nav.navigate("chat/channel/${ch.id}") { popUpTo("create") { inclusive = true } }
            }
        }) { created = core.createChannel(name.trim(), desc.trim(), cat, icon, priv) }
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar("New channel", { nav.popBackStack() })
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            ZField(name, { name = it }, "Channel name", leading = Icons.Rounded.Tag, error = nameErr, maxLength = 40)
            ZField(desc, { desc = it }, "Description (optional)", singleLine = false, minLines = 3, maxLength = 300, imeAction = ImeAction.Default)
            Text("Category", color = Z.c.textDim, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                meta.categories.forEach { c ->
                    val sel = cat == c
                    Text(
                        c, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = if (sel) Color.White else Z.c.textDim,
                        modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Z.c.accent else Z.c.surface)
                            .border(1.dp, if (sel) Z.c.accent else Z.c.border, RoundedCornerShape(50))
                            .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 8.dp),
                    )
                }
            }
            Text("Icon", color = Z.c.textDim, fontSize = 13.sp, modifier = Modifier.padding(top = 8.dp))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                meta.icons.forEach { k ->
                    val sel = icon == k
                    val bg by animateColorAsState(if (sel) Z.c.accent else Z.c.surface, tween(200), label = "iconBg")
                    Box(
                        Modifier.size(52.dp).clip(RoundedCornerShape(16.dp)).background(bg)
                            .border(1.dp, if (sel) Z.c.accent else Z.c.border, RoundedCornerShape(16.dp)).clickable { icon = k },
                        contentAlignment = Alignment.Center,
                    ) { Icon(iconFor(k), k, tint = if (sel) Color.White else Z.c.textDim) }
                }
            }
            Spacer(Modifier.height(8.dp))
            ZCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (priv) Icons.Rounded.Lock else Icons.Rounded.Public, null, tint = Z.c.accentText)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (priv) "Private channel" else "Public channel", color = Z.c.text, fontWeight = FontWeight.SemiBold)
                        Text(
                            if (priv) "People must request to join and you approve each one. Only members can read messages."
                            else "Anyone on this server can join instantly. Only members can read messages.",
                            color = Z.c.textDim, fontSize = 13.sp,
                        )
                    }
                    Switch(priv, { priv = it }, colors = SwitchDefaults.colors(checkedTrackColor = Z.c.accent))
                }
            }
            Text("You will be the owner of this channel and can manage its members.", color = Z.c.textDim, fontSize = 13.sp)
            ErrorBanner(error)
            Spacer(Modifier.height(4.dp))
        }
        Box(Modifier.padding(20.dp).navigationBarsPadding()) { PrimaryButton("Create channel", ::create, loading = loading) }
    }
}

// ------------------------------------------------------------------------------------------ owner tools

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ManageChannelScreen(vm: AppViewModel, id: Long, nav: NavHostController) {
    val core = vm.core
    val meta by core.meta.collectAsState()
    val me by core.me.collectAsState()
    val onlineIds by core.onlineIds.collectAsState()
    val pendingAll by core.pending.collectAsState()
    var channel by remember { mutableStateOf<Channel?>(null) }
    var requests by remember { mutableStateOf<List<JoinRequest>>(emptyList()) }
    var members by remember { mutableStateOf<List<User>>(emptyList()) }
    var tab by remember { mutableIntStateOf(0) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }
    var confirmRemove by remember { mutableStateOf<User?>(null) }
    var confirmTransfer by remember { mutableStateOf<User?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }

    // editable copies
    var name by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("General") }
    var icon by remember { mutableStateOf("chat") }
    var priv by remember { mutableStateOf(false) }
    var saving by remember { mutableStateOf(false) }

    LaunchedEffect(id, reload, pendingAll.size) {
        try {
            val ch = core.channelDetail(id)
            if (channel == null) {
                name = ch.name; desc = ch.description; cat = ch.category; icon = ch.icon; priv = ch.isPrivate
            }
            channel = ch
            members = core.members(id)
            requests = if (ch.myRole == "owner") core.requests(id) else emptyList()
            error = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            error = errMsg(e)
        }
    }

    fun act(done: String? = null, block: suspend () -> Unit) {
        error = null
        vm.run(onDone = { err ->
            if (err != null) error = err else if (done != null) core.toasts.tryEmit(done)
            reload++
        }) { block() }
    }

    val isOwner = channel?.myRole == "owner"
    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        ScreenTitleBar(channel?.name ?: "Manage channel", { nav.popBackStack() })
        if (channel != null && !isOwner) {
            EmptyState(Icons.Rounded.Lock, "Owner only", "Only the channel owner can approve members or change settings.", Modifier.weight(1f))
        } else {
            Row(
                Modifier.padding(horizontal = 20.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Z.c.surface)
                    .border(1.dp, Z.c.border, RoundedCornerShape(14.dp)).padding(4.dp),
            ) {
                listOf("Requests (${requests.size})", "Members (${members.size})", "Settings").forEachIndexed { i, l ->
                    val sel = tab == i
                    Box(
                        Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(11.dp)).background(if (sel) Z.c.accent else Z.c.surface).clickable { tab = i },
                        contentAlignment = Alignment.Center,
                    ) { Text(l, color = if (sel) Color.White else Z.c.textDim, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1) }
                }
            }
            ErrorBanner(error, Modifier.padding(20.dp))
            when (tab) {
                0 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (requests.isEmpty()) item {
                        EmptyState(Icons.Rounded.Groups, "No pending requests", "When someone asks to join this channel, you will see them here and get a notification.")
                    }
                    items(requests, key = { it.id }) { r ->
                        ZCard(Modifier.fillMaxWidth()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Avatar(r.user.fullName, r.user.avatar, 46.dp, onlineIds.contains(r.user.id))
                                Spacer(Modifier.width(12.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(r.user.fullName, color = Z.c.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Text("@${r.user.username} · ${timeLabel(r.createdAt)}", color = Z.c.textDim, fontSize = 12.sp)
                                }
                                IconButton({ act("Request declined") { core.resolve(id, r.id, false) } }) { Icon(Icons.Rounded.Close, "Reject", tint = Z.c.error) }
                                IconButton({ act("${r.user.fullName} is now a member") { core.resolve(id, r.id, true) } }) { Icon(Icons.Rounded.Check, "Approve", tint = Z.c.success) }
                            }
                        }
                    }
                }

                1 -> LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(members, key = { it.id }) { m ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Avatar(m.fullName, m.avatar, 44.dp, onlineIds.contains(m.id))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(m.fullName + if (m.id == me?.id) " (you)" else "", color = Z.c.text, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(if (m.role == "owner") "Owner" else "@${m.username}", color = if (m.role == "owner") Z.c.accentText else Z.c.textDim, fontSize = 12.sp)
                            }
                            if (m.id != me?.id) {
                                IconButton({ confirmTransfer = m }) { Icon(Icons.Rounded.SwapHoriz, "Make owner", tint = Z.c.textDim) }
                                IconButton({ confirmRemove = m }) { Icon(Icons.Rounded.PersonRemove, "Remove", tint = Z.c.error) }
                            }
                        }
                    }
                }

                else -> Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).imePadding().padding(horizontal = 20.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    Spacer(Modifier.height(4.dp))
                    ZField(name, { name = it }, "Channel name", maxLength = 40)
                    ZField(desc, { desc = it }, "Description", singleLine = false, minLines = 3, maxLength = 300, imeAction = ImeAction.Default)
                    Text("Category", color = Z.c.textDim, fontSize = 13.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        meta.categories.forEach { c ->
                            val sel = cat == c
                            Text(
                                c, fontSize = 13.sp, color = if (sel) Color.White else Z.c.textDim,
                                modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Z.c.accent else Z.c.surface)
                                    .border(1.dp, if (sel) Z.c.accent else Z.c.border, RoundedCornerShape(50))
                                    .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 8.dp),
                            )
                        }
                    }
                    Text("Icon", color = Z.c.textDim, fontSize = 13.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        meta.icons.forEach { k ->
                            val sel = icon == k
                            Box(
                                Modifier.size(48.dp).clip(RoundedCornerShape(14.dp)).background(if (sel) Z.c.accent else Z.c.surface)
                                    .border(1.dp, if (sel) Z.c.accent else Z.c.border, RoundedCornerShape(14.dp)).clickable { icon = k },
                                contentAlignment = Alignment.Center,
                            ) { Icon(iconFor(k), k, tint = if (sel) Color.White else Z.c.textDim) }
                        }
                    }
                    ZCard(Modifier.fillMaxWidth()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Private channel", color = Z.c.text, fontWeight = FontWeight.SemiBold)
                                Text("New members need your approval. Making a private channel public adds everyone who is waiting.", color = Z.c.textDim, fontSize = 13.sp)
                            }
                            Switch(priv, { priv = it }, colors = SwitchDefaults.colors(checkedTrackColor = Z.c.accent))
                        }
                    }
                    PrimaryButton("Save changes", {
                        saving = true
                        error = null
                        vm.run(onDone = { err -> saving = false; if (err != null) error = err else core.toasts.tryEmit("Channel updated"); reload++ }) {
                            core.updateChannel(id, name.trim(), desc.trim(), cat, icon, priv)
                        }
                    }, loading = saving)
                    SecondaryButton("Delete channel", { confirmDelete = true }, danger = true)
                    Spacer(Modifier.height(24.dp))
                }
            }
        }
    }

    confirmRemove?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmRemove = null },
            containerColor = Z.c.surface,
            title = { Text("Remove ${m.fullName}?", color = Z.c.text) },
            text = { Text("They will lose access to this channel's messages immediately.", color = Z.c.textDim) },
            confirmButton = { TextButton({ confirmRemove = null; act("${m.fullName} removed") { core.removeMember(id, m.id) } }) { Text("Remove", color = Z.c.error) } },
            dismissButton = { TextButton({ confirmRemove = null }) { Text("Cancel", color = Z.c.textDim) } },
        )
    }
    confirmTransfer?.let { m ->
        AlertDialog(
            onDismissRequest = { confirmTransfer = null },
            containerColor = Z.c.surface,
            title = { Text("Make ${m.fullName} the owner?", color = Z.c.text) },
            text = { Text("They will be able to approve members and change settings. You will become an ordinary member and cannot undo this yourself.", color = Z.c.textDim) },
            confirmButton = { TextButton({ confirmTransfer = null; act("Ownership transferred") { core.transfer(id, m.id) } }) { Text("Transfer ownership", color = Z.c.error) } },
            dismissButton = { TextButton({ confirmTransfer = null }) { Text("Cancel", color = Z.c.textDim) } },
        )
    }
    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            containerColor = Z.c.surface,
            title = { Text("Delete this channel?", color = Z.c.text) },
            text = { Text("All of its messages and members are removed for everyone. This cannot be undone.", color = Z.c.textDim) },
            confirmButton = {
                TextButton({
                    confirmDelete = false
                    vm.run(onDone = { err -> if (err == null) nav.popBackStack("main", false) else error = err }) { core.deleteChannel(id) }
                }) { Text("Delete", color = Z.c.error) }
            },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel", color = Z.c.textDim) } },
        )
    }
}
