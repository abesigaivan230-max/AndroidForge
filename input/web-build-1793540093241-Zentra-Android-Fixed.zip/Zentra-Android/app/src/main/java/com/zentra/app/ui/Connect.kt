package com.zentra.app.ui

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.QrCodeScanner
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanner
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.zentra.app.AppViewModel
import com.zentra.app.R
import com.zentra.app.net.Phase
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectScreen(vm: AppViewModel, mode: String, onScan: () -> Unit, onBack: () -> Unit, onDone: () -> Unit) {
    val core = vm.core
    val state by core.conn.state.collectAsState()
    val wifiUp by core.wifi.wifiUp.collectAsState()
    val health by core.health.collectAsState()
    var manual by remember { mutableStateOf(false) }
    var advanced by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) { core.startAutoConnect() }
    LaunchedEffect(state.phase) {
        if (mode == "setup" && state.phase == Phase.Connected && !advanced) {
            delay(1200)
            advanced = true
            onDone()
        }
    }

    val busy = state.phase == Phase.Searching || state.phase == Phase.Found || state.phase == Phase.Connecting || state.phase == Phase.Idle
    Column(Modifier.fillMaxSize().background(Z.c.bg).statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState()).padding(24.dp)) {
        if (mode == "change") {
            ScreenTitleBar("Server connection", onBack)
        } else {
            Spacer(Modifier.height(8.dp))
            Image(painterResource(R.drawable.brand_symbol), null, Modifier.height(72.dp).align(Alignment.CenterHorizontally))
        }
        Spacer(Modifier.height(20.dp))
        Text("Connect to your neighbourhood", color = Z.c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        Text(
            "Zentra talks to a server on your local Wi-Fi. You don't need internet, just the same Wi-Fi as the server.",
            color = Z.c.textDim, fontSize = 15.sp, lineHeight = 22.sp,
        )
        Spacer(Modifier.height(24.dp))

        ZCard(Modifier.fillMaxWidth(), padding = 24.dp) {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                AnimatedContent(
                    targetState = when (state.phase) {
                        Phase.Connected -> 1
                        Phase.Interrupted, Phase.Unavailable -> 2
                        else -> 0
                    },
                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                    label = "connIndicator",
                ) { kind ->
                    Box(Modifier.size(132.dp), contentAlignment = Alignment.Center) {
                        when (kind) {
                            0 -> {
                                RadarPulse(Modifier.fillMaxSize())
                                Icon(Icons.Rounded.Wifi, null, tint = Z.c.signal, modifier = Modifier.size(40.dp))
                            }
                            1 -> SuccessCheck(Modifier.size(96.dp))
                            else -> Icon(
                                if (wifiUp) Icons.Rounded.ErrorOutline else Icons.Rounded.WifiOff, null,
                                tint = if (state.phase == Phase.Unavailable) Z.c.error else Z.c.warning,
                                modifier = Modifier.size(72.dp).shake(if (state.phase == Phase.Unavailable) 1 else 0),
                            )
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(
                    when (state.phase) {
                        Phase.Idle, Phase.Searching -> "Searching for Zentra…"
                        Phase.Found -> "Server found"
                        Phase.Connecting -> "Connecting…"
                        Phase.Connected -> "Connected"
                        Phase.Interrupted -> "Connection interrupted"
                        Phase.Unavailable -> "Server unavailable"
                    },
                    color = Z.c.text, fontSize = 20.sp, fontWeight = FontWeight.SemiBold,
                )
                Spacer(Modifier.height(6.dp))
                Text(state.message, color = Z.c.textDim, fontSize = 14.sp, textAlign = TextAlign.Center, lineHeight = 20.sp)
                if (state.phase == Phase.Connected && state.address != null) {
                    Spacer(Modifier.height(14.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(12.dp)).background(Z.c.surfaceHi).padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        Icon(Icons.Rounded.Dns, null, tint = Z.c.accentText, modifier = Modifier.size(18.dp))
                        Text(state.address!!.display, color = Z.c.text, fontWeight = FontWeight.Medium)
                    }
                    health?.let {
                        Spacer(Modifier.height(8.dp))
                        Text("${it.onlineUsers} online · server v${it.version}", color = Z.c.textDim, fontSize = 13.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.align(Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(if (wifiUp) Icons.Rounded.Wifi else Icons.Rounded.WifiOff, null, tint = if (wifiUp) Z.c.success else Z.c.warning, modifier = Modifier.size(16.dp))
            Text(if (wifiUp) "Connected to Wi-Fi" else "Not connected to Wi-Fi", color = Z.c.textDim, fontSize = 13.sp)
        }
        Spacer(Modifier.height(24.dp))

        if (state.phase == Phase.Connected) {
            PrimaryButton(if (mode == "change") "Done" else "Continue", onClick = { if (!advanced) { advanced = true; onDone() } })
        } else {
            PrimaryButton("Try again", onClick = { core.startAutoConnect() }, loading = busy, icon = Icons.Rounded.Refresh)
        }
        Spacer(Modifier.height(12.dp))
        SecondaryButton("Scan server QR code", onClick = onScan, icon = Icons.Rounded.QrCodeScanner)
        Spacer(Modifier.height(12.dp))
        SecondaryButton("Enter IP address", onClick = { manual = true }, icon = Icons.Rounded.Dns)
    }

    if (manual) {
        val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
        var host by remember { mutableStateOf(core.settings.value.host) }
        var port by remember { mutableStateOf(core.settings.value.port.toString()) }
        var err by remember { mutableStateOf<String?>(null) }
        ModalBottomSheet(onDismissRequest = { manual = false }, sheetState = sheet, containerColor = Z.c.surface) {
            Column(Modifier.padding(horizontal = 24.dp).padding(bottom = 24.dp).navigationBarsPadding().imePadding()) {
                Text("Server address", color = Z.c.text, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(4.dp))
                Text("Ask whoever runs the Zentra server for its IP address (for example 192.168.1.10).", color = Z.c.textDim, fontSize = 14.sp)
                Spacer(Modifier.height(16.dp))
                ZField(host, { host = it; err = null }, "IP address or name", keyboardType = KeyboardType.Uri, error = err)
                Spacer(Modifier.height(4.dp))
                ZField(port, { port = it.filter(Char::isDigit) }, "Port", keyboardType = KeyboardType.Number, imeAction = ImeAction.Done)
                Spacer(Modifier.height(16.dp))
                PrimaryButton("Connect", onClick = {
                    val a = core.parseAddress(host, port)
                    if (a == null) err = "Enter a valid IP address, like 192.168.1.10" else {
                        manual = false
                        core.startManualConnect(a)
                    }
                })
            }
        }
    }
}

@Composable
fun ScanScreen(vm: AppViewModel, onBack: () -> Unit) {
    val core = vm.core
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var granted by remember { mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val done = remember { AtomicBoolean(false) }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    Box(Modifier.fillMaxSize().background(Z.c.bg)) {
        if (granted) {
            CameraPreview(done) { text ->
                val addr = core.parseQr(text)
                if (addr == null) {
                    core.toasts.tryEmit("That QR code is not from a Zentra server.")
                    scope.launch { delay(1800); done.set(false) }
                } else {
                    core.startManualConnect(addr)
                    onBack()
                }
            }
            Box(Modifier.align(Alignment.Center).size(240.dp).clip(RoundedCornerShape(24.dp)).border(3.dp, Z.c.signal, RoundedCornerShape(24.dp)))
            Text(
                "Point the camera at the QR code shown on the Zentra server's admin page.",
                color = androidx.compose.ui.graphics.Color.White, textAlign = TextAlign.Center, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(32.dp)
                    .clip(RoundedCornerShape(14.dp)).background(androidx.compose.ui.graphics.Color(0x99000000)).padding(14.dp),
            )
        } else {
            Column(Modifier.align(Alignment.Center).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                EmptyState(Icons.Rounded.QrCodeScanner, "Camera access needed", "Zentra uses the camera only to scan the server's QR code. Nothing is recorded or uploaded.")
                Spacer(Modifier.height(8.dp))
                PrimaryButton("Allow camera", onClick = { launcher.launch(Manifest.permission.CAMERA) })
                Spacer(Modifier.height(12.dp))
                SecondaryButton("Enter IP address instead", onClick = onBack)
            }
        }
        Box(Modifier.statusBarsPadding()) { ScreenTitleBar("Scan QR code", onBack) }
    }
}

@Composable
private fun CameraPreview(done: AtomicBoolean, onCode: (String) -> Unit) {
    val owner = LocalLifecycleOwner.current
    val executor = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember {
        BarcodeScanning.getClient(BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build())
    }
    DisposableEffect(Unit) {
        onDispose {
            executor.shutdown()
            scanner.close()
        }
    }
    AndroidView(
        modifier = Modifier.fillMaxSize(),
        factory = { c ->
            val view = PreviewView(c)
            val future = ProcessCameraProvider.getInstance(c)
            future.addListener({
                try {
                    val provider = future.get()
                    val preview = Preview.Builder().build().also { it.setSurfaceProvider(view.surfaceProvider) }
                    val analysis = ImageAnalysis.Builder()
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                    analysis.setAnalyzer(executor) { proxy -> analyze(proxy, scanner, done, onCode) }
                    provider.unbindAll()
                    provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                } catch (_: Exception) {
                }
            }, ContextCompat.getMainExecutor(c))
            view
        },
    )
}

@Suppress("UnsafeOptInUsageError")
private fun analyze(proxy: ImageProxy, scanner: BarcodeScanner, done: AtomicBoolean, onCode: (String) -> Unit) {
    val media = proxy.image
    if (media == null || done.get()) {
        proxy.close()
        return
    }
    val img = InputImage.fromMediaImage(media, proxy.imageInfo.rotationDegrees)
    scanner.process(img)
        .addOnSuccessListener { codes ->
            val raw = codes.firstNotNullOfOrNull { it.rawValue }
            if (raw != null && done.compareAndSet(false, true)) onCode(raw)
        }
        .addOnCompleteListener { proxy.close() }
}
