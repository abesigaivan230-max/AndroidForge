package com.zentra.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.io.IOException
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

/** An error returned by the server (or a network failure) with a message that is safe to show to the user. */
class ApiException(val code: String, override val message: String, val status: Int = 0) : Exception(message)

fun errMsg(e: Throwable): String = when (e) {
    is ApiException -> e.message
    is kotlinx.serialization.SerializationException -> "The server sent something unexpected. Is it a Zentra server?"
    else -> "Something went wrong. Please try again."
}

fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

/** Thin REST client for the Zentra server. All calls are real network calls; nothing is mocked. */
class Api {
    val json = Json { ignoreUnknownKeys = true; coerceInputValues = true; isLenient = true }

    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()

    @Volatile var address: ServerAddress? = null
    @Volatile var token: String? = null

    /** Called when the server says our session is no longer valid (HTTP 401 on an authenticated call). */
    @Volatile var onUnauthorized: (() -> Unit)? = null

    private val jsonType = "application/json; charset=utf-8".toMediaType()

    suspend fun raw(
        method: String,
        path: String,
        body: JsonElement? = null,
        auth: Boolean = true,
        address: ServerAddress? = this.address,
        timeoutMs: Long? = null,
    ): String = withContext(Dispatchers.IO) {
        val addr = address ?: throw ApiException("NO_SERVER", "No Zentra server selected yet.")
        val needsBody = method == "POST" || method == "PUT" || method == "PATCH"
        val rb = when {
            body != null -> body.toString().toRequestBody(jsonType)
            needsBody -> "{}".toRequestBody(jsonType)
            else -> null
        }
        val req = Request.Builder()
            .url(addr.baseUrl + path)
            .method(method, rb)
            .apply { if (auth) token?.let { header("Authorization", "Bearer $it") } }
            .build()
        val client = if (timeoutMs != null) http.newBuilder().callTimeout(timeoutMs, TimeUnit.MILLISECONDS).build() else http
        try {
            client.newCall(req).execute().use { r ->
                val text = r.body?.string().orEmpty()
                if (r.isSuccessful) text else {
                    if (r.code == 401 && auth) onUnauthorized?.invoke()
                    throw parseError(r.code, text)
                }
            }
        } catch (e: ApiException) {
            throw e
        } catch (e: IOException) {
            throw ApiException(
                "NETWORK",
                "Can't reach the Zentra server. Check that you are on the neighbourhood Wi-Fi and the server is switched on."
            )
        } catch (e: IllegalArgumentException) {
            throw ApiException("BAD_ADDRESS", "That server address is not valid.")
        }
    }

    suspend inline fun <reified T> call(
        method: String,
        path: String,
        body: JsonElement? = null,
        auth: Boolean = true,
        address: ServerAddress? = this.address,
        timeoutMs: Long? = null,
    ): T = json.decodeFromString<T>(raw(method, path, body, auth, address, timeoutMs))

    private fun parseError(status: Int, text: String): ApiException {
        var code = "HTTP_$status"
        var detail = when (status) {
            401 -> "Please sign in again."
            403 -> "You are not allowed to do that."
            404 -> "That was not found."
            429 -> "Too many attempts. Please wait a moment."
            else -> "The server could not complete that request."
        }
        try {
            val obj: JsonObject = json.parseToJsonElement(text).jsonObject
            obj["code"]?.jsonPrimitive?.contentOrNull?.let { code = it }
            val d = obj["detail"]
            if (d is kotlinx.serialization.json.JsonPrimitive) d.contentOrNull?.let { detail = it }
        } catch (_: Exception) {
        }
        return ApiException(code, detail, status)
    }
}
