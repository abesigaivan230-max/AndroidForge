package com.zentra.app.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/**
 * Local copy of messages. Room is what the chat screen reads, so history is readable offline.
 * Messages with status "sending" are the outbox: they are re-sent (with the same id, so the server
 * de-duplicates) every time the connection comes back.
 */
@Entity(tableName = "messages", indices = [Index("target", "targetId", "seq")])
data class MessageEntity(
    @PrimaryKey val id: String,
    val target: String,       // "channel" | "dm"
    val targetId: Long,
    val seq: Long,            // 0 while the server has not accepted it yet
    val senderId: Long,
    val senderName: String,
    val body: String,
    val createdAt: Long,
    val status: String,       // sending | sent | delivered | read | failed
)

fun WireMessage.toEntity() = MessageEntity(id, target, targetId, seq, senderId, senderName, body, createdAt, status)

@Dao
interface MessageDao {
    @Query(
        "SELECT * FROM (SELECT * FROM messages WHERE target = :target AND targetId = :tid " +
            "ORDER BY (seq = 0) DESC, seq DESC, createdAt DESC LIMIT :limit) " +
            "ORDER BY (seq = 0) ASC, seq ASC, createdAt ASC"
    )
    fun observe(target: String, tid: Long, limit: Int): Flow<List<MessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(m: MessageEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(list: List<MessageEntity>)

    @Query("SELECT * FROM messages WHERE status = 'sending' ORDER BY createdAt ASC")
    suspend fun pending(): List<MessageEntity>

    @Query("SELECT * FROM messages WHERE id = :id")
    suspend fun get(id: String): MessageEntity?

    @Query("UPDATE messages SET status = :status WHERE id = :id")
    suspend fun setStatus(id: String, status: String)

    @Query("SELECT COALESCE(MAX(seq), 0) FROM messages")
    suspend fun maxSeq(): Long

    @Query("SELECT COALESCE(MIN(seq), 0) FROM messages WHERE target = :target AND targetId = :tid AND seq > 0")
    suspend fun minSeq(target: String, tid: Long): Long

    @Query(
        "UPDATE messages SET status = 'delivered' WHERE target = 'dm' AND targetId = :tid " +
            "AND senderId = :me AND seq > 0 AND seq <= :upTo AND status = 'sent'"
    )
    suspend fun markDelivered(tid: Long, me: Long, upTo: Long)

    @Query(
        "UPDATE messages SET status = 'read' WHERE target = 'dm' AND targetId = :tid " +
            "AND senderId = :me AND seq > 0 AND seq <= :upTo AND status IN ('sent', 'delivered')"
    )
    suspend fun markRead(tid: Long, me: Long, upTo: Long)

    @Query("DELETE FROM messages WHERE target = 'channel' AND targetId = :id")
    suspend fun deleteChannel(id: Long)
}

@Database(entities = [MessageEntity::class], version = 1, exportSchema = false)
abstract class ZentraDb : RoomDatabase() {
    abstract fun messages(): MessageDao
}
