package com.zentra.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Badge
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.PersonOutline
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.VpnKey
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zentra.app.AppViewModel
import com.zentra.app.R
import com.zentra.app.util.ImageUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val USERNAME_RE = Regex("^[a-z0-9_]{3,24}$")

fun passwordProblem(pw: String): String? = when {
    pw.length < 8 -> "Use at least 8 characters."
    !pw.any { it.isLetter() } -> "Include at least one letter."
    !pw.any { it.isDigit() } -> "Include at least one number."
    pw.length > 128 -> "That password is too long."
    else -> null
}

@Composable
fun AuthScreen(vm: AppViewModel, onChangeServer: () -> Unit, onDone: () -> Unit) {
    val core = vm.core
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val health by core.health.collectAsState()
    val settings by core.settings.collectAsState()

    var register by remember { mutableStateOf(false) }
    var fullName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var invite by remember { mutableStateOf("") }
    var avatar by remember { mutableStateOf<String?>(null) }
    var submitted by remember { mutableStateOf(false) }
    var loading by remember { mutableStateOf(false) }
    var success by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var shakes by remember { mutableIntStateOf(0) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            val b64 = withContext(Dispatchers.Default) { ImageUtil.avatarBase64(ctx, uri) }
            if (b64 == null) core.toasts.tryEmit("Couldn't read that picture.") else avatar = b64
        }
    }

    val nameErr = if (register && submitted && fullName.trim().length !in 2..40) "Enter your name (2 to 40 letters)." else null
    val userErr = if (submitted && !USERNAME_RE.matches(username.trim().lowercase())) {
        if (register) "3 to 24 characters: letters, numbers or underscore." else "Enter your username."
    } else null
    val pwErr = if (submitted) (if (register) passwordProblem(password) else if (password.isEmpty()) "Enter your password." else null) else null
    val confErr = if (register && submitted && confirm != password) "Passwords don't match." else null

    fun submit() {
        submitted = true
        error = null
        val valid = if (register) {
            fullName.trim().length in 2..40 && USERNAME_RE.matches(username.trim().lowercase()) &&
                passwordProblem(password) == null && confirm == password
        } else username.isNotBlank() && password.isNotEmpty()
        if (!valid) {
            shakes++
            return
        }
        loading = true
        vm.run(onDone = { err ->
            loading = false
            if (err != null) {
                error = err
                shakes++
            } else success = true
        }) {
            if (register) core.register(fullName, username, password, avatar, invite.takeIf { health?.registrationCodeRequired == true })
            else core.login(username, password)
        }
    }

    LaunchedEffect(success) {
        if (success) {
            delay(900)
            onDone()
        }
    }

    Box(Modifier.fillMaxSize().background(Z.c.bg)) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().imePadding().navigationBarsPadding()
                .verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Spacer(Modifier.height(20.dp))
            Image(painterResource(R.drawable.brand_symbol), null, Modifier.size(width = 96.dp, height = 66.dp))
            Spacer(Modifier.height(10.dp))
            AnimatedContent(register, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(150)) }, label = "authTitle") { reg ->
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (reg) "Join your neighbourhood" else "Welcome back", color = Z.c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text(
                        if (reg) "Create your account on the local server. No internet needed." else "Sign in to continue.",
                        color = Z.c.textDim, fontSize = 14.sp, textAlign = TextAlign.Center,
                    )
                }
            }
            Spacer(Modifier.height(12.dp))
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(Z.c.surface).border(1.dp, Z.c.border, RoundedCornerShape(50))
                    .clickable(onClick = onChangeServer).padding(horizontal = 12.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(Icons.Rounded.Dns, null, tint = Z.c.accentText, modifier = Modifier.size(16.dp))
                Text(settings.address?.display ?: "No server", color = Z.c.textDim, fontSize = 13.sp)
                Text("Change", color = Z.c.accentText, fontSize = 13.sp, fontWeight = FontWeight.Medium)
            }
            Spacer(Modifier.height(20.dp))

            // Sign in / Sign up switch
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Z.c.surface).border(1.dp, Z.c.border, RoundedCornerShape(14.dp)).padding(4.dp)) {
                for ((label, isReg) in listOf("Sign in" to false, "Create account" to true)) {
                    val sel = register == isReg
                    Box(
                        Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(11.dp))
                            .background(if (sel) Z.c.accent else Z.c.surface)
                            .clickable { register = isReg; error = null; submitted = false },
                        contentAlignment = Alignment.Center,
                    ) { Text(label, color = if (sel) androidx.compose.ui.graphics.Color.White else Z.c.textDim, fontWeight = FontWeight.Medium, fontSize = 14.sp) }
                }
            }
            Spacer(Modifier.height(16.dp))

            Column(Modifier.shake(shakes), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                if (register) {
                    Box(Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp)) {
                        Box(
                            Modifier.clip(CircleShape).clickable {
                                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                            },
                        ) { Avatar(fullName.ifBlank { "You" }, avatar, 84.dp) }
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(28.dp).clip(CircleShape).background(Z.c.accent).border(2.dp, Z.c.bg, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) { Icon(Icons.Rounded.PhotoCamera, "Add profile picture", tint = androidx.compose.ui.graphics.Color.White, modifier = Modifier.size(15.dp)) }
                    }
                    Text("Profile picture (optional)", color = Z.c.textDim, fontSize = 12.sp, modifier = Modifier.align(Alignment.CenterHorizontally).padding(bottom = 10.dp))
                    ZField(fullName, { fullName = it }, "Full name", leading = Icons.Rounded.Badge, error = nameErr, maxLength = 40)
                }
                ZField(
                    username, { username = it.filter { ch -> !ch.isWhitespace() } }, "Username", leading = Icons.Rounded.PersonOutline,
                    error = userErr, maxLength = 24,
                    hint = if (register) "Lowercase letters, numbers, underscore" else null,
                )
                ZField(
                    password, { password = it }, "Password", password = true, leading = Icons.Rounded.Lock, error = pwErr,
                    imeAction = if (register) ImeAction.Next else ImeAction.Done, onDone = { if (!register) submit() },
                    hint = if (register) "8+ characters with a letter and a number" else null,
                )
                if (register) {
                    ZField(
                        confirm, { confirm = it }, "Confirm password", password = true, leading = Icons.Rounded.Lock, error = confErr,
                        imeAction = if (health?.registrationCodeRequired == true) ImeAction.Next else ImeAction.Done,
                        onDone = { if (health?.registrationCodeRequired != true) submit() },
                    )
                    if (health?.registrationCodeRequired == true) {
                        ZField(
                            invite, { invite = it }, "Neighbourhood code", leading = Icons.Rounded.VpnKey,
                            imeAction = ImeAction.Done, onDone = ::submit, hint = "Ask the person who runs your Zentra server",
                        )
                    }
                }
            }
            ErrorBanner(error, Modifier.padding(top = 4.dp))
            Spacer(Modifier.height(16.dp))
            if (success) {
                Box(Modifier.fillMaxWidth().height(54.dp), contentAlignment = Alignment.Center) { SuccessCheck(Modifier.size(48.dp)) }
            } else {
                PrimaryButton(if (register) "Create account" else "Sign in", ::submit, loading = loading)
            }
            Spacer(Modifier.height(16.dp))
            Text(
                "Your account lives only on your neighbourhood server. Messages are not end-to-end encrypted.",
                color = Z.c.textDim, fontSize = 12.sp, textAlign = TextAlign.Center,
            )
            Spacer(Modifier.height(24.dp))
        }
    }
}
