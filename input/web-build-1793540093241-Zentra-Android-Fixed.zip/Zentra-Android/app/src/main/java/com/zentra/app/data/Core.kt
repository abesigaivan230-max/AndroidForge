package com.zentra.app.data

import android.app.Application
import android.content.Intent
import androidx.core.content.ContextCompat
import androidx.room.Room
import com.zentra.app.ConnectionService
import com.zentra.app.Notifier
import com.zentra.app.net.ConnState
import com.zentra.app.net.ConnectionManager
import com.zentra.app.net.Discovery
import com.zentra.app.net.Phase
import com.zentra.app.net.WifiBinder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.decodeFromJsonElement
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.jsonObject
import kotlinx.serialization.json.jsonPrimitive
import kotlinx.serialization.json.longOrNull
import kotlinx.serialization.json.put
import java.util.UUID

/**
 * The app's single source of truth. ViewModels expose it to the UI; the foreground service uses it too, so
 * notifications keep working with no Activity on screen.
 *
 * Nothing in here is simulated: every list comes from the server, every message goes through the WebSocket.
 */
class Core(val app: Application) {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    val store = SettingsStore(app)
    val api = Api()
    private val db: ZentraDb = Room.databaseBuilder(app, ZentraDb::class.java, "zentra.db")
        .fallbackToDestructiveMigration()
        .build()
    private val dao = db.messages()
    val notifier = Notifier(app)
    val conn = ConnectionManager(api, scope)
    val wifi = WifiBinder(app) { conn.kick() }
    private val discovery = Discovery(app)

    val settings = MutableStateFlow(Settings())
    val me = MutableStateFlow<User?>(null)
    val myChannels = MutableStateFlow<List<Channel>>(emptyList())
    val discover = MutableStateFlow<List<Channel>>(emptyList())
    val dms = MutableStateFlow<List<Dm>>(emptyList())
    val pending = MutableStateFlow<List<JoinRequest>>(emptyList())
    val notifications = MutableStateFlow<List<ServerNotification>>(emptyList())
    val onlineIds = MutableStateFlow<Set<Long>>(emptySet())
    val onlineCount = MutableStateFlow(0)
    val directory = MutableStateFlow<Map<Long, User>>(emptyMap())
    val meta = MutableStateFlow(Meta(FALLBACK_CATEGORIES, ICON_KEYS))
    val health = MutableStateFlow<Health?>(null)
    val listsLoaded = MutableStateFlow(false)
    val toasts = MutableSharedFlow<String>(extraBufferCapacity = 8)

    /** A route requested by tapping a notification; the navigation host consumes it. */
    val pendingRoute = MutableStateFlow<String?>(null)

    @Volatile var openChat: Pair<String, Long>? = null
    @Volatile var foreground = false
    private var grace = false
    private var graceJob: Job? = null
    private var connectJob: Job? = null
    private var refreshJob: Job? = null
    private var wasLoggedIn = false
    private val sentAt = HashMap<String, Long>()
    private val flushLock = Mutex()

    init {
        notifier.createChannels()
        api.onUnauthorized = { scope.launch { sessionExpired() } }
        conn.onEvent = { obj -> scope.launch { handleEvent(obj) } }
        conn.onReady = { scope.launch { onReady() } }
        conn.onAuthExpired = { scope.launch { sessionExpired() } }
        wifi.start()

        scope.launch {
            store.flow.collect { s ->
                settings.value = s
                api.token = s.token
                s.address?.let { if (api.address != it) api.address = it }
                if (s.user != null && me.value?.id != s.user.id) me.value = s.user
                if (s.loggedIn && !wasLoggedIn) {
                    wasLoggedIn = true
                    onLoggedIn()
                } else if (!s.loggedIn) {
                    wasLoggedIn = false
                }
                updateWanted()
            }
        }
        scope.launch {
            var last = Phase.Idle
            conn.state.collect { st ->
                val s = settings.value
                if ((st.phase == Phase.Interrupted || st.phase == Phase.Unavailable) && last == Phase.Connected &&
                    !foreground && s.stayConnected && s.notifConnection
                ) notifier.connectionInterrupted()
                last = st.phase
            }
        }
    }

    // ------------------------------------------------------------------ lifecycle / connection policy

    fun updateWanted() {
        val s = settings.value
        if (s.loggedIn && (foreground || grace || s.stayConnected)) conn.start() else conn.stop()
    }

    /** The socket is only held open while the app is visible, for a minute after, or when the user chose "Stay connected". */
    fun onForeground(f: Boolean) {
        foreground = f
        graceJob?.cancel()
        if (f) {
            grace = false
            if (settings.value.loggedIn) {
                conn.kick()
                if (settings.value.stayConnected) startService()
                scope.launch { refreshLists() }
            }
        } else {
            grace = true
            graceJob = scope.launch {
                delay(60_000)
                grace = false
                updateWanted()
            }
        }
        updateWanted()
    }

    fun startService() {
        try {
            ContextCompat.startForegroundService(app, Intent(app, ConnectionService::class.java))
        } catch (_: Exception) {
        }
    }

    private fun stopService() {
        try {
            app.stopService(Intent(app, ConnectionService::class.java))
        } catch (_: Exception) {
        }
    }

    suspend fun setStayConnected(v: Boolean) {
        store.setStayConnected(v)
        if (v) startService() else stopService()
    }

    private suspend fun onLoggedIn() {
        refreshMe()
        refreshLists()
        refreshNotifications()
        loadPresence()
    }

    private suspend fun onReady() {
        sentAt.clear()
        flushOutbox()
        syncMissed()
        refreshLists()
        loadPresence()
    }

    // ------------------------------------------------------------------ finding and verifying the server

    fun parseAddress(input: String, portText: String): ServerAddress? {
        var host = input.trim().removePrefix("http://").removePrefix("https://").substringBefore("/")
        var port = portText.trim().toIntOrNull()
        if (host.contains(":")) {
            port = port ?: host.substringAfter(":").toIntOrNull()
            host = host.substringBefore(":")
        }
        if (host.isBlank() || !Regex("^[A-Za-z0-9._-]+$").matches(host)) return null
        val p = port ?: 8000
        return if (p in 1..65535) ServerAddress(host, p) else null
    }

    fun parseQr(text: String): ServerAddress? = try {
        val o = api.json.parseToJsonElement(text).jsonObject
        if (o["app"]?.jsonPrimitive?.contentOrNull != "zentra") null else {
            val host = o["host"]?.jsonPrimitive?.contentOrNull
            val port = o["port"]?.jsonPrimitive?.intOrNull
            if (host.isNullOrBlank() || port == null) null else ServerAddress(host, port)
        }
    } catch (e: Exception) {
        null
    }

    /** Asks the server itself. A real Zentra server is the only thing that can make this succeed. */
    suspend fun verify(addr: ServerAddress): Health {
        val h = try {
            api.call<Health>("GET", "/api/health", auth = false, address = addr, timeoutMs = 4000)
        } catch (e: ApiException) {
            throw e
        } catch (e: Exception) {
            throw ApiException("NOT_ZENTRA", "That address answered, but it is not a Zentra server.")
        }
        if (h.app != "zentra" || h.status != "ok") {
            throw ApiException("NOT_ZENTRA", "That address answered, but it is not a Zentra server.")
        }
        return h
    }

    private suspend fun adopt(addr: ServerAddress) {
        conn.set(ConnState(Phase.Connecting, addr, "Contacting ${addr.display}…"))
        val h = try {
            verify(addr)
        } catch (e: ApiException) {
            conn.set(ConnState(Phase.Unavailable, addr, e.message))
            throw e
        }
        val previous = health.value?.serverId
        if (!previous.isNullOrEmpty() && previous != h.serverId) {
            withContext(Dispatchers.IO) { db.clearAllTables() }
        }
        api.address = addr
        store.saveServer(addr)
        health.value = h
        conn.set(ConnState(Phase.Connected, addr, "Connected"))
        loadMeta()
    }

    fun startAutoConnect() {
        connectJob?.cancel()
        connectJob = scope.launch { autoConnect() }
    }

    fun startManualConnect(addr: ServerAddress) {
        connectJob?.cancel()
        connectJob = scope.launch {
            try {
                adopt(addr)
            } catch (_: Exception) {
            }
        }
    }

    private suspend fun autoConnect() {
        conn.set(ConnState(Phase.Searching, null, "Looking for Zentra on this Wi-Fi…"))
        val saved = settings.value.address
        if (saved != null) {
            try {
                adopt(saved)
                return
            } catch (_: Exception) {
            }
            conn.set(ConnState(Phase.Searching, null, "Looking for Zentra on this Wi-Fi…"))
        }
        val found = discovery.findFirst(8000)
        if (found == null) {
            val hint = if (wifi.wifiUp.value) "No Zentra server found. Enter its IP address or scan its QR code."
            else "You don't seem to be connected to Wi-Fi. Join the neighbourhood Wi-Fi, then try again."
            conn.set(ConnState(Phase.Unavailable, null, hint))
            return
        }
        conn.set(ConnState(Phase.Found, found, "Server found at ${found.display}"))
        delay(600)
        try {
            adopt(found)
        } catch (_: Exception) {
        }
    }

    private suspend fun loadMeta() {
        try {
            meta.value = api.call<Meta>("GET", "/api/meta", auth = false)
        } catch (_: Exception) {
        }
    }

    // ------------------------------------------------------------------ accounts

    suspend fun login(username: String, password: String) {
        val body = buildJsonObject {
            put("username", username.trim().lowercase())
            put("password", password)
        }
        startSession(api.call<AuthResponse>("POST", "/api/auth/login", body, auth = false))
    }

    suspend fun register(fullName: String, username: String, password: String, avatar: String?, invite: String?) {
        val body = buildJsonObject {
            put("full_name", fullName.trim())
            put("username", username.trim().lowercase())
            put("password", password)
            if (avatar != null) put("avatar", avatar)
            if (!invite.isNullOrBlank()) put("invite_code", invite.trim())
        }
        startSession(api.call<AuthResponse>("POST", "/api/auth/register", body, auth = false))
    }

    private suspend fun startSession(r: AuthResponse) {
        if (!store.saveSession(r.token, r.user)) {
            throw ApiException("KEYSTORE", "This phone's secure storage is not available, so Zentra can't keep you signed in.")
        }
        api.token = r.token
        me.value = r.user
        remember(listOf(r.user))
    }

    suspend fun logout() {
        try {
            api.raw("POST", "/api/auth/logout", timeoutMs = 3000)
        } catch (_: Exception) {
        }
        clearLocalSession()
    }

    private suspend fun sessionExpired() {
        if (!settings.value.loggedIn) return
        toasts.tryEmit("Your session ended. Please sign in again.")
        clearLocalSession()
    }

    private suspend fun clearLocalSession() {
        conn.stop()
        stopService()
        api.token = null
        store.clearSession()
        store.setStayConnected(false)
        withContext(Dispatchers.IO) { db.clearAllTables() }
        me.value = null
        myChannels.value = emptyList()
        dms.value = emptyList()
        pending.value = emptyList()
        notifications.value = emptyList()
        discover.value = emptyList()
        onlineIds.value = emptySet()
        listsLoaded.value = false
        notifier.cancelAll()
    }

    suspend fun refreshMe() {
        try {
            val u = api.call<User>("GET", "/api/me")
            me.value = u
            store.saveUser(u)
            remember(listOf(u))
        } catch (_: Exception) {
        }
    }

    suspend fun updateProfile(fullName: String?, avatarB64: String?, removeAvatar: Boolean) {
        val body = buildJsonObject {
            if (fullName != null) put("full_name", fullName.trim())
            if (avatarB64 != null) put("avatar", avatarB64)
            put("remove_avatar", removeAvatar)
        }
        val u = api.call<User>("PATCH", "/api/me", body)
        me.value = u
        store.saveUser(u)
        remember(listOf(u))
    }

    suspend fun changePassword(current: String, new: String) {
        val body = buildJsonObject {
            put("current_password", current)
            put("new_password", new)
        }
        api.raw("POST", "/api/me/password", body)
    }

    // ------------------------------------------------------------------ lists

    fun remember(users: List<User>) {
        if (users.isEmpty()) return
        val m = directory.value.toMutableMap()
        for (u in users) {
            val old = m[u.id]
            m[u.id] = if (u.avatar == null && old?.avatar != null) u.copy(avatar = old.avatar) else u
        }
        directory.value = m
    }

    suspend fun refreshLists() {
        if (!settings.value.loggedIn) return
        try {
            myChannels.value = api.call<ChannelList>("GET", "/api/channels?mine=true").channels
            val d = api.call<DmList>("GET", "/api/dms").conversations
            dms.value = d
            remember(d.map { it.peer })
            pending.value = api.call<RequestList>("GET", "/api/channels/pending-requests").requests
            listsLoaded.value = true
        } catch (_: Exception) {
        }
    }

    private fun scheduleRefresh() {
        refreshJob?.cancel()
        refreshJob = scope.launch {
            delay(350)
            refreshLists()
        }
    }

    suspend fun loadDiscover(q: String, category: String) {
        val path = "/api/channels?q=${enc(q.trim())}&category=${enc(category)}"
        discover.value = api.call<ChannelList>("GET", path).channels
    }

    suspend fun refreshNotifications() {
        try {
            notifications.value = api.call<NotificationList>("GET", "/api/notifications").notifications.reversed()
        } catch (_: Exception) {
        }
    }

    suspend fun markNotificationsRead() {
        api.raw("POST", "/api/notifications/read", buildJsonObject { put("all", true) })
        notifications.value = notifications.value.map { it.copy(read = true) }
    }

    private suspend fun loadPresence() {
        try {
            val p = api.call<PresenceList>("GET", "/api/presence")
            onlineIds.value = p.onlineIds.toSet()
            onlineCount.value = p.count
        } catch (_: Exception) {
        }
    }

    suspend fun searchUsers(q: String): List<User> {
        val users = api.call<UserList>("GET", "/api/users?q=${enc(q.trim())}").users
        remember(users)
        return users
    }

    suspend fun startDm(userId: Long): Dm {
        val d = api.call<Dm>("POST", "/api/dms", buildJsonObject { put("user_id", userId) })
        remember(listOf(d.peer))
        refreshLists()
        return d
    }

    // ------------------------------------------------------------------ channels

    suspend fun channelDetail(id: Long): Channel = api.call("GET", "/api/channels/$id")

    suspend fun createChannel(name: String, description: String, category: String, icon: String, isPrivate: Boolean): Channel {
        val body = buildJsonObject {
            put("name", name)
            put("description", description)
            put("category", category)
            put("icon", icon)
            put("is_private", isPrivate)
        }
        val ch = api.call<Channel>("POST", "/api/channels", body)
        refreshLists()
        return ch
    }

    suspend fun updateChannel(id: Long, name: String, description: String, category: String, icon: String, isPrivate: Boolean): Channel {
        val body = buildJsonObject {
            put("name", name)
            put("description", description)
            put("category", category)
            put("icon", icon)
            put("is_private", isPrivate)
        }
        val ch = api.call<Channel>("PATCH", "/api/channels/$id", body)
        refreshLists()
        return ch
    }

    suspend fun deleteChannel(id: Long) {
        api.raw("DELETE", "/api/channels/$id?confirm=true")
        dao.deleteChannel(id)
        refreshLists()
    }

    suspend fun join(id: Long): JoinResult {
        val r = api.call<JoinResult>("POST", "/api/channels/$id/join")
        refreshLists()
        return r
    }

    suspend fun cancelJoin(id: Long) {
        api.raw("DELETE", "/api/channels/$id/join")
        refreshLists()
    }

    suspend fun leave(id: Long) {
        api.raw("POST", "/api/channels/$id/leave")
        dao.deleteChannel(id)
        refreshLists()
    }

    suspend fun members(id: Long): List<User> {
        val list = api.call<MemberList>("GET", "/api/channels/$id/members").members
        remember(list)
        return list
    }

    suspend fun requests(id: Long): List<JoinRequest> =
        api.call<RequestList>("GET", "/api/channels/$id/requests").requests

    suspend fun resolve(channelId: Long, requestId: Long, approve: Boolean) {
        api.raw("POST", "/api/channels/$channelId/requests/$requestId/${if (approve) "approve" else "reject"}")
        refreshLists()
    }

    suspend fun removeMember(channelId: Long, userId: Long) {
        api.raw("DELETE", "/api/channels/$channelId/members/$userId")
        refreshLists()
    }

    suspend fun transfer(channelId: Long, newOwnerId: Long) {
        val body = buildJsonObject {
            put("new_owner_id", newOwnerId)
            put("confirm", true)
        }
        api.raw("POST", "/api/channels/$channelId/transfer", body)
        refreshLists()
    }

    // ------------------------------------------------------------------ messages

    private fun base(target: String, id: Long) = if (target == "dm") "/api/dms/$id" else "/api/channels/$id"

    fun messages(target: String, id: Long, limit: Int): Flow<List<MessageEntity>> = dao.observe(target, id, limit)

    /** Loads the newest page and tells the server we have read it. Returns true if older messages exist. */
    suspend fun loadHistory(target: String, id: Long): Boolean {
        val page = api.call<MessagePage>("GET", "${base(target, id)}/messages?limit=50")
        dao.upsertAll(page.messages.map { it.toEntity() })
        val top = page.messages.maxOfOrNull { it.seq } ?: 0L
        if (top > 0) markRead(target, id, top)
        return page.hasMore
    }

    suspend fun loadOlder(target: String, id: Long): Boolean {
        val min = dao.minSeq(target, id)
        if (min <= 0) return false
        val page = api.call<MessagePage>("GET", "${base(target, id)}/messages?before_seq=$min&limit=50")
        dao.upsertAll(page.messages.map { it.toEntity() })
        return page.hasMore
    }

    fun send(target: String, targetId: Long, text: String) {
        val body = text.trim().take(2000)
        val u = me.value ?: return
        if (body.isEmpty()) return
        scope.launch {
            val id = UUID.randomUUID().toString().replace("-", "")
            dao.upsert(MessageEntity(id, target, targetId, 0, u.id, u.fullName, body, System.currentTimeMillis(), "sending"))
            flushOutbox()
        }
    }

    fun retry(id: String) {
        scope.launch {
            dao.setStatus(id, "sending")
            sentAt.remove(id)
            flushOutbox()
        }
    }

    /** Sends every queued message. Ids are stable, so the server can safely ignore a repeat. */
    private suspend fun flushOutbox() = flushLock.withLock {
        if (!conn.isOpen) return@withLock
        for (m in dao.pending()) {
            val now = System.currentTimeMillis()
            if (now - (sentAt[m.id] ?: 0L) < 8_000L) continue
            val frame = buildJsonObject {
                put("type", "send")
                put("target", m.target)
                put("target_id", m.targetId)
                put("client_id", m.id)
                put("body", m.body)
            }.toString()
            if (!conn.send(frame)) break
            sentAt[m.id] = now
            delay(60)
        }
    }

    fun markRead(target: String, id: Long, seq: Long) {
        if (seq <= 0) return
        val frame = buildJsonObject {
            put("type", "read")
            put("target", target)
            put("target_id", id)
            put("seq", seq)
        }.toString()
        if (!conn.send(frame)) {
            scope.launch {
                try {
                    api.raw("POST", "${base(target, id)}/read", buildJsonObject { put("seq", seq) })
                } catch (_: Exception) {
                }
            }
        }
        if (target == "dm") {
            dms.value = dms.value.map { if (it.id == id) it.copy(unread = 0) else it }
        } else {
            myChannels.value = myChannels.value.map { if (it.id == id) it.copy(unread = 0) else it }
        }
    }

    private suspend fun syncMissed() {
        try {
            var after = dao.maxSeq()
            val hadHistory = after > 0
            val meId = me.value?.id
            var guard = 0
            var notified = 0
            do {
                val p = api.call<MessagePage>("GET", "/api/sync?after_seq=$after&limit=300")
                if (p.messages.isEmpty()) break
                dao.upsertAll(p.messages.map { it.toEntity() })
                if (hadHistory && !foreground) {
                    for (m in p.messages) if (m.senderId != meId && notified++ < 5) notifyIncoming(m)
                }
                after = p.messages.maxOf { it.seq }
                guard++
            } while (p.hasMore && guard < 20)
        } catch (_: Exception) {
        }
    }

    private fun notifyIncoming(m: WireMessage) {
        val s = settings.value
        val title: String
        val text: String
        if (m.target == "dm") {
            if (!s.notifDms) return
            title = m.senderName
            text = m.body
        } else {
            if (!s.notifMessages) return
            title = myChannels.value.firstOrNull { it.id == m.targetId }?.name ?: "Channel"
            text = "${m.senderName}: ${m.body}"
        }
        notifier.message(m.target, m.targetId, title, text.take(300))
    }

    // ------------------------------------------------------------------ realtime events

    private suspend fun handleEvent(o: JsonObject) {
        val type = o["type"]?.jsonPrimitive?.contentOrNull ?: return
        val meId = me.value?.id
        when (type) {
            "hello" -> o["online_count"]?.jsonPrimitive?.intOrNull?.let { onlineCount.value = it }

            "ack" -> {
                val m = decodeMessage(o) ?: return
                sentAt.remove(m.id)
                dao.upsert(m.toEntity())
                scheduleRefresh()
            }

            "error" -> {
                val cid = o["client_id"]?.jsonPrimitive?.contentOrNull
                val code = o["code"]?.jsonPrimitive?.contentOrNull
                val detail = o["detail"]?.jsonPrimitive?.contentOrNull ?: "Something went wrong."
                if (cid != null && code == "RATE_LIMITED") {
                    sentAt.remove(cid)
                    delay(4_000)
                    flushOutbox()
                } else {
                    if (cid != null) {
                        sentAt.remove(cid)
                        dao.setStatus(cid, "failed")
                    }
                    toasts.tryEmit(detail)
                }
            }

            "message" -> {
                val m = decodeMessage(o) ?: return
                dao.upsert(m.toEntity())
                if (m.senderId != meId) {
                    val open = openChat
                    if (foreground && open != null && open.first == m.target && open.second == m.targetId) {
                        markRead(m.target, m.targetId, m.seq)
                    } else {
                        notifyIncoming(m)
                    }
                }
                scheduleRefresh()
            }

            "receipt" -> {
                val tid = o["target_id"]?.jsonPrimitive?.longOrNull ?: return
                val upTo = o["up_to_seq"]?.jsonPrimitive?.longOrNull ?: return
                val uid = meId ?: return
                if (o["status"]?.jsonPrimitive?.contentOrNull == "read") dao.markRead(tid, uid, upTo)
                else dao.markDelivered(tid, uid, upTo)
            }

            "presence" -> {
                val uid = o["user_id"]?.jsonPrimitive?.longOrNull ?: return
                val online = o["online"]?.jsonPrimitive?.contentOrNull == "true"
                onlineIds.value = if (online) onlineIds.value + uid else onlineIds.value - uid
                o["count"]?.jsonPrimitive?.intOrNull?.let { onlineCount.value = it }
            }

            "membership" -> {
                val cid = o["channel_id"]?.jsonPrimitive?.longOrNull
                if (cid != null && o["status"]?.jsonPrimitive?.contentOrNull == "none") dao.deleteChannel(cid)
                scheduleRefresh()
            }

            "notification" -> {
                val el = o["notification"] ?: return
                val n = try {
                    api.json.decodeFromJsonElement<ServerNotification>(el)
                } catch (e: Exception) {
                    return
                }
                notifications.value = listOf(n) + notifications.value.filter { it.id != n.id }
                onServerNotification(n)
                scheduleRefresh()
            }
        }
    }

    private fun decodeMessage(o: JsonObject): WireMessage? {
        val el = o["message"] ?: return null
        return try {
            api.json.decodeFromJsonElement<WireMessage>(el)
        } catch (e: Exception) {
            null
        }
    }

    private fun onServerNotification(n: ServerNotification) {
        val s = settings.value
        val cid = n.data?.get("channel_id")?.jsonPrimitive?.longOrNull
        val nid = 400_000 + (n.id % 90_000).toInt()
        when (n.type) {
            "join_request" -> if (s.notifRequests)
                notifier.show(nid, Notifier.CH_REQUESTS, n.title, n.body, if (cid != null) "manage/$cid" else null)

            "request_approved" -> if (s.notifRequests)
                notifier.show(nid, Notifier.CH_REQUESTS, n.title, n.body, if (cid != null) "chat/channel/$cid" else null)

            "request_rejected", "removed", "ownership" -> if (s.notifRequests)
                notifier.show(nid, Notifier.CH_REQUESTS, n.title, n.body, null)

            "new_dm" -> if (s.notifDms) {
                val conv = n.data?.get("conversation_id")?.jsonPrimitive?.longOrNull
                notifier.show(nid, Notifier.CH_DMS, n.title, n.body, if (conv != null) "chat/dm/$conv" else null)
            }
        }
    }
}
