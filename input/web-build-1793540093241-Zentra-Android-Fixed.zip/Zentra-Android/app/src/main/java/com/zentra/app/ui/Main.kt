package com.zentra.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.Logout
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Chat
import androidx.compose.material.icons.rounded.Dns
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Explore
import androidx.compose.material.icons.rounded.Forum
import androidx.compose.material.icons.rounded.Home
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Person
import androidx.compose.material.icons.rounded.PersonAdd
import androidx.compose.material.icons.rounded.Public
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.zentra.app.AppViewModel
import com.zentra.app.data.Channel
import com.zentra.app.data.Dm
import com.zentra.app.data.LastMsg
import com.zentra.app.data.errMsg
import com.zentra.app.net.Phase
import kotlinx.coroutines.delay
import java.util.Calendar

private data class TabDef(val label: String, val icon: ImageVector)

private val tabs = listOf(
    TabDef("Home", Icons.Rounded.Home),
    TabDef("Discover", Icons.Rounded.Explore),
    TabDef("Chats", Icons.Rounded.Chat),
    TabDef("Me", Icons.Rounded.Person),
)

@Composable
fun MainScreen(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val dms by core.dms.collectAsState()
    val channels by core.myChannels.collectAsState()
    val unread = dms.sumOf { it.unread } + channels.sumOf { it.unread }
    BackHandler(enabled = tab != 0) { tab = 0 }

    Column(Modifier.fillMaxSize().background(Z.c.bg)) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(tab, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }, label = "tabs") { t ->
                when (t) {
                    0 -> HomeTab(vm, nav, goDiscover = { tab = 1 })
                    1 -> DiscoverTab(vm, nav)
                    2 -> ChatsTab(vm, nav)
                    else -> ProfileTab(vm, nav)
                }
            }
        }
        BottomBar(tab, unread) { tab = it }
    }
}

@Composable
private fun BottomBar(selected: Int, unread: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Z.c.surface).border(1.dp, Z.c.border.copy(alpha = 0.6f)).navigationBarsPadding()
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
    ) {
        tabs.forEachIndexed { i, t ->
            val sel = i == selected
            val bg by animateColorAsState(if (sel) Z.c.accent.copy(alpha = 0.16f) else Color.Transparent, tween(250), label = "navBg")
            val fg by animateColorAsState(if (sel) Z.c.accentText else Z.c.textDim, tween(250), label = "navFg")
            Row(
                Modifier.clip(RoundedCornerShape(50)).background(bg).clickable { onSelect(i) }
                    .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow)).padding(horizontal = 16.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                Box {
                    Icon(t.icon, t.label, tint = fg, modifier = Modifier.size(24.dp))
                    if (i == 2 && unread > 0) {
                        Box(Modifier.align(Alignment.TopEnd).size(9.dp).clip(CircleShape).background(Z.c.error))
                    }
                }
                if (sel) Text(t.label, color = fg, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------- Home

private fun greeting(): String {
    val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        h < 12 -> "Good morning"
        h < 17 -> "Good afternoon"
        else -> "Good evening"
    }
}

@Composable
private fun HomeTab(vm: AppViewModel, nav: NavHostController, goDiscover: () -> Unit) {
    val core = vm.core
    val me by core.me.collectAsState()
    val conn by core.conn.state.collectAsState()
    val online by core.onlineCount.collectAsState()
    val channels by core.myChannels.collectAsState()
    val dms by core.dms.collectAsState()
    val pending by core.pending.collectAsState()
    val discover by core.discover.collectAsState()
    val loaded by core.listsLoaded.collectAsState()
    val notifs by core.notifications.collectAsState()
    val bell = notifs.count { !it.read }

    LaunchedEffect(Unit) {
        try {
            core.loadDiscover("", "")
        } catch (_: Exception) {
        }
    }

    val recent = remember(channels, dms) {
        val items = mutableListOf<Triple<Long, String, Any>>()
        channels.filter { it.lastMessage != null }.forEach { items.add(Triple(it.lastMessage!!.createdAt, "c", it as Any)) }
        dms.filter { it.lastMessage != null }.forEach { items.add(Triple(it.lastMessage!!.createdAt, "d", it as Any)) }
        items.sortedByDescending { it.first }.take(5)
    }
    val suggestions = remember(discover, channels) { discover.filter { !it.isMember && it.myStatus != "pending" }.take(3) }

    LazyColumn(
        Modifier.fillMaxSize().statusBarsPadding(),
        contentPadding = PaddingValues(horizontal = 20.dp, vertical = 12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Avatar(me?.fullName ?: "", me?.avatar, 48.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(greeting(), color = Z.c.textDim, fontSize = 13.sp)
                    Text(
                        (me?.fullName ?: "").substringBefore(" ").ifEmpty { "neighbour" },
                        color = Z.c.text, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                    )
                }
                Box {
                    IconButton({ nav.navigate("notifications") }) { Icon(Icons.Rounded.Notifications, "Notifications", tint = Z.c.text) }
                    if (bell + pending.size > 0) Box(Modifier.align(Alignment.TopEnd).padding(10.dp).size(10.dp).clip(CircleShape).background(Z.c.accent))
                }
                IconButton({ nav.navigate("settings") }) { Icon(Icons.Rounded.Settings, "Settings", tint = Z.c.text) }
            }
        }
        item { StatusCard(vm, online) }
        if (pending.isNotEmpty()) item {
            val first = pending.first()
            ZCard(Modifier.fillMaxWidth(), onClick = { nav.navigate("manage/${first.channelId}") }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Z.c.warning.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.PersonAdd, null, tint = Z.c.warning)
                    }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            if (pending.size == 1) "1 join request waiting" else "${pending.size} join requests waiting",
                            color = Z.c.text, fontWeight = FontWeight.SemiBold,
                        )
                        Text("${first.user.fullName} wants to join ${first.channelName}", color = Z.c.textDim, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                QuickAction(Icons.Rounded.Add, "New channel", Modifier.weight(1f)) { nav.navigate("create") }
                QuickAction(Icons.Rounded.Explore, "Discover", Modifier.weight(1f), goDiscover)
                QuickAction(Icons.Rounded.PersonAdd, "New chat", Modifier.weight(1f)) { nav.navigate("people") }
            }
        }
        item { SectionHeader("My channels", action = if (channels.isNotEmpty()) "Create" else null, onAction = { nav.navigate("create") }) }
        item {
            when {
                !loaded -> Column { SkeletonRow(); SkeletonRow() }
                channels.isEmpty() -> ZCard(Modifier.fillMaxWidth()) {
                    EmptyState(Icons.Rounded.Forum, "No channels yet", "Join a channel from Discover, or start your own for your street, church, school or market.") {
                        PrimaryButton("Discover channels", goDiscover)
                    }
                }
                else -> LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(channels, key = { it.id }) { ch -> MiniChannelCard(ch) { nav.openChat("channel", ch.id) } }
                }
            }
        }
        item { SectionHeader("Recent conversations") }
        if (loaded && recent.isEmpty()) item {
            Text("Messages you send and receive will show up here.", color = Z.c.textDim, fontSize = 14.sp)
        }
        items(recent.size) { i ->
            val (_, kind, obj) = recent[i]
            if (kind == "c") {
                val ch = obj as Channel
                ConversationRow(ch.name, ch.lastMessage, ch.unread, null, null, ch.icon, null) { nav.openChat("channel", ch.id) }
            } else {
                val d = obj as Dm
                val onlineIds by core.onlineIds.collectAsState()
                ConversationRow(d.peer.fullName, d.lastMessage, d.unread, d.peer.avatar, onlineIds.contains(d.peer.id), null, null) { nav.openChat("dm", d.id) }
            }
        }
        if (suggestions.isNotEmpty()) {
            item { SectionHeader("Discover channels", action = "See all", onAction = goDiscover) }
            items(suggestions, key = { "s${it.id}" }) { ch -> ChannelCard(ch) { nav.navigate("channel/${ch.id}") } }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun StatusCard(vm: AppViewModel, online: Int) {
    val core = vm.core
    val conn by core.conn.state.collectAsState()
    val connected = conn.phase == Phase.Connected
    ZCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(if (connected) BrandGradient else androidx.compose.ui.graphics.SolidColor(Z.c.surfaceHi)),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Rounded.Public, null, tint = if (connected) Color.White else Z.c.textDim) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    when (conn.phase) {
                        Phase.Connected -> "Connected to your neighbourhood"
                        Phase.Unavailable -> "Server unavailable"
                        Phase.Interrupted -> "Connection interrupted"
                        Phase.Idle -> "Not connected"
                        else -> "Connecting…"
                    },
                    color = Z.c.text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp,
                )
                Text(
                    if (connected) "${conn.address?.display ?: ""} · $online online now" else conn.message.ifEmpty { "Showing saved messages" },
                    color = Z.c.textDim, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis,
                )
            }
            if (conn.phase == Phase.Unavailable || conn.phase == Phase.Interrupted || conn.phase == Phase.Idle) {
                IconButton({ core.conn.kick(); core.updateWanted() }) { Icon(Icons.Rounded.Refresh, "Reconnect", tint = Z.c.accentText) }
            }
        }
    }
}

@Composable
private fun QuickAction(icon: ImageVector, label: String, modifier: Modifier, onClick: () -> Unit) {
    ZCard(modifier, onClick = onClick, padding = 12.dp) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = Z.c.accentText, modifier = Modifier.size(24.dp))
            Text(label, color = Z.c.text, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1)
        }
    }
}

@Composable
private fun MiniChannelCard(ch: Channel, onClick: () -> Unit) {
    ZCard(Modifier.width(176.dp), onClick = onClick) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ChannelIcon(ch.icon, 40.dp)
            Spacer(Modifier.weight(1f))
            Badge(ch.unread)
        }
        Spacer(Modifier.height(10.dp))
        Text(ch.name, color = Z.c.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text("${ch.memberCount} members · ${ch.onlineCount} online", color = Z.c.textDim, fontSize = 12.sp, maxLines = 1)
    }
}

@Composable
fun ConversationRow(
    title: String, last: LastMsg?, unread: Int, avatar: String?, online: Boolean?, channelIcon: String?, extra: String?, onClick: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (channelIcon != null) ChannelIcon(channelIcon, 48.dp) else Avatar(title, avatar, 48.dp, online)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Z.c.text, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(timeLabel(last?.createdAt ?: 0), color = if (unread > 0) Z.c.accentText else Z.c.textDim, fontSize = 12.sp)
            }
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                val preview = when {
                    last == null -> extra ?: "No messages yet"
                    last.senderName != null && channelIcon != null -> "${last.senderName}: ${last.body}"
                    else -> last.body
                }
                Text(preview, color = Z.c.textDim, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                if (unread > 0) {
                    Spacer(Modifier.width(8.dp))
                    Badge(unread)
                }
            }
        }
    }
}

@Composable
fun ChannelCard(ch: Channel, onClick: () -> Unit) {
    ZCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(verticalAlignment = Alignment.Top) {
            ChannelIcon(ch.icon, 48.dp)
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(ch.name, color = Z.c.text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false))
                    if (ch.isPrivate) LockTag()
                }
                if (ch.description.isNotBlank()) {
                    Text(ch.description, color = Z.c.textDim, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
                }
                Text(
                    "by ${ch.owner.fullName.ifEmpty { ch.owner.username }} · ${ch.category}",
                    color = Z.c.textDim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp), maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
                Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("${ch.memberCount} members", color = Z.c.text, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.size(7.dp).clip(CircleShape).background(Z.c.success))
                        Text("${ch.onlineCount} online", color = Z.c.textDim, fontSize = 12.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    val joined = ch.myStatus == "member" || ch.myStatus == "pending"
                    Text(
                        ch.stateLabel(), fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                        color = if (joined) Z.c.textDim else Color.White,
                        modifier = Modifier.clip(RoundedCornerShape(50))
                            .background(if (joined) Z.c.surfaceHi else Z.c.accent).padding(horizontal = 12.dp, vertical = 5.dp),
                    )
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------- Discover

@Composable
private fun DiscoverTab(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val list by core.discover.collectAsState()
    val meta by core.meta.collectAsState()
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(q, cat, reload) {
        delay(250)
        loading = true
        try {
            core.loadDiscover(q, cat)
            error = null
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            error = errMsg(e)
        }
        loading = false
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Text("Discover", color = Z.c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 4.dp))
        Text("Browse channels in your neighbourhood. Joining is always your choice.", color = Z.c.textDim, fontSize = 14.sp, modifier = Modifier.padding(horizontal = 20.dp))
        Spacer(Modifier.height(12.dp))
        ZField(q, { q = it }, "Search channels", Modifier.padding(horizontal = 20.dp), leading = Icons.Rounded.Search, imeAction = ImeAction.Search)
        LazyRow(contentPadding = PaddingValues(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(listOf("") + meta.categories) { c ->
                val sel = cat == c
                Text(
                    if (c.isEmpty()) "All" else c, fontSize = 13.sp, fontWeight = FontWeight.Medium,
                    color = if (sel) Color.White else Z.c.textDim,
                    modifier = Modifier.clip(RoundedCornerShape(50)).background(if (sel) Z.c.accent else Z.c.surface)
                        .border(1.dp, if (sel) Z.c.accent else Z.c.border, RoundedCornerShape(50))
                        .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 8.dp),
                )
            }
        }
        Spacer(Modifier.height(8.dp))
        ErrorBanner(error, Modifier.padding(horizontal = 20.dp))
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            if (loading && list.isEmpty()) {
                items(4) { SkeletonRow() }
            } else if (list.isEmpty()) {
                item {
                    EmptyState(
                        Icons.Rounded.Search, if (error != null) "Can't load channels" else "No channels found",
                        if (error != null) "Check your connection and try again." else "Try another search, or create the first channel for this topic.",
                    ) {
                        if (error != null) PrimaryButton("Retry", { reload++ }) else PrimaryButton("Create a channel", { nav.navigate("create") })
                    }
                }
            } else {
                items(list, key = { it.id }) { ch ->
                    ChannelCard(ch) { if (ch.isMember) nav.openChat("channel", ch.id) else nav.navigate("channel/${ch.id}") }
                }
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------- Chats

@Composable
private fun ChatsTab(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val dms by core.dms.collectAsState()
    val channels by core.myChannels.collectAsState()
    val onlineIds by core.onlineIds.collectAsState()
    val loaded by core.listsLoaded.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(start = 20.dp, end = 8.dp, top = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Chats", color = Z.c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ nav.navigate("people") }) { Icon(Icons.Rounded.PersonAdd, "New message", tint = Z.c.accentText) }
        }
        LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(horizontal = 20.dp, vertical = 8.dp)) {
            item { SectionHeader("Direct messages") }
            if (!loaded) items(3) { SkeletonRow() }
            else if (dms.isEmpty()) item {
                Text("No conversations yet. Tap the + button to message a neighbour.", color = Z.c.textDim, fontSize = 14.sp, modifier = Modifier.padding(bottom = 8.dp))
            }
            items(dms, key = { "d${it.id}" }) { d ->
                ConversationRow(d.peer.fullName, d.lastMessage, d.unread, d.peer.avatar, onlineIds.contains(d.peer.id), null, "Say hello") { nav.openChat("dm", d.id) }
            }
            item { SectionHeader("Channels", Modifier.padding(top = 12.dp)) }
            if (loaded && channels.isEmpty()) item {
                Text("You haven't joined any channels yet.", color = Z.c.textDim, fontSize = 14.sp)
            }
            items(channels, key = { "c${it.id}" }) { ch ->
                ConversationRow(ch.name, ch.lastMessage, ch.unread, null, null, ch.icon, "${ch.memberCount} members") { nav.openChat("channel", ch.id) }
            }
        }
    }
}

// ----------------------------------------------------------------------------------------------- Profile

@Composable
private fun ProfileTab(vm: AppViewModel, nav: NavHostController) {
    val core = vm.core
    val me by core.me.collectAsState()
    val conn by core.conn.state.collectAsState()
    val online by core.onlineCount.collectAsState()
    val channels by core.myChannels.collectAsState()
    val settings by core.settings.collectAsState()
    var confirmLogout by remember { mutableStateOf(false) }
    val since = remember(me) { me?.createdAt?.takeIf { it > 0 }?.let { java.text.SimpleDateFormat("d MMM yyyy", java.util.Locale.getDefault()).format(java.util.Date(it)) } ?: "—" }

    LazyColumn(Modifier.fillMaxSize().statusBarsPadding(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Spacer(Modifier.height(8.dp))
                Avatar(me?.fullName ?: "", me?.avatar, 104.dp)
                Spacer(Modifier.height(14.dp))
                Text(me?.fullName ?: "", color = Z.c.text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("@${me?.username ?: ""}", color = Z.c.textDim, fontSize = 15.sp)
                Spacer(Modifier.height(10.dp))
                ConnChip(conn, online)
                Spacer(Modifier.height(16.dp))
                SecondaryButton("Edit profile", { nav.navigate("editprofile") }, Modifier.width(200.dp), Icons.Rounded.Edit)
            }
        }
        item {
            ZCard(Modifier.fillMaxWidth()) {
                InfoRow("Name", me?.fullName ?: "")
                InfoRow("Username", "@${me?.username ?: ""}")
                InfoRow("Member since", since)
                InfoRow("Channels joined", channels.size.toString())
                InfoRow("Server", settings.address?.display ?: "—", last = true)
            }
        }
        item { SecondaryButton("Notifications", { nav.navigate("notifications") }, icon = Icons.Rounded.Notifications) }
        item { SecondaryButton("Settings", { nav.navigate("settings") }, icon = Icons.Rounded.Settings) }
        item { SecondaryButton("Log out", { confirmLogout = true }, icon = Icons.AutoMirrored.Rounded.Logout, danger = true) }
    }
    if (confirmLogout) {
        AlertDialog(
            onDismissRequest = { confirmLogout = false },
            containerColor = Z.c.surface,
            title = { Text("Log out?", color = Z.c.text) },
            text = { Text("Saved messages on this phone will be removed. You can sign in again any time.", color = Z.c.textDim) },
            confirmButton = { TextButton({ confirmLogout = false; vm.run { core.logout() } }) { Text("Log out", color = Z.c.error) } },
            dismissButton = { TextButton({ confirmLogout = false }) { Text("Cancel", color = Z.c.textDim) } },
        )
    }
}

@Composable
fun InfoRow(label: String, value: String, last: Boolean = false) {
    Row(Modifier.fillMaxWidth().padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Z.c.textDim, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(value, color = Z.c.text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
    if (!last) Box(Modifier.fillMaxWidth().height(1.dp).background(Z.c.border.copy(alpha = 0.6f)))
}
