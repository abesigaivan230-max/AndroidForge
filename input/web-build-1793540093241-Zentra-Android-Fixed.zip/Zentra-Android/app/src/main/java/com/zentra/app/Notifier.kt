package com.zentra.app

import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

/**
 * Local notifications only (no Firebase). They are shown while the app process is alive: in the foreground,
 * for a short while after it goes to the background, or all the time if the user turned on "Stay connected".
 * Android may pause the app otherwise, and then nothing can be delivered until it is opened again.
 */
class Notifier(private val ctx: Context) {
    companion object {
        const val CH_MESSAGES = "zentra_messages"
        const val CH_DMS = "zentra_dms"
        const val CH_REQUESTS = "zentra_requests"
        const val CH_CONNECTION = "zentra_connection"
        const val CH_SERVICE = "zentra_service"
        const val EXTRA_ROUTE = "open_route"
        const val SERVICE_NOTIFICATION_ID = 7001
    }

    private val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private var lastConnectionNotice = 0L

    fun createChannels() {
        if (Build.VERSION.SDK_INT < 26) return
        fun ch(id: String, name: String, imp: Int, desc: String) =
            NotificationChannel(id, name, imp).apply { description = desc }
        nm.createNotificationChannels(
            listOf(
                ch(CH_MESSAGES, "Channel messages", NotificationManager.IMPORTANCE_HIGH, "New messages in your channels"),
                ch(CH_DMS, "Direct messages", NotificationManager.IMPORTANCE_HIGH, "Private conversations"),
                ch(CH_REQUESTS, "Requests and membership", NotificationManager.IMPORTANCE_DEFAULT, "Join requests and decisions"),
                ch(CH_CONNECTION, "Connection", NotificationManager.IMPORTANCE_LOW, "When the server connection is interrupted"),
                ch(CH_SERVICE, "Stay connected", NotificationManager.IMPORTANCE_MIN, "Shown while Zentra keeps its connection open"),
            )
        )
    }

    fun serviceNotification() =
        NotificationCompat.Builder(ctx, CH_SERVICE)
            .setSmallIcon(R.drawable.ic_stat_zentra)
            .setContentTitle(ctx.getString(R.string.fgs_title))
            .setContentText(ctx.getString(R.string.fgs_text))
            .setOngoing(true)
            .setSilent(true)
            .setContentIntent(openIntent(SERVICE_NOTIFICATION_ID, null))
            .addAction(0, ctx.getString(R.string.fgs_stop), stopIntent())
            .build()

    private fun stopIntent(): PendingIntent {
        val i = Intent(ctx, ConnectionService::class.java).setAction(ConnectionService.ACTION_STOP)
        return PendingIntent.getService(ctx, 1, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun openIntent(requestCode: Int, route: String?): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
            if (route != null) putExtra(EXTRA_ROUTE, route)
        }
        return PendingIntent.getActivity(ctx, requestCode, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    @SuppressLint("MissingPermission")
    fun show(id: Int, channel: String, title: String, text: String, route: String?) {
        val compat = NotificationManagerCompat.from(ctx)
        if (!compat.areNotificationsEnabled()) return
        val n = NotificationCompat.Builder(ctx, channel)
            .setSmallIcon(R.drawable.ic_stat_zentra)
            .setColor(0xFF087BFF.toInt())
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setAutoCancel(true)
            .setPriority(if (channel == CH_CONNECTION) NotificationCompat.PRIORITY_LOW else NotificationCompat.PRIORITY_HIGH)
            .setCategory(if (channel == CH_CONNECTION) NotificationCompat.CATEGORY_STATUS else NotificationCompat.CATEGORY_MESSAGE)
            .setContentIntent(openIntent(id, route))
            .build()
        try {
            compat.notify(id, n)
        } catch (_: SecurityException) {
        }
    }

    fun message(target: String, targetId: Long, title: String, text: String) {
        val id = (if (target == "dm") 200_000 else 100_000) + (targetId % 90_000).toInt()
        show(id, if (target == "dm") CH_DMS else CH_MESSAGES, title, text, "chat/$target/$targetId")
    }

    fun connectionInterrupted() {
        val now = System.currentTimeMillis()
        if (now - lastConnectionNotice < 10 * 60_000L) return
        lastConnectionNotice = now
        show(300_001, CH_CONNECTION, "Zentra connection interrupted",
            "Trying to reconnect to your neighbourhood server.", null)
    }

    fun cancelAll() {
        nm.cancelAll()
    }
}
