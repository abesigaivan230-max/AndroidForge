package com.zentra.app.data

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.JsonObject

/** JSON shapes returned by the Zentra server (see zentra-server/docs/API.md). */

@Serializable
data class User(
    val id: Long,
    val username: String = "",
    @SerialName("full_name") val fullName: String = "",
    val online: Boolean = false,
    @SerialName("last_seen_at") val lastSeenAt: Long? = null,
    @SerialName("created_at") val createdAt: Long = 0,
    val avatar: String? = null,
    val role: String? = null,
    @SerialName("joined_at") val joinedAt: Long? = null,
)

@Serializable
data class AuthResponse(val token: String, val user: User)

@Serializable
data class OwnerRef(
    val id: Long,
    val username: String = "",
    @SerialName("full_name") val fullName: String = "",
)

@Serializable
data class LastMsg(
    val seq: Long = 0,
    val body: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
    @SerialName("sender_name") val senderName: String? = null,
    @SerialName("sender_id") val senderId: Long? = null,
)

@Serializable
data class Channel(
    val id: Long,
    val name: String,
    val description: String = "",
    val category: String = "General",
    val icon: String = "chat",
    @SerialName("is_private") val isPrivate: Boolean = false,
    @SerialName("created_at") val createdAt: Long = 0,
    val owner: OwnerRef,
    @SerialName("member_count") val memberCount: Int = 0,
    @SerialName("online_count") val onlineCount: Int = 0,
    @SerialName("my_status") val myStatus: String = "none",
    @SerialName("my_role") val myRole: String? = null,
    val unread: Int = 0,
    @SerialName("last_message") val lastMessage: LastMsg? = null,
    @SerialName("pending_requests") val pendingRequests: Int = 0,
    @SerialName("retry_at") val retryAt: Long? = null,
) {
    val isMember: Boolean get() = myStatus == "member"
}

@Serializable
data class ChannelList(val channels: List<Channel> = emptyList())

@Serializable
data class Dm(
    val id: Long,
    @SerialName("created_at") val createdAt: Long = 0,
    val peer: User,
    val unread: Int = 0,
    @SerialName("last_message") val lastMessage: LastMsg? = null,
)

@Serializable
data class DmList(val conversations: List<Dm> = emptyList())

@Serializable
data class UserList(val users: List<User> = emptyList())

@Serializable
data class MemberList(val members: List<User> = emptyList())

@Serializable
data class JoinRequest(
    val id: Long,
    @SerialName("channel_id") val channelId: Long,
    @SerialName("channel_name") val channelName: String = "",
    @SerialName("created_at") val createdAt: Long = 0,
    val user: User,
)

@Serializable
data class RequestList(val requests: List<JoinRequest> = emptyList())

@Serializable
data class JoinResult(
    val status: String = "",
    @SerialName("already_pending") val alreadyPending: Boolean = false,
    @SerialName("request_id") val requestId: Long? = null,
)

@Serializable
data class ServerNotification(
    val id: Long,
    val type: String,
    val title: String = "",
    val body: String = "",
    val data: JsonObject? = null,
    @SerialName("created_at") val createdAt: Long = 0,
    val read: Boolean = false,
)

@Serializable
data class NotificationList(val notifications: List<ServerNotification> = emptyList())

@Serializable
data class WireMessage(
    val id: String,
    val seq: Long = 0,
    val target: String,
    @SerialName("target_id") val targetId: Long,
    @SerialName("sender_id") val senderId: Long,
    @SerialName("sender_name") val senderName: String = "",
    val body: String,
    @SerialName("created_at") val createdAt: Long = 0,
    val status: String = "sent",
)

@Serializable
data class MessagePage(
    val messages: List<WireMessage> = emptyList(),
    @SerialName("has_more") val hasMore: Boolean = false,
    @SerialName("server_seq") val serverSeq: Long = 0,
)

@Serializable
data class SendResult(val message: WireMessage, val duplicate: Boolean = false)

@Serializable
data class Health(
    val status: String = "",
    val app: String = "",
    val version: String = "",
    @SerialName("server_id") val serverId: String = "",
    val time: Long = 0,
    @SerialName("online_users") val onlineUsers: Int = 0,
    @SerialName("registration_code_required") val registrationCodeRequired: Boolean = false,
)

@Serializable
data class Meta(
    val categories: List<String> = emptyList(),
    val icons: List<String> = emptyList(),
)

@Serializable
data class PresenceList(
    @SerialName("online_ids") val onlineIds: List<Long> = emptyList(),
    val count: Int = 0,
)

/** Where the server lives on the local network. */
data class ServerAddress(val host: String, val port: Int) {
    val baseUrl: String get() = "http://$host:$port"
    val wsUrl: String get() = "ws://$host:$port/ws"
    val display: String get() = "$host:$port"
}

val FALLBACK_CATEGORIES = listOf(
    "General", "Community", "Security", "Market", "Farming", "Health",
    "Education", "Faith", "Sports", "Events", "Youth", "Other",
)
val ICON_KEYS = listOf(
    "chat", "home", "shield", "store", "build", "event",
    "heart", "alert", "phone", "place", "person", "star",
)
