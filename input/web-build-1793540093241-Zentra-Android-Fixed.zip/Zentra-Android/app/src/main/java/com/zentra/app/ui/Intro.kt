package com.zentra.app.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Groups
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.WifiTethering
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.zentra.app.R
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/** Animated splash: the official logo fades in over expanding "wireless" rings, then hands over to the next screen. */
@Composable
fun SplashScreen(returning: Boolean, onFinish: () -> Unit) {
    val alpha = remember { Animatable(0f) }
    val scale = remember { Animatable(0.86f) }
    var finished by remember { mutableStateOf(false) }
    fun finish() {
        if (!finished) {
            finished = true
            onFinish()
        }
    }
    val t = rememberInfiniteTransition(label = "splash")
    val ring by t.animateFloat(0f, 1f, infiniteRepeatable(tween(2400, easing = LinearEasing)), label = "ring")
    LaunchedEffect(Unit) {
        launch { alpha.animateTo(1f, tween(650)) }
        launch { scale.animateTo(1f, spring(dampingRatio = 0.55f, stiffness = Spring.StiffnessLow)) }
        delay(if (returning) 1500 else 2300)
        finish()
    }
    val signal = Z.c.signal
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF050D25), Color(0xFF071A4F))))
            .clickable(onClick = ::finish),
        contentAlignment = Alignment.Center,
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.46f)
            val maxR = size.minDimension * 0.75f
            for (i in 0 until 3) {
                val q = (ring + i / 3f) % 1f
                drawCircle(signal.copy(alpha = (1f - q) * 0.30f), maxR * (0.18f + 0.82f * q), center, style = Stroke(2.dp.toPx()))
            }
            drawCircle(
                Brush.radialGradient(listOf(Color(0xFF0A3A9E).copy(alpha = 0.5f), Color.Transparent), center, size.minDimension * 0.55f),
                size.minDimension * 0.55f, center,
            )
        }
        Image(
            painterResource(R.drawable.logo_full), "Zentra",
            Modifier.fillMaxWidth(0.72f).aspectRatio(900f / 882f)
                .graphicsLayer { this.alpha = alpha.value; scaleX = scale.value; scaleY = scale.value },
        )
    }
}

private data class IntroPage(val icon: ImageVector, val title: String, val body: String)

private val introPages = listOf(
    IntroPage(
        Icons.Rounded.WifiTethering, "Chat without mobile data",
        "Zentra runs on your neighbourhood Wi-Fi. No airtime, no bundles and no internet connection needed.",
    ),
    IntroPage(
        Icons.Rounded.Groups, "Connect with your neighbourhood",
        "Join local channels for security, markets, events, church, school and more, and talk to the people next door.",
    ),
    IntroPage(
        Icons.Rounded.Lock, "Private channels and direct chats",
        "Channel owners approve who joins a private channel, and you can message any neighbour one to one.",
    ),
)

@Composable
fun OnboardingScreen(onDone: () -> Unit) {
    val pager = rememberPagerState(pageCount = { introPages.size })
    val scope = rememberCoroutineScope()
    val last = pager.currentPage == introPages.size - 1
    Column(Modifier.fillMaxSize().background(Z.c.bg).statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.End) {
            Text(
                "Skip", color = Z.c.textDim, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.clip(RoundedCornerShape(10.dp)).clickable(onClick = onDone).padding(horizontal = 12.dp, vertical = 8.dp),
            )
        }
        HorizontalPager(pager, Modifier.weight(1f)) { page ->
            val p = introPages[page]
            val offset = (pager.currentPage - page) + pager.currentPageOffsetFraction
            Column(
                Modifier.fillMaxSize().padding(horizontal = 32.dp)
                    .graphicsLayer { alpha = 1f - abs(offset).coerceIn(0f, 1f); translationX = offset * -80f },
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                IntroIllustration(p.icon)
                Spacer(Modifier.height(36.dp))
                Text(p.title, color = Z.c.text, fontSize = 26.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                Spacer(Modifier.height(12.dp))
                Text(p.body, color = Z.c.textDim, fontSize = 16.sp, textAlign = TextAlign.Center, lineHeight = 24.sp)
            }
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 16.dp), horizontalArrangement = Arrangement.Center) {
            for (i in introPages.indices) {
                val sel = pager.currentPage == i
                val w by animateDpAsState(if (sel) 26.dp else 8.dp, spring(stiffness = Spring.StiffnessMediumLow), label = "dotW")
                val col by animateColorAsState(if (sel) Z.c.accent else Z.c.border, tween(250), label = "dotC")
                Box(Modifier.padding(horizontal = 4.dp).height(8.dp).size(w, 8.dp).clip(CircleShape).background(col))
            }
        }
        PrimaryButton(
            if (last) "Get started" else "Continue",
            onClick = { if (last) onDone() else scope.launch { pager.animateScrollToPage(pager.currentPage + 1) } },
            modifier = Modifier.padding(horizontal = 24.dp).padding(bottom = 24.dp),
        )
    }
}

@Composable
private fun IntroIllustration(icon: ImageVector) {
    val t = rememberInfiniteTransition(label = "intro")
    val pulse by t.animateFloat(0.92f, 1.08f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse")
    val spin by t.animateFloat(0f, 360f, infiniteRepeatable(tween(14000, easing = LinearEasing)), label = "spin")
    val c = Z.c
    Box(Modifier.size(240.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2f
            drawCircle(c.border.copy(alpha = 0.6f), r * 0.98f, style = Stroke(1.5.dp.toPx()))
            drawCircle(c.accent.copy(alpha = 0.10f), r * 0.78f * pulse)
            drawCircle(c.accent.copy(alpha = 0.16f), r * 0.58f)
            // a small satellite dot orbiting the ring, echoing the orbit swoosh of the logo
            val a = Math.toRadians(spin.toDouble())
            val p = Offset(center.x + (r * 0.98f * Math.cos(a)).toFloat(), center.y + (r * 0.98f * Math.sin(a)).toFloat())
            drawCircle(c.signal, 5.dp.toPx(), p)
        }
        Box(Modifier.size(104.dp).clip(CircleShape).background(AccentGradient), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = Color.White, modifier = Modifier.size(52.dp))
        }
    }
}
