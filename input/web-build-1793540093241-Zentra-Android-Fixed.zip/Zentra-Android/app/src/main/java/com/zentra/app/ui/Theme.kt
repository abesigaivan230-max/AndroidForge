package com.zentra.app.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.core.view.WindowCompat
import com.zentra.app.R

/** Zentra colour tokens. Dark is the default; light is optional. See branding/README.md. */
@Immutable
data class ZColors(
    val isDark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHi: Color,
    val border: Color,
    val text: Color,
    val textDim: Color,
    val accent: Color,
    val accentText: Color,
    val signal: Color,
    val success: Color,
    val warning: Color,
    val error: Color,
)

val DarkZ = ZColors(
    isDark = true,
    bg = Color(0xFF050D25), surface = Color(0xFF0B1736), surfaceHi = Color(0xFF101F45),
    border = Color(0xFF23365B), text = Color(0xFFFFFFFF), textDim = Color(0xFFA9B8D0),
    accent = Color(0xFF087BFF), accentText = Color(0xFF16DDF5), signal = Color(0xFF16DDF5),
    success = Color(0xFF2ED47A), warning = Color(0xFFF5B942), error = Color(0xFFFF5C6C),
)

val LightZ = ZColors(
    isDark = false,
    bg = Color(0xFFF5F8FF), surface = Color(0xFFFFFFFF), surfaceHi = Color(0xFFEAF0FC),
    border = Color(0xFFD3DDF0), text = Color(0xFF0B1736), textDim = Color(0xFF4A5B7A),
    accent = Color(0xFF087BFF), accentText = Color(0xFF0560D6), signal = Color(0xFF0A9FB8),
    success = Color(0xFF12A150), warning = Color(0xFFB7791F), error = Color(0xFFD92D43),
)

val LocalZ = staticCompositionLocalOf { DarkZ }

object Z {
    val c: ZColors
        @Composable @ReadOnlyComposable get() = LocalZ.current
}

/** The only gradient in the app: taken from the logo ribbon (cyan -> electric blue -> indigo). */
val BrandGradient = Brush.linearGradient(listOf(Color(0xFF39F4FE), Color(0xFF0076FD), Color(0xFF4B7DFD)))
val AccentGradient = Brush.horizontalGradient(listOf(Color(0xFF0A8CFF), Color(0xFF0A5BEF)))

val Inter = FontFamily(
    Font(R.font.inter_regular, FontWeight.Normal),
    Font(R.font.inter_medium, FontWeight.Medium),
    Font(R.font.inter_semibold, FontWeight.SemiBold),
    Font(R.font.inter_bold, FontWeight.Bold),
)

private fun TextStyle.i() = copy(fontFamily = Inter)

private fun interTypography(): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.i(), displayMedium = d.displayMedium.i(), displaySmall = d.displaySmall.i(),
        headlineLarge = d.headlineLarge.i(), headlineMedium = d.headlineMedium.i(), headlineSmall = d.headlineSmall.i(),
        titleLarge = d.titleLarge.i(), titleMedium = d.titleMedium.i(), titleSmall = d.titleSmall.i(),
        bodyLarge = d.bodyLarge.i(), bodyMedium = d.bodyMedium.i(), bodySmall = d.bodySmall.i(),
        labelLarge = d.labelLarge.i(), labelMedium = d.labelMedium.i(), labelSmall = d.labelSmall.i(),
    )
}

@Composable
fun ZentraTheme(theme: String, content: @Composable () -> Unit) {
    val dark = when (theme) {
        "dark" -> true
        "light" -> false
        else -> isSystemInDarkTheme()
    }
    val z = if (dark) DarkZ else LightZ
    val scheme = if (dark) {
        darkColorScheme(
            primary = z.accent, onPrimary = Color.White, secondary = z.signal, background = z.bg, onBackground = z.text,
            surface = z.surface, onSurface = z.text, surfaceVariant = z.surfaceHi, onSurfaceVariant = z.textDim,
            outline = z.border, error = z.error,
        )
    } else {
        lightColorScheme(
            primary = z.accent, onPrimary = Color.White, secondary = z.signal, background = z.bg, onBackground = z.text,
            surface = z.surface, onSurface = z.text, surfaceVariant = z.surfaceHi, onSurfaceVariant = z.textDim,
            outline = z.border, error = z.error,
        )
    }
    val view = LocalView.current
    SideEffect {
        val window = (view.context as? Activity)?.window
        if (window != null) {
            val c = WindowCompat.getInsetsController(window, view)
            c.isAppearanceLightStatusBars = !dark
            c.isAppearanceLightNavigationBars = !dark
        }
    }
    CompositionLocalProvider(LocalZ provides z) {
        MaterialTheme(colorScheme = scheme, typography = interTypography(), content = content)
    }
}
