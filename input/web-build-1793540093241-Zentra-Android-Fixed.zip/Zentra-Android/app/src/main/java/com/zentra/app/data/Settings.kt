package com.zentra.app.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

private val Context.zentraStore by preferencesDataStore(name = "zentra_settings")

/** Everything the app remembers between launches. The session token is encrypted with an Android Keystore key. */
data class Settings(
    val loaded: Boolean = false,
    val onboarded: Boolean = false,
    val host: String = "",
    val port: Int = 8000,
    val token: String? = null,
    val user: User? = null,
    val theme: String = "system", // system | dark | light
    val notifMessages: Boolean = true,
    val notifDms: Boolean = true,
    val notifRequests: Boolean = true,
    val notifConnection: Boolean = true,
    val stayConnected: Boolean = false,
) {
    val address: ServerAddress? get() = if (host.isBlank()) null else ServerAddress(host, port)
    val loggedIn: Boolean get() = token != null && user != null
}

class SettingsStore(private val ctx: Context) {
    private object K {
        val onboarded = booleanPreferencesKey("onboarded")
        val host = stringPreferencesKey("server_host")
        val port = intPreferencesKey("server_port")
        val token = stringPreferencesKey("session_token_enc")
        val user = stringPreferencesKey("user_json")
        val theme = stringPreferencesKey("theme")
        val nMsg = booleanPreferencesKey("n_messages")
        val nDm = booleanPreferencesKey("n_dms")
        val nReq = booleanPreferencesKey("n_requests")
        val nConn = booleanPreferencesKey("n_connection")
        val stay = booleanPreferencesKey("stay_connected")
    }

    private val json = Json { ignoreUnknownKeys = true; coerceInputValues = true }

    val flow: Flow<Settings> = ctx.zentraStore.data.map { p ->
        val token = p[K.token]?.let { SecureBox.decrypt(it) }
        val user = p[K.user]?.let { runCatching { json.decodeFromString<User>(it) }.getOrNull() }
        Settings(
            loaded = true,
            onboarded = p[K.onboarded] ?: false,
            host = p[K.host] ?: "",
            port = p[K.port] ?: 8000,
            token = token,
            user = if (token != null) user else null,
            theme = p[K.theme] ?: "system",
            notifMessages = p[K.nMsg] ?: true,
            notifDms = p[K.nDm] ?: true,
            notifRequests = p[K.nReq] ?: true,
            notifConnection = p[K.nConn] ?: true,
            stayConnected = p[K.stay] ?: false,
        )
    }

    private suspend fun edit(block: (MutablePreferences) -> Unit) {
        ctx.zentraStore.edit { block(it) }
    }

    suspend fun setOnboarded() = edit { it[K.onboarded] = true }
    suspend fun saveServer(a: ServerAddress) = edit { it[K.host] = a.host; it[K.port] = a.port }
    /** Returns false (and stores nothing) if the Android Keystore can't encrypt the token. */
    suspend fun saveSession(token: String, user: User): Boolean {
        val encrypted = SecureBox.encrypt(token) ?: return false
        // The profile picture can be large; it is re-downloaded from /api/me instead of being stored here.
        edit {
            it[K.token] = encrypted
            it[K.user] = json.encodeToString(user.copy(avatar = null))
        }
        return true
    }

    suspend fun saveUser(user: User) = edit { it[K.user] = json.encodeToString(user.copy(avatar = null)) }
    suspend fun clearSession() = edit { it.remove(K.token); it.remove(K.user) }
    suspend fun setTheme(v: String) = edit { it[K.theme] = v }
    suspend fun setNotifMessages(v: Boolean) = edit { it[K.nMsg] = v }
    suspend fun setNotifDms(v: Boolean) = edit { it[K.nDm] = v }
    suspend fun setNotifRequests(v: Boolean) = edit { it[K.nReq] = v }
    suspend fun setNotifConnection(v: Boolean) = edit { it[K.nConn] = v }
    suspend fun setStayConnected(v: Boolean) = edit { it[K.stay] = v }
}

/** AES-256-GCM using a key that never leaves the Android Keystore. Returns null if the Keystore misbehaves. */
object SecureBox {
    private const val ALIAS = "zentra_session_key"
    private const val PROVIDER = "AndroidKeyStore"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance(PROVIDER).apply { load(null) }
        val existing = ks.getKey(ALIAS, null) as? SecretKey
        if (existing != null) return existing
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, PROVIDER)
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun encrypt(plain: String): String? = try {
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key())
        val out = c.iv + c.doFinal(plain.toByteArray(Charsets.UTF_8))
        Base64.encodeToString(out, Base64.NO_WRAP)
    } catch (e: Exception) {
        null
    }

    fun decrypt(encoded: String): String? = try {
        val all = Base64.decode(encoded, Base64.NO_WRAP)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12)))
        String(c.doFinal(all.copyOfRange(12, all.size)), Charsets.UTF_8)
    } catch (e: Exception) {
        null
    }
}
