# Known limitations

- **No encryption on the Wi-Fi.** The app uses plain HTTP/WebSocket to the local server. Anyone who can capture traffic on the same Wi-Fi could read messages or steal a session token. Use a Wi-Fi password (WPA2/WPA3). It is *not* end-to-end encrypted and must not be described as such. A pinned-certificate HTTPS mode is a planned improvement.
- **One server is the whole system.** If the server is off or unreachable, nobody can chat. Access points only extend Wi-Fi coverage; they do not create a phone-to-phone mesh.
- **Background delivery is best effort.** Notifications are local (no Firebase). The app keeps its connection while visible and for about a minute after. Turn on *Settings → Stay connected* to keep it alive with a permanent notification; Android battery savers can still stop it.
- **mDNS can be blocked** by some access points/guest networks. Manual IP and QR always work.
- Text messages only (max 2000 characters). No images/files, edit/delete, reactions or typing indicators yet.
- Channel messages show Sending / Sent / Failed. Delivered/Read ticks exist for direct messages only.
- While the app is open it binds its traffic to Wi-Fi so a Wi-Fi network without internet still works; other apps are not affected.
- English only.
