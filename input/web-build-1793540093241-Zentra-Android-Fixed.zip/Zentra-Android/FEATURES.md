# Zentra Android: implemented and outstanding

## Implemented
* Animated splash (your logo over expanding wireless rings), 3-page onboarding with skip/continue.
* Connection screen: Wi-Fi status, mDNS search, saved-server retry, manual IP, QR scan, retry, six states
  (Searching / Found / Connecting / Connected / Interrupted / Unavailable). Success only after `/api/health`
  identifies a Zentra server. Shows the server IP:port.
* Register (name, username, password + confirm, optional picture, optional neighbourhood code), login,
  password visibility toggle, validation, error messages, loading states. Session token stored encrypted with an
  Android Keystore key; account persists across restarts.
* Home: greeting, avatar, live status card, online count, pending-request banner, quick actions, My channels,
  Recent conversations, suggested channels, notifications bell, settings.
* Discover: search + category filters, cards with icon/description/owner/members/online/private-public,
  channel info visible without joining.
* Create channel (name, description, category, icon, public/private); creator becomes owner.
* Private channels: join request, owner notification, owner reviews requests, approve/reject, remove members,
  edit channel, delete channel, transfer ownership (with confirmation). All rules enforced by the server.
* Real-time chat over WebSocket: names, avatars, timestamps, day separators, status (sending / sent / delivered /
  read for DMs / failed + tap to retry), unread counters, history paging, jump-to-latest, online indicators.
* Offline: messages are saved in Room, queued while disconnected, re-sent with the same id after reconnect
  (server de-duplicates), missed messages are synced after reconnect. History readable offline.
* Direct messages: user search, start conversation, list with unread counters and online dots.
* Local notifications (no Firebase): channel messages, DMs, new conversations, join requests, approvals,
  rejections, removals, connection interruptions. Per-type switches in Settings.
* Optional "Stay connected" foreground service (off by default).
* Profile + edit (name, picture), settings (system/dark/light theme, notification switches, server details,
  reconnect, change server, change password, privacy notice, about, logout).
* Wi-Fi binding so a Wi-Fi without internet is still used instead of mobile data.

## Outstanding / not built
End-to-end encryption · HTTPS/WSS with pinned certificate (planned: fingerprint in the QR code) · images, files,
voice notes · typing indicators · read receipts in channels · message edit/delete/reactions · unread divider line ·
push-style delivery when Android has frozen the app · localisation beyond English · tablet layouts ·
tests that run on a device (Room, UI).
