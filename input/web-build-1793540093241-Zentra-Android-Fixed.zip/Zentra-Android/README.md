# Zentra for Android

**Your Neighbourhood. Connected.** Chat with the people on your local Wi-Fi: no mobile data, no airtime, no internet.

Zentra has two parts:

| Part | What it is |
|---|---|
| `Zentra-Android` (this project) | The Android app (Kotlin, Jetpack Compose, Room, DataStore, OkHttp WebSocket, NSD/mDNS) |
| `Zentra-Server` (separate zip) | The local FastAPI server that every phone connects to. **The app does nothing without it.** |

## Build the APK with AndroidForge (GitHub)
1. Create an empty GitHub repository and upload the **contents** of this folder (so `gradlew`, `app/`, `.github/` are at the repo root).
2. Open the **Actions** tab, choose **Build Zentra APK**, press **Run workflow**.
3. When it finishes, download the `zentra-apks` artifact. It contains `app-debug.apk` and `app-release.apk`.
   Both install on a phone (the release one is signed with the debug key unless you set `ZENTRA_KEYSTORE`, `ZENTRA_KEYSTORE_PASSWORD`, `ZENTRA_KEY_ALIAS`, `ZENTRA_KEY_PASSWORD`).

Or locally with Android Studio (Ladybug or newer, JDK 17): open the folder, let it sync, press Run. Command line: `./gradlew assembleDebug`.

Pinned versions: AGP 8.7.3, Gradle 8.10.2, Kotlin 2.0.21, KSP 2.0.21-1.0.28, Compose BOM 2024.12.01, Room 2.6.1, OkHttp 4.12.0. minSdk 24, target/compile SDK 35.

## First run
1. Start the server on a computer or Raspberry Pi that is on the same Wi-Fi as the phones (see the server README).
2. Open Zentra → it looks for the server by mDNS. If it can't find it, tap **Enter IP address** or **Scan server QR code** (the QR is on the server's admin page).
3. Create an account, then create or join a channel.

## What is in the app
Splash and onboarding · connection screen (Wi-Fi status, mDNS, manual IP, QR, verified health check, retry) · register/login with encrypted session storage · home dashboard · discover channels with search and categories · create channel · **private channels with owner-only approval** (requests, approve, reject, remove members, transfer ownership, edit, delete) · real-time channel chat and direct messages over WebSocket · offline outbox with automatic re-send and resync, duplicate-proof by message id · unread counters · presence · local notifications · profile · settings (theme, notifications, server details, reconnect, change password, "Stay connected").

## Honest limits
See `KNOWN_LIMITATIONS.md` and `TESTING_REPORT.md`. Short version: traffic on the local Wi-Fi is **not encrypted** and the app is **not end-to-end encrypted**; background notifications only work while the app is alive or "Stay connected" is on; this Android project has **not been compiled or run on a phone by me** because the build environment had no access to Google's Maven repository.
