# Testing report (Android project)

| Check | Result |
|---|---|
| Kotlin syntax of all 22 source files (Kotlin 2.0.21 compiler front-end) | **Passed**: no syntax errors |
| Cross-file references (every `core.*` member used by screens exists in `Core`) | **Passed** (scripted check) |
| Full compilation, resource linking, Room/KSP, lint, APK build | **NOT RUN**: the sandbox could not reach Google Maven/Gradle services, so the Android SDK and dependencies could not be downloaded. The GitHub workflow is the first real build. |
| Running on a phone, mDNS discovery, QR scan, notifications, Wi-Fi roaming | **NOT RUN** (needs real devices) |
| Server API the app talks to | **Passed**: 50 automated tests in Zentra-Server (auth, channels, private-channel approval and unauthorised-approval rejection, DMs, WebSocket, persistence, concurrency) |

If the first GitHub build fails, send me the error log from the Actions run and I will fix it.
