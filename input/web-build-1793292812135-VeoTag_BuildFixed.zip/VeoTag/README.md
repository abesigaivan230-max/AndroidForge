# VeoTag

Android app for showcasing innovation projects via QR codes.

## Supabase (configured)

- URL: `https://uujagbsiaaweuzxbcglw.supabase.co`
- Publishable key: embedded as BuildConfig default
- Bucket: `veotag-videos`

## Build requirements

- JDK 17
- Android SDK 35
- Android Gradle Plugin 8.7.2 / Gradle 8.9

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk

./gradlew assembleRelease
# APK: app/build/outputs/apk/release/app-release-unsigned.apk
```

Optional overrides in `local.properties`:

```
sdk.dir=/path/to/Android/sdk
SUPABASE_URL=https://uujagbsiaaweuzxbcglw.supabase.co
SUPABASE_ANON_KEY=sb_publishable_jY6EDfuBOI3OdsSSKvnILA_JvVbFoKX
```

## AndroidForge

Upload this ZIP to your workflow. Application ID: `com.veotag.app`.
Release minify is **disabled** for CI reliability.

## Admin

Tap the VeoTag logo five times → login with a Supabase Auth user that exists in `admin_users`.
