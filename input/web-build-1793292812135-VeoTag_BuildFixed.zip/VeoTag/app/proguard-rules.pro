-keepattributes *Annotation*, InnerClasses, Signature, EnclosingMethod
-keep class com.veotag.app.data.model.** { *; }
-keepclassmembers class com.veotag.app.data.model.** { *; }

# kotlinx serialization
-keep,includedescriptorclasses class com.veotag.app.**$$serializer { *; }
-keepclassmembers class com.veotag.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.veotag.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-dontnote kotlinx.serialization.AnnotationsKt

# Supabase / Ktor
-keep class io.github.jan.supabase.** { *; }
-keep class io.ktor.** { *; }
-dontwarn io.ktor.**
-dontwarn io.github.jan.supabase.**

# Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# ML Kit / CameraX
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**
-keep class androidx.camera.** { *; }

# ZXing
-keep class com.google.zxing.** { *; }
