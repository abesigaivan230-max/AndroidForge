package com.veotag.app.ui.navigation

import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.veotag.app.ui.screens.admin.AdminDashboardScreen
import com.veotag.app.ui.screens.admin.AdminLoginScreen
import com.veotag.app.ui.screens.admin.ManageProjectsScreen
import com.veotag.app.ui.screens.admin.ProjectFormScreen
import com.veotag.app.ui.screens.explore.ExploreScreen
import com.veotag.app.ui.screens.home.HomeScreen
import com.veotag.app.ui.screens.project.ProjectDetailScreen
import com.veotag.app.ui.screens.scan.ScanScreen
import com.veotag.app.ui.theme.BluePrimary

sealed class Screen(val route: String) {
    data object Home : Screen("home")
    data object Explore : Screen("explore")
    data object Scan : Screen("scan")
    data object ProjectDetail : Screen("project/{projectId}") {
        fun create(id: String) = "project/$id"
    }
    data object AdminLogin : Screen("admin/login")
    data object AdminDashboard : Screen("admin/dashboard")
    data object ManageProjects : Screen("admin/manage")
    data object AddProject : Screen("admin/add")
    data object EditProject : Screen("admin/edit/{projectId}") {
        fun create(id: String) = "admin/edit/$id"
    }
}

data class BottomNavItem(
    val screen: Screen,
    val label: String,
    val icon: ImageVector
)

val bottomNavItems = listOf(
    BottomNavItem(Screen.Home, "Home", Icons.Default.Home),
    BottomNavItem(Screen.Explore, "Explore", Icons.Default.Explore),
    BottomNavItem(Screen.Scan, "Scan", Icons.Default.QrCodeScanner)
)

@Composable
fun VeoTagNavHost() {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination

    val showBottomBar = bottomNavItems.any { item ->
        currentDestination?.hierarchy?.any { it.route == item.screen.route } == true
    }

    Scaffold(
        bottomBar = {
            if (showBottomBar) {
                NavigationBar {
                    bottomNavItems.forEach { item ->
                        val selected = currentDestination?.hierarchy?.any {
                            it.route == item.screen.route
                        } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(item.screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = BluePrimary,
                                selectedTextColor = BluePrimary,
                                indicatorColor = BluePrimary.copy(alpha = 0.12f)
                            )
                        )
                    }
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Home.route,
            modifier = Modifier.padding(padding),
            enterTransition = {
                fadeIn(tween(220)) + slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(220)
                )
            },
            exitTransition = {
                fadeOut(tween(180)) + slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.Start,
                    tween(180)
                )
            },
            popEnterTransition = {
                fadeIn(tween(220)) + slideIntoContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    tween(220)
                )
            },
            popExitTransition = {
                fadeOut(tween(180)) + slideOutOfContainer(
                    AnimatedContentTransitionScope.SlideDirection.End,
                    tween(180)
                )
            }
        ) {
            composable(Screen.Home.route) {
                HomeScreen(
                    onScanClick = {
                        navController.navigate(Screen.Scan.route) {
                            launchSingleTop = true
                        }
                    },
                    onProjectClick = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id))
                    },
                    onSearchClick = {
                        navController.navigate(Screen.Explore.route) {
                            launchSingleTop = true
                        }
                    },
                    onAdminShortcut = {
                        navController.navigate(Screen.AdminLogin.route)
                    }
                )
            }
            composable(Screen.Explore.route) {
                ExploreScreen(
                    onProjectClick = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id))
                    }
                )
            }
            composable(Screen.Scan.route) {
                ScanScreen(
                    onProjectScanned = { id ->
                        navController.navigate(Screen.ProjectDetail.create(id)) {
                            launchSingleTop = true
                        }
                    },
                    onAdminShortcut = {
                        navController.navigate(Screen.AdminLogin.route)
                    }
                )
            }
            composable(
                route = Screen.ProjectDetail.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("projectId") ?: return@composable
                ProjectDetailScreen(
                    projectId = id,
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AdminLogin.route) {
                AdminLoginScreen(
                    onLoginSuccess = {
                        navController.navigate(Screen.AdminDashboard.route) {
                            popUpTo(Screen.AdminLogin.route) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AdminDashboard.route) {
                AdminDashboardScreen(
                    onAddProject = { navController.navigate(Screen.AddProject.route) },
                    onManageProjects = { navController.navigate(Screen.ManageProjects.route) },
                    onLogout = {
                        navController.navigate(Screen.Home.route) {
                            popUpTo(0) { inclusive = true }
                        }
                    },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.ManageProjects.route) {
                ManageProjectsScreen(
                    onEdit = { id -> navController.navigate(Screen.EditProject.create(id)) },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(Screen.AddProject.route) {
                ProjectFormScreen(
                    projectId = null,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
            composable(
                route = Screen.EditProject.route,
                arguments = listOf(navArgument("projectId") { type = NavType.StringType })
            ) { backStack ->
                val id = backStack.arguments?.getString("projectId")
                ProjectFormScreen(
                    projectId = id,
                    onSaved = { navController.popBackStack() },
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}
