package com.veotag.app.ui.theme

import androidx.compose.ui.graphics.Color

// Brand palette
val BluePrimary = Color(0xFF2563EB)
val BluePrimaryDark = Color(0xFF1D4ED8)
val BlueLight = Color(0xFF3B82F6)
val Navy = Color(0xFF0F172A)
val NavySoft = Color(0xFF1E293B)

val White = Color(0xFFFFFFFF)
val BackgroundLight = Color(0xFFF1F5F9)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFE2E8F0)

val TextPrimary = Color(0xFF0F172A)
val TextSecondary = Color(0xFF64748B)
val TextTertiary = Color(0xFF94A3B8)

val OrangeAccent = Color(0xFFF97316)
val PurpleAccent = Color(0xFF8B5CF6)
val SuccessGreen = Color(0xFF16A34A)
val ErrorRed = Color(0xFFDC2626)

// Dark theme surfaces
val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
