package com.veotag.app.data.model

import kotlinx.serialization.SerialName
import kotlinx.serialization.Serializable

@Serializable
data class Project(
    val id: String,
    val title: String,
    @SerialName("video_path") val videoPath: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("creators_names") val creatorsNames: String? = null,
    @SerialName("school_organization") val schoolOrganization: String? = null,
    val category: String,
    @SerialName("additional_details") val additionalDetails: String? = null,
    @SerialName("thumbnail_path") val thumbnailPath: String? = null,
    @SerialName("is_published") val isPublished: Boolean = false,
    @SerialName("created_at") val createdAt: String? = null,
    @SerialName("updated_at") val updatedAt: String? = null
)

@Serializable
data class ProjectInsert(
    val title: String,
    @SerialName("video_path") val videoPath: String,
    @SerialName("short_description") val shortDescription: String,
    @SerialName("creators_names") val creatorsNames: String? = null,
    @SerialName("school_organization") val schoolOrganization: String? = null,
    val category: String,
    @SerialName("additional_details") val additionalDetails: String? = null,
    @SerialName("thumbnail_path") val thumbnailPath: String? = null,
    @SerialName("is_published") val isPublished: Boolean = false
)

@Serializable
data class ProjectUpdate(
    val title: String? = null,
    @SerialName("video_path") val videoPath: String? = null,
    @SerialName("short_description") val shortDescription: String? = null,
    @SerialName("creators_names") val creatorsNames: String? = null,
    @SerialName("school_organization") val schoolOrganization: String? = null,
    val category: String? = null,
    @SerialName("additional_details") val additionalDetails: String? = null,
    @SerialName("thumbnail_path") val thumbnailPath: String? = null,
    @SerialName("is_published") val isPublished: Boolean? = null
)

@Serializable
data class AdminUser(
    @SerialName("user_id") val userId: String,
    @SerialName("created_at") val createdAt: String? = null
)

data class ProjectFormState(
    val title: String = "",
    val shortDescription: String = "",
    val creatorsNames: String = "",
    val schoolOrganization: String = "",
    val category: String = "",
    val additionalDetails: String = "",
    val videoUri: String? = null,
    val videoFileName: String? = null,
    val thumbnailUri: String? = null
)
