package com.veotag.app.data.remote

import com.veotag.app.BuildConfig
import io.github.jan.supabase.SupabaseClient
import io.github.jan.supabase.auth.Auth
import io.github.jan.supabase.createSupabaseClient
import io.github.jan.supabase.postgrest.Postgrest
import io.github.jan.supabase.storage.Storage

object SupabaseProvider {
    private const val DEFAULT_URL = "https://uujagbsiaaweuzxbcglw.supabase.co"
    private const val DEFAULT_KEY = "sb_publishable_jY6EDfuBOI3OdsSSKvnILA_JvVbFoKX"

    val client: SupabaseClient by lazy {
        val url = BuildConfig.SUPABASE_URL.ifBlank { DEFAULT_URL }
        val key = BuildConfig.SUPABASE_ANON_KEY.ifBlank { DEFAULT_KEY }
        createSupabaseClient(
            supabaseUrl = url,
            supabaseKey = key
        ) {
            install(Auth)
            install(Postgrest)
            install(Storage)
        }
    }

    const val BUCKET = "veotag-videos"

    fun publicVideoUrl(videoPath: String): String {
        val encoded = videoPath.split("/").joinToString("/") { segment ->
            java.net.URLEncoder.encode(segment, Charsets.UTF_8.name()).replace("+", "%20")
        }
        val base = BuildConfig.SUPABASE_URL.ifBlank { DEFAULT_URL }
        return "$base/storage/v1/object/public/$BUCKET/$encoded"
    }

    fun publicThumbnailUrl(thumbnailPath: String?): String? {
        if (thumbnailPath.isNullOrBlank()) return null
        return publicVideoUrl(thumbnailPath)
    }
}
