package com.veotag.app.data.repository

import android.content.Context
import android.net.Uri
import com.veotag.app.data.model.AdminUser
import com.veotag.app.data.model.Project
import com.veotag.app.data.model.ProjectInsert
import com.veotag.app.data.model.ProjectUpdate
import com.veotag.app.data.remote.SupabaseProvider
import io.github.jan.supabase.auth.auth
import io.github.jan.supabase.auth.providers.builtin.Email
import io.github.jan.supabase.postgrest.from
import io.github.jan.supabase.postgrest.query.Columns
import io.github.jan.supabase.postgrest.query.Order
import io.github.jan.supabase.storage.storage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

class ProjectRepository {

    private val client get() = SupabaseProvider.client

    suspend fun getPublishedProjects(
        limit: Int = 20,
        offset: Int = 0,
        category: String? = null,
        search: String? = null
    ): Result<List<Project>> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .select(Columns.ALL) {
                    filter {
                        eq("is_published", true)
                        if (!category.isNullOrBlank()) {
                            eq("category", category)
                        }
                        if (!search.isNullOrBlank()) {
                            val q = "%${search.trim()}%"
                            or {
                                ilike("title", q)
                                ilike("short_description", q)
                                ilike("category", q)
                                ilike("school_organization", q)
                                ilike("creators_names", q)
                            }
                        }
                    }
                    order("created_at", Order.DESCENDING)
                    range(offset.toLong(), (offset + limit - 1).toLong())
                }
                .decodeList<Project>()
        }
    }

    suspend fun getProjectById(id: String, publishedOnly: Boolean = true): Result<Project?> =
        withContext(Dispatchers.IO) {
            runCatching {
                val list = client.from("projects")
                    .select(Columns.ALL) {
                        filter {
                            eq("id", id)
                            if (publishedOnly) {
                                eq("is_published", true)
                            }
                        }
                    }
                    .decodeList<Project>()
                list.firstOrNull()
            }
        }

    suspend fun getAllProjectsAdmin(): Result<List<Project>> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .select(Columns.ALL) {
                    order("created_at", Order.DESCENDING)
                }
                .decodeList<Project>()
        }
    }

    suspend fun getProjectCounts(): Result<Triple<Int, Int, Int>> = withContext(Dispatchers.IO) {
        runCatching {
            val all = client.from("projects")
                .select(Columns.list("id", "is_published"))
                .decodeList<Project>()
            val total = all.size
            val published = all.count { it.isPublished }
            Triple(total, published, total - published)
        }
    }

    suspend fun createProject(insert: ProjectInsert): Result<Project> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .insert(insert) {
                    select()
                }
                .decodeSingle<Project>()
        }
    }

    suspend fun updateProject(id: String, update: ProjectUpdate): Result<Project> =
        withContext(Dispatchers.IO) {
            runCatching {
                client.from("projects")
                    .update(update) {
                        filter { eq("id", id) }
                        select()
                    }
                    .decodeSingle<Project>()
            }
        }

    suspend fun deleteProject(id: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.from("projects")
                .delete {
                    filter { eq("id", id) }
                }
            Unit
        }
    }

    suspend fun uploadVideo(context: Context, uri: Uri, projectId: String): Result<String> =
        withContext(Dispatchers.IO) {
            runCatching {
                val resolver = context.contentResolver
                val inputStream = resolver.openInputStream(uri)
                    ?: throw IllegalStateException("Cannot open video file")
                val bytes = inputStream.use { it.readBytes() }
                if (bytes.size > 100 * 1024 * 1024) {
                    throw IllegalStateException("Video must be 100 MB or smaller")
                }
                val mime = resolver.getType(uri) ?: "video/mp4"
                val ext = when {
                    mime.contains("mp4") -> "mp4"
                    mime.contains("webm") -> "webm"
                    else -> "mp4"
                }
                val path = "$projectId/${UUID.randomUUID()}.$ext"
                client.storage.from(SupabaseProvider.BUCKET)
                    .upload(path, bytes) {
                        upsert = false
                    }
                path
            }
        }

    suspend fun deleteVideo(path: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            if (path.isNotBlank()) {
                client.storage.from(SupabaseProvider.BUCKET).delete(listOf(path))
            }
            Unit
        }
    }

    suspend fun signIn(email: String, password: String): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.auth.signInWith(Email) {
                this.email = email
                this.password = password
            }
            Unit
        }
    }

    suspend fun signOut(): Result<Unit> = withContext(Dispatchers.IO) {
        runCatching {
            client.auth.signOut()
            Unit
        }
    }

    suspend fun currentUserId(): String? = withContext(Dispatchers.IO) {
        client.auth.currentUserOrNull()?.id
    }

    suspend fun isAuthorizedAdmin(): Boolean = withContext(Dispatchers.IO) {
        val userId = client.auth.currentUserOrNull()?.id ?: return@withContext false
        try {
            val admins = client.from("admin_users")
                .select(Columns.ALL) {
                    filter { eq("user_id", userId) }
                }
                .decodeList<AdminUser>()
            admins.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    suspend fun getDistinctCategories(): Result<List<String>> = withContext(Dispatchers.IO) {
        runCatching {
            val projects = client.from("projects")
                .select(Columns.list("category")) {
                    filter { eq("is_published", true) }
                }
                .decodeList<Project>()
            projects.map { it.category }.distinct().sorted()
        }
    }
}
