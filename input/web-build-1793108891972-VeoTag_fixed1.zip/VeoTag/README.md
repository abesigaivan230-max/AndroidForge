# VeoTag

Android application for showcasing physical school, science fair, robotics, agriculture, engineering, technology, and innovation projects using QR codes.

Visitors scan a printed QR code with the VeoTag app and watch the project video streamed from Supabase Storage. No public website is required.

## Tech Stack

- Kotlin + Jetpack Compose + Material 3
- AndroidX Navigation Compose
- Supabase (Auth, PostgREST, Storage)
- CameraX + Google ML Kit Barcode Scanning
- Android Media3 ExoPlayer
- ZXing for QR generation

## Requirements

- Android Studio Ladybug / Koala or newer (AGP 8.7+)
- JDK 17
- Android SDK 35
- Min SDK 26 (Android 8.0)

## Supabase Configuration

The project already points at:

```
https://qxzrkksctmpirpahinml.supabase.co
```

You **must** supply the Supabase **publishable (anon) key**. Never put the service-role key in the app.

### Option A – Gradle property (recommended for local builds)

Create or edit `local.properties` in the project root (already gitignored by Android Studio defaults):

```properties
sdk.dir=/path/to/Android/sdk
SUPABASE_ANON_KEY=your_anon_key_here
```

Or pass on the command line:

```bash
./gradlew assembleRelease -PSUPABASE_ANON_KEY=your_anon_key_here
```

### Option B – Environment variable

```bash
export SUPABASE_ANON_KEY=your_anon_key_here
./gradlew assembleDebug
```

The URL defaults to the provided project. Override with `SUPABASE_URL` if needed.

## Database Schema (existing)

Tables already present:

- `public.projects` – project metadata and video path
- `public.admin_users` – authorized administrator user IDs

Authorized admin UUID already inserted:

```
4b4d6aa8-a88b-44d5-a469-2135067c2af9
```

Storage bucket: `veotag-videos` (public read for playback).

RLS is expected to allow:

- Public `SELECT` on `projects` where `is_published = true`
- Authenticated admin (present in `admin_users`) full access to projects and storage uploads

No extra migrations are required for the current schema.

## Build

```bash
# Debug APK
./gradlew assembleDebug

# Release APK (requires signing config for production)
./gradlew assembleRelease -PSUPABASE_ANON_KEY=your_key
```

Output:

- Debug: `app/build/outputs/apk/debug/app-debug.apk`
- Release: `app/build/outputs/apk/release/app-release-unsigned.apk` (sign before distribution)

## Install & Test

1. Install the APK on a device or emulator with camera support.
2. Open the app → main Scan screen appears (no login required).
3. Tap **Scan QR Code**, grant camera permission.
4. To test admin: tap the **VeoTag** logo five times quickly → login screen.
5. Sign in with the Supabase Auth user that matches the authorized `admin_users` row.
6. Create a project, upload an MP4 (≤ 100 MB), leave unpublished, generate QR from Manage Projects.
7. Publish the project.
8. Scan the QR (or use Explore/Search) and play the video.

### QR format

```
VEOTAG:<project-uuid>
```

Example: `VEOTAG:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx`

## GitHub Actions / AndroidForge

Example workflow snippet:

```yaml
- name: Build
  env:
    SUPABASE_ANON_KEY: ${{ secrets.SUPABASE_ANON_KEY }}
  run: |
    ./gradlew assembleRelease -PSUPABASE_ANON_KEY=$SUPABASE_ANON_KEY
```

Store `SUPABASE_ANON_KEY` as a repository secret. Do not commit the key.

For AndroidForge, set the same property/environment variable in the build configuration and use the standard Gradle Android application module `app`.

## Project Structure

```
VeoTag/
├── app/
│   ├── build.gradle.kts
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml
│       ├── java/com/veotag/app/
│       │   ├── MainActivity.kt
│       │   ├── VeoTagApplication.kt
│       │   ├── data/
│       │   ├── ui/
│       │   └── util/
│       └── res/
├── build.gradle.kts
├── settings.gradle.kts
├── gradle.properties
└── README.md
```

## Features Implemented

- Visitor Scan / Explore / Search with bottom navigation
- Camera permission handling and QR scanning (VEOTAG:UUID)
- Project detail + Media3 video playback from public storage URL
- Hidden admin entry (5 taps on logo)
- Supabase Auth + admin_users authorization check
- Admin dashboard with counts
- Add / Edit / Publish / Unpublish / Delete projects
- Video upload via system document picker (100 MB limit)
- High-resolution QR download and printable label download
- Material 3 light theme (blue primary, orange accents)

## Known Limitations

- PDF label export is not implemented; high-resolution PNG label is provided.
- Video duration is not pre-checked (file size limit is enforced).
- New projects use a random storage path prefix; the database generates the permanent UUID used in QR codes.
- Release builds need your own signing keystore for Play Store / distribution.
- Full offline mode is not supported (internet required for project data and video streaming).

## Security Notes

- Only the publishable (anon) key is embedded via BuildConfig.
- Admin actions rely on Supabase Auth session + `admin_users` row + RLS.
- Service-role key must never be placed in the client.
- Unpublished projects are filtered both client-side and should be enforced by RLS.
