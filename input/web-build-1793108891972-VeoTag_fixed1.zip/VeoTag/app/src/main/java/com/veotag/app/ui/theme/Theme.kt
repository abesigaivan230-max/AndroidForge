package com.veotag.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Primary = Color(0xFF1565C0)
val PrimaryDark = Color(0xFF0D47A1)
val PrimaryLight = Color(0xFF42A5F5)
val Secondary = Color(0xFFFF6D00)
val AccentPurple = Color(0xFF7B1FA2)
val Background = Color(0xFFFFFFFF)
val Surface = Color(0xFFF5F7FA)
val OnBackground = Color(0xFF1A1A1A)
val Error = Color(0xFFD32F2F)
val Success = Color(0xFF2E7D32)

private val LightColors = lightColorScheme(
    primary = Primary,
    onPrimary = Color.White,
    primaryContainer = PrimaryLight,
    onPrimaryContainer = PrimaryDark,
    secondary = Secondary,
    onSecondary = Color.White,
    tertiary = AccentPurple,
    background = Background,
    onBackground = OnBackground,
    surface = Surface,
    onSurface = OnBackground,
    error = Error,
    onError = Color.White
)

private val DarkColors = darkColorScheme(
    primary = PrimaryLight,
    onPrimary = Color.Black,
    secondary = Secondary,
    background = Color(0xFF121212),
    onBackground = Color.White,
    surface = Color(0xFF1E1E1E),
    onSurface = Color.White,
    error = Error
)

@Composable
fun VeoTagTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        content = content
    )
}
