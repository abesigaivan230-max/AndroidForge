package com.veotag.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.veotag.app.ui.navigation.VeoTagNavHost
import com.veotag.app.ui.theme.VeoTagTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VeoTagTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    VeoTagNavHost()
                }
            }
        }
    }
}
