package com.veotag.app

import android.app.Application

class VeoTagApplication : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
