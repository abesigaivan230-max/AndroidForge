# Keep Supabase / kotlinx serialization
-keepattributes *Annotation*, InnerClasses
-dontnote kotlinx.serialization.AnnotationsKt
-keepclassmembers class kotlinx.serialization.json.** { *** Companion; }
-keepclasseswithmembers class kotlinx.serialization.json.** {
    kotlinx.serialization.KSerializer serializer(...);
}
-keep,includedescriptorclasses class com.veotag.app.**$$serializer { *; }
-keepclassmembers class com.veotag.app.** {
    *** Companion;
}
-keepclasseswithmembers class com.veotag.app.** {
    kotlinx.serialization.KSerializer serializer(...);
}

# Keep data models
-keep class com.veotag.app.data.model.** { *; }

# ExoPlayer / Media3
-keep class androidx.media3.** { *; }
-dontwarn androidx.media3.**

# CameraX / ML Kit
-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

# ZXing
-keep class com.google.zxing.** { *; }
