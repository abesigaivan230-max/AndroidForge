# Data providers
- Prices/candles: Twelve Data via the `market-data` function. Free-tier limits seen in public docs: about 8 requests/minute and 800/day, which the
  app's caching and throttling are built around. **Verify the current licence/terms before any public release**: a pricing note suggested free data is
  for internal/non-display use. If it does not allow display in a public app, switch provider (edit only the Edge Function).
- AI: OpenAI via `ai-explain` and `screenshot-analyse` (key stays on the server; per-user hourly limits in `ai_usage`).
- Economic calendar: no free licensed feed was verified. Fill `economic_events` yourself; the app never invents events.
