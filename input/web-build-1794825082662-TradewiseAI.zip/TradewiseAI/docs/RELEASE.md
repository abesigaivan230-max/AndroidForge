# Build and release APK
Debug: `./gradlew assembleDebug` -> `app/build/outputs/apk/debug/`.
Release: create a keystore (`keytool -genkey -v -keystore tradewise.jks -alias tw -keyalg RSA -keysize 2048 -validity 10000`), then add to
`local.properties`: `RELEASE_STORE_FILE`, `RELEASE_STORE_PASSWORD`, `RELEASE_KEY_ALIAS`, `RELEASE_KEY_PASSWORD`. Run `./gradlew assembleRelease`
(R8 shrinking is on). Never commit the keystore or local.properties. For Play Store: the overlay and screen-capture use must be declared, and the
`specialUse` foreground service needs a written justification.
