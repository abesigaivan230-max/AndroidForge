# Testing
- Unit tests (domain): `./gradlew testDebugUnitTest`.
- Instrumented: `./gradlew connectedDebugAndroidTest` (needs a device).

Manual checklist on a REAL phone (an emulator is poor for overlays):
1. Home > Grant permission: system screen opens; return, button becomes Start.
2. Start: persistent notification with a Stop action appears; bubble shows over another app (e.g. a browser).
3. Drag the bubble (smooth, snaps to an edge); tap -> side panel; + / - resizes; expand -> ask a question (keyboard works).
4. Analyse in the overlay: price, decision, rules; status chip says DEMO/LIVE/CACHED correctly.
5. Screenshot button: system consent dialog; bubble hides during capture; image appears; Analyse (signed in); Delete removes it.
6. Revoke the overlay permission while running: service stops with a notice, no crash.
7. Rotate the phone with the panel open: it stays on screen. Kill the app from recents: overlay restarts if it was on.
8. Share an image from the gallery to TRADEWISE AI: lands on Analyse.
9. Turn off network: demo/cached labels, no crash. Journal works offline.
10. Android 14 device: verify the foreground-service types work (specialUse for overlay, mediaProjection for capture).
