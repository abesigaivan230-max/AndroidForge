# Privacy
- No API keys in the APK. Only the public Supabase URL and anon key.
- Screenshots: captured only after Android's own consent dialog each time; stored in app cache; sent to the backend only when you tap Analyse; the
  backend does not store the image. Delete them in Settings > Privacy.
- Journal and settings live on the phone; cloud sync is optional and protected by Row Level Security.
- The app does not read other apps, use Accessibility Service, or collect broker credentials.
