# Setup

## 1. Supabase
1. Create a project at supabase.com. Note the Project URL and the `anon` public key (Settings > API).
2. SQL editor: run `supabase/migrations/0001_init.sql`.
3. Install the Supabase CLI, then from the project root:
   ```
   supabase login
   supabase link --project-ref <your-ref>
   supabase secrets set TWELVEDATA_API_KEY=<key> OPENAI_API_KEY=<key> OPENAI_MODEL=gpt-4o-mini
   supabase functions deploy market-data ai-explain screenshot-analyse calendar
   ```
4. Authentication > Providers: enable Email. (Turn off "Confirm email" while testing if you want instant sign-up.)
5. Economic calendar: insert rows into `economic_events` from a source you are licensed to use (see PROVIDERS.md). Empty table = honest empty screen.

## 2. App
Copy `local.properties.example` to `local.properties` and fill `SUPABASE_URL` and `SUPABASE_ANON_KEY` (the anon key is meant to be public; the
vendor/AI keys only exist as server secrets). Sync Gradle and run on a device.

## 3. Check
Settings > Data > "Check data provider" should say Reachable and Configured. Sign in under Settings > Account to enable AI and screenshot analysis.
