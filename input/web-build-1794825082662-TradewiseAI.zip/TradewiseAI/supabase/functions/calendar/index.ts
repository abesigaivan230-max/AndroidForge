// Returns upcoming events from the economic_events table. Never invents events.
import { admin, cors, fail, json } from "../_shared/util.ts";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const now = Math.floor(Date.now() / 1000);
  const { data, error } = await admin().from("economic_events").select("*")
    .gte("event_time", now - 3600).lte("event_time", now + 7 * 86400).order("event_time").limit(200);
  if (error) return fail(error.message);
  return json({ status: "ok", configured: (data?.length ?? 0) > 0, events: data ?? [] });
});
