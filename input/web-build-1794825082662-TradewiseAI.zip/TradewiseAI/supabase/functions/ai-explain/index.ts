// Explains an already-computed setup. The model never decides the setup and never invents numbers.
import { cors, fail, json, record, underLimit, userId } from "../_shared/util.ts";

const KEY = Deno.env.get("OPENAI_API_KEY");
const MODEL = Deno.env.get("OPENAI_MODEL") ?? "gpt-4o-mini";

const SYSTEM = `You explain a forex rule-engine result to a beginner, in plain language.
Hard rules:
- Use ONLY the numbers and facts in the JSON given. Never add prices, levels, forecasts or news.
- Never say a trade will win, give a probability of profit, or tell the user to place a trade. This is education, not advice.
- The decision (BUY SETUP / SELL SETUP / WAIT) comes from code; explain it, never change it.
- If asked something outside the data, say the data does not cover it.
Reply as JSON with keys: summary, market_state, indicator_notes (array of short strings), why_setup_or_not,
what_would_change (array), beginner_explanation, risks (array), answer (reply to the user's question, or "" if none).`;

const STR_KEYS = ["summary", "market_state", "why_setup_or_not", "beginner_explanation", "answer"];
const ARR_KEYS = ["indicator_notes", "what_would_change", "risks"];

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (!KEY) return fail("OPENAI_API_KEY is not set on the server.");
  const uid = await userId(req);
  if (!uid) return fail("Sign in to use AI explanations.");
  if (!(await underLimit(uid, "explain", 40))) return fail("Hourly AI limit reached. Try again later.");

  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return fail("Invalid JSON body."); }
  const setup = body.setup;
  if (!setup || typeof setup !== "object") return fail("Missing setup.");
  const question = String(body.question ?? "").slice(0, 500);
  const history = Array.isArray(body.history) ? body.history.slice(-8) : [];

  const messages = [
    { role: "system", content: SYSTEM },
    { role: "user", content: "SETUP DATA:\n" + JSON.stringify(setup).slice(0, 12000) },
    ...history.map((h: { role?: string; text?: string }) => ({
      role: h.role === "assistant" ? "assistant" : "user", content: String(h.text ?? "").slice(0, 1500) })),
    { role: "user", content: question ? `Question: ${question}` : "Explain this result." },
  ];

  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${KEY}` },
      body: JSON.stringify({ model: MODEL, messages, response_format: { type: "json_object" }, temperature: 0.2, max_tokens: 900 }),
    });
    const j = await r.json();
    const text = j?.choices?.[0]?.message?.content;
    if (!r.ok || !text) return fail(j?.error?.message ?? "AI provider error.");
    const parsed = JSON.parse(text);
    // validate shape: only expected keys, correct types
    const out: Record<string, unknown> = {};
    for (const k of STR_KEYS) out[k] = typeof parsed[k] === "string" ? parsed[k].slice(0, 1500) : "";
    for (const k of ARR_KEYS) out[k] = Array.isArray(parsed[k]) ? parsed[k].filter((x: unknown) => typeof x === "string").slice(0, 8).map((s: string) => s.slice(0, 400)) : [];
    if (!out.summary) return fail("AI returned an incomplete answer.");
    await record(uid, "explain");
    return json({ status: "ok", explanation: out });
  } catch (e) {
    return fail(`AI request failed: ${(e as Error).message}`);
  }
});
