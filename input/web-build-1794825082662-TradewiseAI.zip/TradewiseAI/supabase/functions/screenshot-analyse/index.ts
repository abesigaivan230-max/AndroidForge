// Reads a chart screenshot with a vision model. The image is processed in memory and NOT stored.
import { admin, cors, fail, json, record, underLimit, userId } from "../_shared/util.ts";

const KEY = Deno.env.get("OPENAI_API_KEY");
const MODEL = Deno.env.get("OPENAI_MODEL") ?? "gpt-4o-mini";
const MAX_B64 = 6_000_000;

const SYSTEM = `You read a screenshot of a trading chart. Report ONLY what is clearly visible.
Never guess. If something is not legible, give status "unclear" and value null. If this is not a chart or is unreadable,
set readable=false and explain in unreadable_reason. Never give trade instructions or predictions.
Reply as JSON: {
 readable: boolean, unreadable_reason: string,
 pair: {value: string|null, status: "read"|"unclear"},
 timeframe: {value: string|null, status: "read"|"unclear"},
 indicators: [{value: string, status: "read"|"unclear"}],
 price_levels: [{label: string, value: number|null, status: "read"|"unclear"}],
 support: number[], resistance: number[],
 structure: string, bullish_scenario: string, bearish_scenario: string, uncertainty: string }`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  const uid = await userId(req);
  if (!uid) return fail("Sign in to analyse screenshots.");
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return fail("Invalid JSON body."); }

  if (body.mode === "delete_all") {
    await admin().from("screenshot_analyses").delete().eq("user_id", uid);
    return json({ status: "ok" });
  }
  if (!KEY) return fail("OPENAI_API_KEY is not set on the server.");
  const b64 = String(body.image_base64 ?? "");
  if (!b64 || b64.length > MAX_B64) return fail("Image missing or too large.");
  if (!(await underLimit(uid, "screenshot", 15))) return fail("Hourly screenshot limit reached.");

  try {
    const r = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${KEY}` },
      body: JSON.stringify({
        model: MODEL, temperature: 0, max_tokens: 1000, response_format: { type: "json_object" },
        messages: [
          { role: "system", content: SYSTEM },
          { role: "user", content: [
            { type: "text", text: "Analyse this chart screenshot." },
            { type: "image_url", image_url: { url: `data:image/jpeg;base64,${b64}`, detail: "high" } },
          ] },
        ],
      }),
    });
    const j = await r.json();
    const text = j?.choices?.[0]?.message?.content;
    if (!r.ok || !text) return fail(j?.error?.message ?? "Vision provider error.");
    const a = JSON.parse(text);
    const safe = {
      readable: a.readable === true,
      unreadable_reason: String(a.unreadable_reason ?? "").slice(0, 300),
      pair: a.pair ?? { value: null, status: "unclear" },
      timeframe: a.timeframe ?? { value: null, status: "unclear" },
      indicators: Array.isArray(a.indicators) ? a.indicators.slice(0, 10) : [],
      price_levels: Array.isArray(a.price_levels) ? a.price_levels.slice(0, 12) : [],
      support: Array.isArray(a.support) ? a.support.filter(Number.isFinite).slice(0, 6) : [],
      resistance: Array.isArray(a.resistance) ? a.resistance.filter(Number.isFinite).slice(0, 6) : [],
      structure: String(a.structure ?? "").slice(0, 500),
      bullish_scenario: String(a.bullish_scenario ?? "").slice(0, 500),
      bearish_scenario: String(a.bearish_scenario ?? "").slice(0, 500),
      uncertainty: String(a.uncertainty ?? "").slice(0, 500),
    };
    await record(uid, "screenshot");
    return json({ status: "ok", analysis: safe });
  } catch (e) {
    return fail(`Screenshot analysis failed: ${(e as Error).message}`);
  }
});
