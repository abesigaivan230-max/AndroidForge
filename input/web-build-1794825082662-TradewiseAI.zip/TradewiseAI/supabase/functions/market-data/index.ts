// Market data proxy. Holds TWELVEDATA_API_KEY server-side, caches, validates.
import { cors, fail, json } from "../_shared/util.ts";

const KEY = Deno.env.get("TWELVEDATA_API_KEY");
const SYMBOLS = new Set(["EUR/USD", "GBP/USD", "USD/JPY"]);
const INTERVALS = new Set(["5min", "15min", "1h", "4h", "1day"]);
const TTL: Record<string, number> = { "5min": 45, "15min": 90, "1h": 240, "4h": 600, "1day": 1800 };
const cache = new Map<string, { at: number; data: unknown }>();   // per warm instance

function fresh(key: string, ttlSec: number) {
  const c = cache.get(key);
  return c && Date.now() - c.at < ttlSec * 1000 ? c : null;
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  let body: Record<string, unknown>;
  try { body = await req.json(); } catch { return fail("Invalid JSON body."); }
  const mode = String(body.mode ?? "");

  if (mode === "status") return json({ status: "ok", configured: !!KEY });
  if (!KEY) return fail("TWELVEDATA_API_KEY is not set on the server.");

  const symbol = String(body.symbol ?? "");
  if (!SYMBOLS.has(symbol)) return fail("Unsupported symbol.");

  try {
    if (mode === "price") {
      const ck = `p:${symbol}`;
      const hit = fresh(ck, 20);
      if (hit) return json({ ...(hit.data as object), cached: true });
      const r = await fetch(`https://api.twelvedata.com/price?symbol=${encodeURIComponent(symbol)}&apikey=${KEY}`);
      const j = await r.json();
      const price = parseFloat(j.price);
      if (!isFinite(price) || price <= 0) return fail(j.message ?? "Provider returned no price.");
      const data = { status: "ok", price, ts: Math.floor(Date.now() / 1000), provider: "twelvedata" };
      cache.set(ck, { at: Date.now(), data });
      return json({ ...data, cached: false });
    }

    if (mode === "candles") {
      const interval = String(body.interval ?? "");
      if (!INTERVALS.has(interval)) return fail("Unsupported interval.");
      const size = Math.min(Math.max(Number(body.outputsize ?? 300) | 0, 30), 600);
      const ck = `c:${symbol}:${interval}:${size}`;
      const hit = fresh(ck, TTL[interval]);
      if (hit) return json({ ...(hit.data as object), cached: true });
      const url = `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbol)}&interval=${interval}` +
        `&outputsize=${size}&timezone=UTC&order=ASC&apikey=${KEY}`;
      const j = await (await fetch(url)).json();
      if (j.status === "error" || !Array.isArray(j.values)) return fail(j.message ?? "Provider returned no candles.");
      const candles = j.values.map((v: Record<string, string>) => ({
        t: Math.floor(Date.parse(v.datetime.replace(" ", "T") + "Z") / 1000),
        o: +v.open, h: +v.high, l: +v.low, c: +v.close, v: v.volume ? +v.volume : 0,
      })).filter((c: { t: number; o: number; h: number; l: number; c: number }) =>
        [c.t, c.o, c.h, c.l, c.c].every(Number.isFinite) && c.h >= c.l);
      if (candles.length < 10) return fail("Too few candles from provider.");
      const data = { status: "ok", candles, provider: "twelvedata", fetched_at: Date.now() };
      cache.set(ck, { at: Date.now(), data });
      return json({ ...data, cached: false });
    }
    return fail("Unknown mode.");
  } catch (e) {
    return fail(`Provider request failed: ${(e as Error).message}`);
  }
});
