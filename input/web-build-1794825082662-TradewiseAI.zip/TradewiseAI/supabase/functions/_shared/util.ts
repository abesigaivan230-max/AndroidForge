import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.4";

export const cors = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

export function json(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), { status, headers: { ...cors, "Content-Type": "application/json" } });
}
export function fail(message: string, status = 200): Response {
  // The app reads {status:"error"}; HTTP 200 keeps it from treating this as a network failure.
  return json({ status: "error", message }, status);
}

export function admin() {
  return createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!);
}

/** Returns the signed-in user id from the bearer token, or null (anon key alone is not a user). */
export async function userId(req: Request): Promise<string | null> {
  const token = (req.headers.get("authorization") ?? "").replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data, error } = await admin().auth.getUser(token);
  return error || !data.user ? null : data.user.id;
}

/** Per-user hourly limit stored in ai_usage. */
export async function underLimit(uid: string, kind: string, perHour: number): Promise<boolean> {
  const since = new Date(Date.now() - 3600_000).toISOString();
  const { count } = await admin().from("ai_usage").select("id", { count: "exact", head: true })
    .eq("user_id", uid).eq("kind", kind).gte("created_at", since);
  return (count ?? 0) < perHour;
}
export async function record(uid: string, kind: string) {
  await admin().from("ai_usage").insert({ user_id: uid, kind });
}
