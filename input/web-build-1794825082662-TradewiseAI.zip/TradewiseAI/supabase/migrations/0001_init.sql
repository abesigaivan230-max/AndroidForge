-- TRADEWISE AI schema. Run in Supabase SQL editor (or `supabase db push`).
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text, preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now());

create table if not exists public.watchlists (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null, created_at timestamptz not null default now(), unique (user_id, symbol));

create table if not exists public.market_candles (   -- shared server cache, written by Edge Functions only
  symbol text not null, interval text not null, ts bigint not null,
  open double precision not null, high double precision not null, low double precision not null, close double precision not null,
  volume double precision, fetched_at timestamptz not null default now(), primary key (symbol, interval, ts));

create table if not exists public.market_analyses (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null, decision text not null, summary jsonb, created_at timestamptz not null default now());

create table if not exists public.indicator_values (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null, timeframe text not null, values jsonb not null, created_at timestamptz not null default now());

create table if not exists public.screenshot_analyses (   -- metadata only; images are NOT stored
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  readable boolean, result jsonb, created_at timestamptz not null default now());

create table if not exists public.price_alerts (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null, target double precision not null, above boolean not null,
  triggered_at timestamptz, created_at timestamptz not null default now());

create table if not exists public.demo_accounts (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  starting_balance numeric not null default 1000, created_at timestamptz not null default now());

create table if not exists public.demo_trades (
  id uuid primary key default gen_random_uuid(), user_id uuid not null references auth.users(id) on delete cascade,
  symbol text not null, direction text not null, entry double precision, exit double precision,
  stop_loss double precision, take_profit double precision, lots numeric, result numeric,
  opened_at timestamptz not null default now(), closed_at timestamptz);

create table if not exists public.trade_journal (    -- used by the app's optional sync
  id text primary key, user_id uuid not null references auth.users(id) on delete cascade,
  payload jsonb not null, updated_at timestamptz not null default now());

create table if not exists public.lessons (
  id text primary key, title text not null, level text, body jsonb);

create table if not exists public.lesson_progress (
  user_id uuid not null references auth.users(id) on delete cascade, lesson_id text not null,
  best_score int, completed_at timestamptz, primary key (user_id, lesson_id));

create table if not exists public.economic_events (   -- YOU fill this from a source you are licensed to use
  id text primary key, title text not null, currency text, event_time bigint not null,
  impact text check (impact in ('low','medium','high')), previous text, forecast text, actual text);

create table if not exists public.ai_usage (
  id bigint generated always as identity primary key, user_id uuid not null references auth.users(id) on delete cascade,
  kind text not null, created_at timestamptz not null default now());
create index if not exists ai_usage_user_time on public.ai_usage (user_id, created_at desc);

-- Row Level Security: every user-owned table is private to its owner.
do $$
declare t text;
begin
  foreach t in array array['watchlists','market_analyses','indicator_values','screenshot_analyses','price_alerts','demo_accounts','demo_trades','trade_journal','ai_usage'] loop
    execute format('alter table public.%I enable row level security', t);
    execute format('drop policy if exists "own rows" on public.%I', t);
    execute format('create policy "own rows" on public.%I for all using (auth.uid() = user_id) with check (auth.uid() = user_id)', t);
  end loop;
end $$;

alter table public.profiles enable row level security;
drop policy if exists "own profile" on public.profiles;
create policy "own profile" on public.profiles for all using (auth.uid() = id) with check (auth.uid() = id);

alter table public.lesson_progress enable row level security;
drop policy if exists "own progress" on public.lesson_progress;
create policy "own progress" on public.lesson_progress for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Public read-only reference data; writes only with the service role (Edge Functions / dashboard).
alter table public.lessons enable row level security;
drop policy if exists "read lessons" on public.lessons;
create policy "read lessons" on public.lessons for select using (true);
alter table public.economic_events enable row level security;
drop policy if exists "read events" on public.economic_events;
create policy "read events" on public.economic_events for select using (true);
alter table public.market_candles enable row level security;   -- no policies: service role only

-- Auto-create a profile row at sign-up.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path = public as $$
begin insert into public.profiles (id) values (new.id) on conflict do nothing; return new; end $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
