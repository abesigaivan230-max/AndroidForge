# OkHttp / Okio
-dontwarn okhttp3.internal.platform.**
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
# Tink (used by androidx.security-crypto)
-dontwarn com.google.errorprone.annotations.**
-dontwarn javax.annotation.**
