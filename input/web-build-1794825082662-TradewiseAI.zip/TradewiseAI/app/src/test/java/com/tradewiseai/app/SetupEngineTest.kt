package com.tradewiseai.app

import com.tradewiseai.app.domain.analysis.SetupConfig
import com.tradewiseai.app.domain.analysis.SetupEngine
import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Decision
import com.tradewiseai.app.domain.model.Direction
import com.tradewiseai.app.domain.model.Timeframe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class SetupEngineTest {

    private val now = 1_700_000_000L
    private val pair = CurrencyPair.EURUSD

    /** Clean trending ramp. All candles are CLOSED at [endAt]; direction sign +1 up / -1 down. */
    private fun ramp(tf: Timeframe, count: Int, step: Double, sign: Int, endAt: Long = now): List<Candle> =
        (0 until count).map { i ->
            val open = 1.1 + sign * i * step
            val close = open + sign * 0.8 * step
            val hi = maxOf(open, close) + 0.1 * step
            val lo = minOf(open, close) - 0.1 * step
            Candle(endAt - (count - i) * tf.seconds, open, hi, lo, close)
        }

    private val relaxed = SetupConfig(rsiMin = 0.0, rsiMax = 100.0, requireMacdTurn = false, pullbackAtrMult = 1000.0)

    private fun eval(h: List<Candle>, s: List<Candle>, e: List<Candle>, cfg: SetupConfig = relaxed, spread: Double? = null, at: Long = now) =
        SetupEngine.evaluate(pair, h, s, e, cfg, at, spread, isDemoData = false)

    private fun up() = Triple(ramp(Timeframe.H4, 120, 0.0010, 1), ramp(Timeframe.H1, 120, 0.0005, 1), ramp(Timeframe.M15, 120, 0.0002, 1))
    private fun down() = Triple(ramp(Timeframe.H4, 120, 0.0010, -1), ramp(Timeframe.H1, 120, 0.0005, -1), ramp(Timeframe.M15, 120, 0.0002, -1))

    @Test fun cleanUptrend_withRelaxedRules_isBuySetup() {
        val (h, s, e) = up()
        val r = eval(h, s, e)
        assertEquals(r.checks.filter { !it.passed }.toString(), Decision.BUY_SETUP, r.decision)
        assertEquals(Direction.LONG, r.candidateDirection)
        val entry = r.entry!!; val stop = r.stopLoss!!
        assertTrue(stop < entry)
        assertTrue(r.riskReward!! >= relaxed.minRiskReward)
        assertTrue(r.targets.all { it.price > entry })
        assertTrue(r.invalidation.isNotEmpty())
        assertTrue(r.entryZoneLow!! < entry && entry < r.entryZoneHigh!!)
    }

    @Test fun cleanDowntrend_isSellSetup_withMirroredLevels() {
        val (h, s, e) = down()
        val r = eval(h, s, e)
        assertEquals(r.checks.filter { !it.passed }.toString(), Decision.SELL_SETUP, r.decision)
        assertTrue(r.stopLoss!! > r.entry!!)
        assertTrue(r.targets.all { it.price < r.entry!! })
    }

    @Test fun defaultRules_rejectOverbought_rsiNearHundred() {
        val (h, s, e) = up()
        val r = eval(h, s, e, SetupConfig())     // default RSI band 35-70, MACD turn required, pullback 1 ATR
        assertEquals(Decision.WAIT, r.decision)
        assertTrue(r.reasonsAgainst.isNotEmpty())
        assertNull(r.entry)
    }

    @Test fun tooFewCandles_isWait() {
        val (h, s, e) = up()
        val r = eval(h.takeLast(20), s, e)
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name == "Enough history" }.passed)
    }

    @Test fun staleData_isWait() {
        val (h, s, e) = up()
        val r = eval(h, s, e, at = now + 10 * 86_400L)
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name == "Fresh data" }.passed)
    }

    @Test fun formingCandle_isDropped() {
        val c = Candle(now - 400, 1.0, 1.1, 0.9, 1.05)     // opened 400 s ago
        assertTrue(SetupEngine.closedOnly(listOf(c), Timeframe.H1, now).isEmpty())          // a 1H candle is still forming
        assertEquals(1, SetupEngine.closedOnly(listOf(c), Timeframe.M5, now).size)          // a 5m candle has closed
    }

    @Test fun flatHigherTimeframe_isWait() {
        val flat = (0 until 120).map { i -> Candle(now - (120 - i) * Timeframe.H4.seconds, 1.1, 1.1005, 1.0995, 1.1) }
        val (_, s, e) = up()
        val r = eval(flat, s, e)
        assertEquals(Decision.WAIT, r.decision)
        assertNull(r.candidateDirection)
    }

    @Test fun conflictingTimeframes_isWait() {
        val (h, _, e) = up()
        val r = eval(h, ramp(Timeframe.H1, 120, 0.0005, -1), e)
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name.endsWith("trend agrees") }.passed)
    }

    @Test fun excessiveSpread_blocksSetup() {
        val (h, s, e) = up()
        val r = eval(h, s, e, spread = 9.0)
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name == "Spread acceptable" }.passed)
    }

    @Test fun unknownSpread_isCaveat_notFailure() {
        val (h, s, e) = up()
        val r = eval(h, s, e, spread = null)
        assertTrue(r.checks.first { it.name == "Spread acceptable" }.passed)
        assertTrue(r.caveats.any { it.contains("Spread was not checked") })
    }

    @Test fun missingCandles_blockSetup() {
        val (h, s, e) = up()
        // remove every 4th candle from the entry series -> many unexpected gaps
        val holes = e.filterIndexed { i, _ -> i % 4 != 0 }
        val r = eval(h, s, holes)
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name == "No missing candles" }.passed)
    }

    @Test fun impossiblyHighMinRiskReward_isWait() {
        val (h, s, e) = up()
        val r = eval(h, s, e, relaxed.copy(minRiskReward = 10.0))
        assertEquals(Decision.WAIT, r.decision)
        assertFalse(r.checks.first { it.name == "Minimum risk/reward" }.passed)
    }

    @Test fun waitResultNeverCarriesATradePlan() {
        val (h, s, e) = up()
        val r = eval(h.takeLast(10), s, e)
        assertNull(r.stopLoss); assertTrue(r.targets.isEmpty()); assertNull(r.riskReward)
        assertTrue(r.watchFor.isNotEmpty())
    }

    @Test fun ruleSummary_isACount_notAProbability() {
        val (h, s, e) = up()
        val r = eval(h, s, e)
        assertTrue(r.ruleSummary.contains("not a probability"))
        assertNotNull(r.htf); assertNotNull(r.setup); assertNotNull(r.entryTfSnapshot)
    }

    @Test fun gapCounter_ignoresWeekendBreak() {
        val base = (0 until 10).map { i -> Candle(i * 3600L, 1.0, 1.1, 0.9, 1.0) }
        val afterWeekend = base + Candle(9 * 3600L + 48 * 3600L, 1.0, 1.1, 0.9, 1.0)
        assertEquals(0, SetupEngine.unexpectedGaps(afterWeekend, Timeframe.H1))
        val afterShortHole = base + Candle(9 * 3600L + 5 * 3600L, 1.0, 1.1, 0.9, 1.0)
        assertEquals(1, SetupEngine.unexpectedGaps(afterShortHole, Timeframe.H1))
    }
}
