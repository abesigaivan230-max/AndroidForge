package com.tradewiseai.app

import com.tradewiseai.app.data.remote.DemoMarketProvider
import com.tradewiseai.app.domain.analysis.DataQuality
import com.tradewiseai.app.domain.analysis.SetupConfig
import com.tradewiseai.app.domain.analysis.SetupEngine
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Timeframe
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class DemoDataTest {
    private val now = 1_763_000_000L
    private val demo = DemoMarketProvider { now }

    @Test fun candles_areValid_sortedAligned_andLabelledDemo() {
        for (pair in CurrencyPair.values()) for (tf in Timeframe.values()) {
            val s = demo.generate(pair, tf, 300)
            assertEquals(300, s.candles.size)
            assertEquals(DataOrigin.DEMO, s.origin)
            assertEquals(DataStatus.DEMO, DataQuality.statusOf(s, now))
            s.candles.forEachIndexed { i, c ->
                assertTrue("$pair $tf high>=low", c.high >= c.low)
                assertTrue(c.high >= maxOf(c.open, c.close) - 1e-12 && c.low <= minOf(c.open, c.close) + 1e-12)
                assertEquals(0L, c.time % tf.seconds)
                if (i > 0) assertEquals(tf.seconds, c.time - s.candles[i - 1].time)
            }
        }
    }

    @Test fun lastCandleAgreesWithQuote_acrossTimeframes() {
        val q = demo.priceAt(CurrencyPair.EURUSD, now)
        Timeframe.values().forEach { tf ->
            val last = demo.generate(CurrencyPair.EURUSD, tf, 60).candles.last()
            assertEquals(q, last.close, q * 1e-9)
        }
    }

    @Test fun engineRunsOnDemoData_andNeverCrashes() {
        for (pair in CurrencyPair.values()) {
            val cfg = SetupConfig()
            val r = SetupEngine.evaluate(pair, demo.generate(pair, cfg.htf, 300).candles, demo.generate(pair, cfg.setupTf, 300).candles,
                demo.generate(pair, cfg.entryTf, 300).candles, cfg, now, null, true)
            assertTrue(r.checks.isNotEmpty())
            assertTrue(r.caveats.any { it.contains("DEMO DATA") })
        }
    }
}
