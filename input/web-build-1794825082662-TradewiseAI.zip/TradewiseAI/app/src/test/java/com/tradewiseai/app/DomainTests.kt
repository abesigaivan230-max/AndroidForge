package com.tradewiseai.app

import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.domain.analysis.AiExplanation
import com.tradewiseai.app.domain.analysis.DataQuality
import com.tradewiseai.app.domain.analysis.LocalExplainer
import com.tradewiseai.app.domain.analysis.ReadItem
import com.tradewiseai.app.domain.analysis.ScreenshotAnalysis
import com.tradewiseai.app.domain.analysis.ScreenshotComparator
import com.tradewiseai.app.domain.analysis.ScreenshotLevel
import com.tradewiseai.app.domain.analysis.SetupEngine
import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Decision
import com.tradewiseai.app.domain.model.Direction
import com.tradewiseai.app.domain.model.Timeframe
import com.tradewiseai.app.domain.risk.DemoSettings
import com.tradewiseai.app.domain.risk.JournalLogic
import com.tradewiseai.app.domain.risk.JournalTrade
import com.tradewiseai.app.domain.risk.RiskCalculator
import com.tradewiseai.app.domain.risk.RiskInput
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class RiskCalculatorTest {

    private fun input(
        pair: CurrencyPair = CurrencyPair.EURUSD, account: String = "USD", balance: Double = 1000.0, risk: Double = 1.0,
        entry: Double = 1.1000, stop: Double = 1.0950, tp: Double? = 1.1100, rate: Double? = null
    ) = RiskInput(account, balance, risk, pair, entry, stop, tp, accountPerUsd = rate, maxRiskPercent = 5.0)

    @Test fun eurusd_usdAccount_handComputed() {
        // risk $10; stop 50 pips; $10/pip/lot -> 10 / (50*10) = 0.02 lots; TP 100 pips -> $20 -> RR 2
        val r = RiskCalculator.calculate(input())
        assertTrue(r.error, r.valid)
        assertEquals(50.0, r.stopPips, 1e-6)
        assertEquals(10.0, r.riskAmount, 1e-9)
        assertEquals(0.02, r.lots, 1e-9)
        assertEquals(10.0, r.potentialLoss, 1e-6)
        assertEquals(20.0, r.potentialProfit!!, 1e-6)
        assertEquals(2.0, r.riskReward!!, 1e-6)
        assertEquals(2000.0, r.units, 1e-6)
        assertTrue(r.exact)
    }

    @Test fun usdjpy_usesJpyPipSize_andConvertsPipValue() {
        // pip = 0.01 ; 1 lot pip = 1000 JPY = 1000/150 USD = 6.6667 ; 50 pips -> lots = 10 / (50*6.6667) = 0.03
        val r = RiskCalculator.calculate(input(CurrencyPair.USDJPY, entry = 150.00, stop = 149.50, tp = 151.00))
        assertTrue(r.error, r.valid)
        assertEquals(50.0, r.stopPips, 1e-6)
        assertEquals(6.6667, r.pipValuePerLot, 1e-3)
        assertEquals(0.03, r.lots, 1e-9)
    }

    @Test fun shortTrade_isHandled() {
        val r = RiskCalculator.calculate(input(entry = 1.1000, stop = 1.1050, tp = 1.0900))
        assertTrue(r.error, r.valid)
        assertEquals(50.0, r.stopPips, 1e-6)
        assertEquals(2.0, r.riskReward!!, 1e-6)
    }

    @Test fun nonUsdAccount_withoutRate_isRejected_withRate_isApproximate() {
        val bad = RiskCalculator.calculate(input(CurrencyPair.GBPUSD, account = "EUR", entry = 1.27, stop = 1.265, tp = null))
        assertFalse(bad.valid)
        val ok = RiskCalculator.calculate(input(CurrencyPair.GBPUSD, account = "EUR", entry = 1.27, stop = 1.265, tp = null, rate = 0.92))
        assertTrue(ok.error, ok.valid)
        assertFalse(ok.exact)
        assertTrue(ok.notes.any { it.contains("Approximate") })
        assertEquals(9.2, ok.pipValuePerLot, 1e-9)
    }

    @Test fun riskAboveMaximum_isRejected() {
        assertFalse(RiskCalculator.calculate(input(risk = 9.0)).valid)
    }

    @Test fun invalidInputs_areRejected() {
        assertFalse(RiskCalculator.calculate(input(balance = 0.0)).valid)
        assertFalse(RiskCalculator.calculate(input(stop = 1.1000)).valid)                // stop == entry
        assertFalse(RiskCalculator.calculate(input(tp = 1.0900)).valid)                  // TP on wrong side for a long
        assertFalse(RiskCalculator.calculate(input(balance = 10.0)).valid)               // account too small for 0.01 lot
    }
}

class JournalLogicTest {

    private fun trade(id: String, result: Double?, risk: Double = 10.0, closedAt: Long? = 1_000_000L, dir: Direction = Direction.LONG,
                      entry: Double = 1.1, stop: Double = 1.095, openedAt: Long = 0L) =
        JournalTrade(id, CurrencyPair.EURUSD, dir, entry, if (result == null) null else entry + 0.001, stop, null, 0.02, risk, result, "calm", "r", "l", null, openedAt, closedAt)

    private val settings = DemoSettings(startingBalance = 1000.0, maxRiskPercent = 2.0, dailyLossLimitPercent = 5.0)

    @Test fun pnl_eurusd_handComputed() {
        // +50 pips * $10 * 0.1 lot = $50
        assertEquals(50.0, JournalLogic.pnlUsd(CurrencyPair.EURUSD, Direction.LONG, 1.1000, 1.1050, 0.1)!!, 1e-6)
        assertEquals(-50.0, JournalLogic.pnlUsd(CurrencyPair.EURUSD, Direction.SHORT, 1.1000, 1.1050, 0.1)!!, 1e-6)
    }

    @Test fun stats_winRate_avgR_drawdown_equity() {
        val s = JournalLogic.stats(listOf(trade("a", 20.0, closedAt = 1L), trade("b", -10.0, closedAt = 2L), trade("c", null, closedAt = null)), 1000.0)
        assertEquals(3, s.total); assertEquals(2, s.closed)
        assertEquals(1, s.wins); assertEquals(1, s.losses)
        assertEquals(50.0, s.winRate, 1e-9)
        assertEquals(10.0, s.totalPnl, 1e-9)
        assertEquals(0.5, s.avgR!!, 1e-9)                     // R = +2 and -1
        assertEquals(10.0, s.maxDrawdown, 1e-9)
        assertEquals(listOf(1000.0, 1020.0, 1010.0), s.equityCurve)
        assertEquals(1010.0, s.balance, 1e-9)
    }

    @Test fun emptyJournal_hasNoStats() {
        val s = JournalLogic.stats(emptyList(), 1000.0)
        assertEquals(0.0, s.winRate, 0.0); assertNull(s.avgR); assertEquals(1000.0, s.balance, 0.0)
    }

    @Test fun guard_requiresStopOnTheCorrectSide() {
        val g = JournalLogic.check(trade("n", null, stop = 1.2), emptyList(), settings, 1_000_000L)
        assertFalse(g.allowed)
        assertTrue(g.blocks.any { it.contains("wrong side") })
        assertFalse(JournalLogic.check(trade("n", null, stop = 0.0), emptyList(), settings, 1_000_000L).allowed)
    }

    @Test fun guard_blocksRiskAboveMaximum() {
        val g = JournalLogic.check(trade("n", null, risk = 50.0), emptyList(), settings, 1_000_000L)
        assertTrue(g.blocks.any { it.contains("above your maximum") })
    }

    @Test fun guard_blocksAfterDailyLossLimit() {
        val now = 10 * 86_400_000L + 12 * 3_600_000L
        val loss = trade("l", -60.0, closedAt = now - 3_600_000L)       // 6% of 1000 > 5% limit
        val g = JournalLogic.check(trade("n", null), listOf(loss), settings, now)
        assertTrue(g.blocks.any { it.contains("Daily simulated loss limit") })
    }

    @Test fun guard_warnsOnRevengeTrading_andRiskEscalation() {
        val now = 10 * 86_400_000L + 12 * 3_600_000L
        val loss = trade("l", -5.0, risk = 5.0, closedAt = now - 10 * 60_000L)
        val g = JournalLogic.check(trade("n", null, risk = 10.0), listOf(loss), settings, now)
        assertTrue(g.allowed)
        assertTrue(g.warnings.any { it.contains("revenge") })
        assertTrue(g.warnings.any { it.contains("risking more") })
    }

    @Test fun guard_cleanTradeHasNoWarnings() {
        val g = JournalLogic.check(trade("n", null), emptyList(), settings, 1_000_000L)
        assertTrue(g.allowed); assertTrue(g.warnings.isEmpty())
    }

    @Test fun dayStart_usesEastAfricaTime() {
        // 2023-11-14 22:00 UTC is already 01:00 on the 15th in EAT; the EAT day started 2023-11-14 21:00 UTC
        val nowMs = 1_699_999_200_000L              // 2023-11-14T22:00:00Z
        val start = JournalLogic.dayStartMs(nowMs, 3 * 3_600_000L)
        assertEquals(1_699_995_600_000L, start)     // 2023-11-14T21:00:00Z
    }
}

class DataQualityAndFmtTest {

    private fun series(origin: DataOrigin, lastTime: Long, tf: Timeframe = Timeframe.M15) =
        CandleSeries(CurrencyPair.EURUSD, tf, listOf(Candle(lastTime, 1.0, 1.1, 0.9, 1.0)), origin, "p", 0L)

    private val now = 1_700_000_000L

    @Test fun live_cached_stale_demo() {
        assertEquals(DataStatus.LIVE, DataQuality.statusOf(series(DataOrigin.LIVE, now - 300), now))
        assertEquals(DataStatus.CACHED, DataQuality.statusOf(series(DataOrigin.CACHED, now - 300), now))
        assertEquals(DataStatus.STALE, DataQuality.statusOf(series(DataOrigin.LIVE, now - 5 * 900), now))
        assertEquals(DataStatus.STALE, DataQuality.statusOf(series(DataOrigin.CACHED, now - 86_400), now))
        assertEquals(DataStatus.DEMO, DataQuality.statusOf(series(DataOrigin.DEMO, now - 86_400), now))
    }

    @Test fun emptySeriesIsStale() {
        val s = CandleSeries(CurrencyPair.EURUSD, Timeframe.H1, emptyList(), DataOrigin.LIVE, "p", 0L)
        assertEquals(DataStatus.STALE, DataQuality.statusOf(s, now))
    }

    @Test fun quoteStatus_rules() {
        assertEquals(DataStatus.LIVE, DataQuality.quoteStatus(DataOrigin.LIVE, now - 10, now))
        assertEquals(DataStatus.CACHED, DataQuality.quoteStatus(DataOrigin.CACHED, now - 10, now))
        assertEquals(DataStatus.STALE, DataQuality.quoteStatus(DataOrigin.LIVE, now - 1000, now))
        assertEquals(DataStatus.DEMO, DataQuality.quoteStatus(DataOrigin.DEMO, now, now))
    }

    @Test fun formatting() {
        assertEquals("1.10000", Fmt.price(CurrencyPair.EURUSD, 1.1))
        assertEquals("150.250", Fmt.price(CurrencyPair.USDJPY, 150.25))
        assertEquals("-", Fmt.price(CurrencyPair.EURUSD, null as Double?))
        assertEquals("50.0 pips", Fmt.pips(CurrencyPair.EURUSD, 0.005))
        assertEquals("50.0 pips", Fmt.pips(CurrencyPair.USDJPY, 0.5))
        assertEquals("01 Jan, 03:00 EAT", Fmt.timeEat(0))
        assertEquals("-\$1,234.50", Fmt.money(-1234.5))
        assertEquals("+\$5.00", Fmt.signedMoney(5.0))
        assertEquals("just now", Fmt.ago(2)); assertEquals("5m ago", Fmt.ago(300)); assertEquals("2d ago", Fmt.ago(2 * 86_400))
    }

    @Test fun pairParsing() {
        assertEquals(CurrencyPair.EURUSD, CurrencyPair.fromSymbol("eur/usd"))
        assertEquals(CurrencyPair.USDJPY, CurrencyPair.fromSymbol("USDJPY"))
        assertNull(CurrencyPair.fromSymbol("BTC/USD"))
        assertEquals(Timeframe.H4, Timeframe.fromLabel("4H"))
    }
}

class ExplainTest {

    private fun waitResult() = SetupEngine.evaluate(
        CurrencyPair.EURUSD, emptyList(), emptyList(), emptyList(),
        com.tradewiseai.app.domain.analysis.SetupConfig(), 1_700_000_000L, null, true
    )

    @Test fun localExplanation_forWait_neverInventsASetup() {
        val r = waitResult()
        assertEquals(Decision.WAIT, r.decision)
        val ex = LocalExplainer.explain(r)
        assertEquals(AiExplanation.Source.ON_DEVICE_RULES, ex.source)
        assertTrue(ex.summary.contains("WAIT"))
        assertTrue(ex.beginnerExplanation.isNotBlank())
        assertTrue(ex.risks.isNotEmpty())
    }

    private fun shot(readable: Boolean = true, pair: String? = "EUR/USD", levels: List<Double> = listOf(1.1)) = ScreenshotAnalysis(
        readable, "", ReadItem(pair, if (pair == null) "unclear" else "read"), ReadItem("15m", "read"), emptyList(),
        levels.map { ScreenshotLevel("price", it, "read") }, emptyList(), emptyList(), "", "", "", ""
    )

    @Test fun comparator_unreadable_noLive_wrongPair_close_far() {
        assertFalse(ScreenshotComparator.compare(shot(readable = false), CurrencyPair.EURUSD, 1.1, true).comparable)
        assertFalse(ScreenshotComparator.compare(shot(), CurrencyPair.EURUSD, null, true).comparable)
        assertFalse(ScreenshotComparator.compare(shot(), CurrencyPair.EURUSD, 1.1, false).comparable)
        assertFalse(ScreenshotComparator.compare(shot(pair = "GBP/USD"), CurrencyPair.EURUSD, 1.1, true).comparable)
        val close = ScreenshotComparator.compare(shot(levels = listOf(1.1005)), CurrencyPair.EURUSD, 1.1, true)
        assertTrue(close.comparable); assertTrue(close.message.contains("within"))
        val far = ScreenshotComparator.compare(shot(levels = listOf(1.2)), CurrencyPair.EURUSD, 1.1, true)
        assertTrue(far.message.contains("differs"))
        assertNotNull(far)
    }
}
