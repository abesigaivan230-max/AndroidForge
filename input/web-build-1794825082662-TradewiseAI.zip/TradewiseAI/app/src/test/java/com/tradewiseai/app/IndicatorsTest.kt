package com.tradewiseai.app

import com.tradewiseai.app.domain.indicators.Indicators
import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.Structure
import com.tradewiseai.app.domain.model.Trend
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Expected values below were worked out by hand (see comments), not copied from the code. */
class IndicatorsTest {

    private fun c(t: Long, o: Double, h: Double, l: Double, cl: Double) = Candle(t, o, h, l, cl)
    private fun hl(i: Int, high: Double, low: Double = high - 1.0) = c(i * 60L, high - 0.2, high, low, high - 0.5)

    @Test fun sma_correctValue() {
        assertEquals(5.0, Indicators.sma(listOf(1.0, 2.0, 3.0, 4.0, 5.0, 6.0), 3)!!, 1e-12)
        assertNull(Indicators.sma(listOf(1.0, 2.0), 3))
    }

    @Test fun ema_seedsWithSmaThenSmooths() {
        // values 1..10, period 3: seed = (1+2+3)/3 = 2 at idx2, k=0.5 -> 3, 4, ... idx9 = 9
        val e = Indicators.ema((1..10).map { it.toDouble() }, 3)
        assertNull(e[0]); assertNull(e[1])
        assertEquals(2.0, e[2]!!, 1e-12)
        assertEquals(3.0, e[3]!!, 1e-12)
        assertEquals(9.0, e[9]!!, 1e-12)
    }

    @Test fun ema_tooShortIsAllNull() {
        assertTrue(Indicators.ema(listOf(1.0, 2.0), 5).all { it == null })
    }

    @Test fun rsi_wilderHandComputed() {
        // period 2, closes 1,2,1,2: idx2 gains .5 losses .5 -> 50; idx3 avgGain=(.5+1)/2=.75 avgLoss=(.5+0)/2=.25 -> RS 3 -> 75
        val r = Indicators.rsi(listOf(1.0, 2.0, 1.0, 2.0), 2)
        assertNull(r[0]); assertNull(r[1])
        assertEquals(50.0, r[2]!!, 1e-9)
        assertEquals(75.0, r[3]!!, 1e-9)
    }

    @Test fun rsi_allGainsIs100_flatIs50() {
        assertEquals(100.0, Indicators.rsi((1..20).map { it.toDouble() }, 14).last()!!, 1e-9)
        assertEquals(50.0, Indicators.rsi(List(20) { 5.0 }, 14).last()!!, 1e-9)
    }

    @Test fun atr_wilderHandComputed() {
        // TR1 = max(2,|11-9|,|9-9|)=2 ; TR2 = 2 ; atr[2] = 2 ; TR3 = max(3,|14-11|,|11-11|)=3 ; atr[3] = (2*1+3)/2 = 2.5
        val cs = listOf(c(0, 9.0, 10.0, 8.0, 9.0), c(1, 9.0, 11.0, 9.0, 10.0), c(2, 10.0, 12.0, 10.0, 11.0), c(3, 11.0, 14.0, 11.0, 13.0))
        val a = Indicators.atr(cs, 2)
        assertNull(a[1])
        assertEquals(2.0, a[2]!!, 1e-12)
        assertEquals(2.5, a[3]!!, 1e-12)
    }

    @Test fun macd_constantSeriesIsZeroAndWarmupIsNull() {
        val m = Indicators.macd(List(60) { 1.1 })
        assertNull(m.macd[24]); assertNotNull(m.macd[25])
        assertNull(m.signal[32]); assertNotNull(m.signal[33])     // 25 + 9 - 1 = 33
        assertEquals(0.0, m.histogram.last()!!, 1e-12)
    }

    @Test fun macd_risingSeriesIsPositive() {
        val m = Indicators.macd((1..80).map { 1.0 + it * 0.01 })
        assertTrue(m.macd.last()!! > 0)
    }

    @Test fun swingHighLow_detectedWithLookback() {
        val highs = listOf(1.0, 2.0, 3.0, 10.0, 3.0, 2.0, 1.0)
        val cs = highs.mapIndexed { i, h -> hl(i, h) }
        assertEquals(listOf(3), Indicators.swingHighs(cs, 3))
        val lows = listOf(9.0, 8.0, 7.0, 1.0, 7.0, 8.0, 9.0)
        val cs2 = lows.mapIndexed { i, l -> c(i * 60L, l + 0.5, l + 1.0, l, l + 0.5) }
        assertEquals(listOf(3), Indicators.swingLows(cs2, 3))
    }

    @Test fun swingHigh_tieIsNotASwing() {
        val highs = listOf(1.0, 2.0, 3.0, 5.0, 5.0, 2.0, 1.0)
        assertTrue(Indicators.swingHighs(highs.mapIndexed { i, h -> hl(i, h) }, 2).isEmpty())
    }

    @Test fun levels_clustersNearbySwings() {
        // two swing highs at 10.0 and 10.05 are within tolerance 0.1 -> one level with 2 touches
        val highs = listOf(1.0, 2.0, 10.0, 2.0, 1.0, 2.0, 10.05, 2.0, 1.0)
        val cs = highs.mapIndexed { i, h -> hl(i, h, low = 0.0 + i * 0.0) }
        val lv = Indicators.levels(cs, 0.1, 2)
        val top = lv.first()
        assertEquals(2, top.touches)
        assertEquals(10.025, top.price, 1e-9)
    }

    @Test fun structure_higherHighsHigherLows() {
        // zig-zag rising: highs 5,3,.. build explicit swings with lookback 1
        val highs = listOf(1.0, 5.0, 2.0, 7.0, 3.0, 9.0, 4.0)
        val cs = highs.mapIndexed { i, h -> c(i * 60L, h - 0.5, h, h - 1.0 - (if (i % 2 == 0) 0.0 else 0.0), h - 0.5) }
        // swing highs (idx1=5, idx3=7, idx5=9) rising; swing lows idx2 (low 1), idx4 (low 2) rising
        assertEquals(Structure.HH_HL, Indicators.structure(cs, 1))
    }

    @Test fun structure_notEnoughSwingsIsUnknown() {
        assertEquals(Structure.UNKNOWN, Indicators.structure((1..8).map { hl(it, it.toDouble()) }, 3))
    }

    @Test fun trend_rampsAndFlat() {
        fun ramp(sign: Int) = (0 until 80).map { i -> val p = 100.0 + sign * i * 0.1; c(i * 60L, p, p + 0.05, p - 0.05, p) }
        assertEquals(Trend.UP, Indicators.trend(ramp(1)).trend)
        assertEquals(Trend.DOWN, Indicators.trend(ramp(-1)).trend)
        assertEquals(Trend.RANGE, Indicators.trend(List(80) { i -> c(i * 60L, 100.0, 100.1, 99.9, 100.0) }).trend)
        assertEquals(Trend.UNKNOWN, Indicators.trend(List(30) { i -> c(i * 60L, 100.0, 100.1, 99.9, 100.0) }).trend)
    }
}
