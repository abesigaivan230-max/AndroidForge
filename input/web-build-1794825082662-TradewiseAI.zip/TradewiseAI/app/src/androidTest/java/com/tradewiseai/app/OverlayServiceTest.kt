package com.tradewiseai.app

import android.content.Context
import android.provider.Settings
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.tradewiseai.app.overlay.OverlayPermission
import com.tradewiseai.app.overlay.OverlayService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class OverlayServiceTest {
    private val ctx: Context = ApplicationProvider.getApplicationContext()

    @Test fun permissionCheckMatchesSystem() {
        assertEquals(Settings.canDrawOverlays(ctx), OverlayPermission.canDraw(ctx))
    }

    /** Without the permission, start() must refuse cleanly instead of crashing. */
    @Test fun startWithoutPermissionIsRefused() {
        if (OverlayPermission.canDraw(ctx)) return   // run on a device where the permission is not granted
        assertFalse(OverlayService.start(ctx))
        assertFalse(OverlayService.running)
    }
}
