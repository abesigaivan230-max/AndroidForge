package com.tradewiseai.app.feature.journal

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Direction
import com.tradewiseai.app.domain.risk.JournalLogic
import com.tradewiseai.app.domain.risk.JournalTrade
import com.tradewiseai.app.domain.risk.RiskCalculator
import com.tradewiseai.app.domain.risk.RiskInput
import com.tradewiseai.app.ui.charts.EquityChart
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.EmptyState
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.Pill
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.SectionTitle
import com.tradewiseai.app.ui.components.StatTile
import com.tradewiseai.app.ui.components.TwCard
import com.tradewiseai.app.ui.components.TwField
import com.tradewiseai.app.ui.components.toDoubleOrNullLoose
import kotlinx.coroutines.launch
import java.util.UUID

private val EMOTIONS = listOf("Calm", "Confident", "Anxious", "Excited", "Frustrated", "Bored")

@Composable
fun JournalScreen(onSize: () -> Unit) {
    val app = rememberApp()
    val scope = rememberCoroutineScope()
    val s by app.settings.state.collectAsState()
    val trades by app.journal.trades.collectAsState()
    val auth by app.auth.state.collectAsState()
    val stats = JournalLogic.stats(trades, s.startingBalance)

    var adding by remember { mutableStateOf(false) }
    var pair by remember { mutableStateOf(s.defaultPair) }
    var dir by remember { mutableStateOf(Direction.LONG) }
    var entry by remember { mutableStateOf("") }
    var stop by remember { mutableStateOf("") }
    var tp by remember { mutableStateOf("") }
    var riskPct by remember { mutableStateOf("1") }
    var emotion by remember { mutableStateOf("Calm") }
    var reason by remember { mutableStateOf("") }
    var formMsg by remember { mutableStateOf<List<String>>(emptyList()) }
    var formErr by remember { mutableStateOf<String?>(null) }
    var closing by remember { mutableStateOf<String?>(null) }
    var exitPrice by remember { mutableStateOf("") }
    var closeLesson by remember { mutableStateOf("") }
    var syncMsg by remember { mutableStateOf<String?>(null) }

    fun save() {
        formErr = null; formMsg = emptyList()
        val e = entry.toDoubleOrNullLoose(); val sl = stop.toDoubleOrNullLoose(); val t = tp.toDoubleOrNullLoose(); val rp = riskPct.toDoubleOrNullLoose()
        if (e == null || sl == null || rp == null) { formErr = "Entry, stop-loss and risk % are required."; return }
        val calc = RiskCalculator.calculate(RiskInput("USD", stats.balance, rp, pair, e, sl, t, null, s.maxRiskPercent))
        if (!calc.valid) { formErr = calc.error; return }
        val draft = JournalTrade(UUID.randomUUID().toString(), pair, dir, e, null, sl, t, calc.lots, calc.riskAmount, null, emotion, reason, "", null, System.currentTimeMillis(), null)
        val g = JournalLogic.check(draft, trades, s.demoSettings(), System.currentTimeMillis())
        if (!g.allowed) { formErr = g.blocks.joinToString("\n"); formMsg = g.warnings; return }
        scope.launch { app.journal.add(draft); formMsg = emptyList(); adding = false; entry = ""; stop = ""; tp = ""; reason = "" }
        if (g.warnings.isNotEmpty()) formMsg = g.warnings
    }

    ScreenColumn {
        Text("Journal", style = TwType.display)
        Banner("SIMULATED demo account. Balances and P/L here are not connected to any broker or real money.", TW.blueSoft, warning = false)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("Balance", Fmt.money(stats.balance), Modifier.weight(1f))
            StatTile("P/L", Fmt.signedMoney(stats.totalPnl), Modifier.weight(1f), if (stats.totalPnl >= 0) TW.green else TW.red)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StatTile("Win rate", if (stats.closed == 0) "-" else Fmt.pct(stats.winRate, 0), Modifier.weight(1f), sub = "${stats.wins}W / ${stats.losses}L")
            StatTile("Avg R", stats.avgR?.let { "%.2f".format(it) } ?: "-", Modifier.weight(1f), sub = "Max DD ${Fmt.money(stats.maxDrawdown)}")
        }
        TwCard { Text("SIMULATED EQUITY", style = TwType.label); EquityChart(stats.equityCurve) }
        formMsg.forEach { Banner(it, TW.amber) }

        if (adding) {
            Appear { TwCard(accent = TW.blue) {
                Text("New demo entry", style = TwType.heading)
                ChipRow(CurrencyPair.values().map { it.symbol }, pair.symbol, { x -> CurrencyPair.fromSymbol(x)?.let { pair = it } })
                ChipRow(listOf("Long", "Short"), if (dir == Direction.LONG) "Long" else "Short", { dir = if (it == "Long") Direction.LONG else Direction.SHORT })
                TwField(entry, { entry = it }, "Entry", numeric = true)
                TwField(stop, { stop = it }, "Stop-loss (required)", numeric = true)
                TwField(tp, { tp = it }, "Take-profit (optional)", numeric = true)
                TwField(riskPct, { riskPct = it }, "Risk % of balance (max ${s.maxRiskPercent})", numeric = true)
                Text("EMOTION", style = TwType.label)
                ChipRow(EMOTIONS, emotion, { emotion = it })
                TwField(reason, { reason = it }, "Why this trade?", singleLine = false, minLines = 2)
                formErr?.let { Banner(it, TW.red) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Save entry", { save() })
                    GhostButton("Cancel", { adding = false; formErr = null })
                    GhostButton("Size", onSize, icon = Icons.Default.Calculate)
                }
            } }
        } else GhostButton("New demo entry", { adding = true }, Modifier.fillMaxWidth(), Icons.Default.Add)

        SectionTitle("Trades")
        if (trades.isEmpty()) EmptyState("No entries yet", "Log demo trades with a stop-loss and a reason. Patterns in your behaviour show up after a few weeks.")
        trades.sortedByDescending { it.openedAtMs }.forEachIndexed { i, t ->
            Appear(i * 30) {
                TwCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("${t.pair.symbol}  ${if (t.direction == Direction.LONG) "LONG" else "SHORT"}", style = TwType.heading, modifier = Modifier.weight(1f))
                        if (t.isClosed) Pill(Fmt.signedMoney(t.resultAmount ?: 0.0), if ((t.resultAmount ?: 0.0) >= 0) TW.green else TW.red) else Pill("OPEN", TW.amber)
                    }
                    Text(Fmt.timeEat(t.openedAtMs / 1000), style = TwType.small)
                    KeyValue("Entry / Stop", "${Fmt.price(t.pair, t.entry)} / ${Fmt.price(t.pair, t.stopLoss)}")
                    KeyValue("Lots / Risk", "${"%.2f".format(t.lots)} / ${Fmt.money(t.riskAmount)}")
                    t.rMultiple?.let { KeyValue("R multiple", "%.2f".format(it)) }
                    if (t.reason.isNotBlank()) Text("Why: ${t.reason}", style = TwType.small)
                    Text("Felt: ${t.emotion}", style = TwType.small)
                    if (t.lessons.isNotBlank()) Text("Lesson: ${t.lessons}", style = TwType.small)
                    if (closing == t.id) {
                        TwField(exitPrice, { exitPrice = it }, "Exit price", numeric = true)
                        TwField(closeLesson, { closeLesson = it }, "What did you learn?", singleLine = false)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PrimaryButton("Close trade", {
                                val x = exitPrice.toDoubleOrNullLoose()
                                val pnl = x?.let { JournalLogic.pnlUsd(t.pair, t.direction, t.entry, it, t.lots) }
                                if (x != null && pnl != null) {
                                    scope.launch { app.journal.update(t.copy(exit = x, resultAmount = pnl, lessons = closeLesson, closedAtMs = System.currentTimeMillis())) }
                                    closing = null; exitPrice = ""; closeLesson = ""
                                }
                            })
                            GhostButton("Cancel", { closing = null })
                        }
                    } else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (!t.isClosed) GhostButton("Close", { closing = t.id; exitPrice = "" })
                        GhostButton("", { scope.launch { app.journal.delete(t.id) } }, icon = Icons.Default.Delete, color = TW.red)
                    }
                }
            }
        }

        SectionTitle("Cloud sync (optional)")
        TwCard {
            Text(if (auth.signedIn) "Signed in as ${auth.email}. Sync uploads your journal to your private account." else "Sign in under Settings > Account to back up your journal. The journal works fully offline without an account.", style = TwType.small)
            if (auth.signedIn) GhostButton("Sync now", {
                syncMsg = "Syncing…"
                scope.launch { syncMsg = app.sync.sync().fold({ it }, { it.message ?: "Sync failed." }) }
            }, Modifier.fillMaxWidth())
            syncMsg?.let { Text(it, style = TwType.small) }
        }
    }
}
