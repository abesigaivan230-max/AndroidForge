package com.tradewiseai.app.overlay

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings

object OverlayPermission {
    fun canDraw(context: Context): Boolean = Settings.canDrawOverlays(context)

    /** Opens the system "Display over other apps" screen for this app. The user must flip the switch themselves. */
    fun settingsIntent(context: Context): Intent =
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
}
