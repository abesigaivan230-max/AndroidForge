package com.tradewiseai.app.notifications

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.tradewiseai.app.TradewiseApp
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.data.preferences.AppSettings
import com.tradewiseai.app.data.remote.Impact
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Decision
import java.util.concurrent.TimeUnit

/**
 * Runs about every 15 minutes (the Android minimum). Rules that keep it from crying wolf:
 *  - nothing is ever fired from DEMO data;
 *  - a price alert fires once, then is marked triggered;
 *  - a setup alert fires only for a NEW BUY/SELL setup (new entry candle), never repeatedly for the same one;
 *  - data errors are rate-limited to one per 6 hours;
 *  - calendar reminders fire once per event.
 */
class AlertWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val app = applicationContext as? TradewiseApp ?: return Result.success()
        val s = app.settings.current
        if (!(s.notifyPrice || s.notifySetup || s.notifyErrors || s.notifyCalendar)) return Result.success()
        try {
            if (s.notifyPrice) checkPrices(app, s)
            if (s.notifySetup) checkSetup(app, s)
            if (s.notifyCalendar) checkCalendar(app)
        } catch (e: Exception) {
            reportError(app, s, e.message ?: "unknown error")
        }
        return Result.success()
    }

    private suspend fun checkPrices(app: TradewiseApp, s: AppSettings) {
        val active = app.alerts.active()
        if (active.isEmpty() || app.market.usingDemo) return
        for (pair in active.map { it.pair }.distinct()) {
            val res = app.market.quote(pair)
            val q = res.getOrNull()
            if (q == null) { reportError(app, s, "Price check for ${pair.symbol} failed: ${res.exceptionOrNull()?.message}"); continue }
            if (q.origin == DataOrigin.DEMO || app.market.statusOf(q) != DataStatus.LIVE) continue
            for (a in active.filter { it.pair == pair }) {
                val hit = if (a.above) q.price >= a.target else q.price <= a.target
                if (hit) {
                    app.alerts.markTriggered(a.id)
                    Notifier.alert(applicationContext, "price_${a.id}", "${pair.symbol} price alert",
                        "${pair.symbol} is ${Fmt.price(pair, q.price)}, ${if (a.above) "above" else "below"} your ${Fmt.price(pair, a.target)} alert.")
                }
            }
        }
    }

    private suspend fun checkSetup(app: TradewiseApp, s: AppSettings) {
        if (app.market.usingDemo) return
        val pair = s.defaultPair
        val res = app.analysis.analyse(pair)
        val o = res.getOrNull()
        if (o == null) { reportError(app, s, "Setup check failed: ${res.exceptionOrNull()?.message}"); return }
        if (o.isDemo || o.worstStatus != DataStatus.LIVE) return
        val key = "setup_${pair.name}"
        val r = o.result
        if (r.decision == Decision.WAIT) { app.alerts.putString(key, "WAIT"); return }
        val candleTime = r.entryTfSnapshot?.lastClosedTime ?: r.generatedAtSec
        val signature = "${r.decision.name}_$candleTime"
        if (app.alerts.getString(key) == signature) return           // already told the user about this exact setup
        app.alerts.putString(key, signature)
        Notifier.alert(applicationContext, key, "${pair.symbol}: ${r.decision.label}",
            "${r.passedCount} of ${r.checks.size} rules satisfied. This is a rule-based setup, not a prediction. Open TRADEWISE AI to see the reasoning and invalidation.")
    }

    private suspend fun checkCalendar(app: TradewiseApp) {
        val res = app.calendar.load()
        val now = System.currentTimeMillis() / 1000
        for (e in res.events) {
            if (e.impact != Impact.HIGH) continue
            if (e.timeSec !in now..(now + 30 * 60)) continue
            val key = "cal_${e.id}"
            if (app.alerts.getLong(key) != 0L) continue
            app.alerts.putLong(key, now)
            Notifier.alert(applicationContext, key, "High-impact event soon: ${e.currency}",
                "${e.title} at ${Fmt.timeEat(e.timeSec, "HH:mm")}. Spreads can widen and prices can jump; consider staying out.")
        }
    }

    private fun reportError(app: TradewiseApp, s: AppSettings, message: String) {
        if (!s.notifyErrors) return
        val now = System.currentTimeMillis()
        if (now - app.alerts.getLong("err_at") < 6 * 3_600_000L) return
        app.alerts.putLong("err_at", now)
        Notifier.alert(applicationContext, "data_error", "Market data problem", message)
    }
}

object AlertScheduler {
    private const val NAME = "tradewise_alerts"

    /** Call whenever the notification toggles change (and at app start). */
    fun sync(context: Context, s: AppSettings) {
        val wm = WorkManager.getInstance(context)
        if (s.notifyPrice || s.notifySetup || s.notifyErrors || s.notifyCalendar) {
            val req = PeriodicWorkRequestBuilder<AlertWorker>(15, TimeUnit.MINUTES)
                .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
                .build()
            wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.UPDATE, req)
        } else {
            wm.cancelUniqueWork(NAME)
        }
    }
}
