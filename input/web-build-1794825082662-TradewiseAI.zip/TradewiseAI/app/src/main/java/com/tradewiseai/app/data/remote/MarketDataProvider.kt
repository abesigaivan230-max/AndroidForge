package com.tradewiseai.app.data.remote

import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.domain.model.Timeframe

data class ProviderStatus(
    val name: String,
    val configured: Boolean,
    val reachable: Boolean?,
    val message: String
)

/** Anything that can supply forex data. Add another provider by implementing this interface. */
interface MarketDataProvider {
    val name: String
    suspend fun getLatestQuote(pair: CurrencyPair): Result<Quote>
    suspend fun getHistoricalCandles(pair: CurrencyPair, timeframe: Timeframe, count: Int): Result<CandleSeries>
    fun getAvailablePairs(): List<CurrencyPair>
    suspend fun getProviderStatus(): ProviderStatus
}
