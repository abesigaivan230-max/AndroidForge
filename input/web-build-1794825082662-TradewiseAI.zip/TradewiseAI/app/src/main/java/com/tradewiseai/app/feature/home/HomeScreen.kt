package com.tradewiseai.app.feature.home

import android.content.Context
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradewiseai.app.Sub
import com.tradewiseai.app.Tab
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.overlay.OverlayMode
import com.tradewiseai.app.overlay.OverlayPermission
import com.tradewiseai.app.overlay.OverlayService
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.DecisionBadge
import com.tradewiseai.app.ui.components.EmptyState
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.SectionTitle
import com.tradewiseai.app.ui.components.StatusChip
import com.tradewiseai.app.ui.components.TwCard
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope

@Composable
fun HomeScreen(onOpen: (Sub) -> Unit, onTab: (Tab) -> Unit) {
    val app = rememberApp()
    val ctx = LocalContext.current
    val s by app.settings.state.collectAsState()
    val recent by app.analysis.recent.collectAsState()
    val scope = rememberCoroutineScope()

    var canDraw by remember { mutableStateOf(OverlayPermission.canDraw(ctx)) }
    var running by remember { mutableStateOf(OverlayService.running) }
    var note by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(Unit) {            // the user may grant the permission in system settings and come back
        while (true) { canDraw = OverlayPermission.canDraw(ctx); running = OverlayService.running; delay(1000) }
    }

    var quotes by remember { mutableStateOf<Map<CurrencyPair, Pair<Quote, DataStatus>>>(emptyMap()) }
    var loading by remember { mutableStateOf(false) }
    fun refresh() {
        if (loading) return
        loading = true
        scope.launch {
            val out = LinkedHashMap<CurrencyPair, Pair<Quote, DataStatus>>()
            for (p in s.watchlist.sortedBy { it.ordinal }) app.market.quote(p).getOrNull()?.let { out[p] = it to app.market.statusOf(it) }
            quotes = out
            loading = false
        }
    }
    LaunchedEffect(s.watchlist, s.forceDemoData) { refresh() }

    ScreenColumn {
        Appear {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TRADEWISE AI", style = TwType.display)
                    Text("Rules-based forex analysis for learning", style = TwType.small)
                }
                GhostButton("", { onOpen(Sub.SETTINGS) }, icon = Icons.Default.Settings)
            }
        }
        app.market.demoReason?.let { Appear(60) { Banner("DEMO DATA: $it Prices are synthetic and not a real market.") } }

        Appear(100) {
            TwCard(accent = if (running) TW.green else null) {
                Text("FLOATING ASSISTANT", style = TwType.label)
                Crossfade(running, label = "ovState") { on ->
                    Text(if (on) "Running. Open your chart app: the bubble stays on top." else "Off. Turn it on to analyse while you look at a chart.", style = TwType.body)
                }
                Text("Stays visible over your other apps. It never taps, types or trades for you.", style = TwType.small)
                ChipRow(OverlayMode.values().map { it.label }, s.overlayMode.label, { l ->
                    OverlayMode.values().firstOrNull { it.label == l }?.let { m -> app.settings.update { it.copy(overlayMode = m) } }
                })
                if (!canDraw) {
                    Banner("Android needs your permission to draw over other apps. You grant it once in system settings.", TW.blueSoft, warning = false)
                    PrimaryButton("Grant permission", { ctx.startActivity(OverlayPermission.settingsIntent(ctx).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth())
                } else if (running) {
                    PrimaryButton("Stop assistant", { OverlayService.stop(ctx); note = null }, Modifier.fillMaxWidth())
                } else {
                    PrimaryButton("Start assistant", {
                        note = if (OverlayService.start(ctx)) null else "Could not start the assistant. Check the permission and try again."
                    }, Modifier.fillMaxWidth(), Icons.Default.ShowChart)
                }
                note?.let { Text(it, style = TwType.small.copy(color = TW.red)) }
            }
        }

        SectionTitle("Watchlist") { GhostButton(if (loading) "…" else "Refresh", { refresh() }) }
        if (quotes.isEmpty()) {
            Appear(140) { TwCard { Text(if (loading) "Loading prices…" else "No prices yet. Check your connection or Settings.", style = TwType.small) } }
        } else quotes.values.forEachIndexed { i, (q, st) ->
            Appear(140 + i * 60) {
                TwCard(onClick = { onTab(Tab.MARKETS) }) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(q.pair.symbol, style = TwType.heading)
                            Text("Updated ${Fmt.clockEat(q.timestampSec)}", style = TwType.small)
                        }
                        Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text(Fmt.price(q.pair, q.price), style = TwType.mono.copy(fontSize = 18.sp))
                            StatusChip(st)
                        }
                    }
                }
            }
        }

        SectionTitle("Quick actions")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GhostButton("Analyse", { onTab(Tab.ANALYSE) }, Modifier.weight(1f), Icons.Default.Analytics)
            GhostButton("Size", { onOpen(Sub.SIZER) }, Modifier.weight(1f), Icons.Default.Calculate)
            GhostButton("Calendar", { onOpen(Sub.CALENDAR) }, Modifier.weight(1f), Icons.Default.CalendarMonth)
        }

        SectionTitle("Recent analyses")
        if (recent.isEmpty()) EmptyState("Nothing yet", "Run an analysis on the Analyse tab or from the floating assistant.")
        else recent.take(5).forEachIndexed { i, r ->
            Appear(i * 50) {
                TwCard {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        DecisionBadge(r.decision)
                        Column(Modifier.weight(1f)) {
                            Text("${r.pair.symbol}${if (r.demo) "  (DEMO)" else ""}", style = TwType.heading)
                            Text(r.summary, style = TwType.small, maxLines = 2)
                        }
                    }
                }
            }
        }
        Text("Educational only. Not financial advice. Setups describe rule agreement on past data, never a guaranteed outcome.", style = TwType.small)
    }
}
