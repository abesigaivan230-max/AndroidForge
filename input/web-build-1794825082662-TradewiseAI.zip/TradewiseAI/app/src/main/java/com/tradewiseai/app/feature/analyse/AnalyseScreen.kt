package com.tradewiseai.app.feature.analyse

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.capture.ImageTools
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.data.remote.ChatTurn
import com.tradewiseai.app.data.repository.AnalysisOutcome
import com.tradewiseai.app.data.repository.ScreenshotReport
import com.tradewiseai.app.domain.analysis.AiExplanation
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Decision
import com.tradewiseai.app.feature.tools.SizerBridge
import com.tradewiseai.app.feature.tools.SizerPrefill
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.BulletList
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.DecisionBadge
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.SectionTitle
import com.tradewiseai.app.ui.components.StatusChip
import com.tradewiseai.app.ui.components.TwCard
import com.tradewiseai.app.ui.components.TwField
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun AnalyseScreen(onSize: () -> Unit) {
    val app = rememberApp()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by app.settings.state.collectAsState()
    var pair by remember { mutableStateOf(s.defaultPair) }
    var outcome by remember { mutableStateOf<AnalysisOutcome?>(app.analysis.lastOutcome(s.defaultPair)) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var explanation by remember { mutableStateOf<AiExplanation?>(outcome?.let { app.ai.localExplanation(it.result) }) }
    var aiBusy by remember { mutableStateOf(false) }
    var aiNote by remember { mutableStateOf<String?>(null) }
    var question by remember { mutableStateOf("") }
    var history by remember { mutableStateOf(listOf<ChatTurn>()) }

    var shotPath by remember { mutableStateOf<String?>(null) }
    var shotBusy by remember { mutableStateOf(false) }
    var shotReport by remember { mutableStateOf<ScreenshotReport?>(null) }
    var shotError by remember { mutableStateOf<String?>(null) }

    fun load(uri: Uri) {
        shotBusy = true; shotError = null; shotReport = null
        scope.launch {
            ImageTools.importUri(ctx, uri).fold(
                onSuccess = { shotPath = it.absolutePath },
                onFailure = { shotError = it.message ?: "Could not read that image." }
            )
            shotBusy = false
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u -> if (u != null) load(u) }
    val sharedUri by app.pendingShareUri.collectAsState()
    val capturedPath by app.pendingShotPath.collectAsState()
    LaunchedEffect(sharedUri) { sharedUri?.let { load(it); app.pendingShareUri.value = null } }
    LaunchedEffect(capturedPath) { capturedPath?.let { shotPath = it; shotReport = null; shotError = null; app.pendingShotPath.value = null } }

    fun select(p: CurrencyPair) {
        pair = p; error = null; history = emptyList(); aiNote = null
        outcome = app.analysis.lastOutcome(p)
        explanation = outcome?.let { app.ai.localExplanation(it.result) }
    }
    fun run() {
        if (loading) return
        loading = true; error = null
        scope.launch {
            app.analysis.analyse(pair, force = true).fold(
                onSuccess = { outcome = it; explanation = app.ai.localExplanation(it.result); history = emptyList(); aiNote = null },
                onFailure = { error = it.message ?: "Analysis failed." }
            )
            loading = false
        }
    }
    fun ask(q: String?) {
        val o = outcome ?: return
        if (aiBusy) return
        aiBusy = true; aiNote = null
        scope.launch {
            app.ai.explain(o.result, q, history).fold(
                onSuccess = { explanation = it; if (q != null) history = (history + ChatTurn("user", q) + ChatTurn("assistant", it.answer)).takeLast(8) },
                onFailure = { aiNote = (it.message ?: "AI unavailable.") + " Showing the on-device explanation." }
            )
            aiBusy = false
        }
    }

    ScreenColumn {
        Text("Analyse", style = TwType.display)
        ChipRow(CurrencyPair.values().map { it.symbol }, pair.symbol, { x -> CurrencyPair.fromSymbol(x)?.let(::select) })
        app.market.demoReason?.let { Banner("DEMO DATA: $it") }
        PrimaryButton(if (loading) "Analysing 4H / 1H / 15m" else "Run analysis", ::run, Modifier.fillMaxWidth(), Icons.Default.ShowChart, loading = loading)
        error?.let { Banner(it, TW.red) }

        val o = outcome
        if (o == null) {
            if (!loading) Text("No analysis yet for ${pair.symbol}.", style = TwType.small)
        } else Appear {
            val r = o.result
            TwCard(accent = when (r.decision) { Decision.BUY_SETUP -> TW.green; Decision.SELL_SETUP -> TW.red; else -> TW.amber }) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    DecisionBadge(r.decision, large = true)
                    StatusChip(o.worstStatus)
                }
                Text(r.ruleSummary, style = TwType.small)
                Text("Generated ${Fmt.clockEat(r.generatedAtSec)}", style = TwType.small)
                if (r.decision != Decision.WAIT) {
                    KeyValue("Entry zone", "${Fmt.price(r.pair, r.entryZoneLow)} - ${Fmt.price(r.pair, r.entryZoneHigh)}")
                    KeyValue("Stop-loss", Fmt.price(r.pair, r.stopLoss), TW.red)
                    r.targets.forEach { KeyValue(it.label + if (it.isProjection) " (projection)" else "", "${Fmt.price(r.pair, it.price)}  (1:${"%.1f".format(it.rr)})", TW.green) }
                    r.riskReward?.let { KeyValue("Risk : reward", "1 : ${"%.2f".format(it)}") }
                    val e = r.entry; val sl = r.stopLoss
                    if (e != null && sl != null) GhostButton("Size this trade", {
                        SizerBridge.prefill.value = SizerPrefill(r.pair, e, sl, r.targets.firstOrNull()?.price); onSize()
                    }, Modifier.fillMaxWidth(), Icons.Default.Calculate)
                }
            }
            SectionTitle("Rule checklist")
            TwCard {
                r.checks.forEach { c ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (c.passed) "PASS" else "FAIL", style = TwType.label.copy(color = if (c.passed) TW.green else TW.red), modifier = Modifier.padding(top = 2.dp))
                        androidx.compose.foundation.layout.Column(Modifier.weight(1f)) {
                            Text(c.name, style = TwType.body); Text(c.detail, style = TwType.small)
                        }
                    }
                }
            }
            if (r.reasonsFor.isNotEmpty()) { SectionTitle("Reasons for"); TwCard { BulletList(r.reasonsFor, TW.green) } }
            if (r.reasonsAgainst.isNotEmpty()) { SectionTitle("Reasons against / why WAIT"); TwCard { BulletList(r.reasonsAgainst, TW.red) } }
            if (r.invalidation.isNotEmpty()) { SectionTitle("Invalidation"); TwCard { BulletList(r.invalidation, TW.amber) } }
            if (r.watchFor.isNotEmpty()) { SectionTitle("Watch for"); TwCard { BulletList(r.watchFor, TW.blueSoft) } }
            if (r.caveats.isNotEmpty()) Banner(r.caveats.joinToString(" "))

            SectionTitle("Explanation (${if (explanation?.source == AiExplanation.Source.AI) "AI" else "on-device rules"})")
            explanation?.let { ex ->
                TwCard {
                    Text(ex.summary, style = TwType.body)
                    if (ex.marketState.isNotBlank()) Text(ex.marketState, style = TwType.small)
                    if (ex.whySetupOrNot.isNotBlank()) Text(ex.whySetupOrNot, style = TwType.small)
                    BulletList(ex.indicatorNotes)
                    if (ex.whatWouldChange.isNotEmpty()) { Text("WHAT WOULD CHANGE THIS", style = TwType.label); BulletList(ex.whatWouldChange, TW.blueSoft) }
                    if (ex.beginnerExplanation.isNotBlank()) { Text("IN PLAIN WORDS", style = TwType.label); Text(ex.beginnerExplanation, style = TwType.small) }
                    if (ex.risks.isNotEmpty()) { Text("RISKS", style = TwType.label); BulletList(ex.risks, TW.red) }
                }
            }
            aiNote?.let { Banner(it, TW.blueSoft, warning = false) }
            GhostButton(if (aiBusy) "Asking AI…" else "Explain with AI", { ask(null) }, Modifier.fillMaxWidth(), enabled = !aiBusy)
            history.forEach { t ->
                Text(if (t.role == "user") "You: ${t.text}" else t.text, style = if (t.role == "user") TwType.small else TwType.body,
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).padding(vertical = 2.dp))
            }
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TwField(question, { question = it }, "Ask about this setup", Modifier.weight(1f))
                PrimaryButton("", { if (question.isNotBlank()) { ask(question); question = "" } }, icon = Icons.Default.Send, loading = aiBusy)
            }
        }

        SectionTitle("Chart screenshot")
        TwCard {
            Text("Pick or share a screenshot of any chart. It is analysed for what is visible only; unclear items are marked unclear, never guessed. Nothing is stored on the server.", style = TwType.small)
            val path = shotPath
            if (path != null) {
                val bmp = remember(path) { try { android.graphics.BitmapFactory.decodeFile(path)?.asImageBitmap() } catch (_: Exception) { null } }
                if (bmp != null) Image(bmp, "Screenshot preview", Modifier.fillMaxWidth().height(180.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Analyse screenshot", {
                        shotBusy = true; shotError = null
                        scope.launch {
                            app.screenshots.analyse(path, pair).fold({ shotReport = it }, { shotError = it.message ?: "Screenshot analysis failed." })
                            shotBusy = false
                        }
                    }, Modifier.weight(1f), loading = shotBusy)
                    GhostButton("", { File(path).delete(); shotPath = null; shotReport = null }, icon = Icons.Default.Delete, color = TW.red)
                }
            } else GhostButton(if (shotBusy) "Loading…" else "Choose screenshot", { picker.launch("image/*") }, Modifier.fillMaxWidth(), Icons.Default.Image)
            shotError?.let { Banner(it, TW.red) }
            shotReport?.let { rep ->
                val a = rep.analysis
                if (!a.readable) Banner(a.unreadableReason.ifBlank { "The chart is not readable." })
                else {
                    KeyValue("Pair", a.pair.value ?: "unclear")
                    KeyValue("Timeframe", a.timeframe.value ?: "unclear")
                    a.indicators.forEach { KeyValue("Indicator", if (it.isRead) it.value!! else "unclear") }
                    a.priceLevels.forEach { KeyValue(it.label, it.value?.toString() ?: "unclear") }
                    if (a.support.isNotEmpty()) KeyValue("Support", a.support.joinToString())
                    if (a.resistance.isNotEmpty()) KeyValue("Resistance", a.resistance.joinToString())
                    Text("Structure: ${a.structure}", style = TwType.small)
                    Text("Bullish case: ${a.bullishScenario}", style = TwType.small.copy(color = TW.green))
                    Text("Bearish case: ${a.bearishScenario}", style = TwType.small.copy(color = TW.red))
                    if (a.uncertainty.isNotBlank()) Text("Uncertainty: ${a.uncertainty}", style = TwType.small)
                    Banner(rep.comparison.message, TW.blueSoft, warning = false)
                }
            }
        }
    }
}
