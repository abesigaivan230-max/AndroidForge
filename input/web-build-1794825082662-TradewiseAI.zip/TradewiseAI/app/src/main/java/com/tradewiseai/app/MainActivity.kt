package com.tradewiseai.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.outlined.Analytics
import androidx.compose.material.icons.outlined.BarChart
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Book
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding as pad
import androidx.compose.foundation.clickable
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TradewiseTheme
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.feature.analyse.AnalyseScreen
import com.tradewiseai.app.feature.home.HomeScreen
import com.tradewiseai.app.feature.journal.JournalScreen
import com.tradewiseai.app.feature.learn.LearnScreen
import com.tradewiseai.app.feature.markets.MarketsScreen
import com.tradewiseai.app.feature.settings.SettingsScreen
import com.tradewiseai.app.feature.tools.CalendarScreen
import com.tradewiseai.app.feature.tools.SizerScreen

enum class Tab(val label: String, val icon: ImageVector) {
    HOME("Home", Icons.Outlined.Home),
    MARKETS("Markets", Icons.Outlined.BarChart),
    ANALYSE("Analyse", Icons.Outlined.Analytics),
    LEARN("Learn", Icons.Outlined.School),
    JOURNAL("Journal", Icons.Outlined.Book)
}

/** Secondary screens opened from inside a tab. */
enum class Sub(val title: String) { SETTINGS("Settings"), SIZER("Position size"), CALENDAR("Economic calendar") }

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) handleShare(intent)
        setContent {
            val app = rememberApp()
            val s by app.settings.state.collectAsState()
            TradewiseTheme(s.theme) { Root() }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleShare(intent)
    }

    /** A chart screenshot shared from another app (Share > TRADEWISE AI) lands on the Analyse tab. */
    private fun handleShare(i: Intent?) {
        if (i?.action != Intent.ACTION_SEND) return
        val uri: Uri? = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra(Intent.EXTRA_STREAM, Uri::class.java)
        else @Suppress("DEPRECATION") i.getParcelableExtra(Intent.EXTRA_STREAM)
        if (uri != null) (application as TradewiseApp).pendingShareUri.value = uri
    }
}

@Composable
private fun Root() {
    val app = rememberApp()
    val s by app.settings.state.collectAsState()
    var tab by rememberSaveable { mutableStateOf(Tab.HOME) }
    var sub by rememberSaveable { mutableStateOf<Sub?>(null) }
    val share by app.pendingShareUri.collectAsState()
    val shot by app.pendingShotPath.collectAsState()

    LaunchedEffect(share, shot) { if (share != null || shot != null) { sub = null; tab = Tab.ANALYSE } }
    BackHandler(enabled = sub != null) { sub = null }
    BackHandler(enabled = sub == null && tab != Tab.HOME) { tab = Tab.HOME }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    LaunchedEffect(s.disclaimerAccepted) {
        if (s.disclaimerAccepted && Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }

    if (!s.disclaimerAccepted) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = TW.surface,
            title = { Text("Before you start", style = TwType.title) },
            text = {
                Text(
                    "TRADEWISE AI is an educational analysis companion. It does not place trades, does not connect to any broker and " +
                        "does not give financial advice. Forex and leveraged products can lose money quickly. Every setup is a rule check on " +
                        "past price data, not a prediction or a probability of profit. Journal and balances are simulated.",
                    style = TwType.body
                )
            },
            confirmButton = { TextButton(onClick = { app.settings.update { it.copy(disclaimerAccepted = true) } }) { Text("I understand", color = TW.blueSoft) } }
        )
    }

    Column(Modifier.fillMaxSize().background(TW.bg).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            AnimatedContent(
                targetState = sub to tab,
                transitionSpec = {
                    if (targetState.first != null && initialState.first == null)
                        (slideInHorizontally(tween(280)) { it / 3 } + fadeIn(tween(280))) togetherWith fadeOut(tween(150))
                    else if (targetState.first == null && initialState.first != null)
                        (slideInHorizontally(tween(280)) { -it / 3 } + fadeIn(tween(280))) togetherWith (slideOutHorizontally(tween(220)) { it / 3 } + fadeOut(tween(150)))
                    else fadeIn(tween(240)) togetherWith fadeOut(tween(160))
                },
                label = "screens"
            ) { (subRoute, t) ->
                if (subRoute != null) {
                    Column(Modifier.fillMaxSize()) {
                        Row(Modifier.clickable { sub = null }.pad(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ArrowBack, "Back", tint = TW.text, modifier = Modifier.size(22.dp))
                            Text("  ${subRoute.title}", style = TwType.title)
                        }
                        Box(Modifier.weight(1f)) {
                            when (subRoute) {
                                Sub.SETTINGS -> SettingsScreen()
                                Sub.SIZER -> SizerScreen()
                                Sub.CALENDAR -> CalendarScreen()
                            }
                        }
                    }
                } else when (t) {
                    Tab.HOME -> HomeScreen(onOpen = { sub = it }, onTab = { tab = it })
                    Tab.MARKETS -> MarketsScreen()
                    Tab.ANALYSE -> AnalyseScreen(onSize = { sub = Sub.SIZER })
                    Tab.LEARN -> LearnScreen()
                    Tab.JOURNAL -> JournalScreen(onSize = { sub = Sub.SIZER })
                }
            }
        }
        NavigationBar(containerColor = TW.surface, tonalElevation = 0.dp) {
            Tab.values().forEach { t ->
                NavigationBarItem(
                    selected = sub == null && tab == t,
                    onClick = { sub = null; tab = t },
                    icon = { Icon(t.icon, t.label) },
                    label = { Text(t.label) },
                    colors = NavigationBarItemDefaults.colors(
                        selectedIconColor = TW.text, selectedTextColor = TW.blueSoft,
                        indicatorColor = TW.blue.copy(alpha = 0.25f),
                        unselectedIconColor = TW.faint, unselectedTextColor = TW.faint
                    )
                )
            }
        }
    }
}
