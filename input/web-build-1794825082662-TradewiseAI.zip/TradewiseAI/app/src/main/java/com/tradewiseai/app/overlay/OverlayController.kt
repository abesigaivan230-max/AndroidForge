package com.tradewiseai.app.overlay

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.ContextThemeWrapper
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.tradewiseai.app.R
import com.tradewiseai.app.TradewiseApp
import com.tradewiseai.app.capture.CaptureBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlin.math.hypot

/** What the overlay UI is allowed to ask of the window it lives in. */
interface OverlayHost {
    fun dragBy(dx: Int, dy: Int)
    fun dragEnd()
    fun setMode(mode: OverlayMode)
    fun setFocusable(focusable: Boolean)
    fun stopAssistant()
}

/**
 * Root view of the overlay window.
 *  - Handles the Back key while the window is focusable (text entry).
 *  - Handles DRAGGING with raw screen coordinates. A Compose drag gesture measures movement in view-local
 *    coordinates, which shift as the window follows the finger, giving jumpy drags. Raw coordinates don't.
 *    Taps and long-presses still reach Compose because we only intercept after the touch slop is exceeded.
 */
private class OverlayRoot(
    context: Context,
    private val dragZoneBottomPx: () -> Int,
    private val onDrag: (Int, Int) -> Unit,
    private val onDragEnd: () -> Unit,
    private val onBack: () -> Unit
) : FrameLayout(context) {
    var focusableWindow = false
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var inZone = false
    private var dragging = false

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (focusableWindow && event.keyCode == KeyEvent.KEYCODE_BACK) {
            if (event.action == KeyEvent.ACTION_UP) onBack()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = ev.rawX; downY = ev.rawY; lastX = downX; lastY = downY
                dragging = false
                inZone = ev.y <= dragZoneBottomPx()
            }
            MotionEvent.ACTION_MOVE -> if (inZone && !dragging && hypot(ev.rawX - downX, ev.rawY - downY) > slop) {
                dragging = true
                lastX = ev.rawX; lastY = ev.rawY
                return true
            }
        }
        return false
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val dx = (ev.rawX - lastX).toInt()
                val dy = (ev.rawY - lastY).toInt()
                lastX += dx; lastY += dy        // keep the fractional remainder for the next event
                if (dx != 0 || dy != 0) onDrag(dx, dy)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> if (dragging) {
                dragging = false
                onDragEnd()
                return true
            }
        }
        return dragging
    }
}

/**
 * Owns the WindowManager window. Everything here runs on the main thread and is defensive: the system can
 * remove the window (permission revoked) at any time, so every WindowManager call is guarded.
 */
class OverlayController(
    private val context: Context,
    private val app: TradewiseApp,
    private val scope: CoroutineScope,
    private val onStopRequested: () -> Unit
) : OverlayHost {

    private val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val handler = Handler(Looper.getMainLooper())
    private val density get() = context.resources.displayMetrics.density
    val model = OverlayModel(app, scope)

    private var root: OverlayRoot? = null
    private var params: WindowManager.LayoutParams? = null
    private var owner: OverlayLifecycleOwner? = null
    private var snapAnim: ValueAnimator? = null

    val isAttached: Boolean get() = root != null

    private fun dp(v: Int) = (v * density).toInt()

    private fun screen(): Pair<Int, Int> =
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds; b.width() to b.height()
        } else {
            @Suppress("DEPRECATION")
            val m = android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
            m.widthPixels to m.heightPixels
        }

    /** Creates the window. Returns false if Android refuses (permission missing). */
    fun attach(): Boolean {
        if (root != null) return true
        if (!OverlayPermission.canDraw(context)) return false
        val s = app.settings.current
        val lp = WindowManager.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = s.overlayX; y = s.overlayY
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        val lifecycleOwner = OverlayLifecycleOwner().also { it.start() }
        val themed = ContextThemeWrapper(context, R.style.Theme_Tradewise)
        val rootView = OverlayRoot(
            themed,
            dragZoneBottomPx = { if (app.settings.current.overlayMode == OverlayMode.BUBBLE) Int.MAX_VALUE else dp(52) },
            onDrag = { dx, dy -> dragBy(dx, dy) },
            onDragEnd = { dragEnd() },
            onBack = { setMode(OverlayMode.BUBBLE) }
        )
        // Compose finds its lifecycle by walking to the ROOT view of the window, so the owners go on the root.
        rootView.setViewTreeLifecycleOwner(lifecycleOwner)
        rootView.setViewTreeViewModelStoreOwner(lifecycleOwner)
        rootView.setViewTreeSavedStateRegistryOwner(lifecycleOwner)
        val compose = ComposeView(themed).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnViewTreeLifecycleDestroyed)
            setContent { OverlayContent(model = model, settings = app.settings, host = this@OverlayController) }
        }
        rootView.addView(compose, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        params = lp
        applyMode(s.overlayMode, s.panelWidthDp, lp)
        try {
            wm.addView(rootView, lp)
        } catch (e: Exception) {   // BadTokenException / SecurityException when the permission vanished
            lifecycleOwner.destroy()
            params = null
            return false
        }
        root = rootView
        owner = lifecycleOwner
        clampSoon()

        // react to mode / width changes coming from Settings or from the overlay itself
        scope.launch {
            app.settings.state.map { it.overlayMode to it.panelWidthDp }.distinctUntilChanged().collect { (mode, w) ->
                params?.let { applyMode(mode, w, it); pushLayout(); clampSoon() }
                model.setPanelVisible(mode != OverlayMode.BUBBLE)
            }
        }
        // hide while a screenshot is being taken so the bubble is not in the picture
        scope.launch {
            CaptureBus.hideOverlay.collect { hide -> root?.visibility = if (hide) View.INVISIBLE else View.VISIBLE }
        }
        return true
    }

    private fun applyMode(mode: OverlayMode, widthDp: Int, lp: WindowManager.LayoutParams) {
        val (sw, _) = screen()
        lp.width = when (mode) {
            OverlayMode.BUBBLE -> ViewGroup.LayoutParams.WRAP_CONTENT
            OverlayMode.SIDE_PANEL -> dp(widthDp).coerceAtMost(sw - dp(8))
            OverlayMode.EXPANDED -> dp(420).coerceAtMost(sw - dp(16))
        }
        lp.height = ViewGroup.LayoutParams.WRAP_CONTENT
    }

    private fun pushLayout() {
        val r = root ?: return
        val lp = params ?: return
        try { wm.updateViewLayout(r, lp) } catch (_: Exception) { /* window already gone */ }
    }

    /** Keeps the window fully on screen (needed after mode changes, rotation and size changes). */
    private fun clamp() {
        val r = root ?: return
        val lp = params ?: return
        val (sw, sh) = screen()
        val w = if (r.width > 0) r.width else dp(56)
        val h = if (r.height > 0) r.height else dp(56)
        lp.x = lp.x.coerceIn(0, (sw - w).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(dp(24), (sh - h - dp(24)).coerceAtLeast(dp(24)))
        pushLayout()
    }

    private fun clampSoon() {
        root?.post { clamp() }
        handler.postDelayed({ clamp() }, 250)   // after the new size has been measured
    }

    override fun dragBy(dx: Int, dy: Int) {
        val lp = params ?: return
        snapAnim?.cancel()
        lp.x += dx; lp.y += dy
        clamp()
    }

    override fun dragEnd() {
        val lp = params ?: return
        val r = root ?: return
        val (sw, _) = screen()
        if (app.settings.current.overlayMode == OverlayMode.BUBBLE) {
            val w = if (r.width > 0) r.width else dp(56)
            val target = if (lp.x + w / 2 < sw / 2) 0 else sw - w     // snap to the nearest edge
            snapAnim?.cancel()
            snapAnim = ValueAnimator.ofInt(lp.x, target).apply {
                duration = 220
                addUpdateListener { lp.x = it.animatedValue as Int; pushLayout() }
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationEnd(animation: Animator) { savePosition() }
                })
                start()
            }
        } else savePosition()
    }

    private fun savePosition() {
        val lp = params ?: return
        app.settings.update { it.copy(overlayX = lp.x, overlayY = lp.y) }
    }

    override fun setMode(mode: OverlayMode) {
        app.settings.update { it.copy(overlayMode = mode) }
        if (mode != OverlayMode.EXPANDED) setFocusable(false)
    }

    override fun setFocusable(focusable: Boolean) {
        val lp = params ?: return
        val r = root ?: return
        r.focusableWindow = focusable
        lp.flags = if (focusable) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        pushLayout()
    }

    override fun stopAssistant() = onStopRequested()

    /** Called by the side panel's +/- buttons. Persisting it re-applies the window width via the settings collector. */
    fun resizePanel(widthDp: Int) {
        app.settings.update { it.copy(panelWidthDp = widthDp.coerceIn(180, 320)) }
    }

    fun onConfigurationChanged() {
        val lp = params ?: return
        val s = app.settings.current
        applyMode(s.overlayMode, s.panelWidthDp, lp)
        pushLayout()
        clampSoon()
    }

    fun detach() {
        handler.removeCallbacksAndMessages(null)
        snapAnim?.cancel()
        model.setPanelVisible(false)
        root?.let { try { wm.removeViewImmediate(it) } catch (_: Exception) {} }
        owner?.destroy()
        root = null; owner = null; params = null
    }
}
