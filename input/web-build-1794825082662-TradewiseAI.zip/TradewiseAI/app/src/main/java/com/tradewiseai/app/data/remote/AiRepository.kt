package com.tradewiseai.app.data.remote

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import com.tradewiseai.app.domain.analysis.AiExplanation
import com.tradewiseai.app.domain.analysis.IndicatorSnapshot
import com.tradewiseai.app.domain.analysis.LocalExplainer
import com.tradewiseai.app.domain.analysis.ReadItem
import com.tradewiseai.app.domain.analysis.ScreenshotAnalysis
import com.tradewiseai.app.domain.analysis.ScreenshotLevel
import com.tradewiseai.app.domain.analysis.SetupResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream

data class ChatTurn(val role: String, val text: String)

/**
 * AI features go through the backend (OpenAI key lives on the server, output is schema-validated there).
 * The decision, prices and indicator values always come from deterministic code; the AI only explains them.
 */
class AiRepository(
    private val http: SupabaseHttp,
    private val auth: AuthRepository
) {
    val available: Boolean get() = http.configured

    /** On-device explanation, always available. */
    fun localExplanation(result: SetupResult): AiExplanation = LocalExplainer.explain(result)

    /**
     * AI explanation (and optional follow-up answer). Requires sign-in so usage can be rate limited per user.
     * Returns Failure with a readable message when unavailable; callers then show [localExplanation].
     */
    suspend fun explain(result: SetupResult, question: String?, history: List<ChatTurn>): Result<AiExplanation> = runCatching {
        if (!http.configured) throw ApiException("AI backend not configured. The on-device explanation is shown instead.")
        val token = auth.validToken() ?: throw ApiException("Sign in (Settings > Account) to use AI explanations.")
        val body = JSONObject()
            .put("mode", "explain")
            .put("setup", setupToJson(result))
            .put("question", question ?: "")
            .put("history", JSONArray().also { a -> history.takeLast(8).forEach { a.put(JSONObject().put("role", it.role).put("text", it.text.take(1500))) } })
        val o = http.postJson("/functions/v1/ai-explain", body, token, retries = 1)
        if (o.optString("status") == "error") throw ApiException(o.optString("message", "AI request failed."))
        val e = o.optJSONObject("explanation") ?: throw ApiException("AI returned no explanation.")
        AiExplanation(
            summary = e.optString("summary"),
            marketState = e.optString("market_state"),
            indicatorNotes = strings(e.optJSONArray("indicator_notes")),
            whySetupOrNot = e.optString("why_setup_or_not"),
            whatWouldChange = strings(e.optJSONArray("what_would_change")),
            beginnerExplanation = e.optString("beginner_explanation"),
            risks = strings(e.optJSONArray("risks")),
            answer = e.optString("answer"),
            source = AiExplanation.Source.AI
        )
    }

    suspend fun analyseScreenshot(path: String): Result<ScreenshotAnalysis> = runCatching {
        if (!http.configured) throw ApiException("AI backend not configured, so screenshots can't be analysed yet. See docs/SETUP.md.")
        val token = auth.validToken() ?: throw ApiException("Sign in (Settings > Account) to analyse screenshots.")
        val b64 = withContext(Dispatchers.IO) { encodeJpeg(path) }
        val body = JSONObject().put("mode", "analyse").put("image_base64", b64).put("mime", "image/jpeg")
        val o = http.postJson("/functions/v1/screenshot-analyse", body, token, retries = 0)
        if (o.optString("status") == "error") throw ApiException(o.optString("message", "Screenshot analysis failed."))
        parseShot(o.optJSONObject("analysis") ?: throw ApiException("No analysis returned."))
    }

    private fun item(o: JSONObject?): ReadItem =
        if (o == null) ReadItem(null, "unclear") else ReadItem(o.optString("value").ifBlank { null }, o.optString("status", "unclear"))

    private fun parseShot(a: JSONObject): ScreenshotAnalysis {
        val indicators = a.optJSONArray("indicators")?.let { arr ->
            (0 until arr.length()).map { item(arr.optJSONObject(it)) }
        } ?: emptyList()
        val levels = a.optJSONArray("price_levels")?.let { arr ->
            (0 until arr.length()).mapNotNull { i ->
                val l = arr.optJSONObject(i) ?: return@mapNotNull null
                ScreenshotLevel(l.optString("label"), if (l.isNull("value")) null else l.optDouble("value"), l.optString("status", "unclear"))
            }
        } ?: emptyList()
        return ScreenshotAnalysis(
            readable = a.optBoolean("readable", false),
            unreadableReason = a.optString("unreadable_reason"),
            pair = item(a.optJSONObject("pair")),
            timeframe = item(a.optJSONObject("timeframe")),
            indicators = indicators,
            priceLevels = levels,
            support = doubles(a.optJSONArray("support")),
            resistance = doubles(a.optJSONArray("resistance")),
            structure = a.optString("structure"),
            bullishScenario = a.optString("bullish_scenario"),
            bearishScenario = a.optString("bearish_scenario"),
            uncertainty = a.optString("uncertainty")
        )
    }

    /** The backend keeps no copy of screenshots (see docs/PRIVACY.md); this only asks it to remove anything stored. */
    suspend fun deleteRemoteScreenshots(): Result<Unit> = runCatching {
        if (!http.configured) return@runCatching
        val token = auth.validToken() ?: return@runCatching
        http.postJson("/functions/v1/screenshot-analyse", JSONObject().put("mode", "delete_all"), token, retries = 0)
        Unit
    }

    private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }
    private fun doubles(a: JSONArray?): List<Double> = if (a == null) emptyList() else (0 until a.length()).mapNotNull { i -> a.optDouble(i).takeIf { !it.isNaN() } }

    companion object {
        /** Downscales to at most 1600 px on the long side and encodes as JPEG, base64 without line breaks. */
        fun encodeJpeg(path: String): String {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(path, bounds)
            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 3200) sample *= 2
            val bmp = BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = sample })
                ?: throw ApiException("The screenshot could not be read.")
            val longest = maxOf(bmp.width, bmp.height)
            val scaled = if (longest > 1600) {
                val f = 1600f / longest
                Bitmap.createScaledBitmap(bmp, (bmp.width * f).toInt().coerceAtLeast(1), (bmp.height * f).toInt().coerceAtLeast(1), true)
            } else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 85, out)
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
        }

        /** Only computed facts go to the server: decision, rule results and indicator values from deterministic code. */
        fun setupToJson(r: SetupResult): JSONObject {
            fun snap(s: IndicatorSnapshot?): Any {
                if (s == null) return JSONObject.NULL
                fun n(v: Double?): Any = v ?: JSONObject.NULL
                return JSONObject()
                    .put("timeframe", s.timeframe.label).put("close", s.close)
                    .put("ema20", n(s.ema20)).put("ema50", n(s.ema50)).put("ema200", n(s.ema200))
                    .put("rsi", n(s.rsi)).put("macd", n(s.macd)).put("macd_signal", n(s.macdSignal)).put("macd_hist", n(s.macdHist))
                    .put("atr", n(s.atr)).put("trend", s.trend.trend.label).put("structure", s.trend.structure.label)
                    .put("supports", JSONArray().also { a -> s.supports.take(3).forEach { a.put(it.price) } })
                    .put("resistances", JSONArray().also { a -> s.resistances.take(3).forEach { a.put(it.price) } })
            }
            fun n(v: Double?): Any = v ?: JSONObject.NULL
            return JSONObject()
                .put("pair", r.pair.symbol)
                .put("decision", r.decision.label)
                .put("rules_passed", r.passedCount).put("rules_total", r.checks.size)
                .put("checks", JSONArray().also { a -> r.checks.forEach { a.put(JSONObject().put("name", it.name).put("passed", it.passed).put("detail", it.detail)) } })
                .put("entry", n(r.entry)).put("stop_loss", n(r.stopLoss)).put("risk_reward", n(r.riskReward))
                .put("targets", JSONArray().also { a -> r.targets.forEach { a.put(JSONObject().put("label", it.label).put("price", it.price).put("rr", it.rr)) } })
                .put("invalidation", JSONArray(r.invalidation)).put("caveats", JSONArray(r.caveats))
                .put("htf", snap(r.htf)).put("setup", snap(r.setup)).put("entry_tf", snap(r.entryTfSnapshot))
        }
    }
}
