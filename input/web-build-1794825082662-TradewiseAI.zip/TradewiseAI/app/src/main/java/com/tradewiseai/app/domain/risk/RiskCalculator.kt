package com.tradewiseai.app.domain.risk

import com.tradewiseai.app.domain.model.CurrencyPair
import kotlin.math.abs
import kotlin.math.floor

data class RiskInput(
    val accountCurrency: String,
    val balance: Double,
    val riskPercent: Double,
    val pair: CurrencyPair,
    val entry: Double,
    val stop: Double,
    val takeProfit: Double?,
    /** Units of account currency per 1 USD. Needed only when the account is not USD and not the pair's base/quote. */
    val accountPerUsd: Double? = null,
    val maxRiskPercent: Double = 5.0,
    val contractSize: Double = 100_000.0,
    val lotStep: Double = 0.01
)

data class RiskResult(
    val valid: Boolean,
    val error: String?,
    val riskAmount: Double = 0.0,
    val stopPips: Double = 0.0,
    val lots: Double = 0.0,
    val units: Double = 0.0,
    val potentialLoss: Double = 0.0,
    val potentialProfit: Double? = null,
    val riskReward: Double? = null,
    val pipValuePerLot: Double = 0.0,
    val exact: Boolean = false,
    val notes: List<String> = emptyList()
)

object RiskCalculator {

    private fun fail(msg: String) = RiskResult(valid = false, error = msg)

    /** Value of one pip for 1 standard lot, in the account currency; null when a conversion rate is missing. */
    fun pipValuePerLot(pair: CurrencyPair, account: String, price: Double, contract: Double, accountPerUsd: Double?): Double? {
        val inQuote = pair.pipSize * contract
        return when {
            account == pair.quote -> inQuote
            account == pair.base -> inQuote / price
            else -> {
                // convert quote -> USD, then USD -> account with a user supplied rate
                val usd = when {
                    pair.quote == "USD" -> inQuote
                    pair.base == "USD" -> inQuote / price
                    else -> return null
                }
                if (account == "USD") usd else accountPerUsd?.let { usd * it }
            }
        }
    }

    fun calculate(i: RiskInput): RiskResult {
        if (i.balance <= 0) return fail("Balance must be above zero.")
        if (i.riskPercent <= 0) return fail("Risk percentage must be above zero.")
        if (i.riskPercent > i.maxRiskPercent) return fail("Risk ${"%.1f".format(i.riskPercent)}% is above your maximum of ${"%.1f".format(i.maxRiskPercent)}%. Lower it, or change the limit in Settings on purpose.")
        if (i.entry <= 0 || i.stop <= 0) return fail("Entry and stop-loss prices must be above zero.")
        if (i.entry == i.stop) return fail("Stop-loss cannot equal the entry price.")
        val long = i.stop < i.entry
        if (i.takeProfit != null && ((long && i.takeProfit <= i.entry) || (!long && i.takeProfit >= i.entry)))
            return fail("Take-profit is on the wrong side of the entry for a ${if (long) "buy" else "sell"}.")

        val account = i.accountCurrency.uppercase()
        val needsRate = account != "USD" && account != i.pair.base && account != i.pair.quote
        val pv = pipValuePerLot(i.pair, account, i.entry, i.contractSize, i.accountPerUsd)
            ?: return fail("Pip value needs a USD→$account rate. Enter the rate, or use a USD/${i.pair.base}/${i.pair.quote} account.")
        val stopPips = abs(i.entry - i.stop) / i.pair.pipSize
        val risk = i.balance * i.riskPercent / 100.0
        val rawLots = risk / (stopPips * pv)
        val lots = floor(rawLots / i.lotStep + 1e-9) * i.lotStep
        if (lots < i.lotStep) return fail("The account is too small to risk ${"%.1f".format(i.riskPercent)}% on a ${"%.1f".format(stopPips)}-pip stop at the minimum lot of ${i.lotStep}. Use a wider-risk % (within limits) or a closer stop.")
        val loss = lots * stopPips * pv
        val profit = i.takeProfit?.let { lots * abs(it - i.entry) / i.pair.pipSize * pv }
        val notes = mutableListOf<String>()
        notes += "Assumes a contract size of ${"%,.0f".format(i.contractSize)} units per lot. Your broker's contract, lot step and spread may differ."
        if (needsRate) notes += "Approximate: converted with the USD→$account rate you entered."
        if (loss < risk * 0.8) notes += "Rounding down to the lot step means you risk less than the target amount."
        return RiskResult(
            true, null, risk, stopPips, lots, lots * i.contractSize, loss, profit,
            profit?.let { it / loss }, pv, exact = !needsRate, notes = notes
        )
    }
}
