package com.tradewiseai.app.domain.model

enum class Timeframe(val label: String, val apiInterval: String, val seconds: Long) {
    M5("5m", "5min", 300L),
    M15("15m", "15min", 900L),
    H1("1H", "1h", 3600L),
    H4("4H", "4h", 14_400L),
    D1("1D", "1day", 86_400L);

    companion object {
        fun fromLabel(label: String?): Timeframe = values().firstOrNull { it.label == label } ?: H1
    }
}

enum class CurrencyPair(
    val symbol: String,
    val base: String,
    val quote: String,
    val pipSize: Double,
    val decimals: Int
) {
    EURUSD("EUR/USD", "EUR", "USD", 0.0001, 5),
    GBPUSD("GBP/USD", "GBP", "USD", 0.0001, 5),
    USDJPY("USD/JPY", "USD", "JPY", 0.01, 3);

    companion object {
        fun fromSymbol(s: String?): CurrencyPair? {
            val n = s?.uppercase()?.replace("-", "/")?.replace("_", "/")?.trim() ?: return null
            return values().firstOrNull {
                it.symbol == n || it.symbol.replace("/", "") == n.replace("/", "")
            }
        }
    }
}

/** time = candle OPEN time, epoch seconds UTC. */
data class Candle(
    val time: Long,
    val open: Double,
    val high: Double,
    val low: Double,
    val close: Double,
    val volume: Double = 0.0
) {
    val bullish: Boolean get() = close > open
    val bearish: Boolean get() = close < open
    val body: Double get() = kotlin.math.abs(close - open)
    val range: Double get() = high - low
}

enum class DataOrigin { LIVE, CACHED, DEMO }

/** What the UI is allowed to say about a data set. Never call cached/stale data "live". */
enum class DataStatus(val label: String) {
    LIVE("LIVE"),
    CACHED("CACHED"),
    STALE("STALE / MARKET CLOSED"),
    DEMO("DEMO DATA")
}

data class CandleSeries(
    val pair: CurrencyPair,
    val timeframe: Timeframe,
    val candles: List<Candle>,
    val origin: DataOrigin,
    val provider: String,
    val fetchedAtMs: Long
)

data class Quote(
    val pair: CurrencyPair,
    val price: Double,
    val timestampSec: Long,
    val origin: DataOrigin,
    val provider: String
)

enum class Decision(val label: String) {
    BUY_SETUP("BUY SETUP"),
    SELL_SETUP("SELL SETUP"),
    WAIT("WAIT")
}

enum class Trend(val label: String) { UP("Uptrend"), DOWN("Downtrend"), RANGE("Range / unclear"), UNKNOWN("Not enough data") }

enum class Structure(val label: String) {
    HH_HL("Higher highs & higher lows"),
    LH_LL("Lower highs & lower lows"),
    MIXED("Mixed structure"),
    UNKNOWN("Not enough swings")
}

enum class Direction { LONG, SHORT }
