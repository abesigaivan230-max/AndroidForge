package com.tradewiseai.app.data.remote

import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.domain.model.Timeframe
import java.util.Random
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * SYNTHETIC data for demos and offline development. Everything it produces is tagged DataOrigin.DEMO
 * and shown as "DEMO DATA". It must never be used for real trading decisions.
 *
 * Prices come from one smooth deterministic function of time, so 5m/15m/1H/4H/1D charts agree with each other.
 */
class DemoMarketProvider(private val nowSec: () -> Long = { System.currentTimeMillis() / 1000 }) : MarketDataProvider {
    override val name = "DEMO DATA (synthetic)"

    override fun getAvailablePairs() = CurrencyPair.values().toList()

    override suspend fun getLatestQuote(pair: CurrencyPair): Result<Quote> =
        Result.success(Quote(pair, priceAt(pair, nowSec()), nowSec(), DataOrigin.DEMO, name))

    override suspend fun getHistoricalCandles(pair: CurrencyPair, timeframe: Timeframe, count: Int): Result<CandleSeries> =
        Result.success(generate(pair, timeframe, count))

    override suspend fun getProviderStatus() = ProviderStatus(name, true, true, "Synthetic prices for demonstration only.")

    private fun base(pair: CurrencyPair) = when (pair) {
        CurrencyPair.EURUSD -> 1.0850
        CurrencyPair.GBPUSD -> 1.2700
        CurrencyPair.USDJPY -> 150.00
    }

    /** Smooth multi-wave price, in the pair's own units. */
    fun priceAt(pair: CurrencyPair, t: Long): Double {
        val b = base(pair)
        val d = t / 86_400.0
        val rel = 0.012 * sin(d / 4.0 + pair.ordinal) + 0.005 * sin(d * 1.7 + pair.ordinal * 2) + 0.0018 * sin(d * 9.0) + 0.0006 * sin(d * 40.0)
        return b * (1 + rel)
    }

    fun generate(pair: CurrencyPair, tf: Timeframe, count: Int): CandleSeries {
        val now = nowSec()
        val lastOpen = now - Math.floorMod(now, tf.seconds)
        val out = ArrayList<Candle>(count)
        val b = base(pair)
        for (i in count - 1 downTo 0) {
            val open = lastOpen - i * tf.seconds
            val rnd = Random(open * 31 + pair.ordinal * 7 + tf.ordinal)
            val steps = 8
            val pts = DoubleArray(steps + 1) { k ->
                val t = open + tf.seconds * k / steps
                priceAt(pair, t) + (rnd.nextGaussian() * 0.00012 * b)
            }
            val o = pts.first()
            val c = if (i == 0) priceAt(pair, now) else pts.last()
            val hi = max(max(o, c), pts.max()) + abs(rnd.nextGaussian()) * 0.00005 * b
            val lo = min(min(o, c), pts.min()) - abs(rnd.nextGaussian()) * 0.00005 * b
            out += Candle(open, o, hi, lo, c)
        }
        return CandleSeries(pair, tf, out, DataOrigin.DEMO, name, System.currentTimeMillis())
    }

    private fun abs(v: Double) = if (v < 0) -v else v
}
