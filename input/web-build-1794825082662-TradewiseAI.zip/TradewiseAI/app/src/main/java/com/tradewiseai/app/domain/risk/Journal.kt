package com.tradewiseai.app.domain.risk

import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Direction
import kotlin.math.abs

/** Everything here is SIMULATED (demo account). It never reflects a real broker balance. */
data class JournalTrade(
    val id: String,
    val pair: CurrencyPair,
    val direction: Direction,
    val entry: Double,
    val exit: Double?,
    val stopLoss: Double,
    val takeProfit: Double?,
    val lots: Double,
    val riskAmount: Double,
    val resultAmount: Double?,
    val emotion: String,
    val reason: String,
    val lessons: String,
    val screenshotPath: String?,
    val openedAtMs: Long,
    val closedAtMs: Long?
) {
    val isClosed: Boolean get() = exit != null && resultAmount != null
    val rMultiple: Double? get() = if (isClosed && riskAmount > 0) resultAmount!! / riskAmount else null
}

data class DemoSettings(
    val startingBalance: Double = 1000.0,
    val maxRiskPercent: Double = 2.0,
    val dailyLossLimitPercent: Double = 5.0,
    val revengeWindowMinutes: Int = 30
)

data class GuardResult(val blocks: List<String>, val warnings: List<String>) {
    val allowed: Boolean get() = blocks.isEmpty()
}

data class JournalStats(
    val total: Int,
    val closed: Int,
    val wins: Int,
    val losses: Int,
    val winRate: Double,
    val totalPnl: Double,
    val avgR: Double?,
    val balance: Double,
    val equityCurve: List<Double>,
    val maxDrawdown: Double
)

object JournalLogic {

    /** P/L in USD for a demo account. Only valid when the pair's pip value can be expressed in USD. */
    fun pnlUsd(pair: CurrencyPair, dir: Direction, entry: Double, exit: Double, lots: Double): Double? {
        val pv = RiskCalculator.pipValuePerLot(pair, "USD", exit, 100_000.0, null) ?: return null
        val pips = (exit - entry) / pair.pipSize * (if (dir == Direction.LONG) 1 else -1)
        return pips * pv * lots
    }

    fun dayStartMs(nowMs: Long, offsetMs: Long): Long {
        val local = nowMs + offsetMs
        return local - Math.floorMod(local, 86_400_000L) - offsetMs
    }

    /**
     * Checks a NEW demo entry against the safety rules.
     * [tzOffsetMs] is the display timezone offset (East Africa Time = +3h).
     */
    fun check(
        newTrade: JournalTrade,
        history: List<JournalTrade>,
        settings: DemoSettings,
        nowMs: Long,
        tzOffsetMs: Long = 3 * 3_600_000L
    ): GuardResult {
        val blocks = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        val closed = history.filter { it.isClosed }
        val balance = settings.startingBalance + closed.sumOf { it.resultAmount ?: 0.0 }

        if (newTrade.stopLoss <= 0.0) blocks += "A stop-loss is mandatory for every demo entry."
        else {
            val longOk = newTrade.direction == Direction.LONG && newTrade.stopLoss < newTrade.entry
            val shortOk = newTrade.direction == Direction.SHORT && newTrade.stopLoss > newTrade.entry
            if (!longOk && !shortOk) blocks += "Stop-loss is on the wrong side of entry for a ${newTrade.direction.name.lowercase()} trade."
        }

        val maxRisk = balance * settings.maxRiskPercent / 100.0
        if (newTrade.riskAmount > maxRisk + 1e-9) blocks += "Risk ${"%.2f".format(newTrade.riskAmount)} is above your maximum of ${settings.maxRiskPercent}% of the balance (${"%.2f".format(maxRisk)})."

        val dayStart = dayStartMs(nowMs, tzOffsetMs)
        val todayLoss = closed.filter { (it.closedAtMs ?: 0L) >= dayStart }.sumOf { it.resultAmount ?: 0.0 }
        val limit = settings.startingBalance * settings.dailyLossLimitPercent / 100.0
        if (todayLoss <= -limit) blocks += "Daily simulated loss limit (${settings.dailyLossLimitPercent}%) is reached. Stop for today; the market will be there tomorrow."

        val lastClosed = closed.maxByOrNull { it.closedAtMs ?: 0L }
        if (lastClosed != null && (lastClosed.resultAmount ?: 0.0) < 0) {
            val mins = (nowMs - (lastClosed.closedAtMs ?: 0L)) / 60_000.0
            if (mins in 0.0..settings.revengeWindowMinutes.toDouble()) {
                warnings += "Your last trade lost ${"%.0f".format(mins)} minutes ago. Entering straight after a loss is classic revenge trading: take a break first."
            }
            if (newTrade.riskAmount > lastClosed.riskAmount * 1.0001) {
                warnings += "You are risking more than on your last (losing) trade. Increasing risk to win losses back is how accounts blow up."
            }
        }
        if (todayLoss < 0 && abs(todayLoss) >= limit * 0.6 && todayLoss > -limit) {
            warnings += "You are close to your daily loss limit."
        }
        return GuardResult(blocks, warnings)
    }

    fun stats(trades: List<JournalTrade>, startingBalance: Double): JournalStats {
        val closed = trades.filter { it.isClosed }.sortedBy { it.closedAtMs ?: 0L }
        val wins = closed.count { (it.resultAmount ?: 0.0) > 0 }
        val losses = closed.count { (it.resultAmount ?: 0.0) < 0 }
        val pnl = closed.sumOf { it.resultAmount ?: 0.0 }
        val rs = closed.mapNotNull { it.rMultiple }
        var eq = startingBalance
        var peak = startingBalance
        var dd = 0.0
        val curve = mutableListOf(startingBalance)
        for (t in closed) {
            eq += t.resultAmount ?: 0.0
            curve += eq
            if (eq > peak) peak = eq
            if (peak - eq > dd) dd = peak - eq
        }
        return JournalStats(
            total = trades.size, closed = closed.size, wins = wins, losses = losses,
            winRate = if (closed.isEmpty()) 0.0 else wins * 100.0 / closed.size,
            totalPnl = pnl, avgR = if (rs.isEmpty()) null else rs.average(),
            balance = startingBalance + pnl, equityCurve = curve, maxDrawdown = dd
        )
    }
}
