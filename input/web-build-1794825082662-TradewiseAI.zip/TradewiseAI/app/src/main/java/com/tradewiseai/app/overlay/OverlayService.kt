package com.tradewiseai.app.overlay

import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.tradewiseai.app.TradewiseApp
import com.tradewiseai.app.notifications.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel

/**
 * Foreground service that owns the floating assistant window.
 * Robustness rules: starting twice is harmless, a restart after the process was killed re-creates the window,
 * and a revoked "display over other apps" permission stops the service instead of crashing it.
 */
class OverlayService : Service() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Main.immediate + job)
    private val handler = Handler(Looper.getMainLooper())
    private var controller: OverlayController? = null

    private val watchdog = object : Runnable {
        override fun run() {
            if (!OverlayPermission.canDraw(this@OverlayService)) {
                Notifier.alert(this@OverlayService, "overlay_perm", "Floating assistant stopped",
                    "The \"Display over other apps\" permission was turned off.")
                stopAssistant()
                return
            }
            handler.postDelayed(this, 4000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopAssistant()
            return START_NOT_STICKY
        }
        val app = application as TradewiseApp

        // A foreground service must call startForeground() promptly after startForegroundService().
        try {
            val stop = PendingIntent.getService(
                this, 7, Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            val type = when {
                Build.VERSION.SDK_INT >= 34 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
                Build.VERSION.SDK_INT >= 29 -> ServiceInfo.FOREGROUND_SERVICE_TYPE_MANIFEST
                else -> 0
            }
            ServiceCompat.startForeground(this, Notifier.ID_OVERLAY, Notifier.overlayNotification(this, stop), type)
        } catch (e: Exception) {
            // e.g. started from the background on Android 12+, or the system refused the type
            stopAssistant()
            return START_NOT_STICKY
        }

        if (!OverlayPermission.canDraw(this)) {
            stopAssistant()
            return START_NOT_STICKY
        }

        if (controller?.isAttached != true) {
            val c = OverlayController(this, app, scope) { stopAssistant() }
            if (!c.attach()) {
                stopAssistant()
                return START_NOT_STICKY
            }
            controller = c
        }
        app.settings.update { it.copy(overlayWanted = true) }
        running = true
        handler.removeCallbacks(watchdog)
        handler.postDelayed(watchdog, 4000)
        return START_STICKY
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        controller?.onConfigurationChanged()      // rotation: re-clamp the window to the new screen size
    }

    private fun stopAssistant() {
        handler.removeCallbacks(watchdog)
        (application as? TradewiseApp)?.settings?.update { it.copy(overlayWanted = false) }
        controller?.detach()
        controller = null
        running = false
        ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        controller?.detach()
        controller = null
        running = false
        scope.cancel()
        super.onDestroy()
    }

    companion object {
        const val ACTION_STOP = "com.tradewiseai.app.action.STOP_ASSISTANT"

        /** True while the window exists in this process. Used by the UI to show the toggle state. */
        @Volatile var running: Boolean = false
            private set

        fun start(context: Context): Boolean {
            if (!OverlayPermission.canDraw(context)) return false
            return try {
                ContextCompat.startForegroundService(context, Intent(context, OverlayService::class.java))
                true
            } catch (e: Exception) { false }
        }

        fun stop(context: Context) {
            context.startService(Intent(context, OverlayService::class.java).setAction(ACTION_STOP))
        }
    }
}
