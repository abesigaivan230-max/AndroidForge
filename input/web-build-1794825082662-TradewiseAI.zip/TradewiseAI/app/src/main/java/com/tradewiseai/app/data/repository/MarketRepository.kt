package com.tradewiseai.app.data.repository

import android.content.Context
import com.tradewiseai.app.data.preferences.SettingsStore
import com.tradewiseai.app.data.remote.BackendMarketProvider
import com.tradewiseai.app.data.remote.DemoMarketProvider
import com.tradewiseai.app.data.remote.MarketDataProvider
import com.tradewiseai.app.data.remote.ProviderStatus
import com.tradewiseai.app.domain.analysis.DataQuality
import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.domain.model.Timeframe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Single entry point for market data. Responsibilities:
 *  - pick the real provider or the clearly labelled demo provider
 *  - memory + disk cache, honest CACHED / STALE labelling
 *  - request throttling (the free tier allows only a few requests per minute)
 *  - never present old data as live
 */
class MarketRepository(
    context: Context,
    private val settings: SettingsStore,
    private val backend: BackendMarketProvider,
    private val demo: DemoMarketProvider
) {
    private val dir = File(context.filesDir, "market_cache").apply { mkdirs() }
    private val netLock = Mutex()
    private var lastNetworkMs = 0L
    private val mem = HashMap<String, CandleSeries>()
    private val memQuote = HashMap<CurrencyPair, Quote>()
    private val memQuoteAtMs = HashMap<CurrencyPair, Long>()

    /** Real data only when the backend is configured and the user has not forced demo mode. */
    val usingDemo: Boolean get() = settings.current.forceDemoData || !backend.configured

    val activeProvider: MarketDataProvider get() = if (usingDemo) demo else backend

    val demoReason: String?
        get() = when {
            settings.current.forceDemoData -> "Demo mode is switched on in Settings."
            !backend.configured -> "Backend not configured yet, showing DEMO DATA. See docs/SETUP.md."
            else -> null
        }

    private fun ttlMs(tf: Timeframe) = when (tf) {
        Timeframe.M5 -> 45_000L
        Timeframe.M15 -> 90_000L
        Timeframe.H1 -> 240_000L
        Timeframe.H4 -> 600_000L
        Timeframe.D1 -> 1_800_000L
    }

    private fun key(p: CurrencyPair, tf: Timeframe) = "${p.name}_${tf.name}"
    private fun nowSec() = System.currentTimeMillis() / 1000

    fun statusOf(series: CandleSeries): DataStatus = DataQuality.statusOf(series, nowSec())
    fun statusOf(q: Quote): DataStatus = DataQuality.quoteStatus(q.origin, q.timestampSec, nowSec())

    suspend fun providerStatus(): ProviderStatus = activeProvider.getProviderStatus()

    suspend fun candles(pair: CurrencyPair, tf: Timeframe, count: Int = 300, force: Boolean = false): Result<CandleSeries> {
        val k = key(pair, tf)
        val now = System.currentTimeMillis()
        val inMem = synchronized(mem) { mem[k] }
        val isDemo = usingDemo
        if (inMem != null && !force && (isDemo == (inMem.origin == DataOrigin.DEMO)) && now - inMem.fetchedAtMs < ttlMs(tf) && inMem.candles.size >= minOf(count, 60)) {
            return Result.success(inMem.copy(origin = if (inMem.origin == DataOrigin.DEMO) DataOrigin.DEMO else DataOrigin.CACHED))
        }
        if (isDemo) {
            val r = demo.getHistoricalCandles(pair, tf, count)
            r.getOrNull()?.let { synchronized(mem) { mem[k] = it } }
            return r
        }
        val fetched = throttled { backend.getHistoricalCandles(pair, tf, count) }
        fetched.getOrNull()?.let {
            synchronized(mem) { mem[k] = it }
            writeDisk(k, it)
            return Result.success(it)
        }
        // network failed: fall back to the last known data, but label it as CACHED (and STALE if old)
        val old = inMem?.takeIf { it.origin != DataOrigin.DEMO } ?: readDisk(pair, tf)
        return if (old != null) Result.success(old.copy(origin = DataOrigin.CACHED))
        else Result.failure(fetched.exceptionOrNull() ?: IllegalStateException("No market data available."))
    }

    suspend fun quote(pair: CurrencyPair, force: Boolean = false): Result<Quote> {
        val now = System.currentTimeMillis()
        val cached = synchronized(memQuote) { memQuote[pair] }
        val cachedAt = synchronized(memQuote) { memQuoteAtMs[pair] ?: 0L }
        val wantDemo = usingDemo
        if (cached != null && !force && (wantDemo == (cached.origin == DataOrigin.DEMO)) && now - cachedAt < 30_000L) {
            return Result.success(if (cached.origin == DataOrigin.DEMO) cached else cached.copy(origin = DataOrigin.CACHED))
        }
        val r = if (wantDemo) demo.getLatestQuote(pair) else throttled { backend.getLatestQuote(pair) }
        r.getOrNull()?.let { q ->
            synchronized(memQuote) { memQuote[pair] = q; memQuoteAtMs[pair] = now }
            return r
        }
        return if (cached != null && cached.origin != DataOrigin.DEMO) Result.success(cached.copy(origin = DataOrigin.CACHED)) else r
    }

    /** Spaces network calls at least 1.2 s apart so bursts do not burn the vendor's per-minute credits. */
    private suspend fun <T> throttled(block: suspend () -> Result<T>): Result<T> = netLock.withLock {
        val wait = 1200L - (System.currentTimeMillis() - lastNetworkMs)
        if (wait > 0) delay(wait)
        try { block() } finally { lastNetworkMs = System.currentTimeMillis() }
    }

    // ----- disk cache -----
    private suspend fun writeDisk(k: String, s: CandleSeries) = withContext(Dispatchers.IO) {
        try {
            val arr = JSONArray()
            s.candles.forEach { c -> arr.put(JSONArray().put(c.time).put(c.open).put(c.high).put(c.low).put(c.close)) }
            val o = JSONObject().put("fetchedAt", s.fetchedAtMs).put("provider", s.provider).put("candles", arr)
            File(dir, "$k.json").writeText(o.toString())
        } catch (_: Exception) { /* cache is best-effort */ }
    }

    private suspend fun readDisk(pair: CurrencyPair, tf: Timeframe): CandleSeries? = withContext(Dispatchers.IO) {
        try {
            val f = File(dir, "${key(pair, tf)}.json")
            if (!f.exists()) return@withContext null
            val o = JSONObject(f.readText())
            val arr = o.getJSONArray("candles")
            val list = ArrayList<Candle>(arr.length())
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                list += Candle(a.getLong(0), a.getDouble(1), a.getDouble(2), a.getDouble(3), a.getDouble(4))
            }
            if (list.isEmpty()) null else CandleSeries(pair, tf, list, DataOrigin.CACHED, o.optString("provider", "cache"), o.optLong("fetchedAt", 0L))
        } catch (_: Exception) { null }
    }

    fun clearCache() {
        synchronized(mem) { mem.clear() }
        synchronized(memQuote) { memQuote.clear(); memQuoteAtMs.clear() }
        dir.listFiles()?.forEach { it.delete() }
    }
}
