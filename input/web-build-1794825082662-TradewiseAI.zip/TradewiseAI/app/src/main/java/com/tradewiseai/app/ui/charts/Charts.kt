package com.tradewiseai.app.ui.charts

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.domain.indicators.Indicators
import com.tradewiseai.app.domain.indicators.Level
import com.tradewiseai.app.domain.model.Candle
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Everything the chart draws, precomputed with the deterministic indicator code (never by an AI model). */
data class ChartData(
    val candles: List<Candle>,
    val ema20: List<Double?>,
    val ema50: List<Double?>,
    val ema200: List<Double?>,
    val rsi: List<Double?>,
    val macdHist: List<Double?>,
    val supports: List<Level>,
    val resistances: List<Level>
) {
    companion object {
        fun from(candles: List<Candle>, supports: List<Level> = emptyList(), resistances: List<Level> = emptyList()): ChartData {
            val closes = candles.map { it.close }
            return ChartData(
                candles, Indicators.ema(closes, 20), Indicators.ema(closes, 50), Indicators.ema(closes, 200),
                Indicators.rsi(closes, 14), Indicators.macd(closes).histogram, supports, resistances
            )
        }
    }
}

private val EMA20 = Color(0xFFFFB020)
private val EMA50 = Color(0xFF6FA3FF)
private val EMA200 = Color(0xFFC77DFF)

@Composable
fun CandleChart(
    data: ChartData,
    modifier: Modifier = Modifier,
    visibleCount: Int = 70,
    showEma: Boolean = true,
    showLevels: Boolean = true,
    height: Dp = 260.dp
) {
    val total = data.candles.size
    if (total < 5) return
    val visible = min(visibleCount, total)
    var panCandles by remember { mutableFloatStateOf(0f) }          // candles scrolled back from the newest
    val reveal = remember { Animatable(0f) }
    LaunchedEffect(data.candles.lastOrNull()?.time, total) { reveal.snapTo(0f); reveal.animateTo(1f, tween(650)) }

    val maxPan = (total - visible).toFloat().coerceAtLeast(0f)
    Column(modifier) {
        Canvas(
            Modifier.fillMaxWidth().height(height)
                .pointerInput(total, visible) {
                    detectHorizontalDragGestures { _, drag ->
                        val perCandle = size.width.toFloat() / visible
                        panCandles = (panCandles + drag / perCandle).coerceIn(0f, maxPan)
                    }
                }
        ) {
            val endIdx = (total - panCandles.toInt()).coerceIn(visible, total)
            val startIdx = endIdx - visible
            val slice = data.candles.subList(startIdx, endIdx)
            var lo = slice.minOf { it.low }
            var hi = slice.maxOf { it.high }
            if (showEma) listOf(data.ema20, data.ema50, data.ema200).forEach { s ->
                for (i in startIdx until endIdx) s.getOrNull(i)?.let { v ->
                    if (v in (lo - (hi - lo))..(hi + (hi - lo))) { lo = min(lo, v); hi = max(hi, v) }
                }
            }
            val pad = (hi - lo) * 0.06
            lo -= pad; hi += pad
            val range = (hi - lo).takeIf { it > 0 } ?: 1.0
            val w = size.width
            val h = size.height
            val cw = w / visible
            fun y(p: Double) = (h - ((p - lo) / range * h)).toFloat()
            fun x(i: Int) = (i - startIdx) * cw + cw / 2

            for (g in 0..4) {
                val gy = h * g / 4f
                drawLine(TW.faint.copy(alpha = 0.18f), Offset(0f, gy), Offset(w, gy), 1f)
            }
            if (showLevels) {
                data.supports.forEach { l -> if (l.price in lo..hi) dashed(y(l.price), w, TW.green.copy(alpha = 0.55f)) }
                data.resistances.forEach { l -> if (l.price in lo..hi) dashed(y(l.price), w, TW.red.copy(alpha = 0.55f)) }
            }
            val anim = reveal.value
            slice.forEachIndexed { k, c ->
                val i = startIdx + k
                val col = if (c.close >= c.open) TW.green else TW.red
                val cx = x(i)
                val yo = y(c.open); val yc = y(c.close)
                val mid = (yo + yc) / 2
                val gate = ((anim * visible) - k).coerceIn(0f, 1f)
                fun g(v: Float) = mid + (v - mid) * gate          // each candle grows outward from its middle
                drawLine(col, Offset(cx, g(y(c.high))), Offset(cx, g(y(c.low))), 1.6f)
                val top = g(min(yo, yc)); val bot = g(max(yo, yc))
                drawRect(col, Offset(cx - cw * 0.34f, top), Size(cw * 0.68f, max(bot - top, 1.5f)))
            }
            if (showEma && anim > 0.8f) {
                emaLine(data.ema20, startIdx, endIdx, { x(it) }, { y(it) }, EMA20)
                emaLine(data.ema50, startIdx, endIdx, { x(it) }, { y(it) }, EMA50)
                emaLine(data.ema200, startIdx, endIdx, { x(it) }, { y(it) }, EMA200)
            }
            val last = slice.last()
            drawLine(TW.blueSoft.copy(alpha = 0.7f), Offset(0f, y(last.close)), Offset(w, y(last.close)), 1f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(4f, 6f)))
        }
        if (showEma) {
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                LegendDot("EMA 20", EMA20); LegendDot("EMA 50", EMA50); LegendDot("EMA 200", EMA200)
            }
        }
    }
}

@Composable
private fun LegendDot(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(14.dp).height(3.dp).background(color))
        Text(" $label", style = TwType.small)
    }
}

private fun DrawScope.dashed(y: Float, w: Float, color: Color) {
    drawLine(color, Offset(0f, y), Offset(w, y), 1.2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 8f)))
}

private fun DrawScope.emaLine(
    s: List<Double?>, start: Int, end: Int, x: (Int) -> Float, y: (Double) -> Float, color: Color
) {
    val p = Path()
    var started = false
    for (i in start until end) {
        val v = s.getOrNull(i) ?: continue
        if (!started) { p.moveTo(x(i), y(v)); started = true } else p.lineTo(x(i), y(v))
    }
    if (started) drawPath(p, color, style = Stroke(width = 2.2f))
}

/** RSI sub-chart with 30/70 guides. */
@Composable
fun RsiChart(values: List<Double?>, modifier: Modifier = Modifier, visibleCount: Int = 70) {
    if (values.size < 5) return
    Canvas(modifier.fillMaxWidth().height(70.dp)) {
        val n = min(visibleCount, values.size)
        val slice = values.takeLast(n)
        val step = size.width / (n - 1).coerceAtLeast(1)
        fun y(v: Double) = (size.height - (v / 100.0 * size.height)).toFloat()
        dashed(y(70.0), size.width, TW.red.copy(alpha = 0.4f))
        dashed(y(30.0), size.width, TW.green.copy(alpha = 0.4f))
        val p = Path(); var started = false
        slice.forEachIndexed { i, v ->
            if (v != null) { if (!started) { p.moveTo(i * step, y(v)); started = true } else p.lineTo(i * step, y(v)) }
        }
        if (started) drawPath(p, EMA50, style = Stroke(2.2f))
    }
}

/** MACD histogram: bars above zero are green, below zero red. */
@Composable
fun MacdChart(hist: List<Double?>, modifier: Modifier = Modifier, visibleCount: Int = 70) {
    if (hist.size < 5) return
    Canvas(modifier.fillMaxWidth().height(70.dp)) {
        val n = min(visibleCount, hist.size)
        val slice = hist.takeLast(n)
        val maxAbs = slice.filterNotNull().maxOfOrNull { abs(it) }?.takeIf { it > 0 } ?: return@Canvas
        val cw = size.width / n
        val mid = size.height / 2
        drawLine(TW.faint.copy(alpha = 0.35f), Offset(0f, mid), Offset(size.width, mid), 1f)
        slice.forEachIndexed { i, v ->
            if (v != null) {
                val bh = (abs(v) / maxAbs * (size.height / 2 - 2)).toFloat()
                val top = if (v >= 0) mid - bh else mid
                drawRect(
                    if (v >= 0) TW.green.copy(alpha = 0.8f) else TW.red.copy(alpha = 0.8f),
                    Offset(i * cw + cw * 0.15f, top), Size(cw * 0.7f, max(bh, 1f))
                )
            }
        }
    }
}

/** Animated line for the SIMULATED equity curve. */
@Composable
fun EquityChart(values: List<Double>, modifier: Modifier = Modifier, height: Dp = 120.dp) {
    val progress = remember { Animatable(0f) }
    LaunchedEffect(values.size, values.lastOrNull()) { progress.snapTo(0f); progress.animateTo(1f, tween(800)) }
    Canvas(modifier.fillMaxWidth().height(height)) {
        if (values.size < 2) {
            drawLine(TW.faint.copy(alpha = 0.4f), Offset(0f, size.height / 2), Offset(size.width, size.height / 2), 1.5f,
                pathEffect = PathEffect.dashPathEffect(floatArrayOf(8f, 8f)))
            return@Canvas
        }
        val lo = values.min(); val hi = values.max()
        val range = (hi - lo).takeIf { it > 0 } ?: 1.0
        val step = size.width / (values.size - 1)
        val shown = max(2, (values.size * progress.value).toInt())
        val p = Path()
        values.take(shown).forEachIndexed { i, v ->
            val yy = (size.height - ((v - lo) / range * (size.height - 12f)) - 6f).toFloat()
            if (i == 0) p.moveTo(0f, yy) else p.lineTo(i * step, yy)
        }
        val up = values.last() >= values.first()
        drawPath(p, if (up) TW.green else TW.red, style = Stroke(3f))
    }
}
