package com.tradewiseai.app.overlay

import android.content.Intent
import com.tradewiseai.app.MainActivity
import com.tradewiseai.app.TradewiseApp
import com.tradewiseai.app.capture.CaptureBus
import com.tradewiseai.app.capture.CaptureEvent
import com.tradewiseai.app.capture.ScreenCaptureService
import com.tradewiseai.app.data.remote.ChatTurn
import com.tradewiseai.app.data.repository.AnalysisOutcome
import com.tradewiseai.app.data.repository.ScreenshotReport
import com.tradewiseai.app.domain.analysis.AiExplanation
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Quote
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File

sealed interface ShotUi {
    object Idle : ShotUi
    data class Captured(val path: String) : ShotUi
    data class Analysing(val path: String) : ShotUi
    data class Result(val path: String, val report: ScreenshotReport) : ShotUi
    data class Error(val message: String) : ShotUi
}

data class OverlayUi(
    val pair: CurrencyPair,
    val quote: Quote? = null,
    val quoteStatus: DataStatus? = null,
    val loading: Boolean = false,
    val outcome: AnalysisOutcome? = null,
    val explanation: AiExplanation? = null,
    val error: String? = null,
    val shot: ShotUi = ShotUi.Idle,
    val asking: Boolean = false,
    val answer: String? = null,
    val history: List<ChatTurn> = emptyList()
)

/** State and actions for the overlay UI. Lives as long as the service; uses the same repositories as the app. */
class OverlayModel(private val app: TradewiseApp, private val scope: CoroutineScope) {

    private val _ui = MutableStateFlow(OverlayUi(pair = app.settings.current.defaultPair))
    val ui: StateFlow<OverlayUi> = _ui.asStateFlow()
    private var quoteLoop: Job? = null

    init {
        selectPair(app.settings.current.defaultPair)
        scope.launch {
            CaptureBus.events.collect { e ->
                when (e) {
                    is CaptureEvent.Success -> _ui.update { it.copy(shot = ShotUi.Captured(e.path)) }
                    is CaptureEvent.Failed -> _ui.update { it.copy(shot = ShotUi.Error(e.message)) }
                }
            }
        }
    }

    /** Poll the price only while a panel is open; a bare bubble should cost nothing. */
    fun setPanelVisible(visible: Boolean) {
        quoteLoop?.cancel()
        if (!visible) return
        quoteLoop = scope.launch {
            while (true) {
                refreshQuote()
                delay(30_000)
            }
        }
    }

    fun selectPair(p: CurrencyPair) {
        val last = app.analysis.lastOutcome(p)
        _ui.update {
            it.copy(pair = p, quote = null, quoteStatus = null, outcome = last, error = null, answer = null, history = emptyList(),
                explanation = last?.let { o -> app.ai.localExplanation(o.result) })
        }
        scope.launch { refreshQuote() }
    }

    suspend fun refreshQuote() {
        val pair = _ui.value.pair
        app.market.quote(pair).fold(
            onSuccess = { q -> _ui.update { if (it.pair == pair) it.copy(quote = q, quoteStatus = app.market.statusOf(q)) else it } },
            onFailure = { e -> _ui.update { if (it.pair == pair && it.quote == null) it.copy(error = "Price unavailable: ${e.message}") else it } }
        )
    }

    fun analyse() {
        val pair = _ui.value.pair
        if (_ui.value.loading) return
        _ui.update { it.copy(loading = true, error = null, answer = null) }
        scope.launch {
            app.analysis.analyse(pair).fold(
                onSuccess = { o ->
                    _ui.update { it.copy(loading = false, outcome = o, explanation = app.ai.localExplanation(o.result), history = emptyList()) }
                    refreshQuote()
                },
                onFailure = { e -> _ui.update { it.copy(loading = false, error = e.message ?: "Analysis failed.") } }
            )
        }
    }

    fun ask(question: String) {
        val o = _ui.value.outcome
        if (o == null) { _ui.update { it.copy(error = "Run an analysis first, then ask about it.") }; return }
        if (question.isBlank() || _ui.value.asking) return
        _ui.update { it.copy(asking = true, error = null, answer = null) }
        scope.launch {
            val hist = _ui.value.history
            app.ai.explain(o.result, question, hist).fold(
                onSuccess = { ex ->
                    _ui.update {
                        it.copy(asking = false, explanation = ex, answer = ex.answer.ifBlank { null },
                            history = (hist + ChatTurn("user", question) + ChatTurn("assistant", ex.answer)).takeLast(8))
                    }
                },
                onFailure = { e -> _ui.update { it.copy(asking = false, error = e.message ?: "AI request failed.") } }
            )
        }
    }

    fun capture() {
        _ui.update { it.copy(shot = ShotUi.Idle, error = null) }
        ScreenCaptureService.requestCapture(app)
    }

    fun analyseShot() {
        val s = _ui.value.shot
        val path = (s as? ShotUi.Captured)?.path ?: (s as? ShotUi.Result)?.path ?: return
        _ui.update { it.copy(shot = ShotUi.Analysing(path)) }
        scope.launch {
            app.screenshots.analyse(path, _ui.value.pair).fold(
                onSuccess = { r -> _ui.update { it.copy(shot = ShotUi.Result(path, r)) } },
                onFailure = { e -> _ui.update { it.copy(shot = ShotUi.Error(e.message ?: "Screenshot analysis failed.")) } }
            )
        }
    }

    fun deleteShot() {
        val s = _ui.value.shot
        val path = (s as? ShotUi.Captured)?.path ?: (s as? ShotUi.Analysing)?.path ?: (s as? ShotUi.Result)?.path
        if (path != null) File(path).delete()
        _ui.update { it.copy(shot = ShotUi.Idle) }
    }

    fun openShotInApp() {
        val path = (_ui.value.shot as? ShotUi.Captured)?.path ?: (_ui.value.shot as? ShotUi.Result)?.path ?: return
        app.pendingShotPath.value = path
        openApp()
    }

    fun openApp() {
        app.startActivity(Intent(app, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
    }
}
