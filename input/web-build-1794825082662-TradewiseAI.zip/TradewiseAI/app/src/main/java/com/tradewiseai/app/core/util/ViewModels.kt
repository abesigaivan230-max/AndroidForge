package com.tradewiseai.app.core.util

import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import com.tradewiseai.app.TradewiseApp

@Composable
fun rememberApp(): TradewiseApp = LocalContext.current.applicationContext as TradewiseApp

/** ViewModel creation without a DI framework: [make] receives the app container. */
@Composable
inline fun <reified VM : ViewModel> appViewModel(crossinline make: (TradewiseApp) -> VM): VM {
    val app = rememberApp()
    return viewModel(factory = object : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T = make(app) as T
    })
}
