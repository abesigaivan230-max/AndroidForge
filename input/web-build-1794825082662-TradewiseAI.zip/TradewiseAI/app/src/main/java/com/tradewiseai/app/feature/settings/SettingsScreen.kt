package com.tradewiseai.app.feature.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.BuildConfig
import com.tradewiseai.app.capture.ImageTools
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.data.preferences.AppSettings
import com.tradewiseai.app.data.preferences.ThemeVariant
import com.tradewiseai.app.data.remote.AuthResult
import com.tradewiseai.app.data.remote.ProviderStatus
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Timeframe
import com.tradewiseai.app.notifications.AlertScheduler
import com.tradewiseai.app.overlay.OverlayMode
import com.tradewiseai.app.overlay.OverlayPermission
import com.tradewiseai.app.overlay.OverlayService
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.SectionTitle
import com.tradewiseai.app.ui.components.ToggleRow
import com.tradewiseai.app.ui.components.TwCard
import com.tradewiseai.app.ui.components.TwField
import com.tradewiseai.app.ui.components.toDoubleOrNullLoose
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val app = rememberApp()
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val s by app.settings.state.collectAsState()
    val auth by app.auth.state.collectAsState()
    var status by remember { mutableStateOf<ProviderStatus?>(null) }
    var msg by remember { mutableStateOf<String?>(null) }
    var email by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var authBusy by remember { mutableStateOf(false) }
    var confirmAll by remember { mutableStateOf(false) }

    fun upd(block: (AppSettings) -> AppSettings) {
        app.settings.update(block)
        AlertScheduler.sync(ctx, app.settings.current)
    }

    ScreenColumn {
        SectionTitle("Floating assistant")
        TwCard {
            ChipRow(OverlayMode.values().map { it.label }, s.overlayMode.label, { l -> OverlayMode.values().firstOrNull { it.label == l }?.let { m -> upd { it.copy(overlayMode = m) } } })
            Text(s.overlayMode.description, style = TwType.small)
            KeyValue("Display over other apps", if (OverlayPermission.canDraw(ctx)) "Allowed" else "Not allowed", if (OverlayPermission.canDraw(ctx)) TW.green else TW.amber)
            if (!OverlayPermission.canDraw(ctx)) GhostButton("Open permission settings", { ctx.startActivity(OverlayPermission.settingsIntent(ctx).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PrimaryButton("Start", { if (!OverlayService.start(ctx)) msg = "Grant the overlay permission first." })
                GhostButton("Stop", { OverlayService.stop(ctx) })
            }
        }

        SectionTitle("Appearance and defaults")
        TwCard {
            ChipRow(ThemeVariant.values().map { it.label }, s.theme.label, { l -> ThemeVariant.values().firstOrNull { it.label == l }?.let { v -> upd { it.copy(theme = v) } } })
            Text("DEFAULT PAIR", style = TwType.label)
            ChipRow(CurrencyPair.values().map { it.symbol }, s.defaultPair.symbol, { x -> CurrencyPair.fromSymbol(x)?.let { p -> upd { it.copy(defaultPair = p) } } })
            Text("DEFAULT TIMEFRAME", style = TwType.label)
            ChipRow(Timeframe.values().map { it.label }, s.defaultTimeframe.label, { l -> upd { it.copy(defaultTimeframe = Timeframe.fromLabel(l)) } })
            Text("WATCHLIST", style = TwType.label)
            CurrencyPair.values().forEach { p ->
                ToggleRow(p.symbol, null, p in s.watchlist, { on ->
                    val next = if (on) s.watchlist + p else s.watchlist - p
                    if (next.isNotEmpty()) upd { it.copy(watchlist = next) }
                })
            }
        }

        SectionTitle("Data")
        TwCard {
            ToggleRow("Force demo data", "Use synthetic prices even if the backend is configured.", s.forceDemoData, { on -> upd { it.copy(forceDemoData = on) }; app.market.clearCache() })
            app.market.demoReason?.let { Banner("DEMO DATA: $it") }
            GhostButton("Check data provider", { scope.launch { status = app.market.providerStatus() } }, Modifier.fillMaxWidth())
            status?.let {
                KeyValue("Provider", it.name)
                KeyValue("Configured", if (it.configured) "Yes" else "No")
                KeyValue("Reachable", when (it.reachable) { true -> "Yes"; false -> "No"; null -> "Unknown" })
                Text(it.message, style = TwType.small)
            }
        }

        SectionTitle("Risk (demo journal and sizer)")
        TwCard {
            var bal by remember(s.startingBalance) { mutableStateOf(s.startingBalance.toString()) }
            var maxR by remember(s.maxRiskPercent) { mutableStateOf(s.maxRiskPercent.toString()) }
            var dl by remember(s.dailyLossPercent) { mutableStateOf(s.dailyLossPercent.toString()) }
            TwField(bal, { bal = it; it.toDoubleOrNullLoose()?.takeIf { v -> v > 0 }?.let { v -> upd { s0 -> s0.copy(startingBalance = v) } } }, "Starting demo balance", numeric = true)
            TwField(maxR, { maxR = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 0.1..10.0 }?.let { v -> upd { s0 -> s0.copy(maxRiskPercent = v) } } }, "Max risk per trade % (0.1 to 10)", numeric = true)
            TwField(dl, { dl = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 0.5..50.0 }?.let { v -> upd { s0 -> s0.copy(dailyLossPercent = v) } } }, "Daily loss limit % (0.5 to 50)", numeric = true)
        }

        SectionTitle("Setup rules")
        TwCard {
            Text("Every rule must pass for a BUY or SELL SETUP. Stricter values mean fewer setups.", style = TwType.small)
            var rr by remember(s.minRiskReward) { mutableStateOf(s.minRiskReward.toString()) }
            var sl by remember(s.slAtrMult) { mutableStateOf(s.slAtrMult.toString()) }
            var pb by remember(s.pullbackAtrMult) { mutableStateOf(s.pullbackAtrMult.toString()) }
            var lo by remember(s.rsiMin) { mutableStateOf(s.rsiMin.toString()) }
            var hi by remember(s.rsiMax) { mutableStateOf(s.rsiMax.toString()) }
            var sp by remember(s.maxSpreadPips) { mutableStateOf(s.maxSpreadPips.toString()) }
            TwField(rr, { rr = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 1.0..5.0 }?.let { v -> upd { s0 -> s0.copy(minRiskReward = v) } } }, "Minimum risk:reward (1 to 5)", numeric = true)
            TwField(sl, { sl = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 0.5..4.0 }?.let { v -> upd { s0 -> s0.copy(slAtrMult = v) } } }, "Stop distance in ATR multiples (0.5 to 4)", numeric = true)
            TwField(pb, { pb = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 0.2..3.0 }?.let { v -> upd { s0 -> s0.copy(pullbackAtrMult = v) } } }, "Pullback zone in ATR multiples (0.2 to 3)", numeric = true)
            TwField(lo, { lo = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 10.0..50.0 }?.let { v -> upd { s0 -> s0.copy(rsiMin = v) } } }, "RSI lower bound (10 to 50)", numeric = true)
            TwField(hi, { hi = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 50.0..90.0 }?.let { v -> upd { s0 -> s0.copy(rsiMax = v) } } }, "RSI upper bound (50 to 90)", numeric = true)
            TwField(sp, { sp = it; it.toDoubleOrNullLoose()?.takeIf { v -> v in 0.1..20.0 }?.let { v -> upd { s0 -> s0.copy(maxSpreadPips = v) } } }, "Max spread in pips", numeric = true)
            ToggleRow("Require MACD momentum turn", null, s.requireMacdTurn, { on -> upd { it.copy(requireMacdTurn = on) } })
        }

        SectionTitle("Notifications")
        TwCard {
            Text("Background checks run about every 15 minutes at best (an Android limit), so these are not instant.", style = TwType.small)
            ToggleRow("Price alerts", null, s.notifyPrice, { on -> upd { it.copy(notifyPrice = on) } })
            ToggleRow("New setup detected", "Each setup is notified once.", s.notifySetup, { on -> upd { it.copy(notifySetup = on) } })
            ToggleRow("Data problems", "At most one notice per few hours.", s.notifyErrors, { on -> upd { it.copy(notifyErrors = on) } })
            ToggleRow("Calendar reminders", null, s.notifyCalendar, { on -> upd { it.copy(notifyCalendar = on) } })
        }

        SectionTitle("Account")
        TwCard {
            if (!app.auth.configured) Text("Backend not configured, so accounts are unavailable. The app works fully offline without one.", style = TwType.small)
            else if (auth.signedIn) {
                KeyValue("Signed in", auth.email ?: "")
                GhostButton("Sign out", { app.auth.signOut(); msg = "Signed out." }, Modifier.fillMaxWidth())
            } else {
                TwField(email, { email = it }, "Email")
                TwField(pass, { pass = it }, "Password (min 8 characters)")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Sign in", {
                        authBusy = true
                        scope.launch { msg = when (val r = app.auth.signIn(email.trim(), pass)) { AuthResult.SignedIn -> "Signed in."; is AuthResult.Failed -> r.message; is AuthResult.NeedsEmailConfirmation -> "Confirm your email first." }; authBusy = false }
                    }, loading = authBusy)
                    GhostButton("Create account", {
                        authBusy = true
                        scope.launch { msg = when (val r = app.auth.signUp(email.trim(), pass)) { AuthResult.SignedIn -> "Account created."; is AuthResult.Failed -> r.message; is AuthResult.NeedsEmailConfirmation -> "Check ${r.email} for a confirmation link, then sign in." }; authBusy = false }
                    })
                }
            }
        }

        SectionTitle("Privacy")
        TwCard {
            Text("Screenshots are processed and not kept on the server. Keys for data and AI live on the server, never in this app.", style = TwType.small)
            GhostButton("Delete saved screenshots (${ImageTools.count(ctx)})", {
                val n = ImageTools.deleteAll(ctx)
                scope.launch { app.ai.deleteRemoteScreenshots() }
                msg = "Deleted $n screenshot(s) on this phone."
            }, Modifier.fillMaxWidth())
            GhostButton("Clear market cache", { app.market.clearCache(); app.calendar.clearCache(); msg = "Cache cleared." }, Modifier.fillMaxWidth())
            GhostButton("Delete ALL app data", { confirmAll = true }, Modifier.fillMaxWidth(), color = TW.red)
        }
        msg?.let { Banner(it, TW.blueSoft, warning = false) }

        SectionTitle("About")
        TwCard {
            KeyValue("Version", "${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})")
            Text("TRADEWISE AI is an educational analysis companion. It does not trade, does not connect to brokers and is not financial advice. Setups describe rule agreement, not probability of profit.", style = TwType.small)
        }
    }

    if (confirmAll) AlertDialog(
        onDismissRequest = { confirmAll = false }, containerColor = TW.surface,
        title = { Text("Delete everything?", style = TwType.title) },
        text = { Text("This removes settings, journal, lessons progress, alerts, caches and screenshots from this phone and signs you out.", style = TwType.body) },
        confirmButton = {
            TextButton({
                confirmAll = false
                OverlayService.stop(ctx)
                scope.launch {
                    app.journal.clear(); app.lessons.clear(); app.alerts.clear(); app.market.clearCache(); app.calendar.clearCache()
                    ImageTools.deleteAll(ctx); app.auth.signOut(); app.settings.clearAll()
                    AlertScheduler.sync(ctx, app.settings.current)
                    msg = "All local data deleted."
                }
            }) { Text("Delete", color = TW.red) }
        },
        dismissButton = { TextButton({ confirmAll = false }) { Text("Cancel") } }
    )
}
