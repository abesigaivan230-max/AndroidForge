package com.tradewiseai.app.domain.analysis

import com.tradewiseai.app.domain.indicators.Indicators
import com.tradewiseai.app.domain.indicators.Level
import com.tradewiseai.app.domain.indicators.TrendInfo
import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Decision
import com.tradewiseai.app.domain.model.Direction
import com.tradewiseai.app.domain.model.Structure
import com.tradewiseai.app.domain.model.Timeframe
import com.tradewiseai.app.domain.model.Trend
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** All trading rules are data, so they can be changed from Settings and unit-tested. */
data class SetupConfig(
    val htf: Timeframe = Timeframe.H4,
    val setupTf: Timeframe = Timeframe.H1,
    val entryTf: Timeframe = Timeframe.M15,
    val minRiskReward: Double = 1.5,
    val slAtrMult: Double = 1.5,
    val pullbackAtrMult: Double = 1.0,
    val rsiMin: Double = 35.0,
    val rsiMax: Double = 70.0,
    val requireMacdTurn: Boolean = true,
    val maxSpreadPips: Double = 3.0,
    val maxAtrSpikeMultiple: Double = 3.0,
    val maxStopAtrMultiple: Double = 3.0,
    val maxStaleCandles: Int = 3,
    val maxUnexpectedGaps: Int = 3,
    val minCandles: Int = 60
)

data class RuleCheck(val name: String, val passed: Boolean, val detail: String)

data class TargetLevel(val label: String, val price: Double, val rr: Double, val isProjection: Boolean)

data class IndicatorSnapshot(
    val timeframe: Timeframe,
    val lastClosedTime: Long,
    val close: Double,
    val ema20: Double?,
    val ema50: Double?,
    val ema200: Double?,
    val rsi: Double?,
    val macd: Double?,
    val macdSignal: Double?,
    val macdHist: Double?,
    val atr: Double?,
    val trend: TrendInfo,
    val supports: List<Level>,
    val resistances: List<Level>
)

data class SetupResult(
    val pair: CurrencyPair,
    val decision: Decision,
    val candidateDirection: Direction?,
    val checks: List<RuleCheck>,
    val reasonsFor: List<String>,
    val reasonsAgainst: List<String>,
    val entry: Double?,
    val entryZoneLow: Double?,
    val entryZoneHigh: Double?,
    val stopLoss: Double?,
    val targets: List<TargetLevel>,
    val riskReward: Double?,
    val invalidation: List<String>,
    val watchFor: List<String>,
    val caveats: List<String>,
    val htf: IndicatorSnapshot?,
    val setup: IndicatorSnapshot?,
    val entryTfSnapshot: IndicatorSnapshot?,
    val generatedAtSec: Long
) {
    val passedCount: Int get() = checks.count { it.passed }
    val ruleSummary: String
        get() = if (checks.isEmpty()) "No rules could be evaluated."
        else "$passedCount of ${checks.size} rules satisfied. This is a rule count, not a probability of profit."
}

object SetupEngine {

    /** Drops the still-forming candle: keeps candles whose close time <= now. */
    fun closedOnly(candles: List<Candle>, tf: Timeframe, nowSec: Long): List<Candle> =
        candles.filter { it.time + tf.seconds <= nowSec }

    /** Counts gaps that are NOT a normal weekend/holiday break (36h-76h gaps are treated as expected). */
    fun unexpectedGaps(candles: List<Candle>, tf: Timeframe, lastN: Int = 100): Int {
        val tail = candles.takeLast(lastN)
        var n = 0
        for (i in 1 until tail.size) {
            val diff = tail[i].time - tail[i - 1].time
            if (diff > tf.seconds * 3 / 2) {
                val hours = diff / 3600.0
                val weekend = hours in 36.0..76.0
                if (!weekend && tf != Timeframe.D1) n++
            }
        }
        return n
    }

    fun snapshot(candles: List<Candle>, tf: Timeframe): IndicatorSnapshot? {
        if (candles.isEmpty()) return null
        val closes = candles.map { it.close }
        val e20 = Indicators.ema(closes, 20).last()
        val e50 = Indicators.ema(closes, 50).last()
        val e200 = Indicators.ema(closes, 200).last()
        val rsi = Indicators.rsi(closes, 14).last()
        val m = Indicators.macd(closes)
        val atr = Indicators.atr(candles, 14).last()
        val close = closes.last()
        val tol = (atr ?: (close * 0.0005)) * 0.5
        val recent = candles.takeLast(200)
        val all = Indicators.levels(recent, tol)
        val supports = all.filter { it.price < close }.sortedByDescending { it.price }
        val resistances = all.filter { it.price > close }.sortedBy { it.price }
        return IndicatorSnapshot(
            tf, candles.last().time, close, e20, e50, e200, rsi,
            m.macd.last(), m.signal.last(), m.histogram.last(), atr,
            Indicators.trend(candles), supports, resistances
        )
    }

    private fun dirOf(t: Trend): Direction? = when (t) { Trend.UP -> Direction.LONG; Trend.DOWN -> Direction.SHORT; else -> null }

    /**
     * Multi-timeframe rule check. WAIT is the default: BUY/SELL SETUP is returned only when EVERY rule passes.
     * [spreadPips] may be null (a data feed rarely knows the broker's spread); that is reported as a caveat.
     */
    fun evaluate(
        pair: CurrencyPair,
        htfRaw: List<Candle>,
        setupRaw: List<Candle>,
        entryRaw: List<Candle>,
        cfg: SetupConfig,
        nowSec: Long,
        spreadPips: Double?,
        isDemoData: Boolean
    ): SetupResult {
        val htf = closedOnly(htfRaw, cfg.htf, nowSec)
        val set = closedOnly(setupRaw, cfg.setupTf, nowSec)
        val ent = closedOnly(entryRaw, cfg.entryTf, nowSec)
        val checks = mutableListOf<RuleCheck>()
        val caveats = mutableListOf<String>()
        if (isDemoData) caveats += "Built on synthetic DEMO DATA. For learning only; never trade on it."
        caveats += "Indicator agreement never guarantees a profitable trade."

        fun wait(snapH: IndicatorSnapshot?, snapS: IndicatorSnapshot?, snapE: IndicatorSnapshot?, dir: Direction? = null, extraWatch: List<String> = emptyList()): SetupResult {
            val against = checks.filter { !it.passed }.map { "${it.name}: ${it.detail}" }
            val forList = checks.filter { it.passed }.map { "${it.name}: ${it.detail}" }
            val watch = extraWatch.ifEmpty { checks.filter { !it.passed }.map { "Wait until: ${it.name.lowercase()}" } }
            return SetupResult(
                pair, Decision.WAIT, dir, checks.toList(), forList, against, null, null, null, null,
                emptyList(), null, emptyList(), watch, caveats.toList(), snapH, snapS, snapE, nowSec
            )
        }

        // ---- data adequacy (any failure => WAIT) ----
        val series = listOf(Triple("4H/higher", htf, cfg.htf), Triple("Setup", set, cfg.setupTf), Triple("Entry", ent, cfg.entryTf))
        val enough = series.all { it.second.size >= cfg.minCandles }
        checks += RuleCheck("Enough history", enough,
            if (enough) "Each timeframe has at least ${cfg.minCandles} closed candles." else "Fewer than ${cfg.minCandles} closed candles on at least one timeframe.")
        val fresh = series.all { (_, c, tf) -> c.isNotEmpty() && nowSec - c.last().time <= (cfg.maxStaleCandles + 1) * tf.seconds }
        checks += RuleCheck("Fresh data", fresh,
            if (fresh) "The latest candles are recent." else "The newest candle is old (market closed, feed delayed or offline), so no setup is allowed.")
        val gaps = unexpectedGaps(set, cfg.setupTf) + unexpectedGaps(ent, cfg.entryTf)
        val gapsOk = gaps <= cfg.maxUnexpectedGaps
        checks += RuleCheck("No missing candles", gapsOk, if (gapsOk) "No unexpected gaps in the recent candles." else "$gaps unexpected gaps in recent candles; the data may be unreliable.")

        val sH = snapshot(htf, cfg.htf)
        val sS = snapshot(set, cfg.setupTf)
        val sE = snapshot(ent, cfg.entryTf)
        if (!enough || !fresh || !gapsOk || sH == null || sS == null || sE == null) {
            return wait(sH, sS, sE, extraWatch = listOf("Reload when the market is open and the data feed is current."))
        }

        // ---- direction from the higher timeframe ----
        val dir = dirOf(sH.trend.trend)
        checks += RuleCheck("${cfg.htf.label} trend is clear", dir != null,
            if (dir != null) "${sH.trend.trend.label}: ${sH.trend.detail}" else "${sH.trend.trend.label}. Trading against an unclear trend is a coin flip, so the answer is WAIT.")
        if (dir == null) return wait(sH, sS, sE)
        val long = dir == Direction.LONG

        checks += RuleCheck("${cfg.setupTf.label} trend agrees", dirOf(sS.trend.trend) == dir,
            "${cfg.setupTf.label} is ${sS.trend.trend.label.lowercase()} (${sS.trend.structure.label.lowercase()}).")

        val atrS = sS.atr
        if (atrS == null || atrS <= 0.0) {
            checks += RuleCheck("Volatility measurable", false, "ATR could not be calculated.")
            return wait(sH, sS, sE, dir)
        }

        // pullback to the EMA 20/50 area on the setup timeframe
        val dist20 = sS.ema20?.let { abs(sS.close - it) }
        val dist50 = sS.ema50?.let { abs(sS.close - it) }
        val nearest = listOfNotNull(dist20, dist50).minOrNull()
        val pullOk = nearest != null && nearest <= cfg.pullbackAtrMult * atrS
        checks += RuleCheck("Pullback to value area", pullOk,
            if (pullOk) "Price is within ${"%.1f".format(cfg.pullbackAtrMult)} ATR of the ${cfg.setupTf.label} EMA 20/50, a pullback in the trend."
            else "Price is stretched away from the ${cfg.setupTf.label} EMAs; chasing a move far from value has poor risk/reward.")

        // confirmation candle on the entry timeframe
        val last = ent.last(); val prev = ent[ent.size - 2]
        val confirm = if (long) last.bullish && last.close > prev.close else last.bearish && last.close < prev.close
        checks += RuleCheck("${cfg.entryTf.label} confirmation candle", confirm,
            if (confirm) "The last closed ${cfg.entryTf.label} candle closed ${if (long) "up" else "down"} in the trade direction."
            else "No ${if (long) "bullish" else "bearish"} confirmation candle on ${cfg.entryTf.label} yet.")

        // RSI band
        val rsi = sE.rsi
        val lo = if (long) cfg.rsiMin else 100 - cfg.rsiMax
        val hi = if (long) cfg.rsiMax else 100 - cfg.rsiMin
        val rsiOk = rsi != null && rsi in lo..hi
        checks += RuleCheck("RSI not contradicting", rsiOk,
            if (rsi == null) "RSI unavailable." else "RSI(14) is ${"%.1f".format(rsi)}; accepted range for this direction is ${"%.0f".format(lo)}-${"%.0f".format(hi)}.")

        // MACD momentum
        val hist = Indicators.macd(ent.map { it.close }).histogram
        val h1 = hist.lastOrNull(); val h0 = if (hist.size >= 2) hist[hist.size - 2] else null
        val macdOk = if (!cfg.requireMacdTurn) true else h1 != null && h0 != null && (if (long) h1 > h0 else h1 < h0)
        checks += RuleCheck("MACD momentum", macdOk,
            if (!cfg.requireMacdTurn) "MACD turn not required by your rules."
            else if (macdOk) "MACD histogram is ${if (long) "rising" else "falling"} on ${cfg.entryTf.label}."
            else "MACD histogram is not moving in the trade direction on ${cfg.entryTf.label}.")

        // spread
        val spreadOk = spreadPips == null || spreadPips <= cfg.maxSpreadPips
        checks += RuleCheck("Spread acceptable", spreadOk,
            if (spreadPips == null) "Spread is not measurable from the data feed (check it in your broker before entering)."
            else "Spread ${"%.1f".format(spreadPips)} pips vs limit ${"%.1f".format(cfg.maxSpreadPips)}.")
        if (spreadPips == null) caveats += "Spread was not checked: the data feed does not know your broker's spread."

        // volatility
        val atrs = Indicators.atr(set, 14).filterNotNull().takeLast(50)
        val avgAtr = if (atrs.isEmpty()) atrS else atrs.average()
        val volOk = atrS <= cfg.maxAtrSpikeMultiple * avgAtr
        checks += RuleCheck("Volatility normal", volOk,
            if (volOk) "ATR is in its normal range." else "ATR is more than ${"%.1f".format(cfg.maxAtrSpikeMultiple)}x its recent average (news spike?).")

        // stop and targets
        val entryPx = last.close
        val stopDist = cfg.slAtrMult * atrS
        val recent = ent.takeLast(5)
        val structStop = if (long) recent.minOf { it.low } - 0.1 * atrS else recent.maxOf { it.high } + 0.1 * atrS
        val stop = if (long) min(entryPx - stopDist, structStop) else max(entryPx + stopDist, structStop)
        val risk = abs(entryPx - stop)
        val stopOk = risk > 0 && risk <= cfg.maxStopAtrMultiple * atrS
        checks += RuleCheck("Stop-loss placement", stopOk,
            if (stopOk) "Stop sits beyond recent swing/ATR distance (${"%.1f".format(risk / pair.pipSize)} pips)."
            else "A sensible stop would be wider than ${"%.1f".format(cfg.maxStopAtrMultiple)} ATR, so the trade is too wide.")

        val levelTarget = if (long) sS.resistances.firstOrNull { it.price > entryPx + 0.2 * atrS }
        else sS.supports.firstOrNull { it.price < entryPx - 0.2 * atrS }
        val targets = mutableListOf<TargetLevel>()
        if (risk > 0) {
            levelTarget?.let { targets += TargetLevel(if (long) "Nearest resistance" else "Nearest support", it.price, abs(it.price - entryPx) / risk, false) }
            listOf(1.5, 2.0, 3.0).forEach { r ->
                targets += TargetLevel("${r}R projection", if (long) entryPx + r * risk else entryPx - r * risk, r, true)
            }
        }
        val firstRr = targets.firstOrNull { !it.isProjection }?.rr ?: 2.0
        val rrOk = risk > 0 && firstRr >= cfg.minRiskReward
        checks += RuleCheck("Minimum risk/reward", rrOk,
            if (levelTarget != null) "Room to the nearest ${if (long) "resistance" else "support"} is 1:${"%.2f".format(firstRr)} (minimum 1:${"%.1f".format(cfg.minRiskReward)})."
            else "No structure level found ahead; reward is a projection of 1:2 (minimum 1:${"%.1f".format(cfg.minRiskReward)}).")

        if (checks.any { !it.passed }) return wait(sH, sS, sE, dir)

        val zone = 0.25 * (sE.atr ?: atrS)
        val decision = if (long) Decision.BUY_SETUP else Decision.SELL_SETUP
        val invalidation = listOf(
            "A ${cfg.entryTf.label} close ${if (long) "below" else "above"} the stop-loss at ${"%.${pair.decimals}f".format(stop)}.",
            "The ${cfg.htf.label} trend stops being ${if (long) "an uptrend" else "a downtrend"} (EMA 20/50 cross or a break of structure).",
            "A high-impact news release before the entry, which can make every rule here meaningless."
        )
        return SetupResult(
            pair, decision, dir, checks.toList(),
            checks.map { "${it.name}: ${it.detail}" }, emptyList(),
            entryPx, entryPx - zone, entryPx + zone, stop, targets, firstRr,
            invalidation, emptyList(), caveats.toList(), sH, sS, sE, nowSec
        )
    }
}
