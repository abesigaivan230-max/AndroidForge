package com.tradewiseai.app.feature.tools

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.data.remote.CalendarResult
import com.tradewiseai.app.data.remote.Impact
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.risk.RiskCalculator
import com.tradewiseai.app.domain.risk.RiskInput
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.BulletList
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.EmptyState
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.Pill
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.Shimmer
import com.tradewiseai.app.ui.components.StatTile
import com.tradewiseai.app.ui.components.TwCard
import com.tradewiseai.app.ui.components.TwField
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.toDoubleOrNullLoose
import kotlinx.coroutines.flow.MutableStateFlow

/** Lets the Analyse tab hand a setup to the position-size calculator. */
data class SizerPrefill(val pair: CurrencyPair, val entry: Double, val stop: Double, val target: Double?)
object SizerBridge { val prefill = MutableStateFlow<SizerPrefill?>(null) }

@Composable
fun SizerScreen() {
    val app = rememberApp()
    val s by app.settings.state.collectAsState()
    val pre by SizerBridge.prefill.collectAsState()
    var pair by remember { mutableStateOf(s.defaultPair) }
    var balance by remember { mutableStateOf(s.startingBalance.toString()) }
    var risk by remember { mutableStateOf(s.maxRiskPercent.coerceAtMost(1.0).toString()) }
    var entry by remember { mutableStateOf("") }
    var stop by remember { mutableStateOf("") }
    var tp by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }
    LaunchedEffect(pre) {
        pre?.let {
            pair = it.pair; entry = Fmt.price(it.pair, it.entry); stop = Fmt.price(it.pair, it.stop)
            tp = it.target?.let { t -> Fmt.price(it.pair, t) } ?: ""
            SizerBridge.prefill.value = null
        }
    }
    val needsRate = s.accountCurrency != "USD" && s.accountCurrency != pair.base && s.accountCurrency != pair.quote
    val b = balance.toDoubleOrNullLoose(); val r = risk.toDoubleOrNullLoose()
    val e = entry.toDoubleOrNullLoose(); val sl = stop.toDoubleOrNullLoose(); val t = tp.toDoubleOrNullLoose()
    val result = if (b != null && r != null && e != null && sl != null)
        RiskCalculator.calculate(RiskInput(s.accountCurrency, b, r, pair, e, sl, t, rate.toDoubleOrNullLoose(), s.maxRiskPercent)) else null

    ScreenColumn {
        Banner("Planning tool. It never sends anything to a broker. Check lot size, contract size and spread in your own platform.", TW.blueSoft, warning = false)
        ChipRow(CurrencyPair.values().map { it.symbol }, pair.symbol, { x -> CurrencyPair.fromSymbol(x)?.let { pair = it } })
        TwCard {
            TwField(balance, { balance = it }, "Account balance (${s.accountCurrency})", numeric = true)
            TwField(risk, { risk = it }, "Risk per trade (%)", numeric = true)
            TwField(entry, { entry = it }, "Entry price", numeric = true)
            TwField(stop, { stop = it }, "Stop-loss price", numeric = true)
            TwField(tp, { tp = it }, "Take-profit (optional)", numeric = true)
            if (needsRate) TwField(rate, { rate = it }, "${s.accountCurrency} per 1 USD (needed for conversion)", numeric = true)
        }
        if (result != null) {
            if (!result.valid) Banner(result.error ?: "Invalid input.", TW.red)
            else Appear {
                TwCard(accent = TW.blue) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        StatTile("Lot size", "%.2f".format(result.lots), Modifier.weight(1f), TW.blueSoft)
                        StatTile("Risk", Fmt.money(result.riskAmount, s.accountCurrency), Modifier.weight(1f))
                    }
                    KeyValue("Stop distance", "%.1f pips".format(result.stopPips))
                    KeyValue("Units", "%,.0f".format(result.units))
                    KeyValue("Loss if stopped", Fmt.money(result.potentialLoss, s.accountCurrency), TW.red)
                    result.potentialProfit?.let { KeyValue("Profit at target", Fmt.money(it, s.accountCurrency), TW.green) }
                    result.riskReward?.let { KeyValue("Risk : reward", "1 : %.2f".format(it)) }
                    BulletList(result.notes)
                }
            }
        } else Text("Fill in balance, risk, entry and stop-loss.", style = TwType.small)
    }
}

@Composable
fun CalendarScreen() {
    val app = rememberApp()
    var res by remember { mutableStateOf<CalendarResult?>(null) }
    var filter by remember { mutableStateOf("All") }
    LaunchedEffect(Unit) { res = app.calendar.load() }
    ScreenColumn {
        Text("All times are East Africa Time (EAT).", style = TwType.small)
        val r = res
        if (r == null) { Shimmer(Modifier.fillMaxWidth(), 60.dp); Shimmer(Modifier.fillMaxWidth(), 60.dp) }
        else {
            r.message?.let { Banner(it) }
            if (r.events.isEmpty()) EmptyState("No events to show", "Events appear only when real data is loaded into the backend. Nothing is invented.")
            else {
                ChipRow(listOf("All", "High", "Medium", "Low"), filter, { filter = it })
                val list = r.events.filter { filter == "All" || it.impact.label == filter }
                list.forEachIndexed { i, ev ->
                    Appear(i * 30) {
                        TwCard {
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Text(ev.title, style = TwType.heading, modifier = Modifier.weight(1f))
                                Pill(ev.impact.label, when (ev.impact) { Impact.HIGH -> TW.red; Impact.MEDIUM -> TW.amber; Impact.LOW -> TW.green })
                            }
                            Text("${ev.currency}  |  ${Fmt.timeEat(ev.timeSec)}", style = TwType.small)
                            if (ev.previous != null || ev.forecast != null || ev.actual != null)
                                Text("Prev ${ev.previous ?: "-"}  |  Fcst ${ev.forecast ?: "-"}  |  Actual ${ev.actual ?: "-"}", style = TwType.mono)
                        }
                    }
                }
            }
        }
        GhostButton("Reload", { res = null; /* triggers shimmer */ }, Modifier.fillMaxWidth())
    }
    LaunchedEffect(res == null) { if (res == null) res = app.calendar.load() }
}
