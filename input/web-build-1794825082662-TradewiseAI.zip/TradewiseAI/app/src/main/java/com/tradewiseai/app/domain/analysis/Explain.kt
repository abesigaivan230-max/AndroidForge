package com.tradewiseai.app.domain.analysis

import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Decision
import kotlin.math.abs

/** Structured explanation. Produced either by the backend AI (validated) or by [LocalExplainer]. */
data class AiExplanation(
    val summary: String,
    val marketState: String,
    val indicatorNotes: List<String>,
    val whySetupOrNot: String,
    val whatWouldChange: List<String>,
    val beginnerExplanation: String,
    val risks: List<String>,
    val answer: String,
    val source: Source
) {
    enum class Source { AI, ON_DEVICE_RULES }
}

/** One extracted item from a screenshot, with an explicit read/unclear flag. Nothing is guessed. */
data class ReadItem(val value: String?, val status: String) {
    val isRead: Boolean get() = status == "read" && !value.isNullOrBlank()
}

data class ScreenshotLevel(val label: String, val value: Double?, val status: String)

data class ScreenshotAnalysis(
    val readable: Boolean,
    val unreadableReason: String,
    val pair: ReadItem,
    val timeframe: ReadItem,
    val indicators: List<ReadItem>,
    val priceLevels: List<ScreenshotLevel>,
    val support: List<Double>,
    val resistance: List<Double>,
    val structure: String,
    val bullishScenario: String,
    val bearishScenario: String,
    val uncertainty: String
)

/** On-device explanation built only from the rule results. Works offline and never invents a number. */
object LocalExplainer {

    fun explain(r: SetupResult): AiExplanation {
        val p = r.pair.symbol
        val h = r.htf; val s = r.setup; val e = r.entryTfSnapshot
        val state = buildString {
            if (h != null) append("${h.timeframe.label}: ${h.trend.trend.label.lowercase()}. ")
            if (s != null) append("${s.timeframe.label}: ${s.trend.trend.label.lowercase()}. ")
            if (e != null) append("${e.timeframe.label}: ${e.trend.trend.label.lowercase()}.")
            if (isEmpty()) append("There was not enough data to describe the market.")
        }.trim()
        val notes = mutableListOf<String>()
        s?.let {
            it.ema20?.let { v -> it.ema50?.let { w -> notes += "On ${it.timeframe.label}, EMA 20 is ${if (v > w) "above" else "below"} EMA 50, which ${if (v > w) "supports" else "argues against"} an uptrend." } }
            it.atr?.let { a -> notes += "ATR(14) on ${it.timeframe.label} is ${"%.1f".format(a / r.pair.pipSize)} pips: that is how far a typical candle moves, and it sizes the stop-loss." }
        }
        e?.rsi?.let { v -> notes += "RSI(14) on ${e.timeframe.label} is ${"%.1f".format(v)}. Above 70 is stretched upward, below 30 is stretched downward; it measures momentum, not direction." }
        e?.macdHist?.let { v -> notes += "The MACD histogram on ${e.timeframe.label} is ${if (v >= 0) "positive" else "negative"}, showing which side has momentum right now." }

        val summary = when (r.decision) {
            Decision.BUY_SETUP -> "$p has a BUY SETUP: all ${r.checks.size} rules agree. That means conditions line up, not that the trade will win."
            Decision.SELL_SETUP -> "$p has a SELL SETUP: all ${r.checks.size} rules agree. That means conditions line up, not that the trade will win."
            Decision.WAIT -> "$p is a WAIT: ${r.passedCount} of ${r.checks.size} rules are satisfied, and every rule must pass."
        }
        val why = when (r.decision) {
            Decision.WAIT -> r.reasonsAgainst.take(3).joinToString(" ").ifBlank { "The evidence is insufficient." }
            else -> "The higher-timeframe trend, the pullback, the confirmation candle and the momentum filters all point the same way, and the stop-loss keeps the risk/reward above your minimum."
        }
        val change = if (r.decision == Decision.WAIT) r.watchFor.take(4) else r.invalidation.take(3)
        val beginner = when (r.decision) {
            Decision.WAIT -> "Waiting is a position. Good traders skip most moments and act only when several things agree. Right now they do not, so the disciplined move is to do nothing and look again later."
            Decision.BUY_SETUP -> "A buy setup means the bigger trend is up, price dipped back to a fair area, and a small candle just showed buyers returning. You would place a stop-loss below the recent low so a wrong guess costs a small, planned amount."
            Decision.SELL_SETUP -> "A sell setup means the bigger trend is down, price bounced back to a fair area, and a small candle just showed sellers returning. You would place a stop-loss above the recent high so a wrong guess costs a small, planned amount."
        }
        return AiExplanation(
            summary, state, notes, why, change, beginner,
            listOf("Any setup can fail; risk only an amount you can afford to lose.", "News releases can jump past a stop-loss.", "Your broker's price can differ from this independent data feed.") + r.caveats.take(1),
            "", AiExplanation.Source.ON_DEVICE_RULES
        )
    }
}

/** Compares price levels read from a screenshot with an independent, FRESH market price. */
object ScreenshotComparator {

    data class Comparison(val comparable: Boolean, val message: String)

    fun compare(a: ScreenshotAnalysis, pair: CurrencyPair?, livePrice: Double?, liveIsFresh: Boolean): Comparison {
        if (!a.readable) return Comparison(false, "Screenshot not readable, so nothing can be compared.")
        if (livePrice == null || !liveIsFresh) {
            return Comparison(false, "No fresh independent market data, so this analysis is based on the screenshot only.")
        }
        val shotPair = CurrencyPair.fromSymbol(a.pair.value)
        if (a.pair.isRead && shotPair != null && pair != null && shotPair != pair) {
            return Comparison(false, "Screenshot shows ${shotPair.symbol} but live data was loaded for ${pair.symbol}.")
        }
        val levels = a.priceLevels.filter { it.status == "read" && it.value != null }.map { it.value!! }
        if (levels.isEmpty()) return Comparison(false, "No price level was legible in the screenshot, so it can't be checked against live data.")
        val nearest = levels.minByOrNull { abs(it - livePrice) }!!
        val diffPct = abs(nearest - livePrice) / livePrice * 100
        return if (diffPct <= 0.3) Comparison(true, "Prices read from the screenshot are within ${"%.2f".format(diffPct)}% of the independent feed.")
        else Comparison(true, "The nearest price in the screenshot differs from the independent feed by ${"%.2f".format(diffPct)}%. Your broker's chart (especially OTC/synthetic) can differ; trust the broker for execution.")
    }
}
