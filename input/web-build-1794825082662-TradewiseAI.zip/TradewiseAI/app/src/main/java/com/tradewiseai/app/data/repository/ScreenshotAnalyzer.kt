package com.tradewiseai.app.data.repository

import android.content.Context
import com.tradewiseai.app.data.remote.AiRepository
import com.tradewiseai.app.domain.analysis.ScreenshotAnalysis
import com.tradewiseai.app.domain.analysis.ScreenshotComparator
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataStatus

data class ScreenshotReport(
    val analysis: ScreenshotAnalysis,
    val comparison: ScreenshotComparator.Comparison,
    val comparedAgainst: CurrencyPair?,
    val livePriceStatus: DataStatus?
)

/** Runs the vision analysis (via the backend) and, only if fresh independent data exists, compares it. */
class ScreenshotAnalyzer(
    @Suppress("unused") private val context: Context,
    private val ai: AiRepository,
    private val market: MarketRepository
) {
    suspend fun analyse(path: String, fallbackPair: CurrencyPair): Result<ScreenshotReport> {
        val a = ai.analyseScreenshot(path).getOrElse { return Result.failure(it) }
        // use the pair the screenshot shows when it was legible, otherwise the pair selected in the app
        val shotPair = if (a.pair.isRead) CurrencyPair.fromSymbol(a.pair.value) else null
        val pair = shotPair ?: fallbackPair
        val quote = if (a.readable) market.quote(pair).getOrNull() else null
        val status = quote?.let { market.statusOf(it) }
        val fresh = quote != null && status == DataStatus.LIVE
        val cmp = ScreenshotComparator.compare(a, shotPair ?: if (a.pair.isRead) null else pair, quote?.price, fresh)
        return Result.success(ScreenshotReport(a, cmp, pair, status))
    }
}
