package com.tradewiseai.app.data.local

import android.content.Context
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Direction
import com.tradewiseai.app.domain.risk.JournalTrade
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.UUID

/** Offline-first demo journal: a JSON file in app-private storage. Works with no network and no account. */
class JournalStore(private val context: Context) {
    private val file = File(context.filesDir, "journal.json")
    private val shotsDir = File(context.filesDir, "journal_shots").apply { mkdirs() }
    private val lock = Mutex()
    private val _trades = MutableStateFlow(readAll())
    val trades: StateFlow<List<JournalTrade>> = _trades.asStateFlow()

    suspend fun add(t: JournalTrade) = mutate { it + t }
    suspend fun update(t: JournalTrade) = mutate { list -> list.map { if (it.id == t.id) t else it } }
    suspend fun delete(id: String) {
        _trades.value.firstOrNull { it.id == id }?.screenshotPath?.let { File(it).delete() }
        mutate { list -> list.filter { it.id != id } }
    }
    suspend fun replaceAll(list: List<JournalTrade>) = mutate { list }

    /** Copies a screenshot into private journal storage so it survives the source being deleted. */
    suspend fun attachScreenshot(sourcePath: String): String = withContext(Dispatchers.IO) {
        val dst = File(shotsDir, "j_${UUID.randomUUID()}.jpg")
        File(sourcePath).copyTo(dst, overwrite = true)
        dst.absolutePath
    }

    suspend fun clear() {
        shotsDir.listFiles()?.forEach { it.delete() }
        mutate { emptyList() }
    }

    private suspend fun mutate(block: (List<JournalTrade>) -> List<JournalTrade>) = lock.withLock {
        val next = block(_trades.value)
        _trades.value = next
        withContext(Dispatchers.IO) {
            val tmp = File(context.filesDir, "journal.json.tmp")
            tmp.writeText(toJson(next).toString())
            if (!tmp.renameTo(file)) { file.writeText(tmp.readText()); tmp.delete() }   // atomic when possible
        }
    }

    private fun readAll(): List<JournalTrade> = try {
        if (!file.exists()) emptyList() else fromJson(JSONArray(file.readText()))
    } catch (_: Exception) { emptyList() }

    companion object {
        fun toJson(list: List<JournalTrade>): JSONArray {
            val a = JSONArray(); list.forEach { a.put(tradeToJson(it)) }; return a
        }

        fun tradeToJson(t: JournalTrade): JSONObject = JSONObject()
            .put("id", t.id).put("pair", t.pair.symbol).put("dir", t.direction.name)
            .put("entry", t.entry).put("exit", t.exit ?: JSONObject.NULL)
            .put("sl", t.stopLoss).put("tp", t.takeProfit ?: JSONObject.NULL)
            .put("lots", t.lots).put("risk", t.riskAmount).put("result", t.resultAmount ?: JSONObject.NULL)
            .put("emotion", t.emotion).put("reason", t.reason).put("lessons", t.lessons)
            .put("shot", t.screenshotPath ?: JSONObject.NULL)
            .put("opened", t.openedAtMs).put("closed", t.closedAtMs ?: JSONObject.NULL)

        fun fromJson(arr: JSONArray): List<JournalTrade> = (0 until arr.length()).mapNotNull { i ->
            try { tradeFromJson(arr.getJSONObject(i)) } catch (_: Exception) { null }
        }

        fun tradeFromJson(o: JSONObject): JournalTrade {
            fun dbl(k: String): Double? = if (o.isNull(k) || !o.has(k)) null else o.getDouble(k)
            fun lng(k: String): Long? = if (o.isNull(k) || !o.has(k)) null else o.getLong(k)
            return JournalTrade(
                id = o.getString("id"),
                pair = CurrencyPair.fromSymbol(o.getString("pair")) ?: throw IllegalArgumentException("pair"),
                direction = Direction.valueOf(o.getString("dir")),
                entry = o.getDouble("entry"), exit = dbl("exit"),
                stopLoss = o.getDouble("sl"), takeProfit = dbl("tp"),
                lots = o.getDouble("lots"), riskAmount = o.getDouble("risk"), resultAmount = dbl("result"),
                emotion = o.optString("emotion"), reason = o.optString("reason"), lessons = o.optString("lessons"),
                screenshotPath = if (o.isNull("shot")) null else o.optString("shot").ifBlank { null },
                openedAtMs = o.getLong("opened"), closedAtMs = lng("closed")
            )
        }
    }
}

/** Lesson completion and best quiz scores. */
class LessonStore(context: Context) {
    private val prefs = context.getSharedPreferences("tradewise_lessons", Context.MODE_PRIVATE)
    private val _done = MutableStateFlow(prefs.getStringSet("done", emptySet())?.toSet() ?: emptySet())
    val completed: StateFlow<Set<String>> = _done.asStateFlow()

    fun bestScore(id: String): Int = prefs.getInt("score_$id", -1)

    fun recordQuiz(id: String, correct: Int, total: Int) {
        val pct = if (total == 0) 0 else correct * 100 / total
        if (pct > bestScore(id)) prefs.edit().putInt("score_$id", pct).apply()
        if (pct >= 60) markDone(id)
    }

    fun markDone(id: String) {
        val next = _done.value + id
        _done.value = next
        prefs.edit().putStringSet("done", next).apply()
    }

    fun clear() { prefs.edit().clear().apply(); _done.value = emptySet() }
}

data class PriceAlert(val id: String, val pair: CurrencyPair, val target: Double, val above: Boolean, val createdMs: Long, val triggeredMs: Long?)

class AlertStore(context: Context) {
    private val prefs = context.getSharedPreferences("tradewise_alerts", Context.MODE_PRIVATE)
    private val _alerts = MutableStateFlow(load())
    val alerts: StateFlow<List<PriceAlert>> = _alerts.asStateFlow()

    @Synchronized fun add(pair: CurrencyPair, target: Double, above: Boolean) {
        save(_alerts.value + PriceAlert(UUID.randomUUID().toString(), pair, target, above, System.currentTimeMillis(), null))
    }
    @Synchronized fun remove(id: String) = save(_alerts.value.filter { it.id != id })
    @Synchronized fun markTriggered(id: String) =
        save(_alerts.value.map { if (it.id == id) it.copy(triggeredMs = System.currentTimeMillis()) else it })
    fun active(): List<PriceAlert> = _alerts.value.filter { it.triggeredMs == null }

    // simple key/value used by the background worker for de-duplication and error cool-downs
    fun getString(k: String): String? = prefs.getString("kv_$k", null)
    fun putString(k: String, v: String) = prefs.edit().putString("kv_$k", v).apply()
    fun getLong(k: String): Long = prefs.getLong("kvl_$k", 0L)
    fun putLong(k: String, v: Long) = prefs.edit().putLong("kvl_$k", v).apply()

    private fun save(list: List<PriceAlert>) {
        _alerts.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("pair", it.pair.symbol).put("target", it.target)
                .put("above", it.above).put("created", it.createdMs).put("triggered", it.triggeredMs ?: JSONObject.NULL))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun load(): List<PriceAlert> = try {
        val arr = JSONArray(prefs.getString("list", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val p = CurrencyPair.fromSymbol(o.optString("pair")) ?: return@mapNotNull null
            PriceAlert(o.getString("id"), p, o.getDouble("target"), o.getBoolean("above"), o.optLong("created"),
                if (o.isNull("triggered")) null else o.getLong("triggered"))
        }
    } catch (_: Exception) { emptyList() }

    /** Clears alerts only (de-duplication keys are kept per-key; they are cleared with the whole store). */
    fun clear() { prefs.edit().clear().apply(); _alerts.value = emptyList() }
}
