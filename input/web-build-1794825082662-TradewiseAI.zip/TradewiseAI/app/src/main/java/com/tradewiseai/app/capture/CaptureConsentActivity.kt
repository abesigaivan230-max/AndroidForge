package com.tradewiseai.app.capture

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Transparent activity that shows Android's own screen-capture consent dialog. Nothing is captured unless the
 * user taps "Start now" in that system dialog, every single time (Android 14 also requires this per capture).
 */
class CaptureConsentActivity : ComponentActivity() {

    private val launcher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        val data = res.data
        if (res.resultCode == Activity.RESULT_OK && data != null) {
            val svc = Intent(this, ScreenCaptureService::class.java)
                .putExtra(ScreenCaptureService.EXTRA_CODE, res.resultCode)
                .putExtra(ScreenCaptureService.EXTRA_DATA, data)
            try {
                ContextCompat.startForegroundService(this, svc)
            } catch (e: Exception) {
                CaptureBus.events.tryEmit(CaptureEvent.Failed("Could not start the capture service: ${e.message}"))
            }
        } else {
            CaptureBus.events.tryEmit(CaptureEvent.Failed("Screen capture was cancelled, nothing was captured."))
        }
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            try {
                launcher.launch(mpm.createScreenCaptureIntent())
            } catch (e: Exception) {
                CaptureBus.events.tryEmit(CaptureEvent.Failed("Screen capture is not available on this device. Use the share option instead."))
                finish()
            }
        }
    }
}
