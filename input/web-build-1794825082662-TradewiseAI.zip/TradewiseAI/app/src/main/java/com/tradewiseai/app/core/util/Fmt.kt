package com.tradewiseai.app.core.util

import com.tradewiseai.app.domain.model.CurrencyPair
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

object Fmt {
    /** East Africa Time. All user-visible times use this zone. */
    val EAT: ZoneId = ZoneId.of("Africa/Kampala")
    const val EAT_OFFSET_MS = 3 * 3_600_000L

    fun price(pair: CurrencyPair, v: Double): String = String.format(Locale.US, "%.${pair.decimals}f", v)
    fun price(pair: CurrencyPair, v: Double?): String = if (v == null) "-" else price(pair, v)

    fun pips(pair: CurrencyPair, priceDistance: Double): String =
        String.format(Locale.US, "%.1f pips", Math.abs(priceDistance) / pair.pipSize)

    fun money(v: Double, currency: String = "USD"): String {
        val sign = if (v < 0) "-" else ""
        val sym = when (currency) { "USD" -> "$"; "EUR" -> "€"; "GBP" -> "£"; else -> "$currency " }
        return sign + sym + String.format(Locale.US, "%,.2f", Math.abs(v))
    }

    fun signedMoney(v: Double): String = (if (v >= 0) "+" else "-") + "$" + String.format(Locale.US, "%,.2f", Math.abs(v))

    fun pct(v: Double, digits: Int = 1): String = String.format(Locale.US, "%.${digits}f%%", v)

    fun timeEat(epochSec: Long, pattern: String = "dd MMM, HH:mm"): String =
        DateTimeFormatter.ofPattern(pattern, Locale.US).withZone(EAT).format(Instant.ofEpochSecond(epochSec)) + " EAT"

    fun clockEat(epochSec: Long): String =
        DateTimeFormatter.ofPattern("HH:mm:ss", Locale.US).withZone(EAT).format(Instant.ofEpochSecond(epochSec)) + " EAT"

    fun ago(seconds: Long): String = when {
        seconds < 5 -> "just now"
        seconds < 60 -> "${seconds}s ago"
        seconds < 3600 -> "${seconds / 60}m ago"
        seconds < 86_400 -> "${seconds / 3600}h ${(seconds % 3600) / 60}m ago"
        else -> "${seconds / 86_400}d ago"
    }
}
