package com.tradewiseai.app.data.remote

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import org.json.JSONObject

data class AuthState(val signedIn: Boolean, val email: String?, val userId: String?)

sealed class AuthResult {
    object SignedIn : AuthResult()
    data class NeedsEmailConfirmation(val email: String) : AuthResult()
    data class Failed(val message: String) : AuthResult()
}

/** Supabase Auth (GoTrue) over REST. Tokens are kept in EncryptedSharedPreferences. */
class AuthRepository(context: Context, private val http: SupabaseHttp) {

    private val prefs: SharedPreferences = try {
        val key = MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build()
        EncryptedSharedPreferences.create(
            context, "tradewise_auth", key,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    } catch (e: Exception) {
        // Keystore problems on some devices: fall back to a private, non-persistent store rather than crash.
        context.getSharedPreferences("tradewise_auth_fallback", Context.MODE_PRIVATE).also { it.edit().clear().apply() }
    }

    private val lock = Mutex()
    private val _state = MutableStateFlow(readState())
    val state: StateFlow<AuthState> = _state.asStateFlow()
    val configured: Boolean get() = http.configured

    private fun readState(): AuthState {
        val token = prefs.getString("access", null)
        return AuthState(token != null, prefs.getString("email", null), prefs.getString("uid", null))
    }

    private fun store(o: JSONObject, fallbackEmail: String?) {
        val user = o.optJSONObject("user")
        val expiresAt = System.currentTimeMillis() + o.optLong("expires_in", 3600L) * 1000L
        prefs.edit()
            .putString("access", o.getString("access_token"))
            .putString("refresh", o.optString("refresh_token"))
            .putLong("expiresAt", expiresAt)
            .putString("email", user?.optString("email")?.ifBlank { null } ?: fallbackEmail)
            .putString("uid", user?.optString("id")?.ifBlank { null } ?: prefs.getString("uid", null))
            .apply()
        _state.value = readState()
    }

    suspend fun signUp(email: String, password: String): AuthResult = try {
        val o = http.postJson("/auth/v1/signup", JSONObject().put("email", email).put("password", password), null, retries = 0)
        if (o.has("access_token")) { store(o, email); AuthResult.SignedIn } else AuthResult.NeedsEmailConfirmation(email)
    } catch (e: Exception) { AuthResult.Failed(e.message ?: "Sign-up failed.") }

    suspend fun signIn(email: String, password: String): AuthResult = try {
        val o = http.postJson("/auth/v1/token?grant_type=password", JSONObject().put("email", email).put("password", password), null, retries = 0)
        store(o, email); AuthResult.SignedIn
    } catch (e: Exception) { AuthResult.Failed(e.message ?: "Sign-in failed.") }

    fun signOut() {
        prefs.edit().clear().apply()
        _state.value = AuthState(false, null, null)
    }

    /** A valid access token, refreshed if it expires within a minute; null when signed out. */
    suspend fun validToken(): String? = lock.withLock {
        val access = prefs.getString("access", null) ?: return null
        val expiresAt = prefs.getLong("expiresAt", 0L)
        if (System.currentTimeMillis() < expiresAt - 60_000L) return access
        val refresh = prefs.getString("refresh", null)
        if (refresh.isNullOrBlank()) { signOut(); return null }
        return try {
            val o = http.postJson("/auth/v1/token?grant_type=refresh_token", JSONObject().put("refresh_token", refresh), null, retries = 1)
            store(o, prefs.getString("email", null))
            o.getString("access_token")
        } catch (e: ApiException) {
            if (e.httpCode in 400..403) signOut()   // refresh token rejected: user must sign in again
            null
        }
    }
}
