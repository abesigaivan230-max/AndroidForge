package com.tradewiseai.app.capture

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

sealed class CaptureEvent {
    data class Success(val path: String) : CaptureEvent()
    data class Failed(val message: String) : CaptureEvent()
}

/** In-process hand-off between the consent activity, the capture service and whoever shows the result. */
object CaptureBus {
    val events = MutableSharedFlow<CaptureEvent>(extraBufferCapacity = 8)

    /** The overlay hides itself while true, so it does not appear in its own screenshot. */
    val hideOverlay = MutableStateFlow(false)
}
