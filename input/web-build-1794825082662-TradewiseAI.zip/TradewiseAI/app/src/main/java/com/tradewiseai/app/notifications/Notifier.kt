package com.tradewiseai.app.notifications

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.tradewiseai.app.MainActivity
import com.tradewiseai.app.R

object Notifier {
    const val CH_OVERLAY = "overlay"
    const val CH_ALERTS = "alerts"
    const val CH_CAPTURE = "capture"
    const val ID_OVERLAY = 1001
    const val ID_CAPTURE = 1002
    private const val ID_ALERT_BASE = 2000

    fun createChannels(context: Context) {
        if (Build.VERSION.SDK_INT < 26) return
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel(CH_OVERLAY, context.getString(R.string.notif_channel_overlay), NotificationManager.IMPORTANCE_LOW).apply {
            description = "Shown while the floating assistant is running."; setShowBadge(false)
        })
        nm.createNotificationChannel(NotificationChannel(CH_ALERTS, context.getString(R.string.notif_channel_alerts), NotificationManager.IMPORTANCE_DEFAULT).apply {
            description = "Price alerts, setup alerts, data errors and calendar reminders."
        })
        nm.createNotificationChannel(NotificationChannel(CH_CAPTURE, context.getString(R.string.notif_channel_capture), NotificationManager.IMPORTANCE_LOW))
    }

    private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 0, Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    fun overlayNotification(context: Context, stopIntent: PendingIntent): Notification =
        NotificationCompat.Builder(context, CH_OVERLAY)
            .setSmallIcon(R.drawable.ic_stat_tw)
            .setContentTitle("TRADEWISE AI assistant is active")
            .setContentText("Floating over your apps. Tap to open, or stop it here.")
            .setContentIntent(openApp(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .addAction(0, "Stop assistant", stopIntent)
            .build()

    fun captureNotification(context: Context): Notification =
        NotificationCompat.Builder(context, CH_CAPTURE)
            .setSmallIcon(R.drawable.ic_stat_tw)
            .setContentTitle("Capturing one screenshot")
            .setContentText("You approved a single capture. It stops by itself.")
            .setOngoing(true)
            .build()

    fun canNotify(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return false
        return NotificationManagerCompat.from(context).areNotificationsEnabled()
    }

    /** [key] makes the notification id stable so the same alert replaces itself instead of stacking. */
    fun alert(context: Context, key: String, title: String, text: String) {
        if (!canNotify(context)) return
        val n = NotificationCompat.Builder(context, CH_ALERTS)
            .setSmallIcon(R.drawable.ic_stat_tw)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setContentIntent(openApp(context))
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(context).notify(ID_ALERT_BASE + (key.hashCode() and 0x3FFF), n)
        } catch (_: SecurityException) { /* permission revoked between the check and the call */ }
    }
}
