package com.tradewiseai.app.data.repository

import android.content.Context
import com.tradewiseai.app.data.preferences.SettingsStore
import com.tradewiseai.app.domain.analysis.SetupConfig
import com.tradewiseai.app.domain.analysis.SetupEngine
import com.tradewiseai.app.domain.analysis.SetupResult
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Decision
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class AnalysisOutcome(
    val result: SetupResult,
    val htf: CandleSeries,
    val setup: CandleSeries,
    val entry: CandleSeries,
    val isDemo: Boolean,
    val worstStatus: DataStatus
)

data class RecentAnalysis(val pair: CurrencyPair, val decision: Decision, val atMs: Long, val summary: String, val demo: Boolean)

class AnalysisRepository(
    context: Context,
    private val market: MarketRepository,
    private val settings: SettingsStore
) {
    private val prefs = context.getSharedPreferences("tradewise_recent", Context.MODE_PRIVATE)
    private val _recent = MutableStateFlow(loadRecent())
    val recent: StateFlow<List<RecentAnalysis>> = _recent.asStateFlow()

    private val last = HashMap<CurrencyPair, AnalysisOutcome>()
    fun lastOutcome(pair: CurrencyPair): AnalysisOutcome? = synchronized(last) { last[pair] }

    suspend fun analyse(pair: CurrencyPair, config: SetupConfig = settings.current.setupConfig(), force: Boolean = false): Result<AnalysisOutcome> {
        val cfg = config
        val h = market.candles(pair, cfg.htf, 300, force).getOrElse { return Result.failure(it) }
        val s = market.candles(pair, cfg.setupTf, 300, force).getOrElse { return Result.failure(it) }
        val e = market.candles(pair, cfg.entryTf, 300, force).getOrElse { return Result.failure(it) }
        val now = System.currentTimeMillis() / 1000
        val demo = listOf(h, s, e).any { it.origin == DataOrigin.DEMO }
        val result = SetupEngine.evaluate(pair, h.candles, s.candles, e.candles, cfg, now, spreadPips = null, isDemoData = demo)
        val statuses = listOf(market.statusOf(h), market.statusOf(s), market.statusOf(e))
        val worst = when {
            statuses.contains(DataStatus.DEMO) -> DataStatus.DEMO
            statuses.contains(DataStatus.STALE) -> DataStatus.STALE
            statuses.contains(DataStatus.CACHED) -> DataStatus.CACHED
            else -> DataStatus.LIVE
        }
        val out = AnalysisOutcome(result, h, s, e, demo, worst)
        synchronized(last) { last[pair] = out }
        remember(RecentAnalysis(pair, result.decision, System.currentTimeMillis(), result.reasonsAgainst.firstOrNull() ?: result.ruleSummary, demo))
        return Result.success(out)
    }

    private fun remember(r: RecentAnalysis) {
        val list = (listOf(r) + _recent.value).take(15)
        _recent.value = list
        val arr = JSONArray()
        list.forEach {
            arr.put(JSONObject().put("pair", it.pair.symbol).put("decision", it.decision.name)
                .put("at", it.atMs).put("summary", it.summary).put("demo", it.demo))
        }
        prefs.edit().putString("list", arr.toString()).apply()
    }

    private fun loadRecent(): List<RecentAnalysis> = try {
        val arr = JSONArray(prefs.getString("list", "[]"))
        (0 until arr.length()).mapNotNull { i ->
            val o = arr.getJSONObject(i)
            val p = CurrencyPair.fromSymbol(o.optString("pair")) ?: return@mapNotNull null
            val d = Decision.values().firstOrNull { it.name == o.optString("decision") } ?: return@mapNotNull null
            RecentAnalysis(p, d, o.optLong("at"), o.optString("summary"), o.optBoolean("demo"))
        }
    } catch (_: Exception) { emptyList() }

    fun clear() {
        prefs.edit().clear().apply(); _recent.value = emptyList()
        synchronized(last) { last.clear() }
    }
}
