package com.tradewiseai.app.domain.analysis

import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.DataStatus

/** Freshness rules. Cached or old data is never allowed to be called LIVE. */
object DataQuality {

    /** Seconds since the last candle OPENED, or null when there are no candles. */
    fun lastCandleAgeSec(series: CandleSeries, nowSec: Long): Long? =
        series.candles.lastOrNull()?.let { (nowSec - it.time).coerceAtLeast(0) }

    /** STALE when more than [staleAfterCandles] whole candles are missing at the end (weekend, closed market, dead feed). */
    fun statusOf(series: CandleSeries, nowSec: Long, staleAfterCandles: Int = 3): DataStatus {
        if (series.origin == DataOrigin.DEMO) return DataStatus.DEMO
        val age = lastCandleAgeSec(series, nowSec) ?: return DataStatus.STALE
        if (age > (staleAfterCandles + 1) * series.timeframe.seconds) return DataStatus.STALE
        return if (series.origin == DataOrigin.CACHED) DataStatus.CACHED else DataStatus.LIVE
    }

    fun quoteStatus(origin: DataOrigin, quoteTimeSec: Long, nowSec: Long, maxAgeSec: Long = 180): DataStatus = when {
        origin == DataOrigin.DEMO -> DataStatus.DEMO
        nowSec - quoteTimeSec > maxAgeSec -> DataStatus.STALE
        origin == DataOrigin.CACHED -> DataStatus.CACHED
        else -> DataStatus.LIVE
    }
}
