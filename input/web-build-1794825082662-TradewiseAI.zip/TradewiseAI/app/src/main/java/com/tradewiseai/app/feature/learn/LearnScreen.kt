package com.tradewiseai.app.feature.learn

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.rememberApp
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.BulletList
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.Pill
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.TwCard

@Composable
fun LearnScreen() {
    val app = rememberApp()
    val done by app.lessons.completed.collectAsState()
    var openId by remember { mutableStateOf<String?>(null) }
    var level by remember { mutableStateOf("All") }
    AnimatedContent(openId, transitionSpec = { fadeIn(tween(220)) togetherWith fadeOut(tween(120)) }, label = "learn") { id ->
        val lesson = LESSONS.firstOrNull { it.id == id }
        if (lesson != null) LessonView(lesson, onBack = { openId = null })
        else ScreenColumn {
            Text("Learn", style = TwType.display)
            val pct = done.size * 100 / LESSONS.size
            val prog by animateFloatAsState(pct / 100f, tween(700), label = "prog")
            TwCard {
                Text("${done.size} of ${LESSONS.size} lessons completed", style = TwType.heading)
                Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(TW.border)) {
                    Box(Modifier.fillMaxWidth(prog).height(8.dp).clip(RoundedCornerShape(4.dp)).background(TW.accentBrush))
                }
                Text("Pass a quiz with 60 percent or more to complete a lesson.", style = TwType.small)
            }
            ChipRow(listOf("All", "Beginner", "Intermediate", "Advanced"), level, { level = it })
            LESSONS.filter { level == "All" || it.level == level }.forEachIndexed { i, l ->
                Appear(i * 25) {
                    TwCard(onClick = { openId = l.id }) {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(l.title, style = TwType.heading)
                                Text(l.intro, style = TwType.small, maxLines = 2)
                            }
                            if (l.id in done) Pill("DONE", TW.green) else Pill(l.level, TW.blueSoft)
                        }
                        val best = app.lessons.bestScore(l.id)
                        if (best >= 0) Text("Best quiz score: $best%", style = TwType.small)
                    }
                }
            }
        }
    }
}

@Composable
private fun LessonView(l: Lesson, onBack: () -> Unit) {
    val app = rememberApp()
    var qi by remember(l.id) { mutableIntStateOf(-1) }       // -1 = reading, then quiz index, then finished
    var picked by remember(l.id) { mutableIntStateOf(-1) }
    var correct by remember(l.id) { mutableIntStateOf(0) }
    ScreenColumn {
        GhostButton("Back to lessons", onBack)
        Text(l.title, style = TwType.display)
        when {
            qi == -1 -> {
                Appear { TwCard { Text(l.intro, style = TwType.body); BulletList(l.points, TW.blueSoft) } }
                Appear(80) { TwCard(accent = TW.amber) { Text("EXAMPLE (made-up numbers)", style = TwType.label); Text(l.example, style = TwType.body) } }
                PrimaryButton("Take the quiz", { qi = 0 }, Modifier.fillMaxWidth())
            }
            qi < l.quiz.size -> {
                val q = l.quiz[qi]
                Text("Question ${qi + 1} of ${l.quiz.size}", style = TwType.label)
                TwCard { Text(q.q, style = TwType.heading) }
                q.options.forEachIndexed { i, o ->
                    val target = when {
                        picked == -1 -> TW.surfaceHi
                        i == q.answer -> TW.green.copy(alpha = 0.25f)
                        i == picked -> TW.red.copy(alpha = 0.25f)
                        else -> TW.surfaceHi
                    }
                    val bg by animateColorAsState(target, tween(300), label = "opt")
                    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(bg)
                        .border(1.dp, TW.border, RoundedCornerShape(14.dp))
                        .clickable(enabled = picked == -1) { picked = i; if (i == q.answer) correct++ }.padding(14.dp)) {
                        Text(o, style = TwType.body)
                    }
                }
                if (picked != -1) {
                    Appear { TwCard { Text(if (picked == q.answer) "Correct." else "Not quite.", style = TwType.heading); Text(q.why, style = TwType.small) } }
                    PrimaryButton(if (qi == l.quiz.size - 1) "See result" else "Next", {
                        if (qi == l.quiz.size - 1) app.lessons.recordQuiz(l.id, correct, l.quiz.size)
                        qi++; picked = -1
                    }, Modifier.fillMaxWidth())
                }
            }
            else -> {
                val pct = correct * 100 / l.quiz.size
                Appear { TwCard(accent = if (pct >= 60) TW.green else TW.amber) {
                    Text("$correct of ${l.quiz.size} correct ($pct%)", style = TwType.title)
                    Text(if (pct >= 60) "Lesson completed." else "Below 60 percent. Read the lesson again and retry.", style = TwType.body)
                } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    GhostButton("Retry", { qi = -1; picked = -1; correct = 0 })
                    PrimaryButton("Finish", onBack)
                }
            }
        }
    }
}
