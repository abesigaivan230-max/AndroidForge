package com.tradewiseai.app.feature.markets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.tradewiseai.app.TradewiseApp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.core.util.appViewModel
import com.tradewiseai.app.domain.analysis.SetupEngine
import com.tradewiseai.app.domain.indicators.Indicators
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.domain.model.Timeframe
import com.tradewiseai.app.ui.charts.CandleChart
import com.tradewiseai.app.ui.charts.ChartData
import com.tradewiseai.app.ui.charts.MacdChart
import com.tradewiseai.app.ui.charts.RsiChart
import com.tradewiseai.app.ui.components.Appear
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.ScreenColumn
import com.tradewiseai.app.ui.components.SectionTitle
import com.tradewiseai.app.ui.components.Shimmer
import com.tradewiseai.app.ui.components.StatusChip
import com.tradewiseai.app.ui.components.TwCard
import com.tradewiseai.app.ui.components.TwField
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.toDoubleOrNullLoose
import com.tradewiseai.app.notifications.AlertScheduler
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MarketsUi(
    val pair: CurrencyPair = CurrencyPair.EURUSD,
    val tf: Timeframe = Timeframe.H1,
    val series: CandleSeries? = null,
    val seriesStatus: DataStatus? = null,
    val quote: Quote? = null,
    val quoteStatus: DataStatus? = null,
    val loading: Boolean = true,
    val error: String? = null
)

class MarketsViewModel(private val app: TradewiseApp) : ViewModel() {
    private val _ui = MutableStateFlow(MarketsUi(app.settings.current.defaultPair, app.settings.current.defaultTimeframe))
    val ui: StateFlow<MarketsUi> = _ui.asStateFlow()
    private var job: Job? = null

    init { load(false) }

    fun setPair(p: CurrencyPair) { _ui.update { it.copy(pair = p, series = null, quote = null) }; load(false) }
    fun setTf(t: Timeframe) { _ui.update { it.copy(tf = t, series = null) }; load(false) }

    fun load(force: Boolean) {
        job?.cancel()
        val (pair, tf) = _ui.value.pair to _ui.value.tf
        _ui.update { it.copy(loading = true, error = null) }
        job = viewModelScope.launch {
            val s = app.market.candles(pair, tf, 300, force)
            val q = app.market.quote(pair, force)
            _ui.update {
                if (it.pair != pair || it.tf != tf) it
                else it.copy(
                    loading = false,
                    series = s.getOrNull(), seriesStatus = s.getOrNull()?.let(app.market::statusOf),
                    quote = q.getOrNull(), quoteStatus = q.getOrNull()?.let(app.market::statusOf),
                    error = if (s.isFailure) (s.exceptionOrNull()?.message ?: "Could not load candles.") else null
                )
            }
        }
    }
}

@Composable
fun MarketsScreen() {
    val app = com.tradewiseai.app.core.util.rememberApp()
    val vm = appViewModel { MarketsViewModel(it) }
    val ui by vm.ui.collectAsState()
    val alerts by app.alerts.alerts.collectAsState()
    var addAlert by remember { mutableStateOf(false) }
    var target by remember { mutableStateOf("") }
    var above by remember { mutableStateOf(true) }
    var alertErr by remember { mutableStateOf<String?>(null) }
    val ctx = androidx.compose.ui.platform.LocalContext.current

    ScreenColumn {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("Markets", style = TwType.display, modifier = Modifier.weight(1f))
            GhostButton("", { vm.load(true) }, icon = Icons.Default.Refresh)
        }
        ChipRow(CurrencyPair.values().map { it.symbol }, ui.pair.symbol, { s -> CurrencyPair.fromSymbol(s)?.let(vm::setPair) })
        ChipRow(Timeframe.values().map { it.label }, ui.tf.label, { l -> vm.setTf(Timeframe.fromLabel(l)) })
        app.market.demoReason?.let { Banner("DEMO DATA: $it") }

        TwCard {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(ui.pair.symbol, style = TwType.heading)
                    Text(ui.quote?.let { "Quote ${Fmt.clockEat(it.timestampSec)}" } ?: "No quote", style = TwType.small)
                }
                Column(horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(ui.quote?.let { Fmt.price(ui.pair, it.price) } ?: "-", style = TwType.price)
                    (ui.quoteStatus ?: ui.seriesStatus)?.let { StatusChip(it) }
                }
            }
        }

        when {
            ui.loading && ui.series == null -> TwCard { Shimmer(Modifier.fillMaxWidth(), 220.dp); Shimmer(Modifier.fillMaxWidth(), 60.dp) }
            ui.series != null -> {
                val series = ui.series!!
                // chart only ever shows CLOSED candles so the picture matches what the engine analyses
                val closed = SetupEngine.closedOnly(series.candles, series.timeframe, System.currentTimeMillis() / 1000)
                val levels = remember(closed) {
                    val atr = Indicators.atr(closed, 14).lastOrNull { it != null } ?: 0.0
                    Indicators.levels(closed, atr * 0.5)
                }
                val lastClose = closed.last().close
                val data = remember(closed) { ChartData.from(closed, levels.filter { it.price < lastClose }, levels.filter { it.price > lastClose }) }
                Appear { TwCard {
                    CandleChart(data)
                    Text("RSI 14", style = TwType.label)
                    RsiChart(data.rsi)
                    Text("MACD histogram", style = TwType.label)
                    MacdChart(data.macdHist)
                    Text("Drag the chart sideways to look back. Dashed lines: green support, red resistance.", style = TwType.small)
                } }
                val last = closed.lastOrNull()
                if (last != null) TwCard {
                    KeyValue("Last closed candle", Fmt.timeEat(last.time))
                    KeyValue("Provider", series.provider)
                    KeyValue("Candles loaded", "${closed.size}")
                }
            }
            else -> Banner(ui.error ?: "No data.", TW.red)
        }
        ui.error?.let { if (ui.series != null) Banner(it, TW.amber) }

        SectionTitle("Price alerts")
        TwCard {
            Text("Checked in the background about every 15 minutes (Android's minimum). Not instant: don't rely on them for fast moves.", style = TwType.small)
            val mine = alerts.filter { it.pair == ui.pair }
            if (mine.isEmpty()) Text("No alerts for ${ui.pair.symbol}.", style = TwType.small)
            mine.forEach { a ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${if (a.above) "Above" else "Below"} ${Fmt.price(a.pair, a.target)}${if (a.triggeredMs != null) "  (triggered)" else ""}",
                        style = TwType.body, modifier = Modifier.weight(1f))
                    GhostButton("", { app.alerts.remove(a.id); AlertScheduler.sync(ctx, app.settings.current) }, icon = Icons.Default.Delete, color = TW.red)
                }
            }
            if (addAlert) {
                TwField(target, { target = it; alertErr = null }, "Target price", numeric = true, error = alertErr != null)
                alertErr?.let { Text(it, style = TwType.small.copy(color = TW.red)) }
                ChipRow(listOf("Price rises above", "Price falls below"), if (above) "Price rises above" else "Price falls below", { above = it.contains("above") })
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton("Save alert", {
                        val v = target.toDoubleOrNullLoose()
                        val cur = ui.quote?.price
                        when {
                            v == null || v <= 0 -> alertErr = "Enter a valid price."
                            cur != null && kotlin.math.abs(v - cur) / cur > 0.2 -> alertErr = "That is more than 20% away from the current price. Check for a typo."
                            else -> {
                                app.alerts.add(ui.pair, v, above)
                                AlertScheduler.sync(ctx, app.settings.current)
                                target = ""; addAlert = false
                            }
                        }
                    })
                    GhostButton("Cancel", { addAlert = false; alertErr = null })
                }
            } else GhostButton("Add alert", { addAlert = true; target = ui.quote?.let { Fmt.price(ui.pair, it.price) } ?: "" }, icon = Icons.Default.Add)
            if (!app.settings.current.notifyPrice) Text("Price alert notifications are switched off in Settings.", style = TwType.small.copy(color = TW.amber))
        }
    }
}
