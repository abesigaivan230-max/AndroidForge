package com.tradewiseai.app.overlay

enum class OverlayMode(val label: String, val description: String) {
    BUBBLE("Floating bubble", "A small draggable icon. Tap to expand."),
    SIDE_PANEL("Side panel", "A narrow panel that stays beside your trading app."),
    EXPANDED("Expanded panel", "Full analysis: levels, reasoning and beginner explanation.");

    companion object {
        fun fromName(n: String?): OverlayMode = values().firstOrNull { it.name == n } ?: BUBBLE
    }
}
