package com.tradewiseai.app.capture

import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import com.tradewiseai.app.notifications.Notifier

/**
 * Takes exactly ONE screenshot with the projection the user just approved, then stops itself.
 * Android 14 rules: the foreground service (type mediaProjection) must be running before getMediaProjection(),
 * and a MediaProjection callback must be registered before createVirtualDisplay().
 */
class ScreenCaptureService : Service() {

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var finished = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_CODE, 0) ?: 0
        val data = intent?.let { IntentCompat.getParcelableExtra(it, EXTRA_DATA, Intent::class.java) }
        if (data == null || code == 0) {
            fail("Capture permission data was missing.")
            return START_NOT_STICKY
        }
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        try {
            ServiceCompat.startForeground(this, Notifier.ID_CAPTURE, Notifier.captureNotification(this), type)
        } catch (e: Exception) {
            fail("Android would not start the capture service: ${e.message}")
            return START_NOT_STICKY
        }
        CaptureBus.hideOverlay.value = true       // hide our own bubble for the shot
        thread = HandlerThread("tw-capture").also { it.start() }
        handler = Handler(thread!!.looper)
        // give the overlay a moment to disappear and the consent dialog to fully close
        main.postDelayed({ startCapture(code, data) }, 450)
        main.postDelayed({ if (!finished) fail("Timed out waiting for a frame. Use the share option instead.") }, 6000)
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        if (finished) return
        try {
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val p = mpm.getMediaProjection(code, data)
            if (p == null) { fail("Could not obtain the projection."); return }
            projection = p
            p.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { release() }
            }, handler)

            val (w, h, dpi) = realScreen()
            val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
            reader = r
            r.setOnImageAvailableListener({ rd ->
                if (finished) return@setOnImageAvailableListener
                val maybeImg = try { rd.acquireLatestImage() } catch (_: Exception) { null }
                val img = maybeImg ?: return@setOnImageAvailableListener
                try {
                    val plane = img.planes[0]
                    val rowPadding = plane.rowStride - plane.pixelStride * w
                    val wide = Bitmap.createBitmap(w + rowPadding / plane.pixelStride, h, Bitmap.Config.ARGB_8888)
                    wide.copyPixelsFromBuffer(plane.buffer)
                    val bmp = Bitmap.createBitmap(wide, 0, 0, w, h)
                    val prepared = ImageTools.prepare(bmp)
                    if (ImageTools.isBlank(prepared)) {
                        fail("The capture came out blank. The app you are viewing probably blocks screenshots, so use the share option instead.")
                    } else {
                        val f = ImageTools.save(this, prepared)
                        finished = true
                        CaptureBus.events.tryEmit(CaptureEvent.Success(f.absolutePath))
                        shutdown()
                    }
                } catch (e: Exception) {
                    fail("Capture failed: ${e.message}")
                } finally {
                    img.close()
                }
            }, handler)
            display = p.createVirtualDisplay("tw-capture", w, h, dpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, r.surface, null, handler)
        } catch (e: SecurityException) {
            fail("Android refused the capture permission: ${e.message}")
        } catch (e: Exception) {
            fail("Capture failed: ${e.message}")
        }
    }

    private fun realScreen(): Triple<Int, Int, Int> {
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val dpi = resources.displayMetrics.densityDpi
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            Triple(b.width(), b.height(), dpi)
        } else {
            @Suppress("DEPRECATION")
            val m = android.util.DisplayMetrics().also { wm.defaultDisplay.getRealMetrics(it) }
            Triple(m.widthPixels, m.heightPixels, dpi)
        }
    }

    private fun fail(message: String) {
        if (finished) return
        finished = true
        CaptureBus.events.tryEmit(CaptureEvent.Failed(message))
        shutdown()
    }

    private fun shutdown() {
        main.post {
            release()
            CaptureBus.hideOverlay.value = false
            ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
    }

    private fun release() {
        try { display?.release() } catch (_: Exception) {}
        try { reader?.setOnImageAvailableListener(null, null); reader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        display = null; reader = null; projection = null
        thread?.quitSafely(); thread = null
    }

    override fun onDestroy() {
        main.removeCallbacksAndMessages(null)
        release()
        CaptureBus.hideOverlay.value = false
        super.onDestroy()
    }

    companion object {
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        /** Opens the system consent dialog. Called only from an explicit user tap. */
        fun requestCapture(context: Context) {
            context.startActivity(Intent(context, CaptureConsentActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        }
    }
}
