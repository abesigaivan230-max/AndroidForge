package com.tradewiseai.app.core.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradewiseai.app.data.preferences.ThemeVariant

/** Background and surfaces change with the theme variant; semantic colours stay fixed so green always means bullish. */
data class Palette(val bg: Color, val surface: Color, val surfaceHi: Color, val border: Color)

val MidnightPalette = Palette(Color(0xFF0A1224), Color(0xFF111C36), Color(0xFF17264A), Color(0xFF22345F))
val AmoledPalette = Palette(Color(0xFF000000), Color(0xFF0B0F1A), Color(0xFF111827), Color(0xFF1C2740))

val LocalPalette = compositionLocalOf { MidnightPalette }

object TW {
    val bg: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.bg
    val surface: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.surface
    val surfaceHi: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.surfaceHi
    val border: Color @Composable @ReadOnlyComposable get() = LocalPalette.current.border

    val blue = Color(0xFF2F7BFF)
    val blueSoft = Color(0xFF6FA3FF)
    val green = Color(0xFF12D98A)
    val red = Color(0xFFFF3B5C)
    val amber = Color(0xFFFFB020)
    val text = Color(0xFFF2F6FF)
    val muted = Color(0xFF8FA0C4)
    val faint = Color(0xFF5B6B90)

    val accentBrush = Brush.linearGradient(listOf(Color(0xFF2F7BFF), Color(0xFF5B5BFF)))
    val greenBrush = Brush.linearGradient(listOf(Color(0xFF12D98A), Color(0xFF0FA3A3)))
    val redBrush = Brush.linearGradient(listOf(Color(0xFFFF3B5C), Color(0xFFD62A6B)))
    val amberBrush = Brush.linearGradient(listOf(Color(0xFFFFB020), Color(0xFFFF7A1A)))
}

object Space {
    val xs = 4.dp
    val sm = 8.dp
    val md = 12.dp
    val lg = 16.dp
    val xl = 24.dp
}

object TwType {
    val display = TextStyle(fontSize = 28.sp, fontWeight = FontWeight.Bold, color = TW.text, letterSpacing = (-0.5).sp)
    val title = TextStyle(fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = TW.text)
    val heading = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = TW.text)
    val body = TextStyle(fontSize = 14.sp, color = TW.text, lineHeight = 20.sp)
    val small = TextStyle(fontSize = 12.sp, color = TW.muted, lineHeight = 16.sp)
    val label = TextStyle(fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = TW.muted, letterSpacing = 0.8.sp)
    val price = TextStyle(fontSize = 30.sp, fontWeight = FontWeight.Bold, color = TW.text, fontFamily = FontFamily.Monospace)
    val mono = TextStyle(fontSize = 13.sp, color = TW.text, fontFamily = FontFamily.Monospace)
}

@Composable
fun TradewiseTheme(variant: ThemeVariant, content: @Composable () -> Unit) {
    val palette = if (variant == ThemeVariant.AMOLED) AmoledPalette else MidnightPalette
    val scheme = darkColorScheme(
        primary = TW.blue, onPrimary = Color.White,
        secondary = TW.blueSoft, background = palette.bg, onBackground = TW.text,
        surface = palette.surface, onSurface = TW.text, surfaceVariant = palette.surfaceHi,
        onSurfaceVariant = TW.muted, outline = palette.border, error = TW.red
    )
    CompositionLocalProvider(LocalPalette provides palette) {
        MaterialTheme(colorScheme = scheme) { content() }
    }
}
