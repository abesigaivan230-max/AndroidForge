package com.tradewiseai.app.data.remote

import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.CandleSeries
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.DataOrigin
import com.tradewiseai.app.domain.model.Quote
import com.tradewiseai.app.domain.model.Timeframe
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Real data. The app NEVER calls the data vendor directly: it calls our Supabase Edge Function
 * (`market-data`), which holds the vendor API key, caches responses and enforces rate limits.
 */
class BackendMarketProvider(
    private val http: SupabaseHttp,
    private val tokenProvider: suspend () -> String?
) : MarketDataProvider {

    override val name = "Twelve Data via TRADEWISE backend"
    val configured: Boolean get() = http.configured

    override fun getAvailablePairs() = CurrencyPair.values().toList()

    override suspend fun getLatestQuote(pair: CurrencyPair): Result<Quote> = runCatching {
        val o = call(JSONObject().put("mode", "price").put("symbol", pair.symbol))
        val price = o.optDouble("price", Double.NaN)
        if (price.isNaN() || price <= 0) throw ApiException("Backend returned no valid price.")
        val ts = o.optLong("ts", System.currentTimeMillis() / 1000)
        Quote(pair, price, ts, if (o.optBoolean("cached", false)) DataOrigin.CACHED else DataOrigin.LIVE, o.optString("provider", "twelvedata"))
    }

    override suspend fun getHistoricalCandles(pair: CurrencyPair, timeframe: Timeframe, count: Int): Result<CandleSeries> = runCatching {
        val o = call(JSONObject().put("mode", "candles").put("symbol", pair.symbol)
            .put("interval", timeframe.apiInterval).put("outputsize", count.coerceIn(30, 600)))
        val arr = o.optJSONArray("candles") ?: throw ApiException("Backend returned no candles.")
        val list = ArrayList<Candle>(arr.length())
        for (i in 0 until arr.length()) {
            val c = arr.getJSONObject(i)
            val cd = Candle(c.getLong("t"), c.getDouble("o"), c.getDouble("h"), c.getDouble("l"), c.getDouble("c"), c.optDouble("v", 0.0))
            // reject malformed candles instead of charting garbage
            if (cd.high >= cd.low && cd.high >= max(cd.open, cd.close) - 1e-12 && cd.low <= min(cd.open, cd.close) + 1e-12 && cd.close > 0) list += cd
        }
        val sorted = list.sortedBy { it.time }.distinctBy { it.time }
        if (sorted.size < 10) throw ApiException("Too few valid candles returned (${sorted.size}).")
        val cached = o.optBoolean("cached", false)
        CandleSeries(pair, timeframe, sorted, if (cached) DataOrigin.CACHED else DataOrigin.LIVE,
            o.optString("provider", "twelvedata"), o.optLong("fetched_at", System.currentTimeMillis()))
    }

    override suspend fun getProviderStatus(): ProviderStatus {
        if (!http.configured) return ProviderStatus(name, false, null, "Backend not configured: add SUPABASE_URL and SUPABASE_ANON_KEY to local.properties.")
        return try {
            val o = call(JSONObject().put("mode", "status"))
            if (o.optBoolean("configured", false)) ProviderStatus(name, true, true, "Reachable. Vendor key is set on the server.")
            else ProviderStatus(name, true, true, "Backend reachable but TWELVEDATA_API_KEY is not set on the server.")
        } catch (e: Exception) {
            ProviderStatus(name, true, false, e.message ?: "Unreachable.")
        }
    }

    private suspend fun call(body: JSONObject): JSONObject {
        val o = http.postJson("/functions/v1/market-data", body, tokenProvider())
        if (o.optString("status") == "error") throw ApiException(o.optString("message", "Market data error."))
        return o
    }
}
