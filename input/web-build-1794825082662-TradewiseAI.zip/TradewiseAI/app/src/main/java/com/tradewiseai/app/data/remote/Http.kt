package com.tradewiseai.app.data.remote

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

class ApiException(message: String, val httpCode: Int = 0, val retryable: Boolean = false) : Exception(message)

fun newHttpClient(): OkHttpClient = OkHttpClient.Builder()
    .connectTimeout(12, TimeUnit.SECONDS)
    .readTimeout(45, TimeUnit.SECONDS)   // AI calls can take a while
    .writeTimeout(30, TimeUnit.SECONDS)
    .build()

/** Talks to the Supabase project (Edge Functions + PostgREST + Auth). Only the PUBLIC anon key is ever used here. */
class SupabaseHttp(
    private val client: OkHttpClient,
    val baseUrl: String,
    val anonKey: String
) {
    val configured: Boolean get() = baseUrl.startsWith("https://") && anonKey.isNotBlank()

    private val json = "application/json; charset=utf-8".toMediaType()

    private fun builder(path: String, bearer: String?): Request.Builder {
        if (!configured) throw ApiException("Cloud backend is not configured (SUPABASE_URL / SUPABASE_ANON_KEY).")
        return Request.Builder()
            .url(baseUrl.trimEnd('/') + path)
            .header("apikey", anonKey)
            .header("Authorization", "Bearer ${bearer ?: anonKey}")
    }

    /** POST JSON and parse a JSON object reply. Retries only transient failures with exponential backoff. */
    suspend fun postJson(path: String, body: JSONObject, bearer: String?, retries: Int = 2, extraHeaders: Map<String, String> = emptyMap()): JSONObject =
        withContext(Dispatchers.IO) {
            var last: ApiException? = null
            for (attempt in 0..retries) {
                try {
                    val rb = builder(path, bearer).post(body.toString().toRequestBody(json))
                    extraHeaders.forEach { (k, v) -> rb.header(k, v) }
                    return@withContext execute(rb.build())
                } catch (e: ApiException) {
                    if (!e.retryable) throw e
                    last = e
                } catch (e: IOException) {
                    last = ApiException("Network error: ${e.message ?: "no connection"}", 0, true)
                }
                if (attempt < retries) delay(600L * (1 shl attempt))
            }
            throw (last ?: ApiException("Request failed."))
        }

    /** PostgREST upsert: POST an array with `Prefer: resolution=merge-duplicates`. An empty body on success is fine. */
    suspend fun postJsonArray(path: String, rows: JSONArray, bearer: String?): Unit = withContext(Dispatchers.IO) {
        val req = builder(path, bearer)
            .header("Prefer", "resolution=merge-duplicates,return=minimal")
            .post(rows.toString().toRequestBody(json)).build()
        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw ApiException(errorMessage(resp.body?.string().orEmpty(), resp.code), resp.code, resp.code >= 500)
            }
        } catch (e: IOException) {
            throw ApiException("Network error: ${e.message ?: "no connection"}", 0, true)
        }
    }

    suspend fun getJsonArray(path: String, bearer: String?): JSONArray = withContext(Dispatchers.IO) {
        val req = builder(path, bearer).get().build()
        try {
            client.newCall(req).execute().use { resp ->
                val text = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) throw ApiException(errorMessage(text, resp.code), resp.code, resp.code >= 500)
                try { JSONArray(text) } catch (e: JSONException) { throw ApiException("Unexpected server reply.") }
            }
        } catch (e: IOException) {
            throw ApiException("Network error: ${e.message ?: "no connection"}", 0, true)
        }
    }

    suspend fun delete(path: String, bearer: String?): Unit = withContext(Dispatchers.IO) {
        val req = builder(path, bearer).delete().build()
        try {
            client.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) throw ApiException(errorMessage(resp.body?.string().orEmpty(), resp.code), resp.code)
            }
        } catch (e: IOException) {
            throw ApiException("Network error: ${e.message ?: "no connection"}", 0, true)
        }
    }

    private fun execute(req: Request): JSONObject {
        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw ApiException(errorMessage(text, resp.code), resp.code, retryable = resp.code >= 500)
            }
            if (text.isBlank()) return JSONObject()
            return try { JSONObject(text) } catch (e: JSONException) { throw ApiException("Unexpected server reply.") }
        }
    }

    private fun errorMessage(text: String, code: Int): String {
        val fromJson = try {
            val o = JSONObject(text)
            o.optString("message").ifBlank { o.optString("error_description") }.ifBlank { o.optString("msg") }.ifBlank { o.optString("error") }
        } catch (e: Exception) { "" }
        return when {
            fromJson.isNotBlank() -> fromJson
            code == 401 || code == 403 -> "Not authorised. Sign in again."
            code == 429 -> "Rate limit reached. Try again in a minute."
            code >= 500 -> "Server error ($code). Try again shortly."
            else -> "Request failed ($code)."
        }
    }
}
