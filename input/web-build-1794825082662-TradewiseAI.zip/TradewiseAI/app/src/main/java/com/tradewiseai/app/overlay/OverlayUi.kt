package com.tradewiseai.app.overlay

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.OpenInFull
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ShowChart
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TradewiseTheme
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.core.util.Fmt
import com.tradewiseai.app.data.preferences.SettingsStore
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Decision
import com.tradewiseai.app.ui.components.Banner
import com.tradewiseai.app.ui.components.ChipRow
import com.tradewiseai.app.ui.components.DecisionBadge
import com.tradewiseai.app.ui.components.GhostButton
import com.tradewiseai.app.ui.components.KeyValue
import com.tradewiseai.app.ui.components.PrimaryButton
import com.tradewiseai.app.ui.components.Spinner
import com.tradewiseai.app.ui.components.StatusChip

@Composable
fun OverlayContent(model: OverlayModel, settings: SettingsStore, host: OverlayHost) {
    val s by settings.state.collectAsState()
    val ui by model.ui.collectAsState()
    TradewiseTheme(s.theme) {
        AnimatedContent(
            targetState = s.overlayMode,
            transitionSpec = {
                (fadeIn(tween(220)) + scaleIn(initialScale = 0.85f, animationSpec = spring(Spring.DampingRatioLowBouncy))) togetherWith
                    (fadeOut(tween(120)) + scaleOut(targetScale = 0.9f))
            },
            label = "overlayMode"
        ) { mode ->
            when (mode) {
                OverlayMode.BUBBLE -> Bubble(ui, onTap = { host.setMode(OverlayMode.SIDE_PANEL) })
                OverlayMode.SIDE_PANEL -> SidePanel(ui, model, host, s.panelWidthDp) { w -> settings.update { it.copy(panelWidthDp = w.coerceIn(180, 320)) } }
                OverlayMode.EXPANDED -> ExpandedPanel(ui, model, host)
            }
        }
    }
}

@Composable
private fun Bubble(ui: OverlayUi, onTap: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val glow by pulse.animateFloat(0.25f, 0.7f, infiniteRepeatable(tween(1600), RepeatMode.Reverse), label = "glow")
    val tint = ui.outcome?.result?.decision?.let {
        when (it) { Decision.BUY_SETUP -> TW.green; Decision.SELL_SETUP -> TW.red; Decision.WAIT -> TW.amber }
    } ?: TW.blue
    Box(
        Modifier.padding(6.dp).size(54.dp)
            .shadow(10.dp, CircleShape, ambientColor = tint, spotColor = tint)
            .clip(CircleShape).background(TW.accentBrush)
            .border(2.dp, tint.copy(alpha = glow), CircleShape)
            .clickable(onClick = onTap),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Default.ShowChart, "Open TRADEWISE assistant", tint = Color.White, modifier = Modifier.size(26.dp)) }
}

@Composable
private fun PanelFrame(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(
        modifier.padding(4.dp)
            .shadow(14.dp, RoundedCornerShape(22.dp))
            .clip(RoundedCornerShape(22.dp))
            .background(Brush.verticalGradient(listOf(TW.surfaceHi, TW.bg)))
            .border(1.dp, TW.border, RoundedCornerShape(22.dp))
            .animateContentSize(spring(Spring.DampingRatioNoBouncy, Spring.StiffnessMedium))
    ) { content() }
}

@Composable
private fun IconBtn(icon: androidx.compose.ui.graphics.vector.ImageVector, desc: String, tint: Color = TW.muted, onClick: () -> Unit) {
    Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(18.dp))
    }
}

@Composable
private fun DragHeader(title: String, host: OverlayHost, actions: @Composable () -> Unit) {
    // The whole header row is the drag handle (OverlayRoot intercepts drags that start in the top 52dp).
    Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(title, style = TwType.heading.copy(fontSize = 14.sp), modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        actions()
        IconBtn(Icons.Default.Close, "Minimise to bubble") { host.setMode(OverlayMode.BUBBLE) }
        IconBtn(Icons.Default.Stop, "Stop assistant", TW.red) { host.stopAssistant() }
    }
}

@Composable
private fun PriceRow(ui: OverlayUi) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Text(ui.quote?.let { Fmt.price(ui.pair, it.price) } ?: "…", style = TwType.mono.copy(fontSize = 20.sp, fontWeight = FontWeight.Bold))
        ui.quoteStatus?.let { StatusChip(it) }
    }
}

@Composable
private fun DecisionBlock(ui: OverlayUi, compact: Boolean) {
    val r = ui.outcome?.result
    if (r == null) {
        Text("Tap Analyse for a rules-based read.", style = TwType.small)
        return
    }
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            DecisionBadge(r.decision)
            Text("${r.passedCount}/${r.checks.size} rules", style = TwType.small)
        }
        if (ui.outcome?.isDemo == true) Text("DEMO DATA - not a real market", style = TwType.small.copy(color = TW.amber, fontWeight = FontWeight.SemiBold))
        val line = ui.explanation?.summary ?: r.ruleSummary
        Text(line, style = TwType.small, maxLines = if (compact) 4 else 8, overflow = TextOverflow.Ellipsis)
        if (!compact && r.decision != Decision.WAIT) {
            KeyValue("Entry zone", "${Fmt.price(r.pair, r.entryZoneLow)} - ${Fmt.price(r.pair, r.entryZoneHigh)}")
            KeyValue("Stop-loss", Fmt.price(r.pair, r.stopLoss), TW.red)
            r.targets.firstOrNull()?.let { KeyValue(it.label, Fmt.price(r.pair, it.price), TW.green) }
            r.riskReward?.let { KeyValue("Risk : reward", "1 : ${"%.2f".format(it)}") }
        }
    }
}

@Composable
private fun SidePanel(ui: OverlayUi, model: OverlayModel, host: OverlayHost, widthDp: Int, onResize: (Int) -> Unit) {
    PanelFrame {
        Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
            DragHeader("TRADEWISE", host) {
                IconBtn(Icons.Default.Remove, "Narrower") { onResize(widthDp - 20) }
                IconBtn(Icons.Default.Add, "Wider") { onResize(widthDp + 20) }
                IconBtn(Icons.Default.OpenInFull, "Expand") { host.setMode(OverlayMode.EXPANDED) }
            }
            Column(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ChipRow(CurrencyPair.values().map { it.symbol }, ui.pair.symbol, { sym -> CurrencyPair.fromSymbol(sym)?.let(model::selectPair) })
                PriceRow(ui)
                PrimaryButton(if (ui.loading) "Analysing" else "Analyse", model::analyse, Modifier.fillMaxWidth(), Icons.Default.ShowChart, loading = ui.loading)
                ui.error?.let { Text(it, style = TwType.small.copy(color = TW.red)) }
                DecisionBlock(ui, compact = true)
                GhostButton("Screenshot", model::capture, Modifier.fillMaxWidth(), Icons.Default.CameraAlt)
                ShotBlock(ui, model)
                GhostButton("Open app", model::openApp, Modifier.fillMaxWidth())
            }
        }
    }
}

@Composable
private fun ExpandedPanel(ui: OverlayUi, model: OverlayModel, host: OverlayHost) {
    var q by remember { mutableStateOf("") }
    PanelFrame {
        Column(Modifier.fillMaxWidth().heightIn(max = 560.dp).padding(bottom = 10.dp)) {
            DragHeader("TRADEWISE assistant", host) {
                IconBtn(Icons.Default.Remove, "Side panel") { host.setMode(OverlayMode.SIDE_PANEL) }
            }
            Column(
                Modifier.weight(1f, fill = false).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ChipRow(CurrencyPair.values().map { it.symbol }, ui.pair.symbol, { sym -> CurrencyPair.fromSymbol(sym)?.let(model::selectPair) })
                PriceRow(ui)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PrimaryButton(if (ui.loading) "Analysing" else "Analyse", model::analyse, Modifier.weight(1f), Icons.Default.ShowChart, loading = ui.loading)
                    GhostButton("Screenshot", model::capture, icon = Icons.Default.CameraAlt)
                }
                ui.error?.let { Banner(it, TW.red) }
                DecisionBlock(ui, compact = false)
                ui.explanation?.let { ex ->
                    if (ex.whySetupOrNot.isNotBlank()) Text(ex.whySetupOrNot, style = TwType.small)
                    ex.risks.take(2).forEach { Text("• $it", style = TwType.small) }
                }
                AnimatedVisibility(ui.answer != null, enter = fadeIn() + slideInVertically { it / 4 }) {
                    Text(ui.answer ?: "", style = TwType.body, modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(TW.surface).padding(10.dp).fillMaxWidth())
                }
                ShotBlock(ui, model)
                GhostButton("Open full app", model::openApp, Modifier.fillMaxWidth())
                Text("Educational analysis. Not financial advice. No orders are ever placed.", style = TwType.small.copy(fontSize = 10.sp, color = TW.faint))
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextField(
                    value = q, onValueChange = { q = it },
                    placeholder = { Text("Ask about this setup…", fontSize = 13.sp) },
                    singleLine = true,
                    modifier = Modifier.weight(1f).onFocusChanged { host.setFocusable(it.isFocused) },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                    keyboardActions = KeyboardActions(onSend = { if (q.isNotBlank()) { model.ask(q); q = "" } }),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = TW.surface, unfocusedContainerColor = TW.surface,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                        focusedTextColor = TW.text, unfocusedTextColor = TW.text
                    ),
                    shape = RoundedCornerShape(14.dp)
                )
                Box(Modifier.padding(start = 6.dp)) {
                    if (ui.asking) Spinner() else IconBtn(Icons.Default.Send, "Send", TW.blueSoft) { if (q.isNotBlank()) { model.ask(q); q = "" } }
                }
            }
        }
    }
}

@Composable
private fun ShotBlock(ui: OverlayUi, model: OverlayModel) {
    when (val s = ui.shot) {
        ShotUi.Idle -> {}
        is ShotUi.Captured -> Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Screenshot captured (kept on this phone only).", style = TwType.small)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                PrimaryButton("Analyse", model::analyseShot, Modifier.weight(1f))
                GhostButton("", model::deleteShot, icon = Icons.Default.Delete, color = TW.red)
            }
            GhostButton("View in app", model::openShotInApp, Modifier.fillMaxWidth())
        }
        is ShotUi.Analysing -> Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Spinner(); Text("Reading the screenshot…", style = TwType.small)
        }
        is ShotUi.Result -> Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            val a = s.report.analysis
            if (!a.readable) Banner(a.unreadableReason.ifBlank { "The screenshot was not readable." }, TW.amber)
            else {
                Text("Pair: ${a.pair.value ?: "unclear"}  |  TF: ${a.timeframe.value ?: "unclear"}", style = TwType.small)
                Text(a.structure.ifBlank { "Structure unclear." }, style = TwType.small)
                Text(s.report.comparison.message, style = TwType.small.copy(color = TW.amber))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                GhostButton("Full result", model::openShotInApp, Modifier.weight(1f))
                GhostButton("", model::deleteShot, icon = Icons.Default.Delete, color = TW.red)
            }
        }
        is ShotUi.Error -> Banner(s.message, TW.red)
    }
}
