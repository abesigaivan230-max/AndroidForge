package com.tradewiseai.app.capture

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.UUID

/** Image validation and import. Screenshots stay in app-private cache until the user deletes them. */
object ImageTools {
    const val MAX_SIDE = 1600
    const val MIN_SIDE = 300

    fun shotsDir(context: Context): File = File(context.cacheDir, "shots").apply { mkdirs() }

    /** Copies a picked/shared image into private storage as a downscaled JPEG, validating it on the way. */
    suspend fun importUri(context: Context, uri: Uri): Result<File> = withContext(Dispatchers.IO) {
        runCatching {
            val resolver = context.contentResolver
            val mime = resolver.getType(uri)
            if (mime != null && !mime.startsWith("image/")) error("That file is not an image.")

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: error("Could not open the image.")
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) error("The file could not be read as an image.")
            if (minOf(bounds.outWidth, bounds.outHeight) < MIN_SIDE) error("Image is too small to read a chart from. Use a larger screenshot.")

            var sample = 1
            while (maxOf(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE * 2) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val raw = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: error("Could not decode the image.")

            val rotation = try {
                resolver.openInputStream(uri)?.use { ExifInterface(it).rotationDegrees } ?: 0
            } catch (_: Exception) { 0 }
            val bmp = prepare(raw, rotation)
            if (isBlank(bmp)) error("The image looks completely blank. Pick the screenshot again.")
            save(context, bmp)
        }
    }

    fun prepare(src: Bitmap, rotationDeg: Int = 0): Bitmap {
        var b = src
        if (rotationDeg != 0) {
            val m = Matrix().apply { postRotate(rotationDeg.toFloat()) }
            b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
        }
        val longest = maxOf(b.width, b.height)
        if (longest > MAX_SIDE) {
            val f = MAX_SIDE.toFloat() / longest
            b = Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
        }
        return b
    }

    fun save(context: Context, bmp: Bitmap): File {
        val f = File(shotsDir(context), "shot_${UUID.randomUUID()}.jpg")
        f.outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 88, it) }
        return f
    }

    /**
     * True when (almost) every sampled pixel is black. Apps that set FLAG_SECURE come out of MediaProjection
     * as a black frame, so this is how we tell the user to use the share method instead.
     */
    fun isBlank(bmp: Bitmap): Boolean {
        val stepX = maxOf(1, bmp.width / 24)
        val stepY = maxOf(1, bmp.height / 24)
        var samples = 0
        var bright = 0
        var x = 0
        while (x < bmp.width) {
            var y = 0
            while (y < bmp.height) {
                val p = bmp.getPixel(x, y)
                val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
                samples++
                if (r + g + b > 24) bright++
                y += stepY
            }
            x += stepX
        }
        return samples > 0 && bright.toDouble() / samples < 0.01
    }

    fun deleteAll(context: Context): Int {
        var n = 0
        shotsDir(context).listFiles()?.forEach { if (it.delete()) n++ }
        return n
    }

    fun count(context: Context): Int = shotsDir(context).listFiles()?.size ?: 0
}
