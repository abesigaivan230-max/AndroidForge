package com.tradewiseai.app.domain.indicators

import com.tradewiseai.app.domain.model.Candle
import com.tradewiseai.app.domain.model.Structure
import com.tradewiseai.app.domain.model.Trend
import kotlin.math.abs
import kotlin.math.max

data class MacdResult(
    val macd: List<Double?>,
    val signal: List<Double?>,
    val histogram: List<Double?>
)

data class Level(val price: Double, val touches: Int)

data class TrendInfo(val trend: Trend, val structure: Structure, val detail: String)

/**
 * Deterministic indicator maths. No AI, no network. All lists are index-aligned with the input
 * and hold null while the indicator has not warmed up.
 */
object Indicators {

    /** Simple average of the last [period] values; null when there are not enough values. */
    fun sma(values: List<Double>, period: Int): Double? {
        if (period <= 0 || values.size < period) return null
        return values.takeLast(period).average()
    }

    /** EMA seeded with the SMA of the first [period] values, then k = 2 / (period + 1). */
    fun ema(values: List<Double>, period: Int): List<Double?> {
        val out = MutableList<Double?>(values.size) { null }
        if (period <= 0 || values.size < period) return out
        var prev = values.take(period).average()
        out[period - 1] = prev
        val k = 2.0 / (period + 1)
        for (i in period until values.size) {
            prev = values[i] * k + prev * (1 - k)
            out[i] = prev
        }
        return out
    }

    /** Wilder RSI. First value appears at index [period]. */
    fun rsi(closes: List<Double>, period: Int = 14): List<Double?> {
        val out = MutableList<Double?>(closes.size) { null }
        if (closes.size <= period) return out
        var gain = 0.0
        var loss = 0.0
        for (i in 1..period) {
            val d = closes[i] - closes[i - 1]
            if (d >= 0) gain += d else loss -= d
        }
        var avgGain = gain / period
        var avgLoss = loss / period
        out[period] = rsiValue(avgGain, avgLoss)
        for (i in period + 1 until closes.size) {
            val d = closes[i] - closes[i - 1]
            val g = if (d > 0) d else 0.0
            val l = if (d < 0) -d else 0.0
            avgGain = (avgGain * (period - 1) + g) / period
            avgLoss = (avgLoss * (period - 1) + l) / period
            out[i] = rsiValue(avgGain, avgLoss)
        }
        return out
    }

    private fun rsiValue(avgGain: Double, avgLoss: Double): Double = when {
        avgLoss == 0.0 && avgGain == 0.0 -> 50.0
        avgLoss == 0.0 -> 100.0
        else -> 100.0 - 100.0 / (1.0 + avgGain / avgLoss)
    }

    /** MACD line = EMA(fast) - EMA(slow); signal = EMA of the MACD line; histogram = MACD - signal. */
    fun macd(closes: List<Double>, fast: Int = 12, slow: Int = 26, signalPeriod: Int = 9): MacdResult {
        val n = closes.size
        val f = ema(closes, fast)
        val s = ema(closes, slow)
        val line = MutableList<Double?>(n) { null }
        for (i in 0 until n) {
            val a = f[i]; val b = s[i]
            if (a != null && b != null) line[i] = a - b
        }
        val signal = MutableList<Double?>(n) { null }
        val firstIdx = line.indexOfFirst { it != null }
        if (firstIdx >= 0 && n - firstIdx >= signalPeriod) {
            val seedEnd = firstIdx + signalPeriod - 1
            var prev = (firstIdx..seedEnd).sumOf { line[it]!! } / signalPeriod
            signal[seedEnd] = prev
            val k = 2.0 / (signalPeriod + 1)
            for (i in seedEnd + 1 until n) {
                prev = line[i]!! * k + prev * (1 - k)
                signal[i] = prev
            }
        }
        val hist = MutableList<Double?>(n) { null }
        for (i in 0 until n) {
            val m = line[i]; val sg = signal[i]
            if (m != null && sg != null) hist[i] = m - sg
        }
        return MacdResult(line, signal, hist)
    }

    /** Wilder ATR. First value appears at index [period] (needs a previous close for the true range). */
    fun atr(candles: List<Candle>, period: Int = 14): List<Double?> {
        val out = MutableList<Double?>(candles.size) { null }
        if (candles.size <= period) return out
        val tr = DoubleArray(candles.size)
        for (i in 1 until candles.size) {
            val c = candles[i]; val pc = candles[i - 1].close
            tr[i] = max(c.high - c.low, max(abs(c.high - pc), abs(c.low - pc)))
        }
        var prev = (1..period).sumOf { tr[it] } / period
        out[period] = prev
        for (i in period + 1 until candles.size) {
            prev = (prev * (period - 1) + tr[i]) / period
            out[i] = prev
        }
        return out
    }

    /** Index i is a swing high when its high is strictly above the [lookback] candles on each side. */
    fun swingHighs(candles: List<Candle>, lookback: Int = 3): List<Int> {
        val res = mutableListOf<Int>()
        for (i in lookback until candles.size - lookback) {
            var ok = true
            for (j in 1..lookback) {
                if (candles[i].high <= candles[i - j].high || candles[i].high <= candles[i + j].high) { ok = false; break }
            }
            if (ok) res += i
        }
        return res
    }

    fun swingLows(candles: List<Candle>, lookback: Int = 3): List<Int> {
        val res = mutableListOf<Int>()
        for (i in lookback until candles.size - lookback) {
            var ok = true
            for (j in 1..lookback) {
                if (candles[i].low >= candles[i - j].low || candles[i].low >= candles[i + j].low) { ok = false; break }
            }
            if (ok) res += i
        }
        return res
    }

    /**
     * Support/resistance candidates: swing prices that lie within [tolerance] of each other are merged into one
     * level (average price) and counted as touches. Sorted by touches, then by recency of the first member.
     */
    fun levels(candles: List<Candle>, tolerance: Double, lookback: Int = 3): List<Level> {
        val pts = (swingHighs(candles, lookback).map { candles[it].high } + swingLows(candles, lookback).map { candles[it].low }).sorted()
        if (pts.isEmpty()) return emptyList()
        val clusters = mutableListOf<MutableList<Double>>()
        for (p in pts) {
            val last = clusters.lastOrNull()
            if (last != null && p - last.average() <= tolerance) last += p else clusters += mutableListOf(p)
        }
        return clusters.map { Level(it.average(), it.size) }.sortedByDescending { it.touches }
    }

    /** Dow-style structure from the last two swing highs and last two swing lows. */
    fun structure(candles: List<Candle>, lookback: Int = 3): Structure {
        val hs = swingHighs(candles, lookback).map { candles[it].high }
        val ls = swingLows(candles, lookback).map { candles[it].low }
        if (hs.size < 2 || ls.size < 2) return Structure.UNKNOWN
        val hh = hs[hs.size - 1] > hs[hs.size - 2]
        val hl = ls[ls.size - 1] > ls[ls.size - 2]
        return when {
            hh && hl -> Structure.HH_HL
            !hh && !hl -> Structure.LH_LL
            else -> Structure.MIXED
        }
    }

    /** Trend from EMA 20/50 order, price vs EMA 50 and swing structure. UP/DOWN need all three to agree or stay neutral. */
    fun trend(candles: List<Candle>): TrendInfo {
        val closes = candles.map { it.close }
        val e20 = ema(closes, 20).lastOrNull()
        val e50 = ema(closes, 50).lastOrNull()
        val st = structure(candles)
        if (e20 == null || e50 == null) return TrendInfo(Trend.UNKNOWN, st, "Need at least 50 candles to classify the trend.")
        val close = closes.last()
        // the EMAs must be clearly apart (about 0.2 pip on EUR/USD); otherwise tiny float noise would look like a trend
        val eps = close * 2e-5
        return when {
            e20 - e50 > eps && close > e50 && st != Structure.LH_LL ->
                TrendInfo(Trend.UP, st, "EMA 20 is above EMA 50 and price is above EMA 50; structure: ${st.label.lowercase()}.")
            e50 - e20 > eps && close < e50 && st != Structure.HH_HL ->
                TrendInfo(Trend.DOWN, st, "EMA 20 is below EMA 50 and price is below EMA 50; structure: ${st.label.lowercase()}.")
            else -> TrendInfo(Trend.RANGE, st, "EMAs, price and swing structure do not agree, so there is no clean trend.")
        }
    }
}
