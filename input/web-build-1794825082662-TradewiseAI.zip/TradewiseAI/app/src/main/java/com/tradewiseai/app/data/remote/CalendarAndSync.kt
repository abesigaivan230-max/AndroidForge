package com.tradewiseai.app.data.remote

import android.content.Context
import com.tradewiseai.app.data.local.JournalStore
import com.tradewiseai.app.data.preferences.SettingsStore
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

enum class Impact(val label: String) { LOW("Low"), MEDIUM("Medium"), HIGH("High") }

data class EconomicEvent(
    val id: String,
    val title: String,
    val currency: String,
    val timeSec: Long,
    val impact: Impact,
    val previous: String?,
    val forecast: String?,
    val actual: String?
)

data class CalendarResult(val events: List<EconomicEvent>, val sourceConfigured: Boolean, val message: String?, val fromCache: Boolean)

/**
 * Economic calendar. No free, reliable, licensed feed was verified for this project, so events are read from the
 * `economic_events` table that YOU fill (see docs/SETUP.md). With an empty table the screen says so honestly:
 * the app never invents events.
 */
class CalendarRepository(context: Context, private val http: SupabaseHttp, private val auth: AuthRepository) {
    private val cache = File(context.filesDir, "calendar_cache.json")

    suspend fun load(): CalendarResult {
        if (!http.configured) return CalendarResult(emptyList(), false, "Backend not configured, so there is no calendar data source.", false)
        return try {
            val o = http.postJson("/functions/v1/calendar", JSONObject().put("mode", "upcoming"), auth.validToken(), retries = 1)
            val events = parse(o.optJSONArray("events") ?: JSONArray())
            val configured = o.optBoolean("configured", events.isNotEmpty())
            if (events.isNotEmpty()) try { cache.writeText(o.toString()) } catch (_: Exception) {}
            CalendarResult(events, configured, if (events.isEmpty()) "No calendar data source is configured: the economic_events table is empty. Nothing is shown rather than made-up events." else null, false)
        } catch (e: Exception) {
            val cached = readCache()
            if (cached.isNotEmpty()) CalendarResult(cached, true, "Offline: showing the last saved calendar.", true)
            else CalendarResult(emptyList(), true, e.message ?: "Could not load the calendar.", false)
        }
    }

    fun cachedEvents(): List<EconomicEvent> = readCache()

    fun clearCache() { try { cache.delete() } catch (_: Exception) {} }

    private fun readCache(): List<EconomicEvent> = try {
        if (!cache.exists()) emptyList() else parse(JSONObject(cache.readText()).optJSONArray("events") ?: JSONArray())
    } catch (_: Exception) { emptyList() }

    private fun parse(arr: JSONArray): List<EconomicEvent> = (0 until arr.length()).mapNotNull { i ->
        try {
            val o = arr.getJSONObject(i)
            EconomicEvent(
                id = o.getString("id"), title = o.getString("title"), currency = o.optString("currency"),
                timeSec = o.getLong("event_time"),
                impact = Impact.values().firstOrNull { it.name.equals(o.optString("impact"), true) } ?: Impact.LOW,
                previous = o.optString("previous").ifBlank { null },
                forecast = o.optString("forecast").ifBlank { null },
                actual = o.optString("actual").ifBlank { null }
            )
        } catch (_: Exception) { null }
    }.sortedBy { it.timeSec }
}

/** Optional cloud sync of the journal through PostgREST. Row Level Security makes every row private to its owner. */
class SyncRepository(
    private val http: SupabaseHttp,
    private val auth: AuthRepository,
    private val journal: JournalStore,
    private val settings: SettingsStore
) {
    suspend fun sync(): Result<String> = runCatching {
        val token = auth.validToken() ?: throw ApiException("Sign in to sync.")
        val uid = auth.state.value.userId ?: throw ApiException("Missing user id.")
        val local = journal.trades.value
        if (local.isNotEmpty()) {
            val rows = JSONArray()
            local.forEach { t ->
                rows.put(JSONObject()
                    .put("id", t.id).put("user_id", uid)
                    .put("payload", JournalStore.tradeToJson(t).put("shot", JSONObject.NULL))
                    .put("updated_at", java.time.Instant.now().toString()))
            }
            http.postJsonArray("/rest/v1/trade_journal?on_conflict=id", rows, token)
        }
        val remote = http.getJsonArray("/rest/v1/trade_journal?select=id,payload", token)
        val byId = local.associateBy { it.id }.toMutableMap()
        var pulled = 0
        for (i in 0 until remote.length()) {
            val row = remote.getJSONObject(i)
            val t = try { JournalStore.tradeFromJson(row.getJSONObject("payload")) } catch (_: Exception) { continue }
            if (!byId.containsKey(t.id)) { byId[t.id] = t.copy(screenshotPath = null); pulled++ }
        }
        if (pulled > 0) journal.replaceAll(byId.values.sortedBy { it.openedAtMs })
        // preferences (risk and rules only; nothing secret)
        val s = settings.current
        val prefs = JSONObject().put("maxRisk", s.maxRiskPercent).put("dailyLoss", s.dailyLossPercent)
            .put("minRR", s.minRiskReward).put("startingBalance", s.startingBalance)
        http.postJsonArray("/rest/v1/profiles?on_conflict=id", JSONArray().put(JSONObject().put("id", uid).put("preferences", prefs)), token)
        "Synced ${local.size} local trade(s), pulled $pulled from the cloud."
    }
}
