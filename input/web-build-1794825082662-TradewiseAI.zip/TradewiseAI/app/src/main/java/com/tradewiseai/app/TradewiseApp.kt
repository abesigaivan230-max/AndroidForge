package com.tradewiseai.app

import android.app.Application
import android.net.Uri
import com.tradewiseai.app.data.local.AlertStore
import com.tradewiseai.app.data.local.JournalStore
import com.tradewiseai.app.data.local.LessonStore
import com.tradewiseai.app.data.preferences.SettingsStore
import com.tradewiseai.app.data.remote.AiRepository
import com.tradewiseai.app.data.remote.AuthRepository
import com.tradewiseai.app.data.remote.BackendMarketProvider
import com.tradewiseai.app.data.remote.CalendarRepository
import com.tradewiseai.app.data.remote.DemoMarketProvider
import com.tradewiseai.app.data.remote.SupabaseHttp
import com.tradewiseai.app.data.remote.SyncRepository
import com.tradewiseai.app.data.remote.newHttpClient
import com.tradewiseai.app.data.repository.AnalysisRepository
import com.tradewiseai.app.data.repository.MarketRepository
import com.tradewiseai.app.data.repository.ScreenshotAnalyzer
import com.tradewiseai.app.notifications.Notifier
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Tiny hand-rolled dependency container (no DI framework: fewer moving parts, nothing to mis-configure).
 * Everything is created lazily and lives for the process lifetime, so the overlay service and the
 * activity share the same caches and settings.
 */
class TradewiseApp : Application() {

    val settings by lazy { SettingsStore(this) }
    val http by lazy { SupabaseHttp(newHttpClient(), BuildConfig.SUPABASE_URL, BuildConfig.SUPABASE_ANON_KEY) }
    val auth by lazy { AuthRepository(this, http) }
    private val backendMarket by lazy { BackendMarketProvider(http) { auth.validToken() } }
    val market by lazy { MarketRepository(this, settings, backendMarket, DemoMarketProvider()) }
    val analysis by lazy { AnalysisRepository(this, market, settings) }
    val ai by lazy { AiRepository(http, auth) }
    val calendar by lazy { CalendarRepository(this, http, auth) }
    val journal by lazy { JournalStore(this) }
    val lessons by lazy { LessonStore(this) }
    val alerts by lazy { AlertStore(this) }
    val sync by lazy { SyncRepository(http, auth, journal, settings) }
    val screenshots by lazy { ScreenshotAnalyzer(this, ai, market) }

    /** A screenshot shared into the app (or captured by the overlay) waiting to be analysed on the Analyse tab. */
    val pendingShareUri = MutableStateFlow<Uri?>(null)
    val pendingShotPath = MutableStateFlow<String?>(null)

    override fun onCreate() {
        super.onCreate()
        Notifier.createChannels(this)
    }
}
