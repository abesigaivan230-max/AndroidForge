package com.tradewiseai.app.data.preferences

import android.content.Context
import android.content.SharedPreferences
import com.tradewiseai.app.domain.analysis.SetupConfig
import com.tradewiseai.app.domain.model.CurrencyPair
import com.tradewiseai.app.domain.model.Timeframe
import com.tradewiseai.app.domain.risk.DemoSettings
import com.tradewiseai.app.overlay.OverlayMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class ThemeVariant(val label: String) { MIDNIGHT("Midnight blue"), AMOLED("AMOLED black") }

data class AppSettings(
    val overlayMode: OverlayMode = OverlayMode.BUBBLE,
    val overlayWanted: Boolean = false,
    val overlayX: Int = 0,
    val overlayY: Int = 400,
    val panelWidthDp: Int = 240,
    val defaultPair: CurrencyPair = CurrencyPair.EURUSD,
    val defaultTimeframe: Timeframe = Timeframe.H1,
    val watchlist: Set<CurrencyPair> = CurrencyPair.values().toSet(),
    val forceDemoData: Boolean = false,
    val notifyPrice: Boolean = true,
    val notifySetup: Boolean = false,
    val notifyErrors: Boolean = true,
    val notifyCalendar: Boolean = false,
    val startingBalance: Double = 1000.0,
    val maxRiskPercent: Double = 2.0,
    val dailyLossPercent: Double = 5.0,
    val accountCurrency: String = "USD",
    val minRiskReward: Double = 1.5,
    val slAtrMult: Double = 1.5,
    val pullbackAtrMult: Double = 1.0,
    val rsiMin: Double = 35.0,
    val rsiMax: Double = 70.0,
    val requireMacdTurn: Boolean = true,
    val maxSpreadPips: Double = 3.0,
    val theme: ThemeVariant = ThemeVariant.MIDNIGHT,
    val disclaimerAccepted: Boolean = false
) {
    fun setupConfig() = SetupConfig(
        minRiskReward = minRiskReward, slAtrMult = slAtrMult, pullbackAtrMult = pullbackAtrMult,
        rsiMin = rsiMin, rsiMax = rsiMax, requireMacdTurn = requireMacdTurn, maxSpreadPips = maxSpreadPips
    )

    fun demoSettings() = DemoSettings(
        startingBalance = startingBalance, maxRiskPercent = maxRiskPercent, dailyLossLimitPercent = dailyLossPercent
    )
}

/** Plain SharedPreferences; nothing secret lives here (tokens are in AuthRepository's encrypted store). */
class SettingsStore(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("tradewise_settings", Context.MODE_PRIVATE)
    private val _state = MutableStateFlow(load())
    val state: StateFlow<AppSettings> = _state.asStateFlow()

    val current: AppSettings get() = _state.value

    @Synchronized
    fun update(block: (AppSettings) -> AppSettings) {
        val next = block(_state.value)
        _state.value = next
        save(next)
    }

    private fun load(): AppSettings {
        val d = AppSettings()
        return try {
            AppSettings(
                overlayMode = OverlayMode.fromName(prefs.getString("overlayMode", null)),
                overlayWanted = prefs.getBoolean("overlayWanted", d.overlayWanted),
                overlayX = prefs.getInt("overlayX", d.overlayX),
                overlayY = prefs.getInt("overlayY", d.overlayY),
                panelWidthDp = prefs.getInt("panelWidthDp", d.panelWidthDp).coerceIn(180, 320),
                defaultPair = CurrencyPair.fromSymbol(prefs.getString("defaultPair", null)) ?: d.defaultPair,
                defaultTimeframe = Timeframe.fromLabel(prefs.getString("defaultTf", d.defaultTimeframe.label)),
                watchlist = prefs.getStringSet("watchlist", null)?.mapNotNull { CurrencyPair.fromSymbol(it) }?.toSet()
                    ?.takeIf { it.isNotEmpty() } ?: d.watchlist,
                forceDemoData = prefs.getBoolean("forceDemo", d.forceDemoData),
                notifyPrice = prefs.getBoolean("nPrice", d.notifyPrice),
                notifySetup = prefs.getBoolean("nSetup", d.notifySetup),
                notifyErrors = prefs.getBoolean("nErrors", d.notifyErrors),
                notifyCalendar = prefs.getBoolean("nCal", d.notifyCalendar),
                startingBalance = prefs.getFloat("startBal", d.startingBalance.toFloat()).toDouble(),
                maxRiskPercent = prefs.getFloat("maxRisk", d.maxRiskPercent.toFloat()).toDouble(),
                dailyLossPercent = prefs.getFloat("dailyLoss", d.dailyLossPercent.toFloat()).toDouble(),
                accountCurrency = prefs.getString("acctCur", d.accountCurrency) ?: d.accountCurrency,
                minRiskReward = prefs.getFloat("minRR", d.minRiskReward.toFloat()).toDouble(),
                slAtrMult = prefs.getFloat("slAtr", d.slAtrMult.toFloat()).toDouble(),
                pullbackAtrMult = prefs.getFloat("pbAtr", d.pullbackAtrMult.toFloat()).toDouble(),
                rsiMin = prefs.getFloat("rsiMin", d.rsiMin.toFloat()).toDouble(),
                rsiMax = prefs.getFloat("rsiMax", d.rsiMax.toFloat()).toDouble(),
                requireMacdTurn = prefs.getBoolean("macdTurn", d.requireMacdTurn),
                maxSpreadPips = prefs.getFloat("maxSpread", d.maxSpreadPips.toFloat()).toDouble(),
                theme = ThemeVariant.values().firstOrNull { it.name == prefs.getString("theme", null) } ?: d.theme,
                disclaimerAccepted = prefs.getBoolean("disclaimer", d.disclaimerAccepted)
            )
        } catch (e: Exception) {
            d  // corrupted prefs: fall back to defaults rather than crash
        }
    }

    private fun save(s: AppSettings) {
        prefs.edit()
            .putString("overlayMode", s.overlayMode.name)
            .putBoolean("overlayWanted", s.overlayWanted)
            .putInt("overlayX", s.overlayX).putInt("overlayY", s.overlayY)
            .putInt("panelWidthDp", s.panelWidthDp)
            .putString("defaultPair", s.defaultPair.symbol)
            .putString("defaultTf", s.defaultTimeframe.label)
            .putStringSet("watchlist", s.watchlist.map { it.symbol }.toSet())
            .putBoolean("forceDemo", s.forceDemoData)
            .putBoolean("nPrice", s.notifyPrice).putBoolean("nSetup", s.notifySetup)
            .putBoolean("nErrors", s.notifyErrors).putBoolean("nCal", s.notifyCalendar)
            .putFloat("startBal", s.startingBalance.toFloat())
            .putFloat("maxRisk", s.maxRiskPercent.toFloat())
            .putFloat("dailyLoss", s.dailyLossPercent.toFloat())
            .putString("acctCur", s.accountCurrency)
            .putFloat("minRR", s.minRiskReward.toFloat())
            .putFloat("slAtr", s.slAtrMult.toFloat())
            .putFloat("pbAtr", s.pullbackAtrMult.toFloat())
            .putFloat("rsiMin", s.rsiMin.toFloat()).putFloat("rsiMax", s.rsiMax.toFloat())
            .putBoolean("macdTurn", s.requireMacdTurn)
            .putFloat("maxSpread", s.maxSpreadPips.toFloat())
            .putString("theme", s.theme.name)
            .putBoolean("disclaimer", s.disclaimerAccepted)
            .apply()
    }

    fun clearAll() {
        prefs.edit().clear().apply()
        _state.value = AppSettings()
    }
}
