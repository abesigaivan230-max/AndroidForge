package com.tradewiseai.app.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Info
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tradewiseai.app.core.theme.Space
import com.tradewiseai.app.core.theme.TW
import com.tradewiseai.app.core.theme.TwType
import com.tradewiseai.app.domain.model.DataStatus
import com.tradewiseai.app.domain.model.Decision

/** Fades and slides content in once, optionally staggered. Used for card entrances. */
@Composable
fun Appear(delayMs: Int = 0, modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { shown = true }
    AnimatedVisibility(
        visible = shown,
        modifier = modifier,
        enter = fadeIn(tween(380, delayMillis = delayMs)) + slideInVertically(tween(380, delayMillis = delayMs)) { it / 8 },
        exit = fadeOut()
    ) { content() }
}

@Composable
fun TwCard(
    modifier: Modifier = Modifier,
    onClick: (() -> Unit)? = null,
    accent: Color? = null,
    padding: Dp = Space.lg,
    content: @Composable ColumnScope.() -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.98f else 1f, spring(Spring.DampingRatioMediumBouncy), label = "cardScale")
    var m = modifier
        .fillMaxWidth()
        .scale(scale)
        .clip(shape)
        .background(Brush.verticalGradient(listOf(TW.surfaceHi, TW.surface)))
        .border(BorderStroke(1.dp, accent?.copy(alpha = 0.55f) ?: TW.border), shape)
    if (onClick != null) {
        m = m.pointerInput(Unit) {
            detectTapGestures(onPress = { pressed = true; tryAwaitRelease(); pressed = false }, onTap = { onClick() })
        }
    }
    Column(m.padding(padding), verticalArrangement = Arrangement.spacedBy(Space.sm), content = content)
}

@Composable
fun Pill(text: String, color: Color, modifier: Modifier = Modifier, filled: Boolean = false) {
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(if (filled) color else color.copy(alpha = 0.16f))
            .padding(horizontal = 10.dp, vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = if (filled) Color.White else color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
    }
}

@Composable
fun StatusChip(status: DataStatus, modifier: Modifier = Modifier) {
    val color = when (status) {
        DataStatus.LIVE -> TW.green
        DataStatus.CACHED -> TW.amber
        DataStatus.STALE -> TW.red
        DataStatus.DEMO -> TW.blueSoft
    }
    val pulse = rememberInfiniteTransition(label = "pulse")
    val a by pulse.animateFloat(0.35f, 1f, infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Reverse), label = "dot")
    Row(
        modifier.clip(RoundedCornerShape(50)).background(color.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(6.dp).alpha(if (status == DataStatus.LIVE) a else 1f).clip(CircleShape).background(color))
        Spacer(Modifier.width(6.dp))
        Text(status.label, color = color, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.4.sp)
    }
}

@Composable
fun decisionColor(d: Decision): Color = when (d) {
    Decision.BUY_SETUP -> TW.green
    Decision.SELL_SETUP -> TW.red
    Decision.WAIT -> TW.amber
}

@Composable
fun DecisionBadge(decision: Decision, modifier: Modifier = Modifier, large: Boolean = false) {
    val brush = when (decision) {
        Decision.BUY_SETUP -> TW.greenBrush
        Decision.SELL_SETUP -> TW.redBrush
        Decision.WAIT -> TW.amberBrush
    }
    Box(
        modifier.clip(RoundedCornerShape(14.dp)).background(brush)
            .padding(horizontal = if (large) 18.dp else 12.dp, vertical = if (large) 10.dp else 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(decision.label, color = Color.White, fontWeight = FontWeight.Bold, fontSize = if (large) 18.sp else 12.sp, letterSpacing = 0.6.sp)
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    enabled: Boolean = true,
    loading: Boolean = false
) {
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.96f else 1f, spring(), label = "btn")
    Box(
        modifier
            .scale(scale)
            .clip(RoundedCornerShape(16.dp))
            .background(if (enabled) TW.accentBrush else Brush.linearGradient(listOf(TW.border, TW.border)))
            .pointerInput(enabled, loading) {
                detectTapGestures(
                    onPress = { if (enabled && !loading) { pressed = true; tryAwaitRelease(); pressed = false } },
                    onTap = { if (enabled && !loading) onClick() }
                )
            }
            .padding(horizontal = 20.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (loading) Spinner(16.dp, Color.White) else if (icon != null) Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp))
            if (text.isNotEmpty()) Text(text, color = if (enabled) Color.White else TW.faint, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }
    }
}

@Composable
fun GhostButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    icon: ImageVector? = null,
    color: Color = TW.blueSoft,
    enabled: Boolean = true
) {
    Row(
        modifier
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, if (enabled) color.copy(alpha = 0.5f) else TW.border, RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
    ) {
        if (icon != null) Icon(icon, null, tint = if (enabled) color else TW.faint, modifier = Modifier.size(16.dp))
        if (text.isNotEmpty()) Text(text, color = if (enabled) color else TW.faint, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun Spinner(size: Dp = 20.dp, color: Color = TW.blue) {
    CircularProgressIndicator(modifier = Modifier.size(size), color = color, strokeWidth = 2.dp)
}

/** Subtle shimmer placeholder used while data loads. */
@Composable
fun Shimmer(modifier: Modifier = Modifier, height: Dp = 16.dp) {
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(-1f, 2f, infiniteRepeatable(tween(1200, easing = LinearEasing)), label = "x")
    Box(
        modifier.height(height).clip(RoundedCornerShape(8.dp)).background(
            Brush.horizontalGradient(
                listOf(TW.surfaceHi, TW.border.copy(alpha = 0.9f), TW.surfaceHi),
                startX = x * 400f, endX = x * 400f + 400f
            )
        )
    )
}

@Composable
fun SectionTitle(text: String, modifier: Modifier = Modifier, trailing: (@Composable RowScope.() -> Unit)? = null) {
    Row(modifier.fillMaxWidth().padding(top = Space.sm), verticalAlignment = Alignment.CenterVertically) {
        Text(text.uppercase(), style = TwType.label, modifier = Modifier.weight(1f))
        if (trailing != null) trailing()
    }
}

@Composable
fun Banner(text: String, color: Color = TW.amber, warning: Boolean = true, modifier: Modifier = Modifier) {
    Row(
        modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(color.copy(alpha = 0.12f))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(14.dp)).padding(12.dp),
        verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Icon(if (warning) Icons.Rounded.Warning else Icons.Rounded.Info, null, tint = color, modifier = Modifier.size(18.dp))
        Text(text, style = TwType.small.copy(color = TW.text), modifier = Modifier.weight(1f))
    }
}

@Composable
fun KeyValue(label: String, value: String, valueColor: Color = TW.text, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, style = TwType.small, modifier = Modifier.weight(1f))
        Text(value, style = TwType.mono.copy(color = valueColor), textAlign = TextAlign.End)
    }
}

@Composable
fun StatTile(label: String, value: String, modifier: Modifier = Modifier, color: Color = TW.text, sub: String? = null) {
    Column(
        modifier.clip(RoundedCornerShape(16.dp)).background(TW.surfaceHi.copy(alpha = 0.6f))
            .border(1.dp, TW.border, RoundedCornerShape(16.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Text(label.uppercase(), style = TwType.label)
        Text(value, style = TwType.heading.copy(color = color, fontSize = 17.sp))
        if (sub != null) Text(sub, style = TwType.small)
    }
}

@Composable
fun BulletList(items: List<String>, color: Color = TW.muted, modifier: Modifier = Modifier) {
    Column(modifier, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        items.forEach {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.padding(top = 7.dp).size(5.dp).clip(CircleShape).background(color))
                Text(it, style = TwType.body, modifier = Modifier.weight(1f))
            }
        }
    }
}

@Composable
fun EmptyState(title: String, message: String, modifier: Modifier = Modifier, action: (@Composable () -> Unit)? = null) {
    Column(
        modifier.fillMaxWidth().padding(vertical = 24.dp, horizontal = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text(title, style = TwType.heading, textAlign = TextAlign.Center)
        Text(message, style = TwType.small, textAlign = TextAlign.Center)
        if (action != null) { Spacer(Modifier.height(4.dp)); action() }
    }
}

/** Single-select chips; scrolls sideways when there are many. */
@Composable
fun ChipRow(options: List<String>, selected: String, onSelect: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            val sel = o == selected
            val bg = if (sel) TW.blue.copy(alpha = 0.22f) else TW.surfaceHi.copy(alpha = 0.6f)
            Box(
                Modifier.clip(RoundedCornerShape(12.dp)).background(bg)
                    .border(1.dp, if (sel) TW.blue else TW.border, RoundedCornerShape(12.dp))
                    .clickable { onSelect(o) }.padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Text(o, color = if (sel) TW.text else TW.muted, fontSize = 13.sp, fontWeight = if (sel) FontWeight.SemiBold else FontWeight.Normal)
            }
        }
    }
}

val ScreenPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp)
