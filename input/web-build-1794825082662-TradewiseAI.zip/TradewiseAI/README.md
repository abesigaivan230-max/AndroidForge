# TRADEWISE AI (Android)

Educational forex analysis companion: Kotlin + Jetpack Compose, package `com.tradewiseai.app`, minSdk 26, target 34.
It analyses EUR/USD, GBP/USD and USD/JPY with deterministic indicators and a rule engine (4H trend / 1H setup / 15m entry),
explains results, and shows a floating assistant over other apps. **It never places trades, never logs in to a broker, and is not financial advice.**

Tabs: Home, Markets, Analyse, Learn (20 lessons + quizzes), Journal (simulated demo account). Extras: position-size calculator, economic calendar, price alerts, Settings.

## Quick start
1. Unzip, open the folder in Android Studio (Koala or newer, JDK 17). Let it sync (it creates the Gradle wrapper jar).
2. Without any backend the app runs in **DEMO DATA** mode (synthetic prices, clearly labelled). Run on a real phone.
3. For real data and AI, follow `docs/SETUP.md` (Supabase project + 3 secrets), then copy `local.properties.example` values into `local.properties`.

## Layout
- `app/` Android app. `domain/` is pure Kotlin (indicators, setup engine, risk, journal logic) and is unit tested.
- `supabase/` SQL migration and Edge Functions (`market-data`, `ai-explain`, `screenshot-analyse`, `calendar`).
- `docs/` SETUP, TESTING, RELEASE, PROVIDERS, PRIVACY.

## Honest status
Domain logic: 54 JUnit tests passed in the build environment. The Android layer (UI, overlay, capture) and backend were written without
access to the Android SDK or a Supabase project, so they have NOT been compiled or run. Expect to fix a few compile errors on first build and
to test the overlay and screenshot capture on a real device (see `docs/TESTING.md`).
