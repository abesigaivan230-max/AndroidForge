# VeoTag

Kotlin + Jetpack Compose + Supabase. QR-code project showcase with an admin area. Package `com.veotag.app`.

## What changed in this version
- **Icon**: adaptive icon (gradient background, bracket + play foreground, monochrome layer for themed icons), legacy PNG mipmaps, 512px Play Store icon, matching splash mark.
- **Theme**: new light/dark palettes (indigo/violet/orange), shapes, type scale. Edge-to-edge with the Android 12+ splash screen API.
- **Motion**: staggered list entrances, shimmer skeleton loading, spring press on cards and tab icons, fade-through between tabs, directional slides for deeper screens, animated bottom bar.
- **Fixes**: removed dead SearchScreen (bad import), ScanScreen `clip` recursion, `@OptIn` clash, `ImageProxy.image` opt-in, BlendMode.Clear without offscreen layer, deprecated LocalLifecycleOwner, partial selects decoding into full `Project` (crash), unsanitised PostgREST search filter, admin session check before auth init (bounced admins to login after restart), memory-heavy video upload, fake `gradlew`, unneeded storage permission and FileProvider.

## Upgrade: dark redesign, gallery scan, cover photos, fullscreen video
- **Look**: dark-only premium navy theme (blue/violet gradients, orange accents), rounded bordered cards, staggered entrances, shimmer skeletons.
- **Scanner**: torch bottom-left, circular gallery button bottom-right. Uses `ActivityResultContracts.PickVisualMedia` (system photo picker; falls back to the document picker on older/OEM builds). No share/chooser intents. Decoding is on-device ML Kit, two passes (2048 px, 1024 px). Messages for no QR, invalid QR, multiple QRs, unreadable image. The gallery button also works when camera permission is denied.
- **Project details**: poster + play button, inline Media3 player with fullscreen button, fullscreen dialog sharing the same ExoPlayer (position preserved, landscape, system bars hidden, close button + back). Retry on failure. Category labels prettified ("FABRIC<TEXTILE>" -> "Fabric & Textile"), blank/"null" fields hidden, key: value lines in details become a tidy table.
- **Cover photos**: admin form has a Project Cover Photo section (select / replace / remove / preview). Photos are re-encoded to a <=1600 px JPEG and stored at `covers/<folder>/<uuid>.jpg`; the path goes into `thumbnail_path`. New videos go to `videos/<folder>/<uuid>.mp4`; existing videos keep their stored path. Replaced/removed/deleted files are removed only after the row update succeeds, and only the project's own paths.
- **Cards**: one `ProjectCard` everywhere (cover, category badge, description, byline, play indicator, shimmer loading, designed fallback graphic).
- **Admin**: dashboard stats, manage list with thumbnails/status, preview for published projects, QR and label export, form with draft/publish, live preview, duplicate-submit guard, separate cover/video upload status.

### Dependencies
None added or changed. Uses existing: Coil, Media3, ML Kit barcode, activity-compose 1.9.3 (photo picker).

### Not verified / known gaps
- Never compiled or run (Maven/Google/Gradle hosts unreachable where this was written). Checked only with a syntax-level kotlinc pass, XML parsing and an import cross-check.
- Upload progress is a per-file indeterminate bar plus Uploading/Uploaded state, not byte-level percentages.
- Volume uses the device volume keys (the stock Media3 controller has no volume slider).
- Storage policies could not be inspected from here: see `docs/storage_policy_check.sql`. No SQL change is required unless your INSERT policy is folder-restricted.
- The gallery path navigates to the project screen, which does the Supabase lookup and shows a not-found state if the code is stale.
- Portrait is locked in the manifest; fullscreen switches to landscape at runtime.
- Not tested on a real device, including Infinix Smart 8 and the Android photo-picker fallback.

## Supabase config
Resolution order for URL/key: Gradle property -> `local.properties` -> environment -> baked default. Put `SUPABASE_URL` / `SUPABASE_ANON_KEY` in `local.properties` (git-ignored). Only ever ship the anon key; protect data with RLS.

## Verification status (honest)
Not built with Gradle: Maven/Google/Gradle hosts were unreachable in the authoring sandbox. Checked only: Kotlin syntax via kotlinc, XML well-formedness, resource references. Expect the first AndroidForge run may surface small compile errors; send me the log.
