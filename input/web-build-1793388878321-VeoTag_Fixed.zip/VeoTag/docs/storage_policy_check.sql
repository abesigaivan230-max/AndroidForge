-- VeoTag: NO migration is required by this release. Run these READ-ONLY queries in the Supabase SQL editor
-- to confirm your existing policies already allow the new cover-photo paths.

-- 1) Show the Storage policies on the bucket
select policyname, cmd, roles, qual, with_check
from pg_policies
where schemaname = 'storage' and tablename = 'objects'
order by policyname;

-- 2) What to look for
--   SELECT : public (anon) can read objects where bucket_id = 'veotag-videos'      -> cover images visible to visitors
--   INSERT / UPDATE / DELETE : restricted to authenticated users who are in public.admin_users
--   and NOT restricted to a specific folder name. New files are written to:
--       covers/<folder-id>/<uuid>.jpg
--       videos/<folder-id>/<uuid>.mp4        (older videos remain at <folder-id>/<uuid>.mp4 and keep working)

-- 3) ONLY if INSERT is limited to particular folders and uploads to covers/ fail with a 403, adapt your
--    existing admin INSERT policy rather than adding a looser one. Template (review before running):
-- create policy "admins can upload covers"
--   on storage.objects for insert to authenticated
--   with check (
--     bucket_id = 'veotag-videos'
--     and (storage.foldername(name))[1] = 'covers'
--     and exists (select 1 from public.admin_users a where a.user_id = auth.uid())
--   );
