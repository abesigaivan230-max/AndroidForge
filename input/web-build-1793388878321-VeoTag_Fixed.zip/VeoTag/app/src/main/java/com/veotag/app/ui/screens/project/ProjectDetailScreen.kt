package com.veotag.app.ui.screens.project

import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Color as AndroidColor
import android.graphics.drawable.ColorDrawable
import android.app.Activity
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.ui.window.DialogWindowProvider
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.veotag.app.data.model.Project
import com.veotag.app.data.remote.SupabaseProvider
import com.veotag.app.data.repository.ProjectRepository
import com.veotag.app.ui.components.CategoryBadge
import com.veotag.app.ui.components.CoverFallback
import com.veotag.app.ui.components.LoadingState
import com.veotag.app.ui.components.ErrorState
import com.veotag.app.ui.components.shimmerBrush
import com.veotag.app.ui.components.staggeredEntrance
import com.veotag.app.ui.theme.brandGradient
import com.veotag.app.util.cleanOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectDetailScreen(projectId: String, onBack: () -> Unit) {
    val repo = remember { ProjectRepository() }
    val context = LocalContext.current
    var project by remember { mutableStateOf<Project?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var reload by remember { mutableIntStateOf(0) }

    LaunchedEffect(projectId, reload) {
        loading = true
        error = null
        val result = withContext(Dispatchers.IO) { repo.getProjectById(projectId, publishedOnly = true) }
        result.onSuccess { p ->
            if (p == null) error = "NOT_FOUND" else project = p
            loading = false
        }.onFailure {
            error = "NETWORK"
            loading = false
        }
    }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = {
                Text(
                    project?.title?.cleanOrNull() ?: "Project",
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    fontWeight = FontWeight.SemiBold
                )
            },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            },
            actions = {
                project?.let { p ->
                    IconButton(onClick = {
                        val text = buildString {
                            append("Check out \"${p.title}\" on VeoTag")
                            p.shortDescription.cleanOrNull()?.let { append(" — $it") }
                        }
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, text)
                        }
                        context.startActivity(Intent.createChooser(send, "Share project"))
                    }) { Icon(Icons.Default.Share, contentDescription = "Share project") }
                }
            },
            colors = TopAppBarDefaults.topAppBarColors(
                containerColor = MaterialTheme.colorScheme.background,
                titleContentColor = MaterialTheme.colorScheme.onBackground,
                navigationIconContentColor = MaterialTheme.colorScheme.onBackground,
                actionIconContentColor = MaterialTheme.colorScheme.onBackground
            )
        )

        when {
            loading -> LoadingState()
            error == "NOT_FOUND" -> ErrorState(
                message = "This project isn't available. It may have been unpublished.",
                onRetry = onBack,
                retryLabel = "Go back"
            )
            error != null -> ErrorState(
                message = "Unable to load project. Check your internet connection.",
                onRetry = { reload++ }
            )
            project != null -> DetailContent(project!!)
        }
    }
}

@Composable
private fun DetailContent(p: Project) {
    val scroll = rememberScrollState()
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
        Column(
            Modifier
                .widthIn(max = 720.dp)
                .fillMaxSize()
                .verticalScroll(scroll)
                .padding(horizontal = 16.dp)
        ) {
            Box(Modifier.staggeredEntrance(0, p.id)) {
                ProjectVideoPlayer(
                    videoUrl = SupabaseProvider.publicVideoUrl(p.videoPath),
                    cover = SupabaseProvider.publicThumbnailUrl(p.thumbnailPath),
                    title = p.title,
                    category = p.category
                )
            }
            Spacer(Modifier.height(18.dp))
            Column(Modifier.staggeredEntrance(1, p.id)) {
                CategoryBadge(p.category)
                Spacer(Modifier.height(10.dp))
                Text(
                    text = p.title.cleanOrNull() ?: "Untitled project",
                    style = MaterialTheme.typography.headlineMedium,
                    fontWeight = FontWeight.ExtraBold
                )
                p.shortDescription.cleanOrNull()?.let {
                    Spacer(Modifier.height(10.dp))
                    Text(
                        text = it,
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            var idx = 2
            p.creatorsNames.cleanOrNull()?.let {
                Spacer(Modifier.height(16.dp))
                Box(Modifier.staggeredEntrance(idx++, p.id)) { InfoCard(Icons.Default.Person, "Created by", it) }
            }
            p.schoolOrganization.cleanOrNull()?.let {
                Spacer(Modifier.height(12.dp))
                Box(Modifier.staggeredEntrance(idx++, p.id)) { InfoCard(Icons.Default.School, "School / Organization", it) }
            }
            p.additionalDetails.cleanOrNull()?.let {
                Spacer(Modifier.height(12.dp))
                Box(Modifier.staggeredEntrance(idx++, p.id)) { DetailsCard(it) }
            }
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun SurfaceCard(content: @Composable () -> Unit) {
    val shape = MaterialTheme.shapes.medium
    Box(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shape)
            .padding(16.dp)
    ) { content() }
}

@Composable
private fun IconTile(icon: ImageVector) {
    Box(
        Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(22.dp))
    }
}

@Composable
private fun InfoCard(icon: ImageVector, label: String, value: String) {
    SurfaceCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconTile(icon)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(2.dp))
                Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

private val keyValue = Regex("^([^:\\n]{2,28}):\\s*(.+)$")

@Composable
private fun DetailsCard(raw: String) {
    val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
    SurfaceCard {
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconTile(Icons.Default.Info)
                Spacer(Modifier.width(14.dp))
                Text("About this project", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            }
            Spacer(Modifier.height(12.dp))
            lines.forEachIndexed { i, line ->
                val kv = keyValue.matchEntire(line)
                if (kv != null) {
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(
                            kv.groupValues[1],
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.weight(0.4f)
                        )
                        Text(
                            kv.groupValues[2],
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(0.6f)
                        )
                    }
                } else {
                    Text(line, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(vertical = 4.dp))
                }
                if (i != lines.lastIndex) {
                    Box(Modifier.fillMaxWidth().height(1.dp).background(MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.6f)))
                }
            }
        }
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

/**
 * One ExoPlayer instance serves both the inline view and the fullscreen dialog, so entering or leaving
 * fullscreen never restarts the video or loses the playback position.
 */
@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun ProjectVideoPlayer(videoUrl: String, cover: Any?, title: String, category: String) {
    val context = LocalContext.current
    var started by remember(videoUrl) { mutableStateOf(false) }
    var fullscreen by remember(videoUrl) { mutableStateOf(false) }
    var failed by remember(videoUrl) { mutableStateOf(false) }

    val player = remember(videoUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(videoUrl))
            playWhenReady = false
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                failed = true
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner, player) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) player.pause()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    fun startPlayback() {
        failed = false
        started = true
        player.prepare()
        player.playWhenReady = true
    }

    val shape = MaterialTheme.shapes.large
    Box(
        Modifier
            .fillMaxWidth()
            .aspectRatio(16f / 9f)
            .clip(shape)
            .background(Color.Black)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
    ) {
        if (!started) {
            // Poster: cover photo (or branded fallback) with a clear play button.
            if (cover != null) {
                SubcomposeAsyncImage(
                    model = ImageRequest.Builder(context).data(cover).crossfade(350).build(),
                    contentDescription = title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = { Box(Modifier.fillMaxSize().background(shimmerBrush())) },
                    error = { CoverFallback(title, category, Modifier.fillMaxSize()) }
                )
            } else {
                CoverFallback(title, category, Modifier.fillMaxSize())
            }
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.45f))))
                    .clickable { startPlayback() }
                    .semantics { contentDescription = "Play video" },
                contentAlignment = Alignment.Center
            ) {
                Box(
                    Modifier
                        .size(68.dp)
                        .clip(CircleShape)
                        .background(brandGradient())
                        .border(2.dp, Color.White.copy(alpha = 0.6f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(40.dp))
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                        setFullscreenButtonClickListener { fullscreen = true }
                    }
                },
                update = { view -> view.player = if (fullscreen) null else player },
                onRelease = { view -> view.player = null },
                modifier = Modifier.fillMaxSize()
            )
        }

        if (failed) {
            Column(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.78f))
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(Icons.Default.WifiOff, contentDescription = null, tint = Color.White, modifier = Modifier.size(32.dp))
                Spacer(Modifier.height(8.dp))
                Text("Couldn't load the video", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Check your connection and try again.", color = Color.White.copy(alpha = 0.7f), style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.height(12.dp))
                Button(onClick = { startPlayback() }) {
                    Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Retry")
                }
            }
        }
    }

    if (fullscreen) {
        FullscreenPlayerDialog(player = player, onExit = { fullscreen = false })
    }
}

@androidx.annotation.OptIn(UnstableApi::class)
@Composable
private fun FullscreenPlayerDialog(player: ExoPlayer, onExit: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }

    DisposableEffect(activity) {
        val previous = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose { activity?.requestedOrientation = previous }
    }

    Dialog(
        onDismissRequest = onExit,
        properties = DialogProperties(
            usePlatformDefaultWidth = false,
            decorFitsSystemWindows = false,
            dismissOnClickOutside = false
        )
    ) {
        val window = (LocalView.current.parent as? DialogWindowProvider)?.window
        SideEffect {
            window?.let { w ->
                w.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                w.setBackgroundDrawable(ColorDrawable(AndroidColor.BLACK))
                WindowCompat.setDecorFitsSystemWindows(w, false)
                WindowInsetsControllerCompat(w, w.decorView).apply {
                    hide(WindowInsetsCompat.Type.systemBars())
                    systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                }
            }
        }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        layoutParams = FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                        useController = true
                        setShowBuffering(PlayerView.SHOW_BUFFERING_ALWAYS)
                        setFullscreenButtonClickListener { onExit() }
                        this.player = player
                    }
                },
                onRelease = { view -> view.player = null },
                modifier = Modifier.fillMaxSize()
            )
            IconButton(
                onClick = onExit,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .windowInsetsPadding(WindowInsets.displayCutout)
                    .padding(12.dp)
                    .background(Color.Black.copy(alpha = 0.5f), CircleShape)
            ) {
                Icon(Icons.Default.Close, contentDescription = "Exit fullscreen", tint = Color.White)
            }
        }
    }
}
