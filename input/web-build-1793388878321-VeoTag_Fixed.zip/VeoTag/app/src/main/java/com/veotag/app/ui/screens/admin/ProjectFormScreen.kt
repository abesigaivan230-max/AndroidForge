package com.veotag.app.ui.screens.admin

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import com.veotag.app.data.model.Project
import com.veotag.app.data.model.ProjectInsert
import com.veotag.app.data.remote.SupabaseProvider
import com.veotag.app.data.repository.ProjectRepository
import com.veotag.app.ui.components.CoverFallback
import com.veotag.app.ui.components.PrimaryButton
import com.veotag.app.ui.components.ProjectCard
import com.veotag.app.ui.components.shimmerBrush
import com.veotag.app.ui.theme.SuccessGreenSoft
import com.veotag.app.util.ImageUtils
import com.veotag.app.util.VideoInfo
import com.veotag.app.util.VideoUtils
import kotlinx.coroutines.launch
import kotlinx.serialization.json.buildJsonObject
import kotlinx.serialization.json.put
import java.util.UUID

private enum class UploadStage { Idle, Uploading, Done }

private val DEFAULT_CATEGORIES = listOf(
    "Robotics", "Agriculture", "Science", "Engineering", "Technology", "Health", "Energy", "Arts & Design"
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectFormScreen(
    projectId: String?,
    onSaved: () -> Unit,
    onBack: () -> Unit
) {
    val repo = remember { ProjectRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val isEdit = projectId != null

    var title by remember { mutableStateOf("") }
    var shortDescription by remember { mutableStateOf("") }
    var creatorsNames by remember { mutableStateOf("") }
    var schoolOrganization by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var additionalDetails by remember { mutableStateOf("") }

    var coverUri by remember { mutableStateOf<Uri?>(null) }
    var existingCoverPath by remember { mutableStateOf<String?>(null) }
    var coverRemoved by remember { mutableStateOf(false) }
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var videoInfo by remember { mutableStateOf<VideoInfo?>(null) }
    var existingVideoPath by remember { mutableStateOf<String?>(null) }
    var wasPublished by remember { mutableStateOf(false) }

    var saving by remember { mutableStateOf(false) }
    var coverStage by remember { mutableStateOf(UploadStage.Idle) }
    var videoStage by remember { mutableStateOf(UploadStage.Idle) }
    var submitted by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var suggestions by remember { mutableStateOf(DEFAULT_CATEGORIES) }

    // Native Android photo picker (falls back to the system picker where unavailable).
    val coverPicker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            if (ImageUtils.isSupported(context, uri)) {
                coverUri = uri
                coverRemoved = false
                error = null
            } else {
                error = "Unsupported image type. Please choose a JPG, PNG or WebP photo."
            }
        }
    }
    val videoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            scope.launch {
                val info = VideoUtils.inspectAsync(context, uri)
                when {
                    info.sizeBytes > VideoUtils.MAX_BYTES -> error = "Video must be 100 MB or smaller."
                    info.durationMs != null && info.durationMs > VideoUtils.MAX_DURATION_MS -> error = "Video must be 5 minutes or shorter."
                    else -> {
                        videoUri = uri
                        videoInfo = info
                        error = null
                    }
                }
            }
        }
    }

    LaunchedEffect(projectId) {
        repo.getDistinctCategories().onSuccess { found ->
            suggestions = (found + DEFAULT_CATEGORIES).distinctBy { it.lowercase() }.take(14)
        }
        if (projectId != null) {
            repo.getProjectById(projectId, publishedOnly = false).onSuccess { p: Project? ->
                if (p != null) {
                    title = p.title
                    shortDescription = p.shortDescription
                    creatorsNames = p.creatorsNames.orEmpty()
                    schoolOrganization = p.schoolOrganization.orEmpty()
                    category = p.category
                    additionalDetails = p.additionalDetails.orEmpty()
                    existingVideoPath = p.videoPath
                    existingCoverPath = p.thumbnailPath?.takeIf { it.isNotBlank() }
                    wasPublished = p.isPublished
                }
            }
        }
    }

    fun save(publish: Boolean) {
        if (saving) return  // blocks duplicate submissions
        submitted = true
        when {
            title.isBlank() || shortDescription.isBlank() || category.isBlank() -> {
                error = "Please fill in the title, short description and category."
                return
            }
            !isEdit && videoUri == null -> {
                error = "Please select a project video."
                return
            }
        }
        scope.launch {
            saving = true
            error = null
            coverStage = UploadStage.Idle
            videoStage = UploadStage.Idle
            val uploaded = mutableListOf<String>()   // files this attempt created, removed again on failure
            try {
                if (!repo.isAuthorizedAdmin()) {
                    error = "Not authorized"
                    return@launch
                }
                val folder = projectId ?: UUID.randomUUID().toString()

                var newCover: String? = null
                coverUri?.let { uri ->
                    coverStage = UploadStage.Uploading
                    val r = repo.uploadCover(context, uri, folder)
                    if (r.isFailure) {
                        error = "Cover photo upload failed: ${r.exceptionOrNull()?.message ?: "unknown error"}"
                        coverStage = UploadStage.Idle
                        return@launch
                    }
                    newCover = r.getOrThrow()
                    uploaded += newCover!!
                    coverStage = UploadStage.Done
                }

                var newVideo: String? = null
                videoUri?.let { uri ->
                    videoStage = UploadStage.Uploading
                    val r = repo.uploadVideo(context, uri, folder)
                    if (r.isFailure) {
                        error = "Video upload failed: ${r.exceptionOrNull()?.message ?: "unknown error"}"
                        videoStage = UploadStage.Idle
                        uploaded.forEach { p -> repo.deleteFile(p) }
                        return@launch
                    }
                    newVideo = r.getOrThrow()
                    uploaded += newVideo!!
                    videoStage = UploadStage.Done
                }

                if (isEdit && projectId != null) {
                    val update = buildJsonObject {
                        put("title", title.trim())
                        put("short_description", shortDescription.trim())
                        put("creators_names", creatorsNames.trim().ifBlank { null })
                        put("school_organization", schoolOrganization.trim().ifBlank { null })
                        put("category", category.trim())
                        put("additional_details", additionalDetails.trim().ifBlank { null })
                        put("is_published", publish)
                        if (newVideo != null) put("video_path", newVideo)
                        if (newCover != null) put("thumbnail_path", newCover)
                        else if (coverRemoved) put("thumbnail_path", null as String?)
                    }
                    val result = repo.updateProjectFields(projectId, update)
                    if (result.isSuccess) {
                        // Only now remove the files this project previously owned.
                        if (newVideo != null) existingVideoPath?.takeIf { it != newVideo }?.let { repo.deleteFile(it) }
                        if (newCover != null || coverRemoved) existingCoverPath?.takeIf { it != newCover }?.let { repo.deleteFile(it) }
                        onSaved()
                    } else {
                        uploaded.forEach { repo.deleteFile(it) }
                        error = "Failed to save changes: ${result.exceptionOrNull()?.message ?: "unknown error"}"
                    }
                } else {
                    val insert = ProjectInsert(
                        title = title.trim(),
                        videoPath = newVideo!!,
                        shortDescription = shortDescription.trim(),
                        creatorsNames = creatorsNames.trim().ifBlank { null },
                        schoolOrganization = schoolOrganization.trim().ifBlank { null },
                        category = category.trim(),
                        additionalDetails = additionalDetails.trim().ifBlank { null },
                        thumbnailPath = newCover,
                        isPublished = publish
                    )
                    val result = repo.createProject(insert)
                    if (result.isSuccess) {
                        onSaved()
                    } else {
                        uploaded.forEach { repo.deleteFile(it) }
                        error = "Failed to create project: ${result.exceptionOrNull()?.message ?: "unknown error"}"
                    }
                }
            } catch (e: Exception) {
                uploaded.forEach { repo.deleteFile(it) }
                error = e.message ?: "Unexpected error"
            } finally {
                saving = false
            }
        }
    }

    val hasCover = coverUri != null || (existingCoverPath != null && !coverRemoved)

    Column(Modifier.fillMaxSize().imePadding()) {
        TopAppBar(
            title = { Text(if (isEdit) "Edit Project" else "Add Project", fontWeight = FontWeight.SemiBold) },
            navigationIcon = {
                IconButton(onClick = onBack, enabled = !saving) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )

        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
            Column(
                modifier = Modifier
                    .widthIn(max = 640.dp)
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp)
            ) {
                SectionLabel("Project details")
                OutlinedTextField(
                    value = title, onValueChange = { title = it },
                    label = { Text("Title *") }, singleLine = true,
                    isError = submitted && title.isBlank(), enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = shortDescription, onValueChange = { shortDescription = it },
                    label = { Text("Short description *") }, minLines = 2, maxLines = 4,
                    isError = submitted && shortDescription.isBlank(), enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = category, onValueChange = { category = it },
                    label = { Text("Category *") }, singleLine = true,
                    isError = submitted && category.isBlank(), enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(8.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    suggestions.forEach { c ->
                        FilterChip(
                            selected = category.trim().equals(c, ignoreCase = true),
                            onClick = { category = c },
                            enabled = !saving,
                            label = { Text(c) }
                        )
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = creatorsNames, onValueChange = { creatorsNames = it },
                    label = { Text("Creators' names") }, singleLine = true, enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = schoolOrganization, onValueChange = { schoolOrganization = it },
                    label = { Text("School / Organization") }, singleLine = true, enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(
                    value = additionalDetails, onValueChange = { additionalDetails = it },
                    label = { Text("Additional details") },
                    supportingText = { Text("Tip: use “Label: value” lines (e.g. “Year: 2026”) for a tidy details card.") },
                    minLines = 3, maxLines = 6, enabled = !saving,
                    modifier = Modifier.fillMaxWidth()
                )

                // ---------- Cover photo ----------
                Spacer(Modifier.height(24.dp))
                SectionLabel("Project Cover Photo")
                Text(
                    "Shown on Home, Explore and search. Use a photo of the prototype, the team or the finished product. Separate from the video.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(Modifier.height(10.dp))
                val shape = MaterialTheme.shapes.medium
                Box(
                    Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 9f)
                        .clip(shape)
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .border(BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant), shape),
                    contentAlignment = Alignment.Center
                ) {
                    val model: Any? = when {
                        coverUri != null -> coverUri
                        existingCoverPath != null && !coverRemoved -> SupabaseProvider.publicThumbnailUrl(existingCoverPath)
                        else -> null
                    }
                    if (model != null) {
                        SubcomposeAsyncImage(
                            model = model,
                            contentDescription = "Cover photo preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize(),
                            loading = { Box(Modifier.fillMaxSize().background(shimmerBrush())) },
                            error = { CoverFallback(title, category, Modifier.fillMaxSize()) }
                        )
                    } else {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(36.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Spacer(Modifier.height(6.dp))
                            Text("No cover photo yet", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                        }
                    }
                }
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { coverPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) },
                        enabled = !saving, modifier = Modifier.weight(1f)
                    ) {
                        Icon(if (hasCover) Icons.Default.SwapHoriz else Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(if (hasCover) "Replace image" else "Select image")
                    }
                    if (hasCover) {
                        OutlinedButton(
                            onClick = { coverUri = null; coverRemoved = existingCoverPath != null },
                            enabled = !saving, modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.error)
                            Spacer(Modifier.width(8.dp))
                            Text("Remove")
                        }
                    }
                }
                UploadStatusRow("Cover photo", coverStage)

                // ---------- Video ----------
                Spacer(Modifier.height(24.dp))
                SectionLabel("Project Video")
                OutlinedButton(
                    onClick = { videoPicker.launch(arrayOf("video/*")) },
                    enabled = !saving, modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(if (videoUri != null || existingVideoPath != null) "Replace video" else "Select video *")
                }
                Spacer(Modifier.height(6.dp))
                val videoText = when {
                    videoInfo != null -> "${videoInfo!!.displayName} · ${VideoUtils.formatSize(videoInfo!!.sizeBytes)}" +
                        (videoInfo!!.durationMs?.let { " · ${VideoUtils.formatDuration(it)}" } ?: "")
                    existingVideoPath != null -> "Current video is kept unless you replace it."
                    submitted && !isEdit -> "A video is required."
                    else -> "MP4 or WebM, up to 100 MB and 5 minutes."
                }
                Text(
                    videoText, style = MaterialTheme.typography.bodySmall,
                    color = if (submitted && !isEdit && videoUri == null) MaterialTheme.colorScheme.error
                    else MaterialTheme.colorScheme.onSurfaceVariant
                )
                UploadStatusRow("Video", videoStage)

                // ---------- Preview ----------
                if (title.isNotBlank()) {
                    Spacer(Modifier.height(24.dp))
                    SectionLabel("Preview")
                    ProjectCard(
                        project = Project(
                            id = projectId ?: "preview",
                            title = title.trim(),
                            videoPath = existingVideoPath ?: "preview",
                            shortDescription = shortDescription.trim(),
                            creatorsNames = creatorsNames.trim().ifBlank { null },
                            schoolOrganization = schoolOrganization.trim().ifBlank { null },
                            category = category.trim().ifBlank { "Category" },
                            thumbnailPath = existingCoverPath?.takeIf { !coverRemoved }
                        ),
                        onClick = {},
                        coverOverride = coverUri
                    )
                }

                error?.let {
                    Spacer(Modifier.height(16.dp))
                    Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
                }

                Spacer(Modifier.height(24.dp))
                PrimaryButton(
                    text = if (isEdit && wasPublished) "Save & keep published" else "Publish",
                    onClick = { save(true) },
                    loading = saving
                )
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    onClick = { save(false) },
                    enabled = !saving,
                    modifier = Modifier.fillMaxWidth().height(52.dp)
                ) {
                    Text(if (isEdit && wasPublished) "Save as draft (unpublish)" else "Save as draft")
                }
                Spacer(Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold,
        color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.padding(bottom = 10.dp)
    )
}

@Composable
private fun UploadStatusRow(label: String, stage: UploadStage) {
    when (stage) {
        UploadStage.Idle -> Unit
        UploadStage.Uploading -> Column(Modifier.padding(top = 10.dp)) {
            Text("Uploading $label…", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small))
        }
        UploadStage.Done -> Row(Modifier.padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SuccessGreenSoft, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("$label uploaded", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
