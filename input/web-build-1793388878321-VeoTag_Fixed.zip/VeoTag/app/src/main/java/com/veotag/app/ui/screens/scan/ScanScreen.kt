package com.veotag.app.ui.screens.scan

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import com.veotag.app.util.QrImageDecoder
import com.veotag.app.util.QrImageResult
import kotlinx.coroutines.launch
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.view.ViewGroup
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.accompanist.permissions.shouldShowRationale
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import com.veotag.app.ui.components.VeoTagLogo
import com.veotag.app.ui.theme.BluePrimary
import com.veotag.app.util.QrUtils
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ScanScreen(
    onProjectScanned: (String) -> Unit,
    onAdminShortcut: () -> Unit
) {
    val context = LocalContext.current
    val permissionState = rememberPermissionState(Manifest.permission.CAMERA)
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var statusMessage by remember { mutableStateOf("Align QR code within the frame") }
    var torchOn by remember { mutableStateOf(false) }
    var cameraRef by remember { mutableStateOf<Camera?>(null) }
    val scanningLock = remember { AtomicBoolean(false) }
    var decoding by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    // Native Android photo picker (falls back to the system document picker on older / OEM builds).
    // The result comes straight back to VeoTag; no share sheet or external app is involved.
    val galleryPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult   // user cancelled
        if (decoding) return@rememberLauncherForActivityResult
        decoding = true
        errorMessage = null
        statusMessage = "Reading image…"
        scope.launch {
            val result = QrImageDecoder.decode(context, uri)
            when (result) {
                is QrImageResult.Found -> {
                    statusMessage = "Project found — opening…"
                    onProjectScanned(result.projectId)
                }
                QrImageResult.NoQr -> errorMessage = "No QR code detected in this image."
                QrImageResult.InvalidQr -> errorMessage = "This QR code is not a valid VeoTag project code."
                QrImageResult.MultipleQr -> errorMessage = "Multiple VeoTag QR codes found. Choose an image with a single code."
                is QrImageResult.Failed -> errorMessage = result.reason
            }
            if (result !is QrImageResult.Found) statusMessage = "Align QR code within the frame"
            decoding = false
        }
    }
    val openGallery = {
        galleryPicker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            VeoTagLogo(size = 40, onMultiTap = onAdminShortcut)
            Spacer(Modifier.height(8.dp))
            Text(
                "Scan Project QR",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Text(
                statusMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
        }

        if (permissionState.status.isGranted) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .padding(horizontal = 16.dp)
                    .clip(RoundedCornerShape(20.dp))
            ) {
                CameraPreview(
                    onBarcodeDetected = { raw ->
                        if (scanningLock.compareAndSet(false, true)) {
                            val id = QrUtils.parsePayload(raw)
                            if (id != null) {
                                statusMessage = "Project found — opening…"
                                onProjectScanned(id)
                            } else {
                                errorMessage = "This QR code is not a valid VeoTag project code."
                                statusMessage = "Invalid QR code"
                            }
                            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                                scanningLock.set(false)
                                statusMessage = "Align QR code within the frame"
                            }, 2500)
                        }
                    },
                    onCameraReady = { cameraRef = it },
                    torchEnabled = torchOn
                )
                ScannerOverlay()
                Row(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .fillMaxWidth()
                        .padding(horizontal = 20.dp, vertical = 20.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ScanRoundButton(
                        icon = if (torchOn) Icons.Default.FlashOn else Icons.Default.FlashOff,
                        description = if (torchOn) "Turn flashlight off" else "Turn flashlight on",
                        highlighted = torchOn,
                        onClick = {
                            torchOn = !torchOn
                            cameraRef?.cameraControl?.enableTorch(torchOn)
                        }
                    )
                    ScanRoundButton(
                        icon = Icons.Default.PhotoLibrary,
                        description = "Scan QR code from gallery",
                        highlighted = false,
                        loading = decoding,
                        onClick = { openGallery() }
                    )
                }
            }
            errorMessage?.let {
                Text(
                    it,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(16.dp),
                    textAlign = TextAlign.Center
                )
            }
            Spacer(Modifier.height(12.dp))
        } else {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        "Camera access is required to scan project QR codes.",
                        textAlign = TextAlign.Center,
                        style = MaterialTheme.typography.bodyLarge
                    )
                    Spacer(Modifier.height(20.dp))
                    Button(onClick = { openGallery() }) {
                        Icon(Icons.Default.PhotoLibrary, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Scan from gallery instead")
                    }
                    errorMessage?.let {
                        Spacer(Modifier.height(12.dp))
                        Text(it, color = MaterialTheme.colorScheme.error, textAlign = TextAlign.Center)
                    }
                    Spacer(Modifier.height(12.dp))
                    if (permissionState.status.shouldShowRationale) {
                        Button(onClick = { permissionState.launchPermissionRequest() }) {
                            Text("Grant Permission")
                        }
                    } else {
                        OutlinedButton(onClick = {
                            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                data = Uri.fromParts("package", context.packageName, null)
                            }
                            context.startActivity(intent)
                        }) {
                            Text("Open Settings")
                        }
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { permissionState.launchPermissionRequest() }) {
                            Text("Request Permission")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ScanRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    description: String,
    highlighted: Boolean,
    onClick: () -> Unit,
    loading: Boolean = false
) {
    Box(
        modifier = Modifier
            .size(56.dp)
            .clip(CircleShape)
            .background(if (highlighted) MaterialTheme.colorScheme.secondary else Color.Black.copy(alpha = 0.55f))
            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape)
            .clickable(enabled = !loading, onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center
    ) {
        if (loading) {
            CircularProgressIndicator(modifier = Modifier.size(24.dp), color = Color.White, strokeWidth = 2.dp)
        } else {
            Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(26.dp))
        }
    }
}

@Composable
private fun ScannerOverlay() {
    val transition = rememberInfiniteTransition(label = "laser")
    val laserY by transition.animateFloat(
        initialValue = 0.15f,
        targetValue = 0.85f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laserY"
    )

    Canvas(
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
    ) {
        val w = size.width
        val h = size.height
        val frameSize = minOf(w, h) * 0.72f
        val left = (w - frameSize) / 2f
        val top = (h - frameSize) / 2f

        // Dim outside frame
        drawRect(Color.Black.copy(alpha = 0.55f))
        drawRoundRect(
            color = Color.Transparent,
            topLeft = Offset(left, top),
            size = Size(frameSize, frameSize),
            cornerRadius = CornerRadius(24f, 24f),
            blendMode = BlendMode.Clear
        )

        // Frame border
        drawRoundRect(
            color = BluePrimary,
            topLeft = Offset(left, top),
            size = Size(frameSize, frameSize),
            cornerRadius = CornerRadius(24f, 24f),
            style = Stroke(width = 4.dp.toPx())
        )

        // Corner accents
        val cornerLen = frameSize * 0.12f
        val stroke = 6.dp.toPx()
        val corners = listOf(
            Offset(left, top) to listOf(Offset(cornerLen, 0f), Offset(0f, cornerLen)),
            Offset(left + frameSize, top) to listOf(Offset(-cornerLen, 0f), Offset(0f, cornerLen)),
            Offset(left, top + frameSize) to listOf(Offset(cornerLen, 0f), Offset(0f, -cornerLen)),
            Offset(left + frameSize, top + frameSize) to listOf(Offset(-cornerLen, 0f), Offset(0f, -cornerLen))
        )
        corners.forEach { (origin, dirs) ->
            dirs.forEach { dir ->
                drawLine(
                    color = Color.White,
                    start = origin,
                    end = origin + dir,
                    strokeWidth = stroke
                )
            }
        }

        // Laser line
        val ly = top + frameSize * laserY
        drawLine(
            color = BluePrimary.copy(alpha = 0.9f),
            start = Offset(left + 12f, ly),
            end = Offset(left + frameSize - 12f, ly),
            strokeWidth = 3.dp.toPx()
        )
        drawLine(
            color = BluePrimary.copy(alpha = 0.25f),
            start = Offset(left + 12f, ly),
            end = Offset(left + frameSize - 12f, ly),
            strokeWidth = 12.dp.toPx()
        )
    }
}

@androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
@Composable
private fun CameraPreview(
    onBarcodeDetected: (String) -> Unit,
    onCameraReady: (Camera) -> Unit,
    torchEnabled: Boolean
) {
    val lifecycleOwner = LocalLifecycleOwner.current
    val context = LocalContext.current
    val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
    val scanner = remember { BarcodeScanning.getClient() }

    DisposableEffect(Unit) {
        onDispose {
            cameraExecutor.shutdown()
            scanner.close()
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx).apply {
                layoutParams = ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.MATCH_PARENT
                )
                scaleType = PreviewView.ScaleType.FILL_CENTER
            }
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    val mediaImage = imageProxy.image
                    if (mediaImage != null) {
                        val image = InputImage.fromMediaImage(
                            mediaImage,
                            imageProxy.imageInfo.rotationDegrees
                        )
                        scanner.process(image)
                            .addOnSuccessListener { barcodes ->
                                for (barcode in barcodes) {
                                    if (barcode.format == Barcode.FORMAT_QR_CODE) {
                                        barcode.rawValue?.let { onBarcodeDetected(it) }
                                    }
                                }
                            }
                            .addOnCompleteListener { imageProxy.close() }
                    } else {
                        imageProxy.close()
                    }
                }
                try {
                    cameraProvider.unbindAll()
                    val camera = cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        CameraSelector.DEFAULT_BACK_CAMERA,
                        preview,
                        analysis
                    )
                    onCameraReady(camera)
                    camera.cameraControl.enableTorch(torchEnabled)
                } catch (_: Exception) {
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        modifier = Modifier.fillMaxSize()
    )
}
