package com.veotag.app.util

/** Turns raw database labels like "FABRIC<TEXTILE>" into "Fabric & Textile". Never returns null markup. */
fun String?.prettyCategory(): String {
    val raw = this?.trim().orEmpty()
    if (raw.isEmpty()) return "Uncategorised"
    val parts = raw.split(Regex("[<>/|_,;+]+|\\s+&\\s+|\\s+and\\s+", RegexOption.IGNORE_CASE))
        .map { it.trim() }
        .filter { it.isNotEmpty() }
    if (parts.isEmpty()) return "Uncategorised"
    return parts.joinToString(" & ") { part ->
        part.lowercase().split(' ').filter { it.isNotEmpty() }.joinToString(" ") { w ->
            w.replaceFirstChar { c -> c.uppercase() }
        }
    }
}

/** Returns the trimmed text or null when it is blank or the literal "null". */
fun String?.cleanOrNull(): String? =
    this?.trim()?.takeIf { it.isNotEmpty() && !it.equals("null", ignoreCase = true) }
