package com.veotag.app.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream

object ImageUtils {
    val SUPPORTED_MIME = setOf("image/jpeg", "image/jpg", "image/png", "image/webp")
    const val MAX_SOURCE_BYTES = 25L * 1024 * 1024
    private const val COVER_MAX_EDGE = 1600

    fun isSupported(context: Context, uri: Uri): Boolean {
        val mime = context.contentResolver.getType(uri)?.lowercase()
        if (mime != null) return mime in SUPPORTED_MIME
        val name = uri.lastPathSegment?.lowercase().orEmpty()
        return listOf(".jpg", ".jpeg", ".png", ".webp").any { name.endsWith(it) }
    }

    /** Decodes [uri] down to at most [maxEdge] px on its longest side without loading the full-size bitmap. */
    fun decodeSampled(context: Context, uri: Uri, maxEdge: Int): Bitmap? {
        val resolver = context.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: return null
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / (sample * 2) >= maxEdge) sample *= 2
        val opts = BitmapFactory.Options().apply { inSampleSize = sample }
        return resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
    }

    /** Re-encodes a picked photo as a ≤1600 px JPEG so covers stay small and load fast on mobile data. */
    suspend fun prepareCover(context: Context, uri: Uri): ByteArray = withContext(Dispatchers.IO) {
        if (!isSupported(context, uri)) throw IllegalStateException("Unsupported image. Use JPG, PNG or WebP.")
        val decoded = decodeSampled(context, uri, COVER_MAX_EDGE)
            ?: throw IllegalStateException("Could not read this image.")
        val scale = COVER_MAX_EDGE.toFloat() / maxOf(decoded.width, decoded.height)
        val scaled = if (scale < 1f)
            Bitmap.createScaledBitmap(decoded, (decoded.width * scale).toInt(), (decoded.height * scale).toInt(), true)
        else decoded
        // Flatten transparency (PNG/WebP) onto white, since JPEG has no alpha channel.
        val flat = Bitmap.createBitmap(scaled.width, scaled.height, Bitmap.Config.ARGB_8888)
        Canvas(flat).apply { drawColor(Color.WHITE); drawBitmap(scaled, 0f, 0f, null) }
        val out = ByteArrayOutputStream()
        flat.compress(Bitmap.CompressFormat.JPEG, 85, out)
        if (scaled !== decoded) decoded.recycle()
        if (flat !== scaled) scaled.recycle()
        flat.recycle()
        out.toByteArray()
    }
}
