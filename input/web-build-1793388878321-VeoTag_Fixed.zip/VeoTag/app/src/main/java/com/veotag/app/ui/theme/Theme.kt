package com.veotag.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LightColors = lightColorScheme(
    primary = BrandIndigo,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFE0E4FF),
    onPrimaryContainer = Color(0xFF1B1A55),
    secondary = BrandOrange,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFE9D6),
    onSecondaryContainer = Color(0xFF7A2E05),
    tertiary = BrandViolet,
    onTertiary = Color.White,
    tertiaryContainer = Color(0xFFEBE0FF),
    onTertiaryContainer = Color(0xFF3B0F8C),
    background = LightBackground,
    onBackground = LightOnSurface,
    surface = LightSurface,
    onSurface = LightOnSurface,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LightOnSurfaceVariant,
    error = ErrorRed,
    onError = Color.White,
    outline = LightOutline,
    outlineVariant = LightOutlineVariant,
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFFA5B4FC),
    onPrimary = Color(0xFF1E1B4B),
    primaryContainer = Color(0xFF343A8F),
    onPrimaryContainer = Color(0xFFE0E4FF),
    secondary = BrandOrangeSoft,
    onSecondary = Color(0xFF3B1700),
    secondaryContainer = Color(0xFF7A3305),
    onSecondaryContainer = Color(0xFFFFE9D6),
    tertiary = Color(0xFFC4B5FD),
    onTertiary = Color(0xFF2E1065),
    tertiaryContainer = Color(0xFF4C2A9E),
    onTertiaryContainer = Color(0xFFEBE0FF),
    background = DarkBackground,
    onBackground = DarkOnSurface,
    surface = DarkSurface,
    onSurface = DarkOnSurface,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = DarkOnSurfaceVariant,
    error = ErrorRedSoft,
    onError = Color(0xFF3B0A0A),
    outline = DarkOutline,
    outlineVariant = DarkOutlineVariant,
)

private val VeoTagShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp),
)

/** Brand gradient used by the Home header, logo and placeholder thumbnails. */
fun brandGradient(): Brush = Brush.linearGradient(listOf(BrandBlue, BrandIndigo, BrandViolet))

/**
 * System bar colours and icon contrast are handled by `enableEdgeToEdge()` in MainActivity, which is configured dark-only.
 */
@Composable
fun VeoTagTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit,
) {
    MaterialTheme(
        colorScheme = if (darkTheme) DarkColors else LightColors,
        typography = Typography,
        shapes = VeoTagShapes,
        content = content,
    )
}
