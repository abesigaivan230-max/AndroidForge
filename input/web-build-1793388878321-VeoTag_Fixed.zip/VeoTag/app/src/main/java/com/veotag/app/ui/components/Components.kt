package com.veotag.app.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.composed
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Inbox
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.veotag.app.util.cleanOrNull
import com.veotag.app.util.prettyCategory
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.material.icons.filled.School
import androidx.compose.ui.platform.LocalContext
import com.veotag.app.data.model.Project
import com.veotag.app.data.remote.SupabaseProvider
import com.veotag.app.ui.theme.BrandBlue
import com.veotag.app.ui.theme.BrandOrangeSoft
import com.veotag.app.ui.theme.BrandViolet
import com.veotag.app.ui.theme.brandGradient

/** Vector-drawn brand mark (scan brackets + play triangle) that matches the launcher icon. */
@Composable
fun VeoTagLogo(
    modifier: Modifier = Modifier,
    size: Int = 48,
    glass: Boolean = false,
    onMultiTap: (() -> Unit)? = null
) {
    val taps = remember { androidx.compose.runtime.mutableIntStateOf(0) }
    val lastTap = remember { androidx.compose.runtime.mutableLongStateOf(0L) }

    Box(
        modifier = modifier
            .size(size.dp)
            .clip(RoundedCornerShape((size * 0.26f).dp))
            .background(
                if (glass) Brush.linearGradient(listOf(Color.White.copy(0.28f), Color.White.copy(0.12f)))
                else brandGradient()
            )
            .then(
                if (onMultiTap != null) {
                    Modifier.clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) {
                        val now = System.currentTimeMillis()
                        if (now - lastTap.longValue < 700) {
                            taps.intValue++
                            if (taps.intValue >= 5) {
                                taps.intValue = 0
                                onMultiTap()
                            }
                        } else {
                            taps.intValue = 1
                        }
                        lastTap.longValue = now
                    }
                } else Modifier
            ),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize().semantics { contentDescription = "VeoTag" }) {
            val u = this.size.minDimension / 108f
            val stroke = Stroke(width = 5f * u, cap = StrokeCap.Round, join = StrokeJoin.Round)
            val bracket = Path().apply {
                moveTo(30f * u, 42f * u); lineTo(30f * u, 34f * u)
                cubicTo(30f * u, 31.8f * u, 31.8f * u, 30f * u, 34f * u, 30f * u); lineTo(42f * u, 30f * u)
                moveTo(66f * u, 30f * u); lineTo(74f * u, 30f * u)
                cubicTo(76.2f * u, 30f * u, 78f * u, 31.8f * u, 78f * u, 34f * u); lineTo(78f * u, 42f * u)
                moveTo(78f * u, 66f * u); lineTo(78f * u, 74f * u)
                cubicTo(78f * u, 76.2f * u, 76.2f * u, 78f * u, 74f * u, 78f * u); lineTo(66f * u, 78f * u)
                moveTo(42f * u, 78f * u); lineTo(34f * u, 78f * u)
                cubicTo(31.8f * u, 78f * u, 30f * u, 76.2f * u, 30f * u, 74f * u); lineTo(30f * u, 66f * u)
            }
            drawPath(bracket, Color.White, style = stroke)
            val play = Path().apply {
                moveTo(49f * u, 45.5f * u); lineTo(49f * u, 62.5f * u); lineTo(63.5f * u, 54f * u); close()
            }
            drawPath(play, BrandOrangeSoft)
        }
    }
}

/** Fade + rise entrance, staggered by [index]. Plays once per [key] (survives rotation / scroll recycling). */
fun Modifier.staggeredEntrance(index: Int, key: Any = Unit): Modifier = composed {
    var shown by rememberSaveable(key) { mutableStateOf(false) }
    val alpha = remember { Animatable(if (shown) 1f else 0f) }
    val lift = remember { Animatable(if (shown) 0f else 36f) }
    LaunchedEffect(key) {
        if (!shown) {
            delay((index.coerceAtMost(8) * 70).toLong())
            launch { alpha.animateTo(1f, tween(380)) }
            lift.animateTo(0f, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessLow))
            shown = true
        }
    }
    this.graphicsLayer {
        this.alpha = alpha.value
        translationY = lift.value
    }
}

/** Moving highlight for skeleton placeholders. */
@Composable
fun shimmerBrush(): Brush {
    val base = MaterialTheme.colorScheme.surfaceVariant
    val shine = MaterialTheme.colorScheme.surface
    val t = rememberInfiniteTransition(label = "shimmer")
    val x by t.animateFloat(
        initialValue = -400f, targetValue = 1200f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)), label = "shimmerX"
    )
    return Brush.linearGradient(
        colors = listOf(base, shine.copy(alpha = 0.9f), base),
        start = Offset(x, 0f), end = Offset(x + 400f, 200f)
    )
}

@Composable
fun SkeletonCard(modifier: Modifier = Modifier) {
    val brush = shimmerBrush()
    Card(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.medium,
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(120.dp).background(brush))
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.fillMaxWidth(0.7f).height(16.dp).clip(RoundedCornerShape(6.dp)).background(brush))
                Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(brush))
                Box(Modifier.width(80.dp).height(20.dp).clip(RoundedCornerShape(8.dp)).background(brush))
            }
        }
    }
}

@Composable
fun CategoryBadge(category: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.primaryContainer
    ) {
        Text(
            text = category.prettyCategory(),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onPrimaryContainer,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

/** Intentional-looking placeholder used whenever a project has no cover photo (or it fails to load). */
@Composable
fun CoverFallback(title: String, category: String?, modifier: Modifier = Modifier) {
    val palettes = listOf(
        listOf(Color(0xFF1D4ED8), Color(0xFF6D28D9)),
        listOf(Color(0xFF4F46E5), Color(0xFFDB2777)),
        listOf(Color(0xFF0E7490), Color(0xFF4338CA)),
        listOf(Color(0xFF7C3AED), Color(0xFFEA580C)),
    )
    val seed = (category.orEmpty() + title).hashCode().let { if (it == Int.MIN_VALUE) 0 else kotlin.math.abs(it) }
    val colors = palettes[seed % palettes.size]
    Box(
        modifier = modifier.background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val r = this.size.minDimension
            drawCircle(Color.White.copy(alpha = 0.08f), radius = r * 0.62f, center = Offset(this.size.width * 0.88f, this.size.height * 0.1f))
            drawCircle(Color.White.copy(alpha = 0.06f), radius = r * 0.46f, center = Offset(this.size.width * 0.08f, this.size.height * 0.95f))
            drawCircle(Color.White.copy(alpha = 0.10f), radius = r * 0.30f, center = Offset(this.size.width * 0.5f, this.size.height * 0.5f), style = Stroke(width = 2f))
        }
        Text(
            text = title.trim().firstOrNull { it.isLetterOrDigit() }?.uppercase() ?: "V",
            style = MaterialTheme.typography.displayMedium,
            fontWeight = FontWeight.ExtraBold,
            color = Color.White.copy(alpha = 0.92f)
        )
    }
}

@Composable
fun ProjectCard(
    project: Project,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    featured: Boolean = false,
    /** Overrides the stored cover (used by the admin preview to show a not-yet-uploaded local image). */
    coverOverride: Any? = null
) {
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.97f else 1f,
        animationSpec = spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium),
        label = "cardScale"
    )
    val shape = MaterialTheme.shapes.large
    val context = LocalContext.current
    val coverModel: Any? = coverOverride ?: SupabaseProvider.publicThumbnailUrl(project.thumbnailPath)
    val request = remember(coverModel) {
        coverModel?.let { ImageRequest.Builder(context).data(it).crossfade(350).build() }
    }

    Column(
        modifier = modifier
            .scale(scale)
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .clickable(interactionSource = interaction, indication = null, onClick = onClick)
    ) {
        Box(
            Modifier
                .fillMaxWidth()
                .aspectRatio(if (featured) 16f / 10f else 16f / 9f)
                .background(MaterialTheme.colorScheme.surfaceVariant)
        ) {
            if (request != null) {
                SubcomposeAsyncImage(
                    model = request,
                    contentDescription = project.title,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxSize(),
                    loading = { Box(Modifier.fillMaxSize().background(shimmerBrush())) },
                    error = { CoverFallback(project.title, project.category, Modifier.fillMaxSize()) }
                )
            } else {
                CoverFallback(project.title, project.category, Modifier.fillMaxSize())
            }
            // Bottom scrim keeps the badge/play chip legible over any photo.
            Box(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.55f))))
            )
            if (project.videoPath.isNotBlank()) {
                Box(
                    Modifier
                        .align(Alignment.BottomEnd)
                        .padding(10.dp)
                        .size(34.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.55f))
                        .border(1.dp, Color.White.copy(alpha = 0.35f), CircleShape),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.PlayArrow, contentDescription = "Has video", tint = Color.White, modifier = Modifier.size(20.dp))
                }
            }
        }
        Column(Modifier.padding(14.dp)) {
            CategoryBadge(project.category)
            Spacer(Modifier.height(8.dp))
            Text(
                text = project.title.ifBlank { "Untitled project" },
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            val blurb = project.shortDescription.cleanOrNull()
            if (blurb != null) {
                Spacer(Modifier.height(4.dp))
                Text(
                    text = blurb,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
            }
            val byline = project.schoolOrganization.cleanOrNull() ?: project.creatorsNames.cleanOrNull()
            if (byline != null) {
                Spacer(Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        Icons.Default.School, contentDescription = null,
                        tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(14.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = byline,
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}

@Composable
fun LoadingState(modifier: Modifier = Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun EmptyState(
    message: String,
    modifier: Modifier = Modifier,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.Inbox,
            contentDescription = null,
            modifier = Modifier.size(56.dp),
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(0.5f)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        if (actionLabel != null && onAction != null) {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = onAction) { Text(actionLabel) }
        }
    }
}

@Composable
fun ErrorState(
    message: String,
    onRetry: () -> Unit,
    modifier: Modifier = Modifier,
    retryLabel: String = "Retry"
) {
    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(
            Icons.Default.ErrorOutline,
            contentDescription = null,
            modifier = Modifier.size(48.dp),
            tint = MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.height(12.dp))
        Text(
            text = message,
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.error
        )
        Spacer(Modifier.height(16.dp))
        Button(
            onClick = onRetry,
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
        ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(retryLabel)
        }
    }
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false
) {
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        modifier = modifier
            .fillMaxWidth()
            .height(52.dp),
        shape = RoundedCornerShape(14.dp),
        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary, contentColor = MaterialTheme.colorScheme.onPrimary)
    ) {
        if (loading) {
            CircularProgressIndicator(
                modifier = Modifier.size(22.dp),
                color = Color.White,
                strokeWidth = 2.dp
            )
        } else {
            Text(text, style = MaterialTheme.typography.labelLarge)
        }
    }
}

@Composable
fun SectionHeader(title: String, modifier: Modifier = Modifier) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleLarge,
        fontWeight = FontWeight.Bold,
        modifier = modifier.padding(horizontal = 20.dp, vertical = 8.dp)
    )
}
