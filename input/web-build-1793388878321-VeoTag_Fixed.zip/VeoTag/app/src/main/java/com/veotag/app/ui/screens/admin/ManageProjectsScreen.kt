package com.veotag.app.ui.screens.admin

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Label
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import coil.compose.SubcomposeAsyncImage
import com.veotag.app.data.remote.SupabaseProvider
import com.veotag.app.ui.components.CoverFallback
import com.veotag.app.ui.components.shimmerBrush
import com.veotag.app.ui.theme.SuccessGreenSoft
import com.veotag.app.util.prettyCategory
import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.veotag.app.data.model.Project
import com.veotag.app.data.repository.ProjectRepository
import com.veotag.app.ui.theme.BluePrimary
import com.veotag.app.util.QrUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.OutputStream

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ManageProjectsScreen(
    onEdit: (String) -> Unit,
    onPreview: (String) -> Unit,
    onBack: () -> Unit
) {
    val repo = remember { ProjectRepository() }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }
    var deleteTarget by remember { mutableStateOf<Project?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    fun load() {
        scope.launch {
            loading = true
            if (!repo.isAuthorizedAdmin()) {
                error = "Not authorized"
                loading = false
                return@launch
            }
            repo.getAllProjectsAdmin().onSuccess {
                projects = it
                loading = false
            }.onFailure {
                error = "Failed to load projects"
                loading = false
            }
        }
    }

    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize()) {
        TopAppBar(
            title = { Text("Manage Projects") },
            navigationIcon = {
                IconButton(onClick = onBack) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                }
            }
        )

        when {
            loading -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
            }
            error != null -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(error!!, color = MaterialTheme.colorScheme.error)
            }
            projects.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No projects yet")
            }
            else -> LazyColumn(
                contentPadding = PaddingValues(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(projects, key = { it.id }) { project ->
                    AdminProjectCard(
                        project = project,
                        onEdit = { onEdit(project.id) },
                        onPreview = { onPreview(project.id) },
                        onTogglePublish = {
                            scope.launch {
                                repo.setPublished(project.id, !project.isPublished)
                                load()
                            }
                        },
                        onDownloadQr = {
                            scope.launch {
                                val bmp = withContext(Dispatchers.Default) {
                                    QrUtils.generateQrBitmap(project.id, 1024)
                                }
                                saveBitmap(context, bmp, "VeoTag_QR_${project.id.take(8)}.png")
                            }
                        },
                        onDownloadLabel = {
                            scope.launch {
                                val bmp = withContext(Dispatchers.Default) {
                                    QrUtils.generatePrintableLabel(project.id, project.title)
                                }
                                saveBitmap(context, bmp, "VeoTag_Label_${project.id.take(8)}.png")
                            }
                        },
                        onDelete = { deleteTarget = project }
                    )
                }
            }
        }
    }

    deleteTarget?.let { target ->
        AlertDialog(
            onDismissRequest = { deleteTarget = null },
            title = { Text("Delete Project") },
            text = { Text("Are you sure you want to delete \"${target.title}\"? This cannot be undone.") },
            confirmButton = {
                TextButton(onClick = {
                    scope.launch {
                        // Delete the row first; only remove its own files once that succeeded.
                        val deleted = repo.deleteProject(target.id)
                        if (deleted.isSuccess) {
                            if (target.videoPath.isNotBlank()) repo.deleteFile(target.videoPath)
                            target.thumbnailPath?.takeIf { it.isNotBlank() }?.let { repo.deleteFile(it) }
                        } else {
                            Toast.makeText(context, "Couldn't delete project. Try again.", Toast.LENGTH_SHORT).show()
                        }
                        deleteTarget = null
                        load()
                    }
                }) {
                    Text("Delete", color = MaterialTheme.colorScheme.error)
                }
            },
            dismissButton = {
                TextButton(onClick = { deleteTarget = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
private fun AdminProjectCard(
    project: Project,
    onEdit: () -> Unit,
    onPreview: () -> Unit,
    onTogglePublish: () -> Unit,
    onDownloadQr: () -> Unit,
    onDownloadLabel: () -> Unit,
    onDelete: () -> Unit
) {
    val shape = MaterialTheme.shapes.medium
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(MaterialTheme.colorScheme.surface)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, shape)
            .padding(14.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val cover = SupabaseProvider.publicThumbnailUrl(project.thumbnailPath)
            Box(Modifier.size(72.dp).clip(RoundedCornerShape(14.dp))) {
                if (cover != null) {
                    SubcomposeAsyncImage(
                        model = cover,
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                        loading = { Box(Modifier.fillMaxSize().background(shimmerBrush())) },
                        error = { CoverFallback(project.title, project.category, Modifier.fillMaxSize()) }
                    )
                } else {
                    CoverFallback(project.title, project.category, Modifier.fillMaxSize())
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    project.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(if (project.isPublished) SuccessGreenSoft else MaterialTheme.colorScheme.secondary)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (project.isPublished) "Published" else "Draft",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "  •  " + project.category.prettyCategory(),
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
        Spacer(Modifier.height(6.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onEdit) { Icon(Icons.Default.Edit, contentDescription = "Edit") }
            IconButton(onClick = onTogglePublish) {
                Icon(
                    if (project.isPublished) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                    contentDescription = if (project.isPublished) "Unpublish" else "Publish"
                )
            }
            if (project.isPublished) {
                IconButton(onClick = onPreview) { Icon(Icons.Default.OpenInNew, contentDescription = "Preview") }
            }
            IconButton(onClick = onDownloadQr) { Icon(Icons.Default.QrCode, contentDescription = "Download QR") }
            IconButton(onClick = onDownloadLabel) {
                Icon(Icons.Default.Label, contentDescription = "Download printable label", tint = MaterialTheme.colorScheme.secondary)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error)
            }
        }
    }
}

private fun saveBitmap(context: Context, bitmap: Bitmap, fileName: String) {
    try {
        val resolver = context.contentResolver
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val contentValues = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
                put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            }
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, contentValues)
            if (uri != null) {
                resolver.openOutputStream(uri)?.use { out: OutputStream ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                Toast.makeText(context, "Saved to Downloads: $fileName", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(context, "Failed to save file", Toast.LENGTH_SHORT).show()
            }
        } else {
            @Suppress("DEPRECATION")
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            if (!dir.exists()) dir.mkdirs()
            val file = java.io.File(dir, fileName)
            java.io.FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            Toast.makeText(context, "Saved to Downloads: $fileName", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Save failed: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
