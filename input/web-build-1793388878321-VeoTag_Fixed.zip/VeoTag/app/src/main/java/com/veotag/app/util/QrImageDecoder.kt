package com.veotag.app.util

import android.content.Context
import android.net.Uri
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

sealed interface QrImageResult {
    data class Found(val projectId: String) : QrImageResult
    data object NoQr : QrImageResult
    data object InvalidQr : QrImageResult
    data object MultipleQr : QrImageResult
    data class Failed(val reason: String) : QrImageResult
}

/** Decodes VeoTag QR codes from an image the user picked, entirely on-device with ML Kit. */
object QrImageDecoder {

    suspend fun decode(context: Context, uri: Uri): QrImageResult = withContext(Dispatchers.Default) {
        val options = BarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE).build()
        val scanner = BarcodeScanning.getClient(options)
        try {
            val payloads = LinkedHashSet<String>()
            // Large screenshots sometimes only decode after downscaling, so try two sizes.
            for (edge in intArrayOf(2048, 1024)) {
                val bitmap = ImageUtils.decodeSampled(context, uri, edge)
                    ?: return@withContext QrImageResult.Failed("Could not open this image.")
                val image = InputImage.fromBitmap(bitmap, 0)
                val codes = scanner.awaitProcess(image)
                bitmap.recycle()
                codes.mapNotNullTo(payloads) { it.rawValue }
                if (payloads.isNotEmpty()) break
            }
            if (payloads.isEmpty()) return@withContext QrImageResult.NoQr
            val ids = payloads.mapNotNull { QrUtils.parsePayload(it) }.distinct()
            when {
                ids.size == 1 -> QrImageResult.Found(ids.first())
                ids.size > 1 -> QrImageResult.MultipleQr
                else -> QrImageResult.InvalidQr
            }
        } catch (e: OutOfMemoryError) {
            QrImageResult.Failed("This image is too large to read.")
        } catch (e: Exception) {
            QrImageResult.Failed("Could not read this image.")
        } finally {
            scanner.close()
        }
    }

    private suspend fun com.google.mlkit.vision.barcode.BarcodeScanner.awaitProcess(
        image: InputImage
    ): List<Barcode> = suspendCancellableCoroutine { cont ->
        process(image)
            .addOnSuccessListener { if (cont.isActive) cont.resume(it) }
            .addOnFailureListener { if (cont.isActive) cont.resumeWithException(it) }
    }
}
