# VeoTag

Android app for showcasing school, science fair, robotics, and innovation projects via QR codes.

Visitors scan a printed QR code and stream the project video from Supabase Storage. No public website required.

## New Supabase project

- **URL:** `https://uujagbsiaaweuzxbcglw.supabase.co`
- **Publishable key:** configured in `app/build.gradle.kts` defaults and `SupabaseProvider`
- **Bucket:** `veotag-videos`

Override via `local.properties` or Gradle properties if needed:

```properties
SUPABASE_URL=https://uujagbsiaaweuzxbcglw.supabase.co
SUPABASE_ANON_KEY=sb_publishable_jY6EDfuBOI3OdsSSKvnILA_JvVbFoKX
```

Never put a service-role key in the app.

## Tech

- Kotlin, Jetpack Compose, Material 3
- Navigation Compose with animated transitions
- Supabase Auth / PostgREST / Storage
- CameraX + ML Kit QR scanning (animated laser overlay)
- Media3 ExoPlayer
- ZXing QR generation

## Build

```bash
./gradlew assembleDebug
# or
./gradlew assembleRelease
```

Application ID: `com.veotag.app`  
Min SDK 26 · Target / Compile SDK 35 · JDK 17

## AndroidForge / GitHub Actions

Upload this ZIP to your existing AndroidForge workflow. Secrets (optional if defaults are used):

- `SUPABASE_ANON_KEY`
- `SUPABASE_URL`

## Visitor flow

Home → Scan / Explore → Project detail + video

Admin: tap VeoTag logo 5 times → login → dashboard (auth + `admin_users` + RLS).

## Schema

Compatible with `projects` (including nullable `thumbnail_path`) and `admin_users`.
