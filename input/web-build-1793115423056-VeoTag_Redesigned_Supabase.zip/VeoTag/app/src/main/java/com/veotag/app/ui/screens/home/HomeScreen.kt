package com.veotag.app.ui.screens.home

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.veotag.app.data.model.Project
import com.veotag.app.data.repository.ProjectRepository
import com.veotag.app.ui.components.EmptyState
import com.veotag.app.ui.components.ErrorState
import com.veotag.app.ui.components.LoadingState
import com.veotag.app.ui.components.ProjectCard
import com.veotag.app.ui.components.SectionHeader
import com.veotag.app.ui.components.VeoTagLogo
import com.veotag.app.ui.theme.BluePrimary
import com.veotag.app.ui.theme.PurpleAccent
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    onScanClick: () -> Unit,
    onProjectClick: (String) -> Unit,
    onSearchClick: () -> Unit,
    onAdminShortcut: () -> Unit
) {
    val repo = remember { ProjectRepository() }
    val scope = rememberCoroutineScope()
    var projects by remember { mutableStateOf<List<Project>>(emptyList()) }
    var categories by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedCategory by remember { mutableStateOf<String?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var visible by remember { mutableStateOf(false) }

    fun load() {
        scope.launch {
            loading = true
            error = null
            categories = repo.getDistinctCategories().getOrDefault(emptyList())
            val result = repo.getPublishedProjects(limit = 30, category = selectedCategory)
            result.onSuccess {
                projects = it
                loading = false
            }.onFailure {
                error = "Unable to load projects. Check your connection."
                loading = false
            }
        }
    }

    LaunchedEffect(selectedCategory) { load() }
    LaunchedEffect(Unit) { visible = true }

    val featured = projects.take(6)
    val recent = projects

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(bottom = 28.dp)
    ) {
        item {
            AnimatedVisibility(
                visible = visible,
                enter = fadeIn(tween(450)) + slideInVertically(
                    initialOffsetY = { -48 },
                    animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
                )
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(bottomStart = 28.dp, bottomEnd = 28.dp))
                        .background(
                            Brush.verticalGradient(
                                listOf(BluePrimary, BluePrimary.copy(0.9f), PurpleAccent.copy(0.75f))
                            )
                        )
                        .padding(horizontal = 20.dp, vertical = 28.dp)
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            VeoTagLogo(size = 44, onMultiTap = onAdminShortcut)
                            Spacer(Modifier.width(12.dp))
                            Text(
                                text = "VeoTag",
                                style = MaterialTheme.typography.headlineLarge,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(Modifier.height(16.dp))
                        Text(
                            text = "Discover innovation",
                            style = MaterialTheme.typography.headlineMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(Modifier.height(6.dp))
                        Text(
                            text = "Scan QR codes on physical projects to watch videos and explore student innovation.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White.copy(alpha = 0.92f)
                        )
                        Spacer(Modifier.height(20.dp))
                        Button(
                            onClick = onScanClick,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color.White,
                                contentColor = BluePrimary
                            )
                        ) {
                            Icon(Icons.Default.QrCodeScanner, contentDescription = null)
                            Spacer(Modifier.width(10.dp))
                            Text("Scan QR Code", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(Modifier.height(16.dp))
            Surface(
                onClick = onSearchClick,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 1.dp,
                shadowElevation = 1.dp
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Search,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(Modifier.width(12.dp))
                    Text(
                        "Search projects…",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        if (categories.isNotEmpty()) {
            item {
                Spacer(Modifier.height(12.dp))
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 20.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { selectedCategory = null },
                            label = { Text("All") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = BluePrimary,
                                selectedLabelColor = Color.White
                            )
                        )
                    }
                }
            }
        }

        when {
            loading -> item {
                Box(
                    Modifier
                        .fillMaxWidth()
                        .height(240.dp),
                    contentAlignment = Alignment.Center
                ) {
                    LoadingState(Modifier.height(120.dp))
                }
            }
            error != null -> item {
                ErrorState(message = error!!, onRetry = { load() }, modifier = Modifier.height(240.dp))
            }
            projects.isEmpty() -> item {
                EmptyState(
                    message = "No published projects yet.",
                    modifier = Modifier.height(240.dp)
                )
            }
            else -> {
                if (featured.isNotEmpty()) {
                    item {
                        Spacer(Modifier.height(8.dp))
                        SectionHeader("Featured")
                    }
                    item {
                        LazyRow(
                            contentPadding = PaddingValues(horizontal = 20.dp),
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            itemsIndexed(featured) { index, project ->
                                AnimatedVisibility(
                                    visible = visible,
                                    enter = fadeIn(tween(400, delayMillis = index * 60)) +
                                        slideInVertically(
                                            initialOffsetY = { 30 },
                                            animationSpec = tween(400, delayMillis = index * 60)
                                        )
                                ) {
                                    ProjectCard(
                                        project = project,
                                        onClick = { onProjectClick(project.id) },
                                        featured = true,
                                        modifier = Modifier.width(280.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                item {
                    Spacer(Modifier.height(12.dp))
                    SectionHeader("Recently added")
                }
                itemsIndexed(recent, key = { _, p -> p.id }) { index, project ->
                    AnimatedVisibility(
                        visible = visible,
                        enter = fadeIn(tween(350, delayMillis = 80 + index * 40)) +
                            slideInVertically(
                                initialOffsetY = { 24 },
                                animationSpec = tween(350, delayMillis = 80 + index * 40)
                            )
                    ) {
                        ProjectCard(
                            project = project,
                            onClick = { onProjectClick(project.id) },
                            modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }
    }
}
