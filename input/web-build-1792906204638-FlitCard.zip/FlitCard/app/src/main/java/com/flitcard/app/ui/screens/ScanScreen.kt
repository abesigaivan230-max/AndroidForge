package com.flitcard.app.ui.screens

import android.Manifest
import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.ContextWrapper
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.SystemClock
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.flitcard.app.contact.ContactCard
import com.flitcard.app.contact.ParseResult
import com.flitcard.app.contact.VCard
import com.flitcard.app.qr.QrAnalyzer
import com.flitcard.app.ui.components.BigButton
import com.flitcard.app.ui.components.Entrance
import com.flitcard.app.ui.components.QrGlyph
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitError
import com.flitcard.app.ui.theme.FlitMuted
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOrange
import com.flitcard.app.ui.theme.FlitWhite
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlinx.coroutines.delay

private class BadScan(var text: String = "", var at: Long = 0L)

@Composable
fun ScanScreen(onContact: (ContactCard) -> Unit, onBack: () -> Unit) {
    val context = LocalContext.current
    val activity = remember(context) { context.findActivity() }
    val haptics = LocalHapticFeedback.current
    val hasCamera = remember { context.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_ANY) }

    var granted by remember { mutableStateOf(hasCameraPermission(context)) }
    var askedBefore by rememberSaveable { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        granted = ok
        askedBefore = true
    }
    // Re-check when returning from system Settings.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { granted = hasCameraPermission(context) }

    val permanentlyDenied = !granted && askedBefore && activity != null &&
        !ActivityCompat.shouldShowRequestPermissionRationale(activity, Manifest.permission.CAMERA)

    var cameraFailed by remember { mutableStateOf(false) }
    var attempt by remember { mutableIntStateOf(0) }
    var torchOn by remember { mutableStateOf(false) }
    var torchAvailable by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var lastError by remember { mutableStateOf("") }
    val consumed = remember { AtomicBoolean(false) }
    val bad = remember { BadScan() }

    LaunchedEffect(error) {
        if (error != null) {
            delay(3200)
            error = null
        }
    }

    val onDecoded: (String) -> Unit = { text ->
        if (!consumed.get()) {
            when (val result = VCard.parse(text)) {
                is ParseResult.Success -> if (consumed.compareAndSet(false, true)) {
                    haptics.performHapticFeedback(HapticFeedbackType.LongPress)
                    onContact(result.card)
                }
                is ParseResult.Failure -> {
                    val now = SystemClock.elapsedRealtime()
                    if (text != bad.text || now - bad.at > 3500) {
                        bad.text = text
                        bad.at = now
                        lastError = result.reason
                        error = result.reason
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = FlitNavy)
            }
            Text("Scan a QR code", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = FlitNavy)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                !hasCamera -> InfoPanel(
                    title = "No camera found",
                    body = "This phone doesn't seem to have a camera, so scanning isn't available. You can still show and share your own QR code.",
                    button = "Go back", onClick = onBack,
                )
                !granted -> when {
                    !askedBefore -> InfoPanel(
                        title = "Camera access needed",
                        body = "FlitCard uses the camera only to read QR codes. Nothing is recorded, saved or sent anywhere, and scanning works without internet.",
                        button = "Allow camera",
                        onClick = { launcher.launch(Manifest.permission.CAMERA) },
                    )
                    permanentlyDenied -> InfoPanel(
                        title = "Camera is blocked",
                        body = "Android won't show the permission prompt again. Open Settings, tap Permissions, then Camera, and allow it for FlitCard.",
                        button = "Open settings",
                        onClick = { openAppSettings(context) },
                    )
                    else -> InfoPanel(
                        title = "Camera permission is off",
                        body = "Without the camera FlitCard can't scan QR codes. You can still show and share your own QR code.",
                        button = "Try again",
                        onClick = { launcher.launch(Manifest.permission.CAMERA) },
                    )
                }
                cameraFailed -> InfoPanel(
                    title = "Couldn't start the camera",
                    body = "Another app may be using it. Close other camera apps and try again.",
                    button = "Try again",
                    onClick = { cameraFailed = false; attempt++ },
                )
                else -> Box(
                    Modifier.fillMaxSize().clip(RoundedCornerShape(28.dp)).background(FlitNavy)
                ) {
                    CameraView(
                        torchOn = torchOn,
                        attempt = attempt,
                        onDecoded = onDecoded,
                        onError = { cameraFailed = true },
                        onTorchSupport = { torchAvailable = it },
                        modifier = Modifier.fillMaxSize(),
                    )
                    ScanOverlay()
                    if (torchAvailable) {
                        Box(
                            Modifier
                                .align(Alignment.TopEnd)
                                .padding(12.dp)
                                .heightIn(min = 48.dp)
                                .clip(RoundedCornerShape(50))
                                .background(if (torchOn) FlitOrange else Color.Black.copy(alpha = 0.55f))
                                .clickable { torchOn = !torchOn }
                                .padding(horizontal = 16.dp),
                            contentAlignment = Alignment.Center,
                        ) {
                            Text(
                                if (torchOn) "Light: on" else "Light: off",
                                color = if (torchOn) FlitNavy else FlitWhite,
                                fontWeight = FontWeight.Bold, fontSize = 14.sp,
                            )
                        }
                    }
                    ScanErrorBanner(visible = error != null, message = lastError)
                }
            }
        }
        Text(
            "Point the camera at someone's FlitCard QR code.",
            modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
            textAlign = TextAlign.Center, color = FlitMuted, fontSize = 15.sp,
        )
    }
}

/**
 * Extracted as a BoxScope extension on purpose. Called inline from the nested Box, Kotlin resolves
 * AnimatedVisibility to the ColumnScope overload (the outer Column is still an implicit receiver) and
 * Compose's scope marker rejects it. Here BoxScope is the only layout receiver, so the plain overload is used.
 */
@Composable
private fun BoxScope.ScanErrorBanner(visible: Boolean, message: String) {
    AnimatedVisibility(
        visible = visible,
        modifier = Modifier.align(Alignment.BottomCenter).padding(12.dp),
        enter = slideInVertically(tween(250)) { it } + fadeIn(tween(250)),
        exit = slideOutVertically(tween(200)) { it } + fadeOut(tween(200)),
    ) {
        Row(
            Modifier
                .fillMaxWidth()
                .background(FlitWhite, RoundedCornerShape(16.dp))
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Default.Warning, contentDescription = null, tint = FlitError)
            Spacer(Modifier.size(10.dp))
            Text(message, color = FlitNavy, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun InfoPanel(title: String, body: String, button: String, onClick: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Entrance { QrGlyph(Modifier.size(84.dp)) }
        Spacer(Modifier.height(20.dp))
        Entrance(delayMs = 80) {
            Text(title, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = FlitNavy, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(10.dp))
        Entrance(delayMs = 160) {
            Text(body, fontSize = 16.sp, lineHeight = 23.sp, color = FlitMuted, textAlign = TextAlign.Center)
        }
        Spacer(Modifier.height(24.dp))
        Entrance(delayMs = 240) { BigButton(button, onClick) }
    }
}

@Composable
private fun CameraView(
    torchOn: Boolean,
    attempt: Int,
    onDecoded: (String) -> Unit,
    onError: () -> Unit,
    onTorchSupport: (Boolean) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val previewView = remember {
        PreviewView(context).apply {
            scaleType = PreviewView.ScaleType.FILL_CENTER
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
        }
    }
    var camera by remember { mutableStateOf<Camera?>(null) }
    val currentOnDecoded by rememberUpdatedState(onDecoded)
    val currentOnError by rememberUpdatedState(onError)
    val currentOnTorch by rememberUpdatedState(onTorchSupport)

    DisposableEffect(lifecycleOwner, attempt) {
        val executor = Executors.newSingleThreadExecutor()
        val mainExecutor = ContextCompat.getMainExecutor(context)
        val providerFuture = ProcessCameraProvider.getInstance(context)
        var provider: ProcessCameraProvider? = null
        var disposed = false

        providerFuture.addListener({
            if (disposed) return@addListener
            try {
                val p = providerFuture.get()
                provider = p
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val analysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                analysis.setAnalyzer(executor, QrAnalyzer { text -> mainExecutor.execute { currentOnDecoded(text) } })
                p.unbindAll()
                val cam = p.bindToLifecycle(lifecycleOwner, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
                camera = cam
                currentOnTorch(cam.cameraInfo.hasFlashUnit())
            } catch (_: Exception) {
                currentOnError()
            }
        }, mainExecutor)

        onDispose {
            disposed = true
            provider?.unbindAll()
            camera = null
            executor.shutdown()
        }
    }

    LaunchedEffect(camera, torchOn) { camera?.cameraControl?.enableTorch(torchOn) }

    AndroidView(factory = { previewView }, modifier = modifier)
}

@Composable
private fun ScanOverlay() {
    val t = rememberInfiniteTransition(label = "scan")
    val line by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1900, easing = EaseInOut), RepeatMode.Reverse),
        label = "line",
    )
    Canvas(Modifier.fillMaxSize().graphicsLayer(compositingStrategy = CompositingStrategy.Offscreen)) {
        val side = size.minDimension * 0.68f
        val left = (size.width - side) / 2f
        val top = (size.height - side) / 2f
        val radius = 28.dp.toPx()

        drawRect(Color.Black.copy(alpha = 0.45f))
        drawRoundRect(
            color = Color.Black, topLeft = Offset(left, top), size = Size(side, side),
            cornerRadius = CornerRadius(radius), blendMode = BlendMode.Clear,
        )

        val len = side * 0.18f
        val stroke = 5.dp.toPx()
        fun corner(x: Float, y: Float, dx: Float, dy: Float) {
            drawLine(FlitWhite, Offset(x, y), Offset(x + dx * len, y), stroke, StrokeCap.Round)
            drawLine(FlitWhite, Offset(x, y), Offset(x, y + dy * len), stroke, StrokeCap.Round)
        }
        corner(left, top, 1f, 1f)
        corner(left + side, top, -1f, 1f)
        corner(left, top + side, 1f, -1f)
        corner(left + side, top + side, -1f, -1f)

        val y = top + side * 0.06f + side * 0.88f * line
        drawLine(
            brush = Brush.horizontalGradient(
                listOf(Color.Transparent, FlitOrange, Color.Transparent), startX = left, endX = left + side,
            ),
            start = Offset(left + 12.dp.toPx(), y),
            end = Offset(left + side - 12.dp.toPx(), y),
            strokeWidth = 4.dp.toPx(), cap = StrokeCap.Round,
        )
    }
}

private fun hasCameraPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED

private fun openAppSettings(context: Context) {
    val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
    try {
        context.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        // Extremely rare; the user can open Settings manually.
    }
}

private tailrec fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}
