package com.zentra.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.consumeWindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.Send
import androidx.compose.material.icons.rounded.Done
import androidx.compose.material.icons.rounded.DoneAll
import androidx.compose.material.icons.rounded.ErrorOutline
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Schedule
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import com.zentra.app.AppViewModel
import com.zentra.app.data.Channel
import com.zentra.app.data.MessageEntity
import com.zentra.app.net.Phase
import kotlinx.coroutines.launch

private val senderColors = listOf(0xFF16DDF5, 0xFFF5B942, 0xFF2ED47A, 0xFFFF8A65, 0xFFB388FF, 0xFFFF6FA3, 0xFF7FB8FF)

@Composable
fun ChatScreen(vm: AppViewModel, target: String, id: Long, nav: NavHostController) {
    val core = vm.core
    val me by core.me.collectAsState()
    val directory by core.directory.collectAsState()
    val onlineIds by core.onlineIds.collectAsState()
    val channels by core.myChannels.collectAsState()
    val dms by core.dms.collectAsState()
    val conn by core.conn.state.collectAsState()
    val isDm = target == "dm"

    val scope = rememberCoroutineScope()
    var limit by remember { mutableIntStateOf(100) }
    val msgs by remember(target, id, limit) { core.messages(target, id, limit) }.collectAsState(initial = emptyList())
    var hasMore by remember { mutableStateOf(true) }
    var loadingOlder by remember { mutableStateOf(false) }
    var text by remember { mutableStateOf("") }
    var offlineNote by remember { mutableStateOf(false) }

    var fetched by remember { mutableStateOf<Channel?>(null) }
    val channel = channels.firstOrNull { it.id == id } ?: fetched
    val dm = dms.firstOrNull { it.id == id }
    val isMember = isDm || channel?.isMember == true || channels.any { it.id == id }
    val knownLoaded by core.listsLoaded.collectAsState()
    val removed = !isDm && knownLoaded && channels.none { it.id == id }

    DisposableEffect(target, id) {
        core.openChat = target to id
        onDispose { if (core.openChat == (target to id)) core.openChat = null }
    }
    LaunchedEffect(target, id, conn.phase == Phase.Connected) {
        try {
            hasMore = core.loadHistory(target, id)
            offlineNote = false
        } catch (e: kotlinx.coroutines.CancellationException) {
            throw e
        } catch (e: Exception) {
            offlineNote = true
        }
    }
    LaunchedEffect(target, id) {
        if (!isDm) {
            try {
                if (channels.none { it.id == id }) fetched = core.channelDetail(id)
                core.members(id)
            } catch (e: kotlinx.coroutines.CancellationException) {
                throw e
            } catch (_: Exception) {
            }
        }
    }

    val rev = remember(msgs) { msgs.asReversed() }
    val listState = rememberLazyListState()
    val showJump by remember { derivedStateOf { listState.firstVisibleItemIndex > 3 } }

    // follow new messages when we are already at the bottom (or when we sent them)
    val newestId = msgs.lastOrNull()?.id
    LaunchedEffect(newestId) {
        if (newestId != null && (listState.firstVisibleItemIndex <= 2 || msgs.lastOrNull()?.senderId == me?.id)) {
            listState.animateScrollToItem(0)
        }
    }
    // load older messages when scrolled to the top
    val nearTop by remember { derivedStateOf { rev.isNotEmpty() && (listState.layoutInfo.visibleItemsInfo.lastOrNull()?.index ?: 0) >= rev.size - 3 } }
    LaunchedEffect(nearTop, rev.size) {
        if (nearTop && !loadingOlder) {
            if (rev.size >= limit) limit += 100
            else if (hasMore && conn.phase == Phase.Connected) {
                loadingOlder = true
                try {
                    hasMore = core.loadOlder(target, id)
                } catch (e: kotlinx.coroutines.CancellationException) {
                    throw e
                } catch (_: Exception) {
                }
                loadingOlder = false
            }
        }
    }

    val title = if (isDm) dm?.peer?.fullName ?: "Chat" else channel?.name ?: "Channel"
    val subtitle = when {
        isDm -> if (onlineIds.contains(dm?.peer?.id)) "Online" else "Offline"
        channel != null -> "${channel.memberCount} members · ${channel.onlineCount} online"
        else -> ""
    }

    Column(Modifier.fillMaxSize().background(Z.c.bg).statusBarsPadding()) {
        // header
        Row(
            Modifier.fillMaxWidth().height(64.dp).background(Z.c.surface).padding(horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            IconButton({ nav.popBackStack() }) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Z.c.text) }
            Row(
                Modifier.weight(1f).clip(RoundedCornerShape(12.dp)).clickable(enabled = !isDm) { nav.navigate("channel/$id") }.padding(vertical = 6.dp, horizontal = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                if (isDm) Avatar(dm?.peer?.fullName ?: "", dm?.peer?.avatar, 40.dp, onlineIds.contains(dm?.peer?.id))
                else ChannelIcon(channel?.icon ?: "chat", 40.dp)
                Spacer(Modifier.width(10.dp))
                Column {
                    Text(title, color = Z.c.text, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (subtitle.isNotEmpty()) Text(subtitle, color = if (subtitle == "Online") Z.c.success else Z.c.textDim, fontSize = 12.sp, maxLines = 1)
                }
            }
            if (!isDm && channel?.myRole == "owner") {
                IconButton({ nav.navigate("manage/$id") }) { Icon(Icons.Rounded.Settings, "Manage channel", tint = Z.c.textDim) }
            }
        }

        // connection banner
        val bannerText = when {
            conn.phase == Phase.Interrupted -> "Reconnecting… messages will be sent when you're back"
            conn.phase == Phase.Unavailable -> "Server unavailable. Showing saved messages"
            conn.phase == Phase.Idle || offlineNote -> if (conn.phase == Phase.Connected) null else "Offline. Showing saved messages"
            else -> null
        }
        AnimatedVisibility(bannerText != null, enter = fadeIn(tween(200)), exit = fadeOut(tween(200))) {
            Text(
                bannerText ?: "", color = Z.c.warning, fontSize = 12.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.fillMaxWidth().background(Z.c.warning.copy(alpha = 0.12f)).padding(horizontal = 16.dp, vertical = 6.dp),
            )
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (rev.isEmpty()) {
                EmptyState(Icons.Rounded.Lock, if (isDm) "Say hello" else "No messages yet", if (isDm) "Only you and ${title} can read this conversation." else "Be the first to say something to your neighbours.", Modifier.align(Alignment.Center))
            }
            LazyColumn(
                Modifier.fillMaxSize(), state = listState, reverseLayout = true,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp),
            ) {
                itemsIndexed(rev, key = { _, m -> m.id }) { i, m ->
                    val older = rev.getOrNull(i + 1)
                    val mine = m.senderId == me?.id
                    val newDay = older == null || !sameDay(older.createdAt, m.createdAt)
                    val groupStart = newDay || older?.senderId != m.senderId || m.createdAt - (older?.createdAt ?: 0) > 5 * 60_000
                    Column(Modifier.animateItem()) {
                        if (newDay && m.createdAt > 0) {
                            Box(Modifier.fillMaxWidth().padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                                Text(
                                    dayLabel(m.createdAt), color = Z.c.textDim, fontSize = 12.sp,
                                    modifier = Modifier.clip(RoundedCornerShape(50)).background(Z.c.surface).padding(horizontal = 12.dp, vertical = 4.dp),
                                )
                            }
                        }
                        Bubble(m, mine, groupStart && !mine && !isDm, directory[m.senderId]?.avatar, groupStart, !isDm, onRetry = { core.retry(m.id) })
                    }
                }
            }
            if (showJump) {
                Box(
                    Modifier.align(Alignment.BottomEnd).padding(16.dp).size(44.dp)
                        .clip(CircleShape).background(Z.c.surfaceHi).border(1.dp, Z.c.border, CircleShape)
                        .clickable { scope.launch { listState.animateScrollToItem(0) } },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.Rounded.KeyboardArrowDown, "Jump to latest", tint = Z.c.text) }
            }
        }

        // input
        if (removed) {
            Text(
                "You are no longer a member of this channel.", color = Z.c.textDim, fontSize = 14.sp,
                modifier = Modifier.fillMaxWidth().background(Z.c.surface).navigationBarsPadding().padding(16.dp),
            )
        } else {
            Row(
                Modifier.fillMaxWidth().background(Z.c.surface).navigationBarsPadding().imePadding().padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.Bottom,
            ) {
                TextField(
                    text, { text = it.take(2000) },
                    Modifier.weight(1f),
                    placeholder = { Text("Message", color = Z.c.textDim) },
                    maxLines = 5,
                    shape = RoundedCornerShape(24.dp),
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
                    colors = TextFieldDefaults.colors(
                        focusedContainerColor = Z.c.surfaceHi, unfocusedContainerColor = Z.c.surfaceHi,
                        focusedTextColor = Z.c.text, unfocusedTextColor = Z.c.text, cursorColor = Z.c.accent,
                        focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                    ),
                )
                Spacer(Modifier.width(8.dp))
                val canSend = text.isNotBlank() && isMember
                val src = remember { MutableInteractionSource() }
                val scale by androidx.compose.animation.core.animateFloatAsState(if (canSend) 1f else 0.85f, spring(stiffness = Spring.StiffnessMedium), label = "send")
                Box(
                    Modifier.size(48.dp).scale(scale).clip(CircleShape).background(if (canSend) Z.c.accent else Z.c.border)
                        .clickable(interactionSource = src, indication = null, enabled = canSend) {
                            core.send(target, id, text)
                            text = ""
                        },
                    contentAlignment = Alignment.Center,
                ) { Icon(Icons.AutoMirrored.Rounded.Send, "Send", tint = Color.White, modifier = Modifier.size(22.dp)) }
            }
        }
    }
}

@Composable
private fun Bubble(m: MessageEntity, mine: Boolean, showName: Boolean, avatar: String?, groupStart: Boolean, avatarColumn: Boolean, onRetry: () -> Unit) {
    val maxW = 300.dp
    val c = Z.c
    val shape = if (mine) RoundedCornerShape(18.dp, 18.dp, 6.dp, 18.dp)
    else RoundedCornerShape(if (groupStart) 6.dp else 18.dp, 18.dp, 18.dp, 18.dp)
    Row(
        Modifier.fillMaxWidth().padding(top = if (groupStart) 8.dp else 2.dp),
        horizontalArrangement = if (mine) Arrangement.End else Arrangement.Start,
        verticalAlignment = Alignment.Top,
    ) {
        if (!mine && avatarColumn) {
            if (showName) Avatar(m.senderName, avatar, 32.dp) else Spacer(Modifier.width(32.dp))
            Spacer(Modifier.width(8.dp))
        }
        Column(
            Modifier.widthIn(max = maxW).clip(shape).background(if (mine) c.accent else c.surfaceHi)
                .then(if (m.status == "failed") Modifier.border(1.dp, c.error, shape).clickable(onClick = onRetry) else Modifier)
                .padding(horizontal = 12.dp, vertical = 8.dp),
        ) {
            if (showName) {
                Text(
                    m.senderName, color = Color(senderColors[(m.senderId % senderColors.size).toInt()]),
                    fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                )
            }
            Text(m.body, color = if (mine) Color.White else c.text, fontSize = 15.sp, lineHeight = 21.sp)
            Row(Modifier.align(Alignment.End).padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (m.status == "failed") Text("Not sent · tap to retry", color = if (mine) Color.White else c.error, fontSize = 11.sp)
                else if (m.createdAt > 0) Text(clockLabel(m.createdAt), color = if (mine) Color.White.copy(alpha = 0.75f) else c.textDim, fontSize = 11.sp)
                if (mine) {
                    val (icon, tint) = when (m.status) {
                        "sending" -> Icons.Rounded.Schedule to Color.White.copy(alpha = 0.75f)
                        "failed" -> Icons.Rounded.ErrorOutline to Color.White
                        "delivered" -> Icons.Rounded.DoneAll to Color.White.copy(alpha = 0.75f)
                        "read" -> Icons.Rounded.DoneAll to Color(0xFF39F4FE)
                        else -> Icons.Rounded.Done to Color.White.copy(alpha = 0.75f)
                    }
                    Icon(icon, m.status, tint = tint, modifier = Modifier.size(14.dp))
                }
            }
        }
    }
}
