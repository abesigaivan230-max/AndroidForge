package com.zentra.app.ui

import androidx.navigation.NavHostController

/** Opens a channel or direct-message conversation using the app's registered chat route. */
fun NavHostController.openChat(target: String, id: Long) {
    require(target == "channel" || target == "dm") { "Unsupported chat target: $target" }
    navigate("chat/$target/$id") {
        launchSingleTop = true
    }
}
