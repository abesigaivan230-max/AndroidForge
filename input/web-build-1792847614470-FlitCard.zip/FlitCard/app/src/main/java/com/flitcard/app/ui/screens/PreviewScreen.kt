package com.flitcard.app.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flitcard.app.contact.ContactCard
import com.flitcard.app.share.ContactIntents
import com.flitcard.app.ui.components.BigButton
import com.flitcard.app.ui.components.ButtonKind
import com.flitcard.app.ui.components.Entrance
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitBlueSoft
import com.flitcard.app.ui.theme.FlitMuted
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOrange
import com.flitcard.app.ui.theme.FlitPurple
import com.flitcard.app.ui.theme.FlitWhite

@Composable
fun PreviewScreen(contact: ContactCard, onScanAnother: () -> Unit, onDone: () -> Unit) {
    val context = LocalContext.current
    val initials = contact.name.split(' ').filter { it.isNotEmpty() }.take(2)
        .joinToString("") { it.first().uppercase() }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
        ) {
            Spacer(Modifier.height(16.dp))
            Entrance {
                Box(
                    Modifier
                        .size(96.dp)
                        .background(Brush.linearGradient(listOf(FlitBlue, FlitPurple)), CircleShape),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(initials, color = FlitWhite, fontSize = 36.sp, fontWeight = FontWeight.ExtraBold)
                }
            }
            Spacer(Modifier.height(14.dp))
            Entrance(delayMs = 80) {
                Text(
                    contact.name, fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.ExtraBold,
                    color = FlitNavy, textAlign = TextAlign.Center,
                )
            }
            Spacer(Modifier.height(4.dp))
            Entrance(delayMs = 140) { Text("Review before saving", fontSize = 15.sp, color = FlitMuted) }
            Spacer(Modifier.height(22.dp))

            Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                var step = 0
                contact.phone?.let {
                    Entrance(delayMs = 200 + 90 * step++) { InfoRow(Icons.Default.Call, "Phone", it, FlitBlue) }
                }
                contact.whatsapp?.let {
                    Entrance(delayMs = 200 + 90 * step++) { InfoRow(Icons.Default.Send, "WhatsApp", it, FlitPurple) }
                }
                contact.email?.let {
                    Entrance(delayMs = 200 + 90 * step++) { InfoRow(Icons.Default.Email, "Email", it, FlitOrange) }
                }
            }
            Spacer(Modifier.height(16.dp))
            Entrance(delayMs = 500) {
                Text(
                    "This opens your Contacts app with these details filled in. Nothing is saved until you tap Save there.",
                    fontSize = 13.sp, lineHeight = 19.sp, color = FlitMuted, textAlign = TextAlign.Center,
                )
            }
        }

        Column(Modifier.padding(top = 8.dp, bottom = 10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Entrance(delayMs = 300) {
                BigButton(
                    text = "Save to Contacts",
                    icon = Icons.Default.Add,
                    onClick = {
                        if (!ContactIntents.open(context, contact)) {
                            Toast.makeText(context, "No Contacts app found on this phone.", Toast.LENGTH_LONG).show()
                        }
                    },
                )
            }
            Entrance(delayMs = 380) { BigButton("Scan another", onScanAnother, kind = ButtonKind.Outline) }
            TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
                Text("Done", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = FlitMuted)
            }
        }
    }
}

@Composable
private fun InfoRow(icon: ImageVector, label: String, value: String, accent: androidx.compose.ui.graphics.Color) {
    Row(
        Modifier
            .fillMaxWidth()
            .background(FlitBlueSoft, RoundedCornerShape(18.dp))
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(44.dp).background(FlitWhite, CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, contentDescription = null, tint = accent)
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(label, fontSize = 13.sp, color = FlitMuted)
            Text(value, fontSize = 18.sp, fontWeight = FontWeight.Bold, color = FlitNavy)
        }
    }
}
