package com.flitcard.app.contact

sealed interface ParseResult {
    data class Success(val card: ContactCard) : ParseResult
    data class Failure(val reason: String) : ParseResult
}

/**
 * Minimal vCard 3.0 writer/reader.
 *
 * WhatsApp is written as a second TEL (so other contact apps keep the number) plus an
 * X-WHATSAPP property so FlitCard can restore the label.
 */
object VCard {
    const val MAX_PAYLOAD = 2048

    fun build(card: ContactCard): String {
        val sb = StringBuilder()
        sb.append("BEGIN:VCARD\r\nVERSION:3.0\r\n")
        sb.append("N:").append(structuredName(card.name)).append("\r\n")
        sb.append("FN:").append(escape(card.name)).append("\r\n")
        card.phone?.let { sb.append("TEL;TYPE=CELL:").append(it).append("\r\n") }
        card.whatsapp?.let {
            if (it != card.phone) sb.append("TEL;TYPE=OTHER:").append(it).append("\r\n")
            sb.append("X-WHATSAPP:").append(it).append("\r\n")
        }
        card.email?.let { sb.append("EMAIL;TYPE=INTERNET:").append(escape(it)).append("\r\n") }
        sb.append("END:VCARD\r\n")
        return sb.toString()
    }

    fun parse(raw: String): ParseResult {
        val text = raw.trim()
        if (text.isEmpty()) return fail("The QR code is empty.")
        if (text.length > MAX_PAYLOAD) return fail("This QR code holds too much data to be a contact card.")
        if (!text.startsWith("BEGIN:VCARD", ignoreCase = true)) return fail("This QR code isn't a contact card.")

        var fn: String? = null
        var structured: String? = null
        val phones = mutableListOf<String>()
        var whatsapp: String? = null
        var email: String? = null
        var sawEnd = false

        for (line in unfold(text)) {
            val colon = line.indexOf(':')
            if (colon <= 0) continue
            val key = line.substring(0, colon)
            val value = line.substring(colon + 1)
            val prop = key.substringBefore(';').substringAfterLast('.').trim().uppercase()
            when (prop) {
                "END" -> if (value.trim().equals("VCARD", ignoreCase = true)) { sawEnd = true }
                "FN" -> if (fn == null) fn = unescape(value)
                "N" -> if (structured == null) {
                    val parts = splitUnescaped(value, ';')
                    val family = parts.getOrNull(0)?.let(::unescape).orEmpty()
                    val given = parts.getOrNull(1)?.let(::unescape).orEmpty()
                    structured = "$given $family"
                }
                "TEL" -> phones += value
                "X-WHATSAPP" -> if (whatsapp == null) whatsapp = value
                "EMAIL" -> if (email == null) email = unescape(value)
            }
            if (sawEnd) break
        }

        if (!sawEnd) return fail("This contact card is incomplete.")

        val name = Validators.cleanText(fn ?: structured ?: "", Validators.MAX_NAME)
        if (name.isEmpty()) return fail("This contact card has no name.")

        val phone = phones.firstNotNullOfOrNull { Validators.normalizePhone(it) }
        val wa = whatsapp?.let { Validators.normalizePhone(it) }
        val mail = email?.let { Validators.normalizeEmail(it) }

        if (phone == null && wa == null && mail == null) {
            return fail("This contact has no valid phone number or email.")
        }
        return ParseResult.Success(ContactCard(name = name, phone = phone, whatsapp = wa, email = mail))
    }

    private fun fail(reason: String) = ParseResult.Failure(reason)

    private fun structuredName(name: String): String {
        val idx = name.lastIndexOf(' ')
        return if (idx < 0) ";${escape(name)};;;"
        else "${escape(name.substring(idx + 1))};${escape(name.substring(0, idx))};;;"
    }

    private fun escape(s: String): String =
        s.replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r", "").replace("\n", "\\n")

    private fun unescape(s: String): String {
        val sb = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                val n = s[i + 1]
                sb.append(if (n == 'n' || n == 'N') ' ' else n)
                i += 2
            } else {
                sb.append(c); i++
            }
        }
        return sb.toString()
    }

    private fun splitUnescaped(s: String, sep: Char): List<String> {
        val out = mutableListOf<String>()
        val cur = StringBuilder()
        var i = 0
        while (i < s.length) {
            val c = s[i]
            if (c == '\\' && i + 1 < s.length) {
                cur.append(c).append(s[i + 1]); i += 2
            } else if (c == sep) {
                out += cur.toString(); cur.clear(); i++
            } else {
                cur.append(c); i++
            }
        }
        out += cur.toString()
        return out
    }

    /** RFC 6350 line unfolding: a line starting with space/tab continues the previous one. */
    private fun unfold(text: String): List<String> {
        val out = mutableListOf<String>()
        for (l in text.split(Regex("\r\n|\n|\r"))) {
            if ((l.startsWith(" ") || l.startsWith("\t")) && out.isNotEmpty()) {
                out[out.lastIndex] = out.last() + l.substring(1)
            } else {
                out += l
            }
        }
        return out
    }
}
