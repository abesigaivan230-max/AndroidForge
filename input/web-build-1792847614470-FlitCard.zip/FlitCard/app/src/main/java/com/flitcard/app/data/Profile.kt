package com.flitcard.app.data

import com.flitcard.app.contact.ContactCard

/** The user's own details. Optional fields are empty strings when unset. */
data class Profile(
    val fullName: String,
    val phone: String,
    val whatsapp: String = "",
    val email: String = "",
) {
    fun toCard() = ContactCard(
        name = fullName,
        phone = phone.ifBlank { null },
        whatsapp = whatsapp.ifBlank { null },
        email = email.ifBlank { null },
    )
}
