package com.flitcard.app

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.flitcard.app.contact.VCard
import com.flitcard.app.data.Profile
import com.flitcard.app.data.ProfileRepository
import com.flitcard.app.qr.QrGenerator
import com.flitcard.app.ui.Screen
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface ProfileState {
    data object Loading : ProfileState
    data object Empty : ProfileState
    data class Ready(val profile: Profile) : ProfileState
}

/** A rendered QR together with the payload it encodes, so the UI never shows a stale code. */
class QrUi(val payload: String, val image: ImageBitmap)

class FlitCardViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ProfileRepository(app)

    val profileState: StateFlow<ProfileState> = repo.profile
        .map { if (it == null) ProfileState.Empty else ProfileState.Ready(it) }
        .stateIn(viewModelScope, SharingStarted.Eagerly, ProfileState.Loading)

    val qr: StateFlow<QrUi?> = repo.profile
        .map { p ->
            p?.let {
                val payload = payloadFor(it)
                QrUi(payload, QrGenerator.generate(payload).asImageBitmap())
            }
        }
        .catch { emit(null) }
        .flowOn(Dispatchers.Default)
        .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** Null means "derive from profile": Welcome when empty, Card when a profile exists. */
    var screen by mutableStateOf<Screen?>(null)
        private set

    fun goTo(target: Screen) { screen = target }

    fun saveProfile(profile: Profile) {
        viewModelScope.launch {
            repo.save(profile)
            screen = Screen.Card
        }
    }

    companion object {
        fun payloadFor(profile: Profile): String = VCard.build(profile.toCard())
    }
}
