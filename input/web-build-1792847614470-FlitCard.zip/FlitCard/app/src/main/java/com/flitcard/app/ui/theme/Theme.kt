package com.flitcard.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

val FlitWhite = Color(0xFFFFFFFF)
val FlitBlue = Color(0xFF2563EB)
val FlitOrange = Color(0xFFFF8A34)
val FlitPurple = Color(0xFF8B5CF6)
val FlitNavy = Color(0xFF172554)
val FlitMuted = Color(0xFF475569)
val FlitBlueSoft = Color(0xFFEFF4FF)
val FlitOutline = Color(0xFFCBD5E1)
val FlitError = Color(0xFFDC2626)

private val FlitColors = lightColorScheme(
    primary = FlitBlue,
    onPrimary = FlitWhite,
    secondary = FlitPurple,
    onSecondary = FlitWhite,
    tertiary = FlitOrange,
    onTertiary = FlitNavy,
    background = FlitWhite,
    onBackground = FlitNavy,
    surface = FlitWhite,
    onSurface = FlitNavy,
    surfaceVariant = FlitBlueSoft,
    onSurfaceVariant = FlitMuted,
    outline = FlitOutline,
    error = FlitError,
)

private val FlitTypography = Typography(
    headlineLarge = TextStyle(fontSize = 34.sp, lineHeight = 40.sp, fontWeight = FontWeight.ExtraBold),
    headlineMedium = TextStyle(fontSize = 28.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold),
    titleLarge = TextStyle(fontSize = 22.sp, lineHeight = 28.sp, fontWeight = FontWeight.Bold),
    titleMedium = TextStyle(fontSize = 18.sp, lineHeight = 24.sp, fontWeight = FontWeight.SemiBold),
    bodyLarge = TextStyle(fontSize = 17.sp, lineHeight = 24.sp),
    bodyMedium = TextStyle(fontSize = 15.sp, lineHeight = 22.sp),
    labelLarge = TextStyle(fontSize = 16.sp, fontWeight = FontWeight.Bold),
)

@Composable
fun FlitCardTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = FlitColors, typography = FlitTypography, content = content)
}
