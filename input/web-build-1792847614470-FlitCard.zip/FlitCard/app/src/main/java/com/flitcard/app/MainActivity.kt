package com.flitcard.app

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.flitcard.app.ui.FlitCardApp
import com.flitcard.app.ui.theme.FlitCardTheme

class MainActivity : ComponentActivity() {
    private val viewModel: FlitCardViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // White UI everywhere: force dark status/navigation icons regardless of system dark mode.
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT),
        )
        super.onCreate(savedInstanceState)
        setContent {
            FlitCardTheme { FlitCardApp(viewModel) }
        }
    }
}
