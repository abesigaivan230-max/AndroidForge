package com.flitcard.app.ui.screens

import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flitcard.app.ui.components.BigButton
import com.flitcard.app.ui.components.Entrance
import com.flitcard.app.ui.components.QrGlyph
import com.flitcard.app.ui.components.SoftBackdrop
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitBlueSoft
import com.flitcard.app.ui.theme.FlitMuted
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOrange
import com.flitcard.app.ui.theme.FlitPurple
import com.flitcard.app.ui.theme.FlitWhite

@Composable
fun WelcomeScreen(onCreate: () -> Unit) {
    Box(Modifier.fillMaxSize()) {
        SoftBackdrop()
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp, vertical = 16.dp)) {
            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Entrance { HeroQr() }
                Spacer(Modifier.height(28.dp))
                Entrance(delayMs = 150) {
                    Text("FlitCard", fontSize = 40.sp, fontWeight = FontWeight.ExtraBold, color = FlitNavy)
                }
                Spacer(Modifier.height(6.dp))
                Entrance(delayMs = 260) {
                    Text(
                        buildAnnotatedString {
                            withStyle(SpanStyle(color = FlitBlue)) { append("Scan. ") }
                            withStyle(SpanStyle(color = FlitPurple)) { append("Save. ") }
                            withStyle(SpanStyle(color = FlitOrange)) { append("Connect.") }
                        },
                        fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    )
                }
                Spacer(Modifier.height(18.dp))
                Entrance(delayMs = 380) {
                    Text(
                        "Share your contact details with one scan. No account, no sign-up, no internet. Your details stay on this phone.",
                        fontSize = 16.sp, lineHeight = 23.sp, color = FlitMuted, textAlign = TextAlign.Center,
                    )
                }
                Spacer(Modifier.height(18.dp))
                Entrance(delayMs = 500) {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("Works offline")
                        Chip("No account")
                        Chip("Private")
                    }
                }
            }
            Entrance(delayMs = 620) {
                BigButton(text = "Create My QR", onClick = onCreate)
            }
        }
    }
}

@Composable
private fun Chip(label: String) {
    Box(
        Modifier
            .background(FlitBlueSoft, RoundedCornerShape(50))
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, color = FlitBlue) }
}

@Composable
private fun HeroQr() {
    val t = rememberInfiniteTransition(label = "hero")
    val float by t.animateFloat(
        initialValue = -8f, targetValue = 8f,
        animationSpec = infiniteRepeatable(tween(2200, easing = EaseInOut), RepeatMode.Reverse),
        label = "float",
    )
    val pulse by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2400, easing = LinearEasing)),
        label = "pulse",
    )
    Box(Modifier.size(230.dp), contentAlignment = Alignment.Center) {
        // Expanding rings
        for (offset in listOf(0f, 0.5f)) {
            val p = (pulse + offset) % 1f
            Box(
                Modifier
                    .size(150.dp)
                    .graphicsLayer {
                        val s = 1f + p * 0.55f
                        scaleX = s; scaleY = s; alpha = (1f - p) * 0.45f
                    }
                    .border(3.dp, Brush.sweepGradient(listOf(FlitBlue, FlitPurple, FlitOrange, FlitBlue)), CircleShape)
            )
        }
        Box(
            Modifier
                .size(150.dp)
                .graphicsLayer { translationY = float.dp.toPx() }
                .shadow(18.dp, RoundedCornerShape(36.dp), ambientColor = FlitBlue, spotColor = FlitBlue)
                .background(FlitWhite, RoundedCornerShape(36.dp))
                .padding(26.dp)
        ) { QrGlyph(Modifier.fillMaxSize()) }
    }
}
