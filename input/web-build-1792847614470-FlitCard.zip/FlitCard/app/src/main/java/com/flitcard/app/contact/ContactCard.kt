package com.flitcard.app.contact

/** A contact as shown in the preview and written to the QR code. Optional fields are null when absent. */
data class ContactCard(
    val name: String,
    val phone: String?,
    val whatsapp: String?,
    val email: String?,
)
