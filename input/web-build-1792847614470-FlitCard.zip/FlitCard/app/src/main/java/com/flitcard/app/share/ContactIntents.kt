package com.flitcard.app.share

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.provider.ContactsContract
import android.provider.ContactsContract.CommonDataKinds.Email
import android.provider.ContactsContract.CommonDataKinds.Phone
import com.flitcard.app.contact.ContactCard

/** Opens the system "add contact" screen prefilled. The user must tap Save; nothing is written silently. */
object ContactIntents {

    fun buildInsertIntent(card: ContactCard): Intent {
        val phones = listOfNotNull(card.phone, card.whatsapp).distinct()
        return Intent(ContactsContract.Intents.Insert.ACTION).apply {
            type = ContactsContract.RawContacts.CONTENT_TYPE
            putExtra(ContactsContract.Intents.Insert.NAME, card.name)
            phones.getOrNull(0)?.let {
                putExtra(ContactsContract.Intents.Insert.PHONE, it)
                putExtra(ContactsContract.Intents.Insert.PHONE_TYPE, Phone.TYPE_MOBILE)
            }
            phones.getOrNull(1)?.let {
                putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE, it)
                putExtra(ContactsContract.Intents.Insert.SECONDARY_PHONE_TYPE, Phone.TYPE_OTHER)
            }
            card.email?.let {
                putExtra(ContactsContract.Intents.Insert.EMAIL, it)
                putExtra(ContactsContract.Intents.Insert.EMAIL_TYPE, Email.TYPE_OTHER)
            }
            card.whatsapp?.let { putExtra(ContactsContract.Intents.Insert.NOTES, "WhatsApp: $it") }
        }
    }

    /** Returns false when no contacts app can handle the request. */
    fun open(context: Context, card: ContactCard): Boolean = try {
        val intent = buildInsertIntent(card)
        if (context !is Activity) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (_: ActivityNotFoundException) {
        false
    }
}
