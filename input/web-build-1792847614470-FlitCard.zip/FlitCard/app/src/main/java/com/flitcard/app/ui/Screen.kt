package com.flitcard.app.ui

import com.flitcard.app.contact.ContactCard

/** App destinations. [depth] drives slide direction in transitions. */
sealed interface Screen {
    val depth: Int

    data object Welcome : Screen { override val depth = 0 }
    data class EditProfile(val creating: Boolean) : Screen {
        override val depth get() = if (creating) 1 else 3
    }
    data object Card : Screen { override val depth = 2 }
    data object Scan : Screen { override val depth = 3 }
    data class Preview(val contact: ContactCard) : Screen { override val depth = 4 }
}
