package com.flitcard.app.qr

import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.zxing.BarcodeFormat
import com.google.zxing.BinaryBitmap
import com.google.zxing.DecodeHintType
import com.google.zxing.MultiFormatReader
import com.google.zxing.PlanarYUVLuminanceSource
import com.google.zxing.ReaderException
import com.google.zxing.common.HybridBinarizer

/** Decodes QR codes from CameraX luminance frames, offline. Runs on the analysis executor. */
class QrAnalyzer(private val onQrText: (String) -> Unit) : ImageAnalysis.Analyzer {

    private val reader = MultiFormatReader().apply {
        setHints(
            mapOf(
                DecodeHintType.POSSIBLE_FORMATS to listOf(BarcodeFormat.QR_CODE),
                DecodeHintType.TRY_HARDER to true,
                DecodeHintType.CHARACTER_SET to "UTF-8",
            )
        )
    }

    override fun analyze(image: ImageProxy) {
        try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val rowStride = plane.rowStride
            val width = image.width
            val height = image.height
            val data = ByteArray(maxOf(buffer.remaining(), rowStride * height))
            buffer.get(data, 0, buffer.remaining())
            val source = PlanarYUVLuminanceSource(data, rowStride, height, 0, 0, width, height, false)
            val result = reader.decodeWithState(BinaryBitmap(HybridBinarizer(source)))
            result.text?.let(onQrText)
        } catch (_: ReaderException) {
            // No QR code in this frame: normal, keep scanning.
        } catch (_: RuntimeException) {
            // Defensive: a bad frame must never crash the scanner.
        } finally {
            reader.reset()
            image.close()
        }
    }
}
