package com.flitcard.app.share

import android.app.Activity
import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.text.TextPaint
import android.text.TextUtils
import androidx.core.content.FileProvider
import com.flitcard.app.qr.QrGenerator
import java.io.File
import java.io.FileOutputStream
import kotlin.coroutines.cancellation.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Renders a shareable PNG of the user's QR card and hands it to the Android share sheet. */
object QrShare {
    private const val BLUE = 0xFF2563EB.toInt()
    private const val PURPLE = 0xFF8B5CF6.toInt()
    private const val ORANGE = 0xFFFF8A34.toInt()
    private const val NAVY = 0xFF172554.toInt()

    fun renderCard(name: String, payload: String): Bitmap {
        val w = 1080
        val h = 1400
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)

        val gradient = LinearGradient(0f, 0f, w.toFloat(), 0f, intArrayOf(BLUE, PURPLE, ORANGE), null, Shader.TileMode.CLAMP)
        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply { shader = gradient }
        c.drawRect(0f, 0f, w.toFloat(), 24f, paint)

        val text = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        text.color = BLUE; text.textSize = 72f
        c.drawText("FlitCard", w / 2f, 150f, text)

        text.color = NAVY; text.textSize = 60f
        val shown = TextUtils.ellipsize(name, text, w - 160f, TextUtils.TruncateAt.END).toString()
        c.drawText(shown, w / 2f, 262f, text)

        val qrSize = 800
        val qr = QrGenerator.generate(payload, qrSize)
        val left = (w - qrSize) / 2f
        val top = 340f
        paint.style = Paint.Style.STROKE
        paint.strokeWidth = 12f
        c.drawRoundRect(RectF(left - 44, top - 44, left + qrSize + 44, top + qrSize + 44), 56f, 56f, paint)
        c.drawBitmap(qr, left, top, null)
        qr.recycle()

        text.color = ORANGE; text.textSize = 52f
        c.drawText("Scan. Save. Connect.", w / 2f, 1290f, text)
        return bmp
    }

    /** Returns true if the share sheet was opened. */
    suspend fun share(context: Context, name: String, payload: String): Boolean {
        val uri = try {
            withContext(Dispatchers.IO) {
                val dir = File(context.cacheDir, "shared").apply { mkdirs() }
                dir.listFiles()?.forEach { it.delete() }
                val file = File(dir, "flitcard-qr-${System.currentTimeMillis()}.png")
                val bmp = renderCard(name, payload)
                FileOutputStream(file).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
                bmp.recycle()
                FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (_: Exception) {
            return false
        }

        return try {
            val send = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "Scan my FlitCard QR code to save my contact.")
                clipData = ClipData.newRawUri("FlitCard QR", uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            val chooser = Intent.createChooser(send, "Share your FlitCard")
            if (context !is Activity) chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
            true
        } catch (_: Exception) {
            false
        }
    }
}
