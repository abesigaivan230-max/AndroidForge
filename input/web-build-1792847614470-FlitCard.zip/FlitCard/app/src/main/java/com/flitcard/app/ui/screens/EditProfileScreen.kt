package com.flitcard.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flitcard.app.contact.Validators
import com.flitcard.app.data.Profile
import com.flitcard.app.ui.components.BigButton
import com.flitcard.app.ui.components.Entrance
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitError
import com.flitcard.app.ui.theme.FlitMuted
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOutline

@Composable
fun EditProfileScreen(
    initial: Profile?,
    creating: Boolean,
    onSave: (Profile) -> Unit,
    onBack: () -> Unit,
) {
    var name by rememberSaveable { mutableStateOf(initial?.fullName.orEmpty()) }
    var phone by rememberSaveable { mutableStateOf(initial?.phone.orEmpty()) }
    var whatsapp by rememberSaveable { mutableStateOf(initial?.whatsapp.orEmpty()) }
    var email by rememberSaveable { mutableStateOf(initial?.email.orEmpty()) }
    var submitted by rememberSaveable { mutableStateOf(false) }
    val focus = LocalFocusManager.current

    val cleanName = Validators.normalizeName(name)
    val cleanPhone = Validators.normalizePhone(phone)
    val cleanWhatsapp = if (whatsapp.isBlank()) "" else Validators.normalizePhone(whatsapp)
    val cleanEmail = if (email.isBlank()) "" else Validators.normalizeEmail(email)

    val nameError = if (submitted && cleanName == null) "Enter your full name (at least 2 characters)." else null
    val phoneError = if (submitted && cleanPhone == null) "Enter a valid phone number, e.g. 0700123456 or +256700123456." else null
    val waError = if (submitted && cleanWhatsapp == null) "That WhatsApp number doesn't look right. Leave it empty if you don't have one." else null
    val emailError = if (submitted && cleanEmail == null) "That email address doesn't look right. Leave it empty if you don't have one." else null

    fun submit() {
        submitted = true
        if (cleanName != null && cleanPhone != null && cleanWhatsapp != null && cleanEmail != null) {
            focus.clearFocus()
            onSave(Profile(cleanName, cleanPhone, cleanWhatsapp, cleanEmail))
        }
    }

    Column(Modifier.fillMaxSize().imePadding().padding(horizontal = 20.dp)) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack, modifier = Modifier.size(52.dp)) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = FlitNavy)
            }
            Text(
                if (creating) "Create your card" else "Edit your card",
                fontSize = 22.sp, fontWeight = FontWeight.Bold, color = FlitNavy,
            )
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Entrance {
                Text(
                    "Your name and phone number go into your QR code. Everything stays on this phone.",
                    fontSize = 15.sp, lineHeight = 22.sp, color = FlitMuted,
                )
            }
            Entrance(delayMs = 80) {
                Field("Full name", name, { if (it.length <= Validators.MAX_NAME) name = it },
                    Icons.Default.Person, nameError, KeyboardType.Text, ImeAction.Next, { focus.moveFocus(androidx.compose.ui.focus.FocusDirection.Down) })
            }
            Entrance(delayMs = 160) {
                Field("Phone number", phone, { if (it.length <= Validators.MAX_PHONE) phone = it },
                    Icons.Default.Call, phoneError, KeyboardType.Phone, ImeAction.Next, { focus.moveFocus(androidx.compose.ui.focus.FocusDirection.Down) })
            }
            Entrance(delayMs = 240) {
                Field("WhatsApp number (optional)", whatsapp, { if (it.length <= Validators.MAX_PHONE) whatsapp = it },
                    Icons.Default.Send, waError, KeyboardType.Phone, ImeAction.Next, { focus.moveFocus(androidx.compose.ui.focus.FocusDirection.Down) })
            }
            Entrance(delayMs = 320) {
                Field("Email (optional)", email, { if (it.length <= Validators.MAX_EMAIL) email = it },
                    Icons.Default.Email, emailError, KeyboardType.Email, ImeAction.Done, { submit() })
            }
            Spacer(Modifier.height(4.dp))
        }

        Box(Modifier.padding(vertical = 14.dp)) {
            BigButton(
                text = if (creating) "Generate my QR" else "Save & update QR",
                onClick = ::submit,
                icon = Icons.Default.Check,
            )
        }
    }
}

@Composable
private fun Field(
    label: String,
    value: String,
    onChange: (String) -> Unit,
    icon: ImageVector,
    error: String?,
    keyboard: KeyboardType,
    ime: ImeAction,
    onImeAction: () -> Unit,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onChange,
        modifier = Modifier.fillMaxWidth(),
        label = { Text(label) },
        leadingIcon = { Icon(icon, contentDescription = null) },
        singleLine = true,
        isError = error != null,
        supportingText = error?.let { { Text(it, color = FlitError) } },
        keyboardOptions = KeyboardOptions(keyboardType = keyboard, imeAction = ime),
        keyboardActions = KeyboardActions(onNext = { onImeAction() }, onDone = { onImeAction() }),
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = FlitBlue,
            unfocusedBorderColor = FlitOutline,
            focusedLabelColor = FlitBlue,
            focusedLeadingIconColor = FlitBlue,
            cursorColor = FlitBlue,
        ),
    )
}
