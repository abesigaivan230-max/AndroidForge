package com.flitcard.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.emptyPreferences
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import java.io.IOException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map

private val Context.profileStore by preferencesDataStore(name = "flitcard_profile")

/** Local-only profile storage (Jetpack DataStore). Nothing leaves the device. */
class ProfileRepository(context: Context) {
    private val store = context.applicationContext.profileStore

    private object Keys {
        val NAME = stringPreferencesKey("full_name")
        val PHONE = stringPreferencesKey("phone")
        val WHATSAPP = stringPreferencesKey("whatsapp")
        val EMAIL = stringPreferencesKey("email")
    }

    /** Emits null when no valid profile has been saved yet. */
    val profile: Flow<Profile?> = store.data
        .catch { if (it is IOException) emit(emptyPreferences()) else throw it }
        .map { p ->
            val name = p[Keys.NAME]
            val phone = p[Keys.PHONE]
            if (name.isNullOrBlank() || phone.isNullOrBlank()) null
            else Profile(name, phone, p[Keys.WHATSAPP].orEmpty(), p[Keys.EMAIL].orEmpty())
        }

    suspend fun save(profile: Profile) {
        store.edit {
            it[Keys.NAME] = profile.fullName
            it[Keys.PHONE] = profile.phone
            it[Keys.WHATSAPP] = profile.whatsapp
            it[Keys.EMAIL] = profile.email
        }
    }
}
