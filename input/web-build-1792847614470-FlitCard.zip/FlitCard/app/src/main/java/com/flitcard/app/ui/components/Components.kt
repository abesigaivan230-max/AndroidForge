package com.flitcard.app.ui.components

import androidx.compose.animation.core.EaseInOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOrange
import com.flitcard.app.ui.theme.FlitPurple
import com.flitcard.app.ui.theme.FlitWhite
import androidx.compose.ui.text.font.FontWeight
import kotlinx.coroutines.delay

enum class ButtonKind { Primary, Accent, Outline }

/** Large (58dp+) button with a springy press animation. */
@Composable
fun BigButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    kind: ButtonKind = ButtonKind.Primary,
    icon: ImageVector? = null,
    enabled: Boolean = true,
) {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "pressScale",
    )
    val m = modifier
        .fillMaxWidth()
        .heightIn(min = 58.dp)
        .graphicsLayer { scaleX = scale; scaleY = scale }
    val shape = RoundedCornerShape(18.dp)
    val content: @Composable RowScope.() -> Unit = {
        if (icon != null) {
            Icon(icon, contentDescription = null, modifier = Modifier.size(22.dp))
            Spacer(Modifier.width(10.dp))
        }
        Text(text, fontSize = 17.sp, fontWeight = FontWeight.Bold)
    }
    when (kind) {
        ButtonKind.Primary -> Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = FlitBlue, contentColor = FlitWhite),
            interactionSource = source, content = content,
        )
        ButtonKind.Accent -> Button(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            colors = ButtonDefaults.buttonColors(containerColor = FlitOrange, contentColor = FlitNavy),
            interactionSource = source, content = content,
        )
        ButtonKind.Outline -> OutlinedButton(
            onClick = onClick, modifier = m, enabled = enabled, shape = shape,
            border = BorderStroke(2.dp, FlitBlue),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = FlitBlue),
            interactionSource = source, content = content,
        )
    }
}

/** Fades and slides its content up after [delayMs]; layout space is reserved so nothing jumps. */
@Composable
fun Entrance(modifier: Modifier = Modifier, delayMs: Int = 0, content: @Composable () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        delay(delayMs.toLong())
        shown = true
    }
    val p by animateFloatAsState(
        targetValue = if (shown) 1f else 0f,
        animationSpec = tween(520, easing = FastOutSlowInEasing),
        label = "entrance",
    )
    Box(modifier.graphicsLayer { alpha = p; translationY = (1f - p) * 36.dp.toPx() }) { content() }
}

private val GLYPH = listOf(
    "11111011111",
    "10001110001",
    "10101010101",
    "10001110001",
    "11111011111",
    "01011010010",
    "11111010110",
    "10001101001",
    "10101011010",
    "10001000111",
    "11111010101",
)

/** Stylised QR glyph used for branding (not a scannable code). */
@Composable
fun QrGlyph(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val n = GLYPH.size
        val cell = size.minDimension / n
        for (r in 0 until n) for (c in 0 until n) {
            if (GLYPH[r][c] != '1') continue
            val color = when {
                r < 5 && c < 5 -> FlitBlue
                r < 5 && c > 5 -> FlitPurple
                r > 5 && c < 5 -> FlitOrange
                else -> FlitNavy
            }
            drawRoundRect(
                color = color,
                topLeft = Offset(c * cell + cell * 0.06f, r * cell + cell * 0.06f),
                size = Size(cell * 0.88f, cell * 0.88f),
                cornerRadius = CornerRadius(cell * 0.22f),
            )
        }
    }
}

@Composable
fun AppLogo(modifier: Modifier = Modifier) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .size(40.dp)
                .background(Brush.linearGradient(listOf(FlitBlue, FlitPurple)), RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(26.dp).background(FlitWhite, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                QrGlyph(Modifier.size(20.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Text("FlitCard", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = FlitNavy)
    }
}

/** Soft drifting colour blobs behind a screen. Pure canvas, cheap on low-end phones. */
@Composable
fun SoftBackdrop(modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "backdrop")
    val drift by t.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = EaseInOut), RepeatMode.Reverse),
        label = "drift",
    )
    Box(
        modifier
            .fillMaxSize()
            .drawBehind {
                val w = size.width
                val h = size.height
                fun blob(color: Color, cx: Float, cy: Float, r: Float) = drawCircle(
                    brush = Brush.radialGradient(listOf(color.copy(alpha = 0.22f), Color.Transparent), Offset(cx, cy), r),
                    radius = r, center = Offset(cx, cy),
                )
                blob(FlitBlue, w * (0.12f + 0.10f * drift), h * 0.08f, w * 0.7f)
                blob(FlitPurple, w * (0.95f - 0.12f * drift), h * (0.45f + 0.05f * drift), w * 0.6f)
                blob(FlitOrange, w * (0.20f + 0.08f * drift), h * 0.98f, w * 0.65f)
            }
    )
}

/** Simple "scan" icon (corner brackets + centre line); not in the core icon set. */
val ScanIcon: ImageVector by lazy {
    ImageVector.Builder(
        name = "Scan", defaultWidth = 24.dp, defaultHeight = 24.dp,
        viewportWidth = 24f, viewportHeight = 24f,
    ).apply {
        path(
            stroke = SolidColor(Color.Black),
            strokeLineWidth = 2.2f,
            strokeLineCap = StrokeCap.Round,
            strokeLineJoin = StrokeJoin.Round,
        ) {
            moveTo(4f, 8f); lineTo(4f, 5f); lineTo(7f, 5f)
            moveTo(17f, 5f); lineTo(20f, 5f); lineTo(20f, 8f)
            moveTo(20f, 16f); lineTo(20f, 19f); lineTo(17f, 19f)
            moveTo(7f, 19f); lineTo(4f, 19f); lineTo(4f, 16f)
            moveTo(4f, 12f); lineTo(20f, 12f)
        }
    }.build()
}
