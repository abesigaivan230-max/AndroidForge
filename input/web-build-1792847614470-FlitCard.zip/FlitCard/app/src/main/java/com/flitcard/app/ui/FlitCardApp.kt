package com.flitcard.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.flitcard.app.FlitCardViewModel
import com.flitcard.app.ProfileState
import com.flitcard.app.ui.screens.CardScreen
import com.flitcard.app.ui.screens.EditProfileScreen
import com.flitcard.app.ui.screens.PreviewScreen
import com.flitcard.app.ui.screens.ScanScreen
import com.flitcard.app.ui.screens.WelcomeScreen
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitWhite

@Composable
fun FlitCardApp(vm: FlitCardViewModel) {
    val profileState by vm.profileState.collectAsStateWithLifecycle()
    val qr by vm.qr.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize().background(FlitWhite).systemBarsPadding()) {
        val state = profileState
        if (state is ProfileState.Loading) {
            CircularProgressIndicator(Modifier.align(Alignment.Center), color = FlitBlue)
            return@Box
        }

        val screen: Screen = vm.screen ?: if (state is ProfileState.Ready) Screen.Card else Screen.Welcome
        val profile = (state as? ProfileState.Ready)?.profile

        BackHandler(enabled = screen != Screen.Welcome && screen != Screen.Card) {
            vm.goTo(
                when (screen) {
                    is Screen.EditProfile -> if (screen.creating) Screen.Welcome else Screen.Card
                    is Screen.Preview -> Screen.Scan
                    else -> Screen.Card.takeIf { profile != null } ?: Screen.Welcome
                }
            )
        }

        AnimatedContent(
            targetState = screen,
            contentKey = { it::class },
            transitionSpec = {
                val forward = targetState.depth >= initialState.depth
                val dir = if (forward) 1 else -1
                (slideInHorizontally(tween(340)) { dir * it / 4 } + fadeIn(tween(340))) togetherWith
                    (slideOutHorizontally(tween(260)) { -dir * it / 4 } + fadeOut(tween(200)))
            },
            label = "screens",
        ) { s ->
            when (s) {
                Screen.Welcome -> WelcomeScreen(onCreate = { vm.goTo(Screen.EditProfile(creating = true)) })
                is Screen.EditProfile -> EditProfileScreen(
                    initial = profile.takeIf { !s.creating },
                    creating = s.creating,
                    onSave = vm::saveProfile,
                    onBack = { vm.goTo(if (s.creating) Screen.Welcome else Screen.Card) },
                )
                Screen.Card -> if (profile != null) {
                    CardScreen(
                        profile = profile,
                        qr = qr,
                        onScan = { vm.goTo(Screen.Scan) },
                        onEdit = { vm.goTo(Screen.EditProfile(creating = false)) },
                    )
                }
                Screen.Scan -> ScanScreen(
                    onContact = { vm.goTo(Screen.Preview(it)) },
                    onBack = { vm.goTo(if (profile != null) Screen.Card else Screen.Welcome) },
                )
                is Screen.Preview -> PreviewScreen(
                    contact = s.contact,
                    onScanAnother = { vm.goTo(Screen.Scan) },
                    onDone = { vm.goTo(if (profile != null) Screen.Card else Screen.Welcome) },
                )
            }
        }
    }
}
