package com.flitcard.app.ui.screens

import android.widget.Toast
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flitcard.app.FlitCardViewModel
import com.flitcard.app.QrUi
import com.flitcard.app.data.Profile
import com.flitcard.app.share.QrShare
import com.flitcard.app.ui.components.AppLogo
import com.flitcard.app.ui.components.BigButton
import com.flitcard.app.ui.components.ButtonKind
import com.flitcard.app.ui.components.Entrance
import com.flitcard.app.ui.components.ScanIcon
import com.flitcard.app.ui.components.SoftBackdrop
import com.flitcard.app.ui.theme.FlitBlue
import com.flitcard.app.ui.theme.FlitMuted
import com.flitcard.app.ui.theme.FlitNavy
import com.flitcard.app.ui.theme.FlitOrange
import com.flitcard.app.ui.theme.FlitPurple
import com.flitcard.app.ui.theme.FlitWhite
import kotlinx.coroutines.launch

@Composable
fun CardScreen(
    profile: Profile,
    qr: QrUi?,
    onScan: () -> Unit,
    onEdit: () -> Unit,
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var sharing by remember { mutableStateOf(false) }
    val payload = remember(profile) { FlitCardViewModel.payloadFor(profile) }
    val readyQr = qr?.takeIf { it.payload == payload }

    Box(Modifier.fillMaxSize()) {
        SoftBackdrop()
        Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
            Row(
                Modifier.fillMaxWidth().height(64.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
            ) {
                AppLogo()
                TextButton(onClick = onEdit, modifier = Modifier.heightIn(min = 48.dp)) {
                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(18.dp), tint = FlitBlue)
                    Spacer(Modifier.size(6.dp))
                    Text("Edit profile", fontWeight = FontWeight.Bold, color = FlitBlue, fontSize = 15.sp)
                }
            }

            Column(
                Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
            ) {
                Entrance {
                    Text(
                        profile.fullName, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = FlitNavy,
                        maxLines = 2, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                    )
                }
                Spacer(Modifier.height(2.dp))
                Entrance(delayMs = 60) { Text(profile.phone, fontSize = 16.sp, color = FlitMuted) }
                Spacer(Modifier.height(18.dp))
                Entrance(delayMs = 140) { QrCard(readyQr) }
                Spacer(Modifier.height(16.dp))
                Entrance(delayMs = 260) {
                    Text(
                        "Ask them to scan this to save your contact.",
                        fontSize = 15.sp, color = FlitMuted, textAlign = TextAlign.Center,
                    )
                }
            }

            Column(Modifier.padding(vertical = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Entrance(delayMs = 320) {
                    BigButton("Scan a QR code", onScan, icon = ScanIcon)
                }
                Entrance(delayMs = 400) {
                    BigButton(
                        text = if (sharing) "Preparing image…" else "Share QR image",
                        onClick = {
                            if (!sharing && readyQr != null) {
                                sharing = true
                                scope.launch {
                                    val ok = QrShare.share(context, profile.fullName, payload)
                                    sharing = false
                                    if (!ok) Toast.makeText(context, "Couldn't share the image. Please try again.", Toast.LENGTH_LONG).show()
                                }
                            }
                        },
                        kind = ButtonKind.Accent,
                        icon = Icons.Default.Share,
                        enabled = !sharing && readyQr != null,
                    )
                }
            }
        }
    }
}

@Composable
private fun QrCard(qr: QrUi?) {
    // Springy pop-in each time a (new) QR becomes available.
    val scale by animateFloatAsState(
        targetValue = if (qr != null) 1f else 0.85f,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow),
        label = "qrScale",
    )
    Box(
        Modifier
            .widthIn(max = 320.dp)
            .fillMaxWidth()
            .aspectRatio(1f)
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .background(Brush.sweepGradient(listOf(FlitBlue, FlitPurple, FlitOrange, FlitBlue)), RoundedCornerShape(28.dp))
            .padding(4.dp)
            .background(FlitWhite, RoundedCornerShape(24.dp))
            .padding(14.dp),
        contentAlignment = Alignment.Center,
    ) {
        if (qr == null) {
            CircularProgressIndicator(color = FlitBlue)
        } else {
            Image(
                bitmap = qr.image,
                contentDescription = "Your FlitCard QR code",
                modifier = Modifier.fillMaxSize(),
            )
        }
    }
}
