package com.flitcard.app.contact

/** Pure-Kotlin input cleaning/validation shared by the profile form and the QR parser. */
object Validators {
    const val MAX_NAME = 80
    const val MAX_PHONE = 20
    const val MAX_EMAIL = 100

    private val whitespace = Regex("\\s+")
    private val emailRegex = Regex("^[A-Za-z0-9._%+\\-]{1,64}@[A-Za-z0-9\\-]+(\\.[A-Za-z0-9\\-]+)*\\.[A-Za-z]{2,24}$")

    /** Removes control characters, collapses whitespace, trims and caps the length. */
    fun cleanText(raw: String, max: Int): String =
        raw.filter { !it.isISOControl() }.replace(whitespace, " ").trim().take(max)

    /** Returns a clean display name (2..80 chars) or null when invalid. */
    fun normalizeName(raw: String): String? =
        cleanText(raw, MAX_NAME).takeIf { it.length >= 2 }

    /**
     * Accepts digits with optional leading '+' and common separators (space - . ( )).
     * Returns "+digits" or "digits", or null if not 7..15 digits or if it contains letters/other symbols.
     */
    fun normalizePhone(raw: String): String? {
        val t = raw.trim().removePrefix("tel:").trim()
        if (t.isEmpty() || t.length > 40) return null
        for ((i, c) in t.withIndex()) {
            val ok = c in '0'..'9' || c in " -.()" || (c == '+' && i == 0)
            if (!ok) return null
        }
        val digits = t.filter { it in '0'..'9' }
        if (digits.length !in 7..15) return null
        return if (t.startsWith("+")) "+$digits" else digits
    }

    /** Returns a trimmed email or null when invalid. */
    fun normalizeEmail(raw: String): String? {
        val t = raw.trim().removePrefix("mailto:").trim()
        if (t.length > MAX_EMAIL || t.contains("..")) return null
        return t.takeIf { emailRegex.matches(it) }
    }
}
