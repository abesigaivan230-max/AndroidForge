package com.flitcard.app.contact

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class VCardTest {

    private fun ok(raw: String): ContactCard {
        val r = VCard.parse(raw)
        assertTrue("expected success but got $r", r is ParseResult.Success)
        return (r as ParseResult.Success).card
    }

    private fun fails(raw: String) = assertTrue(VCard.parse(raw) is ParseResult.Failure)

    @Test fun roundTripAllFields() {
        val card = ContactCard("Amina Nakato", "+256700123456", "+256770987654", "amina@example.com")
        assertEquals(card, ok(VCard.build(card)))
    }

    @Test fun roundTripMinimal() {
        val card = ContactCard("Joel", "0700123456", null, null)
        assertEquals(card, ok(VCard.build(card)))
    }

    @Test fun whatsappSameAsPhoneSurvivesRoundTrip() {
        val card = ContactCard("Ayvan K", "+256700123456", "+256700123456", null)
        assertEquals(card, ok(VCard.build(card)))
    }

    @Test fun specialCharactersInNameAreEscaped() {
        val card = ContactCard("Doe; Jane, Jr", "+256700123456", null, null)
        assertEquals("Doe; Jane, Jr", ok(VCard.build(card)).name)
    }

    @Test fun foldedLinesAreUnfolded() {
        val raw = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Long\r\n  Name\r\nTEL:+256700123456\r\nEND:VCARD"
        assertEquals("Long Name", ok(raw).name)
    }

    @Test fun thirdPartyCardWithoutWhatsappParses() {
        val raw = "BEGIN:VCARD\nVERSION:3.0\nN:Okello;Peter;;;\nTEL;TYPE=CELL:+256 700 123 456\nEMAIL:peter@x.org\nEND:VCARD"
        val c = ok(raw)
        assertEquals("Peter Okello", c.name)
        assertEquals("+256700123456", c.phone)
        assertEquals("peter@x.org", c.email)
        assertNull(c.whatsapp)
    }

    @Test fun invalidOptionalFieldsAreDropped() {
        val raw = "BEGIN:VCARD\nFN:Sam\nTEL:+256700123456\nEMAIL:not-an-email\nX-WHATSAPP:abc\nEND:VCARD"
        val c = ok(raw)
        assertNull(c.email)
        assertNull(c.whatsapp)
    }

    @Test fun nonContactTextIsRejected() {
        fails("https://example.com")
        fails("")
        fails("WIFI:S:home;T:WPA;P:secret;;")
    }

    @Test fun incompleteOrEmptyCardsAreRejected() {
        fails("BEGIN:VCARD\nFN:No End\nTEL:+256700123456")
        fails("BEGIN:VCARD\nTEL:+256700123456\nEND:VCARD")          // no name
        fails("BEGIN:VCARD\nFN:Nobody\nEND:VCARD")                 // nothing to save
        fails("BEGIN:VCARD\nFN:Bad\nTEL:12\nEND:VCARD")            // invalid phone
    }

    @Test fun oversizedPayloadIsRejected() {
        fails("BEGIN:VCARD\nFN:" + "A".repeat(5000) + "\nEND:VCARD")
    }

    @Test fun phoneValidation() {
        assertEquals("0700123456", Validators.normalizePhone("0700 123-456"))
        assertEquals("+256700123456", Validators.normalizePhone("+256 (700) 123456"))
        assertNull(Validators.normalizePhone("abc1234567"))
        assertNull(Validators.normalizePhone("123"))
        assertNull(Validators.normalizePhone("12+3456789"))
    }
}
