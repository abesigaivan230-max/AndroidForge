# No custom rules needed: ZXing core, CameraX, Compose and DataStore ship consumer rules.
