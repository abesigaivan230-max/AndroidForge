# FlitCard — Scan. Save. Connect.

Native Android app (Kotlin + Jetpack Compose) that shares contact details through a locally generated QR code.
No account, no server, no analytics, **no INTERNET permission**. The only permission is CAMERA (for scanning).

## Status: READ THIS FIRST
This project was written without access to the Android SDK or Google's Maven repository, so **the full app has
NOT been compiled or run**. What *was* verified: the pure-Kotlin contact logic (`contact/` package: vCard build/parse,
validation) compiled and passed its 11 JUnit tests on a JVM, and every source file parses without syntax errors.
Compose/CameraX/Android-API code is unverified until you build it. Expect to possibly fix a few compile errors on
first build (most likely API-version nits), then test on a real phone.

## Project structure
```
app/src/main/java/com/flitcard/app/
  MainActivity.kt            entry point, edge-to-edge, theme
  FlitCardViewModel.kt       profile state, QR generation, navigation state
  contact/                   pure Kotlin (JVM-testable): ContactCard, Validators, VCard (build + parse)
  data/                      Profile, ProfileRepository (DataStore, local only)
  qr/                        QrGenerator (ZXing encode), QrAnalyzer (CameraX frames -> ZXing decode)
  share/                     ContactIntents (system "add contact" screen), QrShare (PNG + share sheet)
  ui/                        FlitCardApp (animated navigation), Screen
  ui/theme, ui/components    colours, typography, buttons, animations, branding glyph
  ui/screens/                Welcome, EditProfile, Card, Scan, Preview
app/src/test/.../VCardTest.kt  11 unit tests
```

## Open, build, run
1. Install Android Studio (Ladybug 2024.2 or newer) with JDK 17 (bundled JBR is fine) and SDK Platform 35.
2. File > Open > select the `FlitCard` folder. Let Gradle sync (needs internet once; downloads Gradle 8.9 + libraries).
3. Plug in a phone (USB debugging on) or start an emulator (API 26+; set the emulator's back camera to "Webcam0" or "VirtualScene").
4. Press Run. Command line alternative: `./gradlew assembleDebug` then `./gradlew installDebug`.

## Test
- Unit tests: `./gradlew testDebugUnitTest`
- Manual checklist on two phones (or one phone + a printed/other-screen QR):
  1. Welcome > Create My QR > enter name + phone > Generate. QR appears.
  2. Force-close and reopen: QR shows immediately (no welcome screen).
  3. Edit profile, change the phone number, save: QR changes. Scan it and confirm the new number.
  4. Scan from the second phone: preview shows name, phone, optional WhatsApp/email. "Save to Contacts" opens the
     system contact editor prefilled; nothing saves until you tap Save there.
  5. Scan a non-contact QR (a website, Wi-Fi code): red banner, app keeps scanning, no crash.
  6. Deny camera permission, deny again with "Don't ask again": the Open settings path appears; enabling it and
     returning resumes the camera.
  7. Airplane mode: everything above still works.
  8. Share QR image: share sheet opens with a PNG card; send it to yourself and scan it from the other screen.

## Signed release APK (distribution outside Google Play)
1. Create a keystore once and **back it up** (lose it = you can never ship updates to installed copies):
   ```
   keytool -genkeypair -v -keystore flitcard-release.jks -alias flitcard -keyalg RSA -keysize 2048 -validity 10000
   ```
2. Copy `keystore.properties.example` to `keystore.properties` (git-ignored) and fill in the path, passwords and alias.
3. Build: `./gradlew assembleRelease`
   Output: `app/build/outputs/apk/release/app-release.apk` (signed automatically because `keystore.properties` exists).
   Or in Android Studio: Build > Generate Signed App Bundle / APK > APK.
4. Verify: `apksigner verify --verbose app/build/outputs/apk/release/app-release.apk` (in `<sdk>/build-tools/<ver>/`).
5. Distribute the APK (WhatsApp, link, USB). Recipients must allow "Install unknown apps" for the app they open it from.
6. Bump `versionCode` (and `versionName`) in `app/build.gradle.kts` for every update you ship.

## Known limitations / needs physical-device testing
- **Not compiled by me.** Treat the first build as the real test; fix whatever Gradle reports.
- Scanning speed and reliability on low-end phones, low light, glare, and cracked/small screens (ZXing decode on
  CameraX 640x480 luminance frames; TRY_HARDER is on). Torch button only appears if the phone reports a flash.
- Whether the stock camera / Google Lens on other phones offers "Add contact" for FlitCard's vCard QR varies by phone;
  FlitCard-to-FlitCard is the tested design path. MeCard (`MECARD:`) QR codes are not supported, only vCard.
- Contact prefill differs per manufacturer's Contacts app. WhatsApp is passed as a second phone number plus a
  "WhatsApp: ..." note, because Android has no standard WhatsApp field.
- Phone validation is format-only (7-15 digits). Numbers are stored/encoded without spaces, e.g. `0700123456`.
- Portrait only; English only (strings are in code, not `strings.xml`); minSdk 26 (Android 8.0), so Android 7 is unsupported.
- Release build uses R8 minification; it is configured conservatively but was never run. If a release-only crash
  appears, set `isMinifyEnabled = false` to confirm.
- No brightness boost on the QR screen, no QR import from gallery, no multiple profiles, no instrumented UI tests.
