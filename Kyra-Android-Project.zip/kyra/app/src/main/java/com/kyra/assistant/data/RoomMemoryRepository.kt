package com.kyra.assistant.data

import com.kyra.assistant.domain.Memory
import com.kyra.assistant.domain.MemoryRepository
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

class RoomMemoryRepository(private val dao: MemoryDao) : MemoryRepository {
    override val memories: Flow<List<Memory>> = dao.observeAll().map { list -> list.map { it.toDomain() } }

    override suspend fun save(text: String) {
        val clean = text.trim().take(500)
        if (clean.isNotEmpty()) dao.insert(MemoryEntity(text = clean, createdAt = System.currentTimeMillis()))
    }

    override suspend fun delete(id: Long) = dao.deleteById(id)

    override suspend fun clearAll() = dao.deleteAll()

    override suspend fun snapshot(): List<Memory> = dao.getAll().map { it.toDomain() }
}
