package com.kyra.assistant.ui

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.kyra.assistant.KyraApp
import com.kyra.assistant.domain.ChatMessage
import com.kyra.assistant.domain.KyraSettings
import com.kyra.assistant.domain.MessageAuthor
import com.kyra.assistant.domain.Memory
import com.kyra.assistant.domain.ReplySource
import com.kyra.assistant.overlay.FloatingOrbService
import com.kyra.assistant.voice.SpeechInput
import com.kyra.assistant.voice.TtsManager
import com.kyra.assistant.voice.TtsStatus
import com.kyra.assistant.voice.VoiceOption
import com.kyra.assistant.voice.WakeWordState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

enum class AssistantPhase { IDLE, LISTENING, THINKING, SPEAKING }

data class ChatUiState(
    val messages: List<ChatMessage> = emptyList(),
    val phase: AssistantPhase = AssistantPhase.IDLE,
    val partialSpeech: String = "",
    val micLevel: Float = 0f,
    val banner: String? = null,
)

data class DeviceStatus(
    val micGranted: Boolean = false,
    val overlayGranted: Boolean = false,
    val notificationsRequired: Boolean = false,
    val notificationsGranted: Boolean = true,
    val flashlightAvailable: Boolean = false,
    val speechRecognitionAvailable: Boolean = false,
    val onDeviceSpeechAvailable: Boolean = false,
    val wakeWordState: WakeWordState = WakeWordState.NOT_IMPLEMENTED,
    val aiConfigured: Boolean = false,
)

class KyraViewModel(app: Application) : AndroidViewModel(app) {
    private val container = (app as KyraApp).container
    private val assistant = container.assistant
    private val settingsRepo = container.settings
    private val memoryRepo = container.memory

    private val speech = SpeechInput(app)
    private val tts = TtsManager(app) { speaking -> onTtsSpeaking(speaking) }

    private var nextId = 1L

    private val _ui = MutableStateFlow(
        ChatUiState(
            messages = listOf(
                ChatMessage(
                    id = 0,
                    author = MessageAuthor.KYRA,
                    text = "Hey, I'm Kyra! Right now I run in built-in offline mode: I can control the flashlight, " +
                        "open apps, tell you the time and date, and keep memories you ask me to save. " +
                        "There's no online AI connected yet, so I can't answer open-ended questions. Say \"help\" for the list.",
                    source = ReplySource.BUILT_IN,
                ),
            ),
        ),
    )
    val ui: StateFlow<ChatUiState> = _ui.asStateFlow()

    val settings: StateFlow<KyraSettings> = settingsRepo.settings
    val memories: StateFlow<List<Memory>> =
        memoryRepo.memories.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val ttsStatus: StateFlow<TtsStatus> = tts.status
    val ttsVoices: StateFlow<List<VoiceOption>> = tts.voices
    val orbRunning: StateFlow<Boolean> = FloatingOrbService.running

    private val _device = MutableStateFlow(DeviceStatus())
    val device: StateFlow<DeviceStatus> = _device.asStateFlow()

    init {
        tts.setVoice(settingsRepo.settings.value.voiceName)
        refreshDeviceStatus()
    }

    // ---- Chat ----

    fun send(raw: String) {
        val text = raw.trim()
        if (text.isEmpty()) return
        tts.stop()
        val history = _ui.value.messages
        _ui.update {
            it.copy(
                messages = it.messages + ChatMessage(nextId++, MessageAuthor.USER, text),
                phase = AssistantPhase.THINKING,
                partialSpeech = "",
                banner = null,
            )
        }
        viewModelScope.launch {
            val reply = try {
                assistant.respond(text, history)
            } catch (e: Exception) {
                com.kyra.assistant.domain.AssistantReply(
                    "Something went wrong: ${e.message ?: "unknown error"}.",
                    ReplySource.SYSTEM,
                    isError = true,
                )
            }
            _ui.update {
                it.copy(
                    messages = it.messages + ChatMessage(nextId++, MessageAuthor.KYRA, reply.text, reply.source, reply.isError),
                    phase = AssistantPhase.IDLE,
                )
            }
            maybeSpeak(reply.text)
        }
    }

    private fun maybeSpeak(text: String) {
        if (!settingsRepo.settings.value.speakResponses) return
        if (tts.status.value != TtsStatus.READY) {
            if (tts.status.value == TtsStatus.UNAVAILABLE) {
                _ui.update { it.copy(banner = "Spoken replies are on, but no text-to-speech voice is available on this phone.") }
            }
            return
        }
        if (!tts.speak(text)) {
            _ui.update { it.copy(banner = "Text-to-speech couldn't start speaking.") }
        }
    }

    private fun onTtsSpeaking(speaking: Boolean) {
        _ui.update {
            when {
                speaking && it.phase == AssistantPhase.IDLE -> it.copy(phase = AssistantPhase.SPEAKING)
                !speaking && it.phase == AssistantPhase.SPEAKING -> it.copy(phase = AssistantPhase.IDLE)
                else -> it
            }
        }
    }

    // ---- Voice input ----

    fun toggleListening() {
        if (_ui.value.phase == AssistantPhase.LISTENING) {
            speech.stop()
            return
        }
        startListening()
    }

    private fun startListening() {
        refreshDeviceStatus()
        val d = _device.value
        if (!d.micGranted) {
            _ui.update { it.copy(banner = "I need microphone permission to listen. You can type instead.") }
            return
        }
        if (!d.speechRecognitionAvailable) {
            _ui.update { it.copy(banner = "Speech recognition isn't available on this phone. You can type instead.") }
            return
        }
        tts.stop()
        _ui.update { it.copy(phase = AssistantPhase.LISTENING, partialSpeech = "", micLevel = 0f, banner = null) }
        speech.start(object : SpeechInput.Listener {
            override fun onPartial(text: String) {
                _ui.update { it.copy(partialSpeech = text) }
            }

            override fun onLevel(level: Float) {
                _ui.update { it.copy(micLevel = level) }
            }

            override fun onResult(text: String) {
                _ui.update { it.copy(phase = AssistantPhase.IDLE, partialSpeech = "", micLevel = 0f) }
                send(text)
            }

            override fun onError(message: String) {
                _ui.update {
                    it.copy(phase = AssistantPhase.IDLE, partialSpeech = "", micLevel = 0f, banner = message)
                }
            }
        })
    }

    fun onMicPermissionResult() {
        refreshDeviceStatus()
        if (_device.value.micGranted) {
            startListening()
        } else {
            _ui.update { it.copy(banner = "Microphone permission was denied. Typing still works.") }
        }
    }

    fun dismissBanner() = _ui.update { it.copy(banner = null) }

    fun stopSpeaking() = tts.stop()

    /** Called when the app leaves the foreground: never keep the mic open or keep talking in the background. */
    fun onBackgrounded() {
        speech.cancel()
        tts.stop()
        _ui.update {
            if (it.phase == AssistantPhase.LISTENING || it.phase == AssistantPhase.SPEAKING) {
                it.copy(phase = AssistantPhase.IDLE, partialSpeech = "", micLevel = 0f)
            } else {
                it
            }
        }
    }

    // ---- Settings ----

    fun setSpeakResponses(value: Boolean) {
        settingsRepo.setSpeakResponses(value)
        if (!value) tts.stop()
    }

    fun setMemoryEnabled(value: Boolean) = settingsRepo.setMemoryEnabled(value)

    fun setVoice(name: String?) {
        settingsRepo.setVoiceName(name)
        tts.setVoice(name)
    }

    fun previewVoice() {
        if (!tts.speak("Hi, this is how I sound.")) {
            _ui.update { it.copy(banner = "Text-to-speech isn't ready.") }
        }
    }

    fun setFloatingOrbEnabled(value: Boolean) {
        settingsRepo.setFloatingOrbEnabled(value)
        refreshDeviceStatus()
    }

    // ---- Memory ----

    fun saveMemory(text: String) {
        if (!settingsRepo.settings.value.memoryEnabled) return
        viewModelScope.launch { memoryRepo.save(text) }
    }

    fun deleteMemory(id: Long) {
        viewModelScope.launch { memoryRepo.delete(id) }
    }

    fun clearMemories() {
        viewModelScope.launch { memoryRepo.clearAll() }
    }

    // ---- Device status ----

    /** Re-reads permissions and capabilities, and makes the floating orb service match the user's setting. */
    fun refreshDeviceStatus() {
        val ctx = getApplication<Application>()
        val notificationsRequired = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
        val overlay = Settings.canDrawOverlays(ctx)
        _device.value = DeviceStatus(
            micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED,
            overlayGranted = overlay,
            notificationsRequired = notificationsRequired,
            notificationsGranted = !notificationsRequired ||
                ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED,
            flashlightAvailable = ctx.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH),
            speechRecognitionAvailable = speech.isAvailable,
            onDeviceSpeechAvailable = speech.isOnDeviceAvailable,
            wakeWordState = container.wakeWord.state,
            aiConfigured = container.aiProvider.isConfigured,
        )
        syncFloatingOrb(ctx, overlay)
    }

    private fun syncFloatingOrb(ctx: Application, overlayGranted: Boolean) {
        val wanted = settingsRepo.settings.value.floatingOrbEnabled
        val running = FloatingOrbService.running.value
        when {
            wanted && overlayGranted && !running -> FloatingOrbService.start(ctx)
            (!wanted || !overlayGranted) && running -> FloatingOrbService.stop(ctx)
        }
    }

    override fun onCleared() {
        speech.cancel()
        tts.shutdown()
        super.onCleared()
    }
}
