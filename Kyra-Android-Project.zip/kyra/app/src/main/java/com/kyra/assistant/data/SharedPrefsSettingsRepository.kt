package com.kyra.assistant.data

import android.content.Context
import com.kyra.assistant.domain.KyraSettings
import com.kyra.assistant.domain.SettingsRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SharedPrefsSettingsRepository(context: Context) : SettingsRepository {
    private val prefs = context.applicationContext.getSharedPreferences("kyra_settings", Context.MODE_PRIVATE)

    private val _settings = MutableStateFlow(
        KyraSettings(
            speakResponses = prefs.getBoolean(KEY_SPEAK, true),
            memoryEnabled = prefs.getBoolean(KEY_MEMORY, true),
            floatingOrbEnabled = prefs.getBoolean(KEY_ORB, false),
            voiceName = prefs.getString(KEY_VOICE, null),
        ),
    )
    override val settings: StateFlow<KyraSettings> = _settings.asStateFlow()

    override fun setSpeakResponses(value: Boolean) {
        prefs.edit().putBoolean(KEY_SPEAK, value).apply()
        _settings.value = _settings.value.copy(speakResponses = value)
    }

    override fun setMemoryEnabled(value: Boolean) {
        prefs.edit().putBoolean(KEY_MEMORY, value).apply()
        _settings.value = _settings.value.copy(memoryEnabled = value)
    }

    override fun setFloatingOrbEnabled(value: Boolean) {
        prefs.edit().putBoolean(KEY_ORB, value).apply()
        _settings.value = _settings.value.copy(floatingOrbEnabled = value)
    }

    override fun setVoiceName(value: String?) {
        prefs.edit().apply { if (value == null) remove(KEY_VOICE) else putString(KEY_VOICE, value) }.apply()
        _settings.value = _settings.value.copy(voiceName = value)
    }

    private companion object {
        const val KEY_SPEAK = "speak_responses"
        const val KEY_MEMORY = "memory_enabled"
        const val KEY_ORB = "floating_orb_enabled"
        const val KEY_VOICE = "voice_name"
    }
}
