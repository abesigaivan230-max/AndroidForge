package com.kyra.assistant.voice

enum class WakeWordState { NOT_IMPLEMENTED, STOPPED, LISTENING }

/**
 * Seam for a future offline "Hey Kyra" detector (e.g. a dedicated on-device keyword-spotting library).
 * It must NOT be faked with repeated SpeechRecognizer calls. See README for the requirements.
 */
interface WakeWordEngine {
    val phrase: String
    val state: WakeWordState
    val isSupported: Boolean
    fun start()
    fun stop()
}

class NotImplementedWakeWordEngine : WakeWordEngine {
    override val phrase: String = "Hey Kyra"
    override val state: WakeWordState = WakeWordState.NOT_IMPLEMENTED
    override val isSupported: Boolean = false
    override fun start() = Unit
    override fun stop() = Unit
}
