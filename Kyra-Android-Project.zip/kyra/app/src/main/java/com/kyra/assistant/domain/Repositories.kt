package com.kyra.assistant.domain

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

interface AssistantRepository {
    suspend fun respond(input: String, history: List<ChatMessage>): AssistantReply
}

interface MemoryRepository {
    val memories: Flow<List<Memory>>
    suspend fun save(text: String)
    suspend fun delete(id: Long)
    suspend fun clearAll()
    suspend fun snapshot(): List<Memory>
}

data class KyraSettings(
    val speakResponses: Boolean = true,
    val memoryEnabled: Boolean = true,
    val floatingOrbEnabled: Boolean = false,
    val voiceName: String? = null,
)

interface SettingsRepository {
    val settings: StateFlow<KyraSettings>
    fun setSpeakResponses(value: Boolean)
    fun setMemoryEnabled(value: Boolean)
    fun setFloatingOrbEnabled(value: Boolean)
    fun setVoiceName(value: String?)
}
