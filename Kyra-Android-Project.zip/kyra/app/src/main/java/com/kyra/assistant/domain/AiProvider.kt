package com.kyra.assistant.domain

/**
 * Replaceable seam for a future online AI service (ideally behind your own secure backend,
 * never with an API key embedded in the app). See README.
 */
interface AiProvider {
    val displayName: String
    val isConfigured: Boolean
    suspend fun generate(prompt: String, history: List<ChatMessage>): Result<String>
}

/** Default provider for v0.1: nothing is configured, nothing touches the network. */
class UnconfiguredAiProvider : AiProvider {
    override val displayName: String = "None"
    override val isConfigured: Boolean = false
    override suspend fun generate(prompt: String, history: List<ChatMessage>): Result<String> =
        Result.failure(IllegalStateException("No AI provider is configured."))
}
