package com.kyra.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import com.kyra.assistant.ui.AssistantPhase
import com.kyra.assistant.ui.theme.KyraColors

/** The big glowing orb. Pure Compose drawing; animation state is only read in the draw phase. */
@Composable
fun KyraOrb(phase: AssistantPhase, level: Float, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "orb")
    val breath by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(2600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "breath",
    )
    val spin by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)),
        label = "spin",
    )
    val amplitude by animateFloatAsState(
        targetValue = when (phase) {
            AssistantPhase.IDLE -> 0.6f
            AssistantPhase.LISTENING -> 1.2f
            AssistantPhase.THINKING -> 1.0f
            AssistantPhase.SPEAKING -> 1.0f
        },
        animationSpec = tween(400),
        label = "amplitude",
    )
    val smoothLevel by animateFloatAsState(targetValue = level, animationSpec = tween(120), label = "level")
    val accent by animateColorAsState(
        targetValue = when (phase) {
            AssistantPhase.IDLE -> KyraColors.NeonPurple
            AssistantPhase.LISTENING -> KyraColors.Cyan
            AssistantPhase.THINKING -> Color(0xFF7C8CFF)
            AssistantPhase.SPEAKING -> KyraColors.Pink
        },
        animationSpec = tween(500),
        label = "accent",
    )
    val spinBoost = if (phase == AssistantPhase.THINKING) 2f else 1f

    Canvas(modifier = modifier.aspectRatio(1f)) {
        val c = center
        val r = size.minDimension / 2f
        val pulse = 1f + 0.035f * amplitude * breath + smoothLevel * 0.14f

        // Outer glow
        drawCircle(
            brush = Brush.radialGradient(
                0.3f to accent.copy(alpha = 0.34f * (0.7f + 0.3f * breath)),
                1f to Color.Transparent,
                center = c,
                radius = r,
            ),
            radius = r,
            center = c,
        )

        // Core sphere
        val coreR = r * 0.50f * pulse
        drawCircle(
            brush = Brush.radialGradient(
                0f to Color.White.copy(alpha = 0.95f),
                0.35f to accent,
                1f to Color(0xFF1A0B3A),
                center = c + Offset(-coreR * 0.25f, -coreR * 0.3f),
                radius = coreR * 1.5f,
            ),
            radius = coreR,
            center = c,
        )

        // Orbiting rings
        val ring1 = r * 0.74f
        rotate(degrees = spin * spinBoost, pivot = c) {
            drawArc(
                brush = Brush.sweepGradient(
                    0f to Color.Transparent,
                    0.5f to KyraColors.Cyan,
                    1f to Color.Transparent,
                    center = c,
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(c.x - ring1, c.y - ring1),
                size = Size(ring1 * 2f, ring1 * 2f),
                style = Stroke(width = 3.dp.toPx(), cap = StrokeCap.Round),
            )
        }
        val ring2 = r * 0.64f
        rotate(degrees = -spin * 0.6f * spinBoost, pivot = c) {
            drawArc(
                brush = Brush.sweepGradient(
                    0f to Color.Transparent,
                    0.5f to KyraColors.NeonPurple,
                    1f to Color.Transparent,
                    center = c,
                ),
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = Offset(c.x - ring2, c.y - ring2),
                size = Size(ring2 * 2f, ring2 * 2f),
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round),
            )
        }
    }
}
