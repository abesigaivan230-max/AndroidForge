package com.kyra.assistant.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kyra.assistant.ui.KyraViewModel
import com.kyra.assistant.ui.components.KyraCard
import com.kyra.assistant.ui.components.StatusChip
import com.kyra.assistant.ui.components.StatusKind
import com.kyra.assistant.ui.theme.KyraColors
import java.text.DateFormat
import java.util.Date

@Composable
fun MemoryScreen(vm: KyraViewModel, onBack: () -> Unit) {
    val memories by vm.memories.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    var newText by rememberSaveable { mutableStateOf("") }
    var confirmClear by remember { mutableStateOf(false) }
    val dateFormat = remember { DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT) }

    ScreenScaffold("Memory", onBack) {
        LazyColumn(
            modifier = Modifier.fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            item {
                KyraCard("Memory is " + if (settings.memoryEnabled) "on" else "off") {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            "Kyra only saves what you explicitly tell her to. Conversations are never saved automatically. Everything here is stored on this phone only.",
                            color = KyraColors.TextDim,
                            fontSize = 12.sp,
                            modifier = Modifier.weight(1f),
                        )
                        Switch(
                            checked = settings.memoryEnabled,
                            onCheckedChange = { vm.setMemoryEnabled(it) },
                            modifier = Modifier.padding(start = 8.dp),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = KyraColors.Cyan,
                                checkedTrackColor = KyraColors.NeonPurple.copy(alpha = 0.6f),
                                uncheckedThumbColor = KyraColors.TextDim,
                                uncheckedTrackColor = KyraColors.DeepPurple,
                            ),
                        )
                    }
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            value = newText,
                            onValueChange = { newText = it.take(500) },
                            enabled = settings.memoryEnabled,
                            modifier = Modifier.weight(1f),
                            placeholder = { Text("Save a memory…", color = KyraColors.TextDim) },
                            shape = RoundedCornerShape(18.dp),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = KyraColors.TextPrimary,
                                unfocusedTextColor = KyraColors.TextPrimary,
                                disabledTextColor = KyraColors.TextDim,
                                cursorColor = KyraColors.Cyan,
                                focusedBorderColor = KyraColors.NeonPurple,
                                unfocusedBorderColor = KyraColors.NeonPurple.copy(alpha = 0.3f),
                            ),
                        )
                        TextButton(
                            enabled = settings.memoryEnabled && newText.isNotBlank(),
                            onClick = {
                                vm.saveMemory(newText)
                                newText = ""
                            },
                        ) { Text("Save", color = KyraColors.Cyan) }
                    }
                }
            }

            item {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    StatusChip(
                        text = "${memories.size} saved",
                        kind = if (memories.isEmpty()) StatusKind.ACTION else StatusKind.OK,
                    )
                    Row(Modifier.weight(1f)) {}
                    if (memories.isNotEmpty()) {
                        TextButton(onClick = { confirmClear = true }) { Text("Clear all", color = KyraColors.Danger) }
                    }
                }
            }

            if (memories.isEmpty()) {
                item {
                    Text(
                        "Nothing saved yet. Try telling Kyra: \"remember that my favourite colour is purple\".",
                        color = KyraColors.TextDim,
                        fontSize = 13.sp,
                    )
                }
            }

            items(memories, key = { it.id }) { memory ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(memory.text, color = KyraColors.TextPrimary, fontSize = 15.sp)
                        Text(dateFormat.format(Date(memory.createdAt)), color = KyraColors.TextDim, fontSize = 11.sp)
                    }
                    IconButton(onClick = { vm.deleteMemory(memory.id) }) {
                        Icon(Icons.Filled.Delete, contentDescription = "Delete memory", tint = KyraColors.Danger)
                    }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            containerColor = KyraColors.CardPurple,
            title = { Text("Delete all memories?", color = KyraColors.TextPrimary) },
            text = { Text("This permanently removes every saved memory from this phone.", color = KyraColors.TextDim) },
            confirmButton = {
                TextButton(onClick = {
                    vm.clearMemories()
                    confirmClear = false
                }) { Text("Delete all", color = KyraColors.Danger) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text("Cancel", color = KyraColors.TextDim) }
            },
        )
    }
}
