package com.kyra.assistant.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

enum class TtsStatus { INITIALIZING, READY, UNAVAILABLE }

data class VoiceOption(val name: String, val label: String)

/**
 * Wraps Android TextToSpeech. Android does not expose voice gender, so Kyra can't reliably
 * filter "female" voices; instead the user picks from the voices the installed engine offers.
 */
class TtsManager(
    context: Context,
    private val onSpeakingChanged: (Boolean) -> Unit,
) {
    private val main = Handler(Looper.getMainLooper())
    private var engine: TextToSpeech? = null
    private var preferredVoice: String? = null

    private val _status = MutableStateFlow(TtsStatus.INITIALIZING)
    val status: StateFlow<TtsStatus> = _status.asStateFlow()

    private val _voices = MutableStateFlow<List<VoiceOption>>(emptyList())
    val voices: StateFlow<List<VoiceOption>> = _voices.asStateFlow()

    init {
        engine = TextToSpeech(context.applicationContext) { code ->
            if (code == TextToSpeech.SUCCESS) onEngineReady() else _status.value = TtsStatus.UNAVAILABLE
        }
    }

    private fun onEngineReady() {
        val tts = engine ?: return
        var langResult = tts.setLanguage(Locale.getDefault())
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            langResult = tts.setLanguage(Locale.US)
        }
        if (langResult == TextToSpeech.LANG_MISSING_DATA || langResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            _status.value = TtsStatus.UNAVAILABLE
            return
        }
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) = notifySpeaking(true)
            override fun onDone(utteranceId: String?) = notifySpeaking(false)
            override fun onStop(utteranceId: String?, interrupted: Boolean) = notifySpeaking(false)

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) = notifySpeaking(false)
        })
        loadVoices(tts)
        preferredVoice?.let { applyVoice(it) }
        _status.value = TtsStatus.READY
    }

    private fun loadVoices(tts: TextToSpeech) {
        val language = tts.voice?.locale?.language ?: Locale.getDefault().language
        val found: List<Voice> = try {
            tts.voices?.filter { it.locale.language == language && !it.isNetworkConnectionRequired }.orEmpty()
        } catch (_: Exception) {
            emptyList()
        }
        _voices.value = found.sortedBy { it.name }.take(16).mapIndexed { index, v ->
            VoiceOption(name = v.name, label = "Voice ${index + 1} · ${v.locale.displayName} · ${v.name}")
        }
    }

    /** Set by the ViewModel from saved settings; null means the engine's default voice. */
    fun setVoice(name: String?) {
        preferredVoice = name
        if (_status.value == TtsStatus.READY) applyVoice(name)
    }

    private fun applyVoice(name: String?) {
        val tts = engine ?: return
        if (name == null) return
        try {
            tts.voices?.firstOrNull { it.name == name }?.let { tts.voice = it }
        } catch (_: Exception) {
        }
    }

    /** Returns false if speech could not be started. */
    fun speak(text: String): Boolean {
        val tts = engine
        if (tts == null || _status.value != TtsStatus.READY) return false
        val clipped = text.take(TextToSpeech.getMaxSpeechInputLength() - 1)
        val result = tts.speak(clipped, TextToSpeech.QUEUE_FLUSH, null, "kyra-${System.nanoTime()}")
        return result == TextToSpeech.SUCCESS
    }

    fun stop() {
        engine?.stop()
        notifySpeaking(false)
    }

    fun shutdown() {
        engine?.stop()
        engine?.shutdown()
        engine = null
    }

    private fun notifySpeaking(speaking: Boolean) {
        main.post { onSpeakingChanged(speaking) }
    }
}
