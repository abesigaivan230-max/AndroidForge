package com.kyra.assistant.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kyra.assistant.ui.KyraViewModel
import com.kyra.assistant.ui.components.KyraCard
import com.kyra.assistant.ui.components.StatusKind
import com.kyra.assistant.ui.components.StatusRow
import com.kyra.assistant.ui.theme.KyraColors
import com.kyra.assistant.voice.TtsStatus
import com.kyra.assistant.voice.WakeWordState

@Composable
fun SettingsScreen(vm: KyraViewModel, onBack: () -> Unit) {
    val settings by vm.settings.collectAsStateWithLifecycle()
    val device by vm.device.collectAsStateWithLifecycle()
    val ttsStatus by vm.ttsStatus.collectAsStateWithLifecycle()
    val voices by vm.ttsVoices.collectAsStateWithLifecycle()
    val orbRunning by vm.orbRunning.collectAsStateWithLifecycle()
    val context = LocalContext.current
    var showVoices by remember { mutableStateOf(false) }

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshDeviceStatus()
    }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.refreshDeviceStatus()
    }

    fun openOverlaySettings() {
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}")),
        )
    }

    fun openAppSettings() {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")),
        )
    }

    // Once the overlay permission is granted, ask for the notification permission that the orb's persistent notification needs.
    LaunchedEffect(settings.floatingOrbEnabled, device.overlayGranted, device.notificationsGranted) {
        if (settings.floatingOrbEnabled && device.overlayGranted && device.notificationsRequired && !device.notificationsGranted) {
            notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    ScreenScaffold("Settings", onBack) {
        Column(
            Modifier
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 4.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            KyraCard("Assistant") {
                StatusRow(
                    label = "Answer mode",
                    chip = if (device.aiConfigured) "Online AI" else "Built-in only",
                    kind = if (device.aiConfigured) StatusKind.OK else StatusKind.ACTION,
                    detail = if (device.aiConfigured) null
                    else "No AI model is connected in this version. Kyra understands a fixed set of commands. Online AI is prepared for a later version.",
                )
            }

            KyraCard("Voice") {
                SwitchRow("Speak responses", settings.speakResponses) { vm.setSpeakResponses(it) }
                StatusRow(
                    label = "Text-to-speech",
                    chip = when (ttsStatus) {
                        TtsStatus.READY -> "Ready"
                        TtsStatus.INITIALIZING -> "Starting…"
                        TtsStatus.UNAVAILABLE -> "Unavailable"
                    },
                    kind = when (ttsStatus) {
                        TtsStatus.READY -> StatusKind.OK
                        TtsStatus.INITIALIZING -> StatusKind.ACTION
                        TtsStatus.UNAVAILABLE -> StatusKind.UNAVAILABLE
                    },
                    detail = if (ttsStatus == TtsStatus.UNAVAILABLE) "Install or enable a text-to-speech engine in Android settings." else null,
                )
                if (ttsStatus == TtsStatus.READY) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = "Voice: " + (voices.firstOrNull { it.name == settings.voiceName }?.label ?: "Engine default"),
                            color = KyraColors.TextPrimary,
                            fontSize = 13.sp,
                            modifier = Modifier.weight(1f),
                        )
                        TextButton(onClick = { showVoices = true }) { Text("Change", color = KyraColors.Cyan) }
                    }
                    Text(
                        "Android doesn't tell apps a voice's gender, so Kyra can't filter for female voices. Try a few and keep the one you like.",
                        color = KyraColors.TextDim,
                        fontSize = 12.sp,
                    )
                }
                StatusRow(
                    label = "Speech recognition",
                    chip = if (device.speechRecognitionAvailable) "Available" else "Unavailable",
                    kind = if (device.speechRecognitionAvailable) StatusKind.OK else StatusKind.UNAVAILABLE,
                    detail = if (device.speechRecognitionAvailable) {
                        if (device.onDeviceSpeechAvailable) "An on-device recognizer exists, but Kyra can't guarantee it handles your language offline."
                        else "No on-device recognizer detected. Voice input may need internet, depending on your phone's speech service."
                    } else "This phone has no speech recognition service. Typing still works.",
                )
                StatusRow(
                    label = "Microphone permission",
                    chip = if (device.micGranted) "Granted" else "Not granted",
                    kind = if (device.micGranted) StatusKind.OK else StatusKind.ACTION,
                )
                if (!device.micGranted) {
                    Row {
                        TextButton(onClick = { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }) {
                            Text("Grant", color = KyraColors.Cyan)
                        }
                        TextButton(onClick = { openAppSettings() }) { Text("App settings", color = KyraColors.TextDim) }
                    }
                }
            }

            KyraCard("Memory") {
                SwitchRow("Allow saving memories", settings.memoryEnabled) { vm.setMemoryEnabled(it) }
                Text(
                    "Kyra only saves what you explicitly tell her to (for example \"remember that…\"). Conversations are not stored.",
                    color = KyraColors.TextDim,
                    fontSize = 12.sp,
                )
            }

            KyraCard("Floating orb") {
                SwitchRow("Show floating orb over other apps", settings.floatingOrbEnabled) { on ->
                    vm.setFloatingOrbEnabled(on)
                    if (on && !device.overlayGranted) openOverlaySettings()
                }
                StatusRow(
                    label = "Overlay permission",
                    chip = if (device.overlayGranted) "Granted" else "Not granted",
                    kind = if (device.overlayGranted) StatusKind.OK else StatusKind.ACTION,
                    detail = if (!device.overlayGranted) "Android requires you to allow \"Display over other apps\" in system settings. The orb only appears after you do." else null,
                )
                if (!device.overlayGranted) {
                    TextButton(onClick = { openOverlaySettings() }) { Text("Open overlay settings", color = KyraColors.Cyan) }
                }
                if (device.notificationsRequired) {
                    StatusRow(
                        label = "Notification permission",
                        chip = if (device.notificationsGranted) "Granted" else "Not granted",
                        kind = if (device.notificationsGranted) StatusKind.OK else StatusKind.ACTION,
                        detail = "Used for the persistent notification Android requires while the orb is active.",
                    )
                }
                StatusRow(
                    label = "Orb status",
                    chip = when {
                        orbRunning -> "Showing"
                        settings.floatingOrbEnabled && !device.overlayGranted -> "Waiting for permission"
                        else -> "Off"
                    },
                    kind = when {
                        orbRunning -> StatusKind.OK
                        settings.floatingOrbEnabled -> StatusKind.ACTION
                        else -> StatusKind.UNAVAILABLE
                    },
                    detail = "The orb is only a shortcut that opens Kyra. It does not listen to the microphone.",
                )
            }

            KyraCard("Phone actions") {
                StatusRow(
                    label = "Flashlight",
                    chip = if (device.flashlightAvailable) "Available" else "No flash found",
                    kind = if (device.flashlightAvailable) StatusKind.OK else StatusKind.UNAVAILABLE,
                    detail = "Uses the camera flash through Android's CameraManager. No camera permission is needed.",
                )
                StatusRow(label = "Open apps", chip = "Available", kind = StatusKind.OK, detail = "Works for launchable apps installed on this phone.")
            }

            KyraCard("Wake phrase \"Hey Kyra\"") {
                StatusRow(
                    label = "Wake-word listening",
                    chip = if (device.wakeWordState == WakeWordState.NOT_IMPLEMENTED) "Not implemented yet" else "Prepared",
                    kind = StatusKind.UNAVAILABLE,
                    detail = "Kyra does not listen for \"Hey Kyra\" in this version. A real offline wake-word engine has to be integrated and tested first. See the README.",
                )
            }
        }
    }

    if (showVoices) {
        AlertDialog(
            onDismissRequest = { showVoices = false },
            containerColor = KyraColors.CardPurple,
            title = { Text("Choose a voice", color = KyraColors.TextPrimary) },
            text = {
                LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    item {
                        TextButton(onClick = { vm.setVoice(null); showVoices = false }) {
                            Text("Engine default", color = KyraColors.TextPrimary)
                        }
                    }
                    items(voices, key = { it.name }) { voice ->
                        TextButton(onClick = { vm.setVoice(voice.name); showVoices = false }) {
                            Text(voice.label, color = KyraColors.TextPrimary, fontSize = 13.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { vm.previewVoice() }) { Text("Preview", color = KyraColors.Cyan) }
            },
            dismissButton = {
                TextButton(onClick = { showVoices = false }) { Text("Close", color = KyraColors.TextDim) }
            },
        )
    }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(
        Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
    ) {
        Text(label, color = KyraColors.TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = KyraColors.Cyan,
                checkedTrackColor = KyraColors.NeonPurple.copy(alpha = 0.6f),
                uncheckedThumbColor = KyraColors.TextDim,
                uncheckedTrackColor = KyraColors.DeepPurple,
            ),
        )
    }
}
