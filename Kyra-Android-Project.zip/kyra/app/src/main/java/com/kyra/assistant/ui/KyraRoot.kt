package com.kyra.assistant.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import com.kyra.assistant.ui.screens.ChatScreen
import com.kyra.assistant.ui.screens.MemoryScreen
import com.kyra.assistant.ui.screens.SettingsScreen
import com.kyra.assistant.ui.theme.KyraBackground

enum class Screen { CHAT, SETTINGS, MEMORY }

@Composable
fun KyraRoot(vm: KyraViewModel = viewModel()) {
    var screen by rememberSaveable { mutableStateOf(Screen.CHAT) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) { vm.refreshDeviceStatus() }
    LifecycleEventEffect(Lifecycle.Event.ON_STOP) { vm.onBackgrounded() }
    BackHandler(enabled = screen != Screen.CHAT) { screen = Screen.CHAT }

    KyraBackground {
        AnimatedContent(
            targetState = screen,
            transitionSpec = {
                if (targetState == Screen.CHAT) {
                    (fadeIn(tween(240)) + slideInHorizontally(tween(240)) { -it / 6 }) togetherWith
                        (fadeOut(tween(180)) + slideOutHorizontally(tween(180)) { it / 6 })
                } else {
                    (fadeIn(tween(240)) + slideInHorizontally(tween(240)) { it / 6 }) togetherWith
                        (fadeOut(tween(180)) + slideOutHorizontally(tween(180)) { -it / 6 })
                }
            },
            label = "screen",
        ) { current ->
            when (current) {
                Screen.CHAT -> ChatScreen(
                    vm = vm,
                    onOpenSettings = { screen = Screen.SETTINGS },
                    onOpenMemory = { screen = Screen.MEMORY },
                )
                Screen.SETTINGS -> SettingsScreen(vm = vm, onBack = { screen = Screen.CHAT })
                Screen.MEMORY -> MemoryScreen(vm = vm, onBack = { screen = Screen.CHAT })
            }
        }
    }
}
