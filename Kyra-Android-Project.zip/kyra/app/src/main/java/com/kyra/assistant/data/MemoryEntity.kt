package com.kyra.assistant.data

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.kyra.assistant.domain.Memory

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val text: String,
    val createdAt: Long,
) {
    fun toDomain() = Memory(id = id, text = text, createdAt = createdAt)
}
