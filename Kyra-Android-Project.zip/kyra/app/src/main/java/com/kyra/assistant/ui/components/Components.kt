package com.kyra.assistant.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.MutableTransitionState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kyra.assistant.domain.ChatMessage
import com.kyra.assistant.domain.MessageAuthor
import com.kyra.assistant.domain.ReplySource
import com.kyra.assistant.ui.theme.KyraColors

@Composable
fun MessageBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    val visibleState = remember { MutableTransitionState(false).apply { targetState = true } }
    AnimatedVisibility(
        visibleState = visibleState,
        enter = fadeIn(tween(260)) + slideInVertically(tween(260)) { it / 3 },
        modifier = modifier,
    ) {
        val isUser = message.author == MessageAuthor.USER
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start,
        ) {
            val shape = RoundedCornerShape(
                topStart = 20.dp,
                topEnd = 20.dp,
                bottomStart = if (isUser) 20.dp else 6.dp,
                bottomEnd = if (isUser) 6.dp else 20.dp,
            )
            val bubble = if (isUser) {
                Modifier.background(Brush.linearGradient(listOf(KyraColors.Violet, KyraColors.NeonPurple)), shape)
            } else {
                Modifier
                    .background(KyraColors.CardPurple, shape)
                    .border(
                        BorderStroke(1.dp, if (message.isError) KyraColors.Danger.copy(alpha = 0.7f) else KyraColors.Cyan.copy(alpha = 0.25f)),
                        shape,
                    )
            }
            Box(
                Modifier
                    .widthIn(max = 320.dp)
                    .then(bubble)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
            ) {
                Text(
                    text = message.text,
                    color = if (isUser) Color.White else KyraColors.TextPrimary,
                    fontSize = 15.sp,
                    lineHeight = 21.sp,
                )
            }
            if (!isUser && message.source != null) {
                Text(
                    text = sourceLabel(message.source, message.isError),
                    color = KyraColors.TextDim,
                    fontSize = 11.sp,
                    modifier = Modifier.padding(start = 8.dp, top = 3.dp),
                )
            }
        }
    }
}

private fun sourceLabel(source: ReplySource, isError: Boolean): String {
    val base = when (source) {
        ReplySource.BUILT_IN -> "Built-in reply · offline, not AI"
        ReplySource.PHONE_ACTION -> "Phone action · real result"
        ReplySource.AI -> "AI-generated"
        ReplySource.SYSTEM -> "System message"
    }
    return if (isError) "$base · failed" else base
}

@Composable
fun MicButton(listening: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.size(52.dp), contentAlignment = Alignment.Center) {
        if (listening) ListeningPulse()
        val fill = if (listening) {
            Brush.linearGradient(listOf(KyraColors.Cyan, KyraColors.NeonPurple))
        } else {
            Brush.linearGradient(listOf(KyraColors.NeonPurple, KyraColors.Violet))
        }
        Box(
            Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(fill)
                .semantics { contentDescription = if (listening) "Stop listening" else "Start listening" }
                .clickable(onClick = onClick),
            contentAlignment = Alignment.Center,
        ) {
            Canvas(Modifier.size(22.dp)) {
                val w = size.width
                val h = size.height
                val stroke = 2.dp.toPx()
                drawRoundRect(
                    color = Color.White,
                    topLeft = Offset(w * 0.36f, 0f),
                    size = Size(w * 0.28f, h * 0.58f),
                    cornerRadius = CornerRadius(w * 0.14f, w * 0.14f),
                )
                drawArc(
                    color = Color.White,
                    startAngle = 0f,
                    sweepAngle = 180f,
                    useCenter = false,
                    topLeft = Offset(w * 0.2f, h * 0.22f),
                    size = Size(w * 0.6f, h * 0.5f),
                    style = Stroke(width = stroke, cap = StrokeCap.Round),
                )
                drawLine(Color.White, Offset(w / 2f, h * 0.72f), Offset(w / 2f, h * 0.92f), strokeWidth = stroke, cap = StrokeCap.Round)
                drawLine(Color.White, Offset(w * 0.32f, h * 0.95f), Offset(w * 0.68f, h * 0.95f), strokeWidth = stroke, cap = StrokeCap.Round)
            }
        }
    }
}

@Composable
private fun ListeningPulse() {
    val transition = rememberInfiniteTransition(label = "mic-pulse")
    val scale by transition.animateFloat(
        initialValue = 1f,
        targetValue = 1.3f,
        animationSpec = infiniteRepeatable(tween(900), RepeatMode.Reverse),
        label = "mic-scale",
    )
    Box(
        Modifier
            .size(48.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(KyraColors.Cyan.copy(alpha = 0.25f)),
    )
}

enum class StatusKind { OK, ACTION, UNAVAILABLE }

@Composable
fun StatusChip(text: String, kind: StatusKind, modifier: Modifier = Modifier) {
    val color = when (kind) {
        StatusKind.OK -> KyraColors.Cyan
        StatusKind.ACTION -> KyraColors.Amber
        StatusKind.UNAVAILABLE -> KyraColors.Danger
    }
    Box(
        modifier
            .clip(RoundedCornerShape(50))
            .background(color.copy(alpha = 0.14f))
            .border(1.dp, color.copy(alpha = 0.5f), RoundedCornerShape(50))
            .padding(horizontal = 10.dp, vertical = 4.dp),
    ) {
        Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun KyraCard(title: String, modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(22.dp)
    Column(
        modifier
            .fillMaxWidth()
            .background(Brush.verticalGradient(listOf(KyraColors.CardPurple, KyraColors.DeepPurple)), shape)
            .border(1.dp, KyraColors.NeonPurple.copy(alpha = 0.22f), shape)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        Text(title, color = KyraColors.TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        content()
    }
}

@Composable
fun StatusRow(label: String, chip: String, kind: StatusKind, detail: String? = null) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(label, color = KyraColors.TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
            StatusChip(chip, kind)
        }
        if (detail != null) {
            Text(detail, color = KyraColors.TextDim, fontSize = 12.sp, lineHeight = 16.sp)
        }
    }
}
