package com.kyra.assistant

import android.content.Context
import com.kyra.assistant.data.AndroidPhoneActions
import com.kyra.assistant.data.KyraDatabase
import com.kyra.assistant.data.RoomMemoryRepository
import com.kyra.assistant.data.SharedPrefsSettingsRepository
import com.kyra.assistant.domain.AiProvider
import com.kyra.assistant.domain.AssistantRepository
import com.kyra.assistant.domain.CommandInterpreter
import com.kyra.assistant.domain.CommandRouter
import com.kyra.assistant.domain.DefaultAssistantRepository
import com.kyra.assistant.domain.LocalResponseEngine
import com.kyra.assistant.domain.MemoryRepository
import com.kyra.assistant.domain.SettingsRepository
import com.kyra.assistant.domain.UnconfiguredAiProvider
import com.kyra.assistant.voice.NotImplementedWakeWordEngine
import com.kyra.assistant.voice.WakeWordEngine

/** Small hand-rolled dependency container: no DI framework needed for this app size. */
class AppContainer(context: Context) {
    private val appContext = context.applicationContext

    val settings: SettingsRepository by lazy { SharedPrefsSettingsRepository(appContext) }
    val memory: MemoryRepository by lazy { RoomMemoryRepository(KyraDatabase.create(appContext).memoryDao()) }
    val aiProvider: AiProvider = UnconfiguredAiProvider()
    val wakeWord: WakeWordEngine = NotImplementedWakeWordEngine()

    private val phoneActions by lazy { AndroidPhoneActions(appContext) }
    private val local = LocalResponseEngine()

    val assistant: AssistantRepository by lazy {
        DefaultAssistantRepository(
            router = CommandRouter(CommandInterpreter(), phoneActions, memory, settings, local),
            ai = aiProvider,
            local = local,
        )
    }
}
