package com.kyra.assistant.domain

/**
 * Fixed, built-in replies. This is NOT an AI model: it is a small set of canned responses
 * for the commands in [Command]. Replies from here are always tagged [ReplySource.BUILT_IN].
 */
class LocalResponseEngine {

    fun greeting(): String =
        "Hey you! Kyra here, ready when you are. Try \"turn on the flashlight\", \"open YouTube\", or \"what time is it?\""

    fun help(): String = buildString {
        appendLine("Here's what I can do right now (all offline, built in):")
        appendLine("• \"Turn on / off the flashlight\"")
        appendLine("• \"Open <app name>\" (any launchable app installed on this phone)")
        appendLine("• \"What time is it?\" / \"What's the date?\"")
        appendLine("• \"Remember that <something>\", then \"What do you remember?\"")
        append("I don't have an online AI connected yet, so open-ended questions are outside what I can do for now.")
    }

    fun about(): String =
        "I'm Kyra, an AI companion app. I'm not a person and I don't have feelings or experiences. " +
            "Right now I run in built-in offline mode: I understand a fixed set of commands, and no AI model is connected yet."

    fun fallback(raw: String): String =
        "I didn't understand \"${raw.take(60)}\". In this version I only handle built-in commands, " +
            "and there's no online AI connected to answer open-ended questions. Say \"help\" to see what I can do."
}
