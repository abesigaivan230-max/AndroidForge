package com.kyra.assistant.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ResolveInfo
import android.hardware.camera2.CameraAccessException
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import com.kyra.assistant.domain.ActionResult
import com.kyra.assistant.domain.PhoneActions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.util.Locale

/**
 * Real phone actions. Each action returns what actually happened:
 *  - Flashlight: after setTorchMode() we wait for the system's TorchCallback to confirm the new state.
 *  - Open app: success means Android accepted the launch request (startActivity did not throw).
 */
class AndroidPhoneActions(context: Context) : PhoneActions {
    private val appContext = context.applicationContext
    private val cameraManager: CameraManager? = appContext.getSystemService(CameraManager::class.java)

    @Volatile private var torchState: Boolean? = null
    @Volatile private var torchUnavailable = false

    private val torchCameraId: String? by lazy { findTorchCameraId() }

    private val torchCallback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(cameraId: String, enabled: Boolean) {
            if (cameraId == torchCameraId) {
                torchState = enabled
                torchUnavailable = false
            }
        }

        override fun onTorchModeUnavailable(cameraId: String) {
            if (cameraId == torchCameraId) torchUnavailable = true
        }
    }

    init {
        if (hasFlash()) {
            try {
                cameraManager?.registerTorchCallback(torchCallback, Handler(Looper.getMainLooper()))
            } catch (_: Exception) {
                // Reported later when the user actually asks for the flashlight.
            }
        }
    }

    private fun hasFlash() = appContext.packageManager.hasSystemFeature(PackageManager.FEATURE_CAMERA_FLASH)

    private fun findTorchCameraId(): String? {
        val manager = cameraManager ?: return null
        return try {
            manager.cameraIdList.firstOrNull { id ->
                val c = manager.getCameraCharacteristics(id)
                c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true &&
                    c.get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK
            }
        } catch (_: CameraAccessException) {
            null
        }
    }

    override suspend fun setFlashlight(on: Boolean): ActionResult {
        val word = if (on) "on" else "off"
        if (!hasFlash()) return ActionResult(false, "This phone doesn't report a camera flash, so I can't control a flashlight.")
        val manager = cameraManager ?: return ActionResult(false, "The camera service isn't available right now.")
        val id = torchCameraId ?: return ActionResult(false, "I couldn't find a rear camera with a flash unit.")

        if (torchState == on) return ActionResult(true, "The flashlight is already $word.")
        if (torchUnavailable) {
            return ActionResult(false, "The flashlight is unavailable right now. Another app may be using the camera.")
        }

        return try {
            manager.setTorchMode(id, on)
            val confirmed = withTimeoutOrNull(1500) {
                while (torchState != on) delay(50)
                true
            } == true
            if (confirmed) ActionResult(true, "Flashlight is $word.")
            else ActionResult(false, "I asked Android to turn the flashlight $word, but it didn't confirm the change.")
        } catch (e: CameraAccessException) {
            ActionResult(false, "I couldn't turn the flashlight $word: the camera is in use or unavailable.")
        } catch (e: IllegalArgumentException) {
            ActionResult(false, "I couldn't turn the flashlight $word: this phone rejected the request.")
        } catch (e: SecurityException) {
            ActionResult(false, "Android blocked flashlight access: ${e.message ?: "permission denied"}.")
        }
    }

    override suspend fun openApp(target: String): ActionResult = withContext(Dispatchers.Default) {
        val pm = appContext.packageManager
        val query = target.trim()
        if (query.isEmpty()) return@withContext ActionResult(false, "Tell me which app to open.")

        // 1. A package name, e.g. "com.whatsapp".
        if (query.contains('.') && !query.contains(' ')) {
            pm.getLaunchIntentForPackage(query)?.let { return@withContext launch(it, query) }
        }

        // 2. Match against labels of installed launchable apps.
        val apps = launcherApps(pm)
        val wanted = query.lowercase(Locale.ROOT)
        fun label(info: ResolveInfo) = info.loadLabel(pm).toString()

        val exact = apps.firstOrNull { label(it).lowercase(Locale.ROOT) == wanted }
        if (exact != null) return@withContext launchInfo(pm, exact)

        val partial = apps.filter { label(it).lowercase(Locale.ROOT).let { l -> l.startsWith(wanted) || l.contains(wanted) } }
            .distinctBy { it.activityInfo.packageName }
        when {
            partial.size == 1 -> launchInfo(pm, partial.first())
            partial.size > 1 -> {
                val names = partial.map { label(it) }.sorted().take(5).joinToString(", ")
                ActionResult(false, "I found several apps matching \"$query\": $names. Which one do you want?")
            }
            else -> ActionResult(false, "I couldn't find an app called \"$query\" on this phone.")
        }
    }

    private fun launcherApps(pm: PackageManager): List<ResolveInfo> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            pm.queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(0L))
        } else {
            @Suppress("DEPRECATION")
            pm.queryIntentActivities(intent, 0)
        }
    }

    private fun launchInfo(pm: PackageManager, info: ResolveInfo): ActionResult {
        val pkg = info.activityInfo.packageName
        val intent = pm.getLaunchIntentForPackage(pkg)
            ?: return ActionResult(false, "\"${info.loadLabel(pm)}\" has no launchable screen.")
        return launch(intent, info.loadLabel(pm).toString())
    }

    private fun launch(intent: Intent, name: String): ActionResult = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        appContext.startActivity(intent)
        ActionResult(true, "Opening $name. Android accepted the launch request.")
    } catch (e: ActivityNotFoundException) {
        ActionResult(false, "Android couldn't find a screen to launch for $name.")
    } catch (e: SecurityException) {
        ActionResult(false, "Android blocked me from opening $name: ${e.message ?: "not allowed"}.")
    }
}
