package com.kyra.assistant.domain

import java.util.Locale

/**
 * Turns raw text into a [Command]. Pure Kotlin (no Android types) so it is unit-testable.
 * It only recognises a fixed set of phrases; it does not understand free-form language.
 */
class CommandInterpreter {

    private val wakePrefix = Regex("^(?:(?:hey|hi|ok|okay)\\s+)?kyra[,!]?\\s+")
    private val politePrefix = Regex("^(?:please|can you|could you|would you)\\s+")
    private val politeSuffix = Regex("\\s+please$")

    private val flashlightWord = Regex("\\b(flash\\s?light|torch)\\b")
    private val offWord = Regex("\\b(off|disable|kill|stop)\\b")
    private val onWord = Regex("\\b(on|enable|start|activate)\\b|\\blight up\\b")

    private val openApp = Regex("^(?:open|launch|start|run)\\s+(.+)$")
    private val remember = Regex(
        "^(?:remember|memorize)(?:\\s+that)?\\s*[:,]?\\s+(.+)$",
        RegexOption.IGNORE_CASE,
    )
    private val listMemories = Regex(
        "what do you (?:remember|know) about me|what do you remember|show (?:my )?memor(?:y|ies)|list (?:my )?memor(?:y|ies)",
    )
    private val timeWord = Regex("\\b(time)\\b")
    private val dateWord = Regex("\\b(date|day)\\b")
    private val greeting = Regex("^(?:hi|hello|hey|yo|hola|good (?:morning|afternoon|evening))(?:\\s+there)?$")
    private val nameOnly = Regex("^(?:(?:hey|hi|hello)\\s+)?kyra$")
    private val help = Regex("^(?:help|commands|what can you do|what can i say)$")
    private val about = Regex("^(?:who are you|what are you|are you (?:human|real|an? ai|a person))$")

    fun interpret(input: String): Command {
        val original = input.trim()
        if (original.isEmpty()) return Command.Unknown(original)

        var n = original.lowercase(Locale.ROOT).trimEnd('.', '!', '?', ',', ' ')
        if (nameOnly.matches(n) || greeting.matches(n)) return Command.Greeting
        n = n.replace(wakePrefix, "").replace(politePrefix, "").replace(politeSuffix, "").trim()

        // Memory commands keep the user's original casing for the stored text.
        val originalForMemory = original
            .replace(Regex("^(?:(?:hey|hi|ok|okay)\\s+)?kyra[,!]?\\s+", RegexOption.IGNORE_CASE), "")
            .trim()
        remember.find(originalForMemory)?.let { m ->
            val text = m.groupValues[1].trim()
            if (text.isNotEmpty()) return Command.Remember(text)
        }
        if (listMemories.containsMatchIn(n)) return Command.ListMemories

        if (flashlightWord.containsMatchIn(n)) {
            return when {
                offWord.containsMatchIn(n) -> Command.FlashlightOff
                onWord.containsMatchIn(n) -> Command.FlashlightOn
                else -> Command.Unknown(original)
            }
        }

        openApp.find(n)?.let { m ->
            val target = m.groupValues[1]
                .removePrefix("the ")
                .removeSuffix(" app")
                .trim()
            if (target.isNotEmpty()) return Command.OpenApp(target)
        }

        val asksTime = timeWord.containsMatchIn(n) && (n.contains("what") || n.contains("tell") || n.contains("current") || n.contains("show"))
        val asksDate = dateWord.containsMatchIn(n) && (n.contains("what") || n.contains("tell") || n.contains("today") || n.contains("current") || n.contains("show"))
        if (asksTime && asksDate) return Command.ShowDateTime
        if (asksTime) return Command.ShowTime
        if (asksDate) return Command.ShowDate

        if (help.matches(n)) return Command.Help
        if (about.matches(n)) return Command.About
        return Command.Unknown(original)
    }
}
