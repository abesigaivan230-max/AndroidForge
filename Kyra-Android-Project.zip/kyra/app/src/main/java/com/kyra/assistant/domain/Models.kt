package com.kyra.assistant.domain

enum class MessageAuthor { USER, KYRA }

/** Where a Kyra reply came from. The UI labels each source so built-in replies are never passed off as AI. */
enum class ReplySource { BUILT_IN, PHONE_ACTION, AI, SYSTEM }

data class ChatMessage(
    val id: Long,
    val author: MessageAuthor,
    val text: String,
    val source: ReplySource? = null,
    val isError: Boolean = false,
)

data class AssistantReply(
    val text: String,
    val source: ReplySource,
    val isError: Boolean = false,
)

data class Memory(
    val id: Long,
    val text: String,
    val createdAt: Long,
)

data class ActionResult(val success: Boolean, val message: String)
