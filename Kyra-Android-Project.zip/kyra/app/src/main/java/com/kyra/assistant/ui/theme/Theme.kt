package com.kyra.assistant.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

object KyraColors {
    val Black = Color(0xFF05030A)
    val DeepPurple = Color(0xFF120A24)
    val CardPurple = Color(0xFF1A1030)
    val NeonPurple = Color(0xFFB44CFF)
    val Violet = Color(0xFF6D28D9)
    val Cyan = Color(0xFF22E5FF)
    val Pink = Color(0xFFFF6BD6)
    val Amber = Color(0xFFFFC857)
    val Danger = Color(0xFFFF5C7A)
    val TextPrimary = Color(0xFFEDE7FF)
    val TextDim = Color(0xFF9C93B8)
}

private val KyraScheme = darkColorScheme(
    primary = KyraColors.NeonPurple,
    onPrimary = Color.White,
    secondary = KyraColors.Cyan,
    onSecondary = Color.Black,
    background = KyraColors.Black,
    onBackground = KyraColors.TextPrimary,
    surface = KyraColors.CardPurple,
    onSurface = KyraColors.TextPrimary,
    surfaceVariant = KyraColors.CardPurple,
    onSurfaceVariant = KyraColors.TextDim,
    error = KyraColors.Danger,
    outline = KyraColors.TextDim,
)

@Composable
fun KyraTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = KyraScheme, content = content)
}

/** Near-black to deep-purple gradient with two soft neon glows drawn behind the content. */
@Composable
fun KyraBackground(content: @Composable () -> Unit) {
    Box(
        Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(KyraColors.Black, KyraColors.DeepPurple, KyraColors.Black)))
            .drawBehind {
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(KyraColors.NeonPurple.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width * 0.15f, size.height * 0.05f),
                        radius = size.width * 0.9f,
                    ),
                    radius = size.width * 0.9f,
                    center = Offset(size.width * 0.15f, size.height * 0.05f),
                )
                drawCircle(
                    brush = Brush.radialGradient(
                        listOf(KyraColors.Cyan.copy(alpha = 0.10f), Color.Transparent),
                        center = Offset(size.width * 0.95f, size.height * 0.95f),
                        radius = size.width * 0.8f,
                    ),
                    radius = size.width * 0.8f,
                    center = Offset(size.width * 0.95f, size.height * 0.95f),
                )
            },
        content = { content() },
    )
}
