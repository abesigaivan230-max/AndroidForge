package com.kyra.assistant.domain

/** Order of answering: built-in commands first, then the AI provider (if configured), then an honest fallback. */
class DefaultAssistantRepository(
    private val router: CommandRouter,
    private val ai: AiProvider,
    private val local: LocalResponseEngine,
) : AssistantRepository {

    override suspend fun respond(input: String, history: List<ChatMessage>): AssistantReply {
        router.route(input)?.let { return it }

        if (ai.isConfigured) {
            return ai.generate(input, history).fold(
                onSuccess = { AssistantReply(it, ReplySource.AI) },
                onFailure = {
                    AssistantReply(
                        "The AI service didn't respond: ${it.message ?: "unknown error"}.",
                        ReplySource.SYSTEM,
                        isError = true,
                    )
                },
            )
        }
        return AssistantReply(local.fallback(input), ReplySource.BUILT_IN)
    }
}
