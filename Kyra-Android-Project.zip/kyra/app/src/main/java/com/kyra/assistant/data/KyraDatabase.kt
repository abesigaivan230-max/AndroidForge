package com.kyra.assistant.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [MemoryEntity::class], version = 1, exportSchema = false)
abstract class KyraDatabase : RoomDatabase() {
    abstract fun memoryDao(): MemoryDao

    companion object {
        fun create(context: Context): KyraDatabase =
            Room.databaseBuilder(context.applicationContext, KyraDatabase::class.java, "kyra.db").build()
    }
}
