package com.kyra.assistant.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.kyra.assistant.KyraApp
import com.kyra.assistant.MainActivity
import com.kyra.assistant.R
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Foreground service that shows a draggable orb over other apps.
 * Only runs while the user has enabled it AND Android's overlay permission is granted.
 * A persistent notification is shown while active, with a "Turn off" action.
 */
class FloatingOrbService : Service() {

    private var windowManager: WindowManager? = null
    private var orbView: OrbOverlayView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            disableAndStop()
            return START_NOT_STICKY
        }
        startInForeground()
        if (!Settings.canDrawOverlays(this)) {
            // Permission missing or revoked: do not draw anything.
            disableAndStop()
            return START_NOT_STICKY
        }
        if (orbView == null && !addOrb()) {
            disableAndStop()
            return START_NOT_STICKY
        }
        _running.value = true
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Floating orb", NotificationManager.IMPORTANCE_LOW).apply {
                description = "Shown while Kyra's floating orb is active."
            },
        )
        val open = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this, 1,
            Intent(this, FloatingOrbService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Kyra floating orb is on")
            .setContentText("Tap the orb to open Kyra. Kyra is not listening in the background.")
            .setOngoing(true)
            .setContentIntent(open)
            .addAction(0, "Turn off", stop)
            .build()
        val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
        } else {
            0
        }
        ServiceCompat.startForeground(this, NOTIFICATION_ID, notification, type)
    }

    private fun addOrb(): Boolean {
        val wm = getSystemService(WindowManager::class.java) ?: return false
        val size = (64 * resources.displayMetrics.density).toInt()
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = resources.displayMetrics.widthPixels - size - (16 * resources.displayMetrics.density).toInt()
            y = (resources.displayMetrics.heightPixels * 0.35f).toInt()
        }
        val view = OrbOverlayView(this, wm, params) { openKyra() }
        return try {
            wm.addView(view, params)
            windowManager = wm
            orbView = view
            true
        } catch (_: Exception) {
            // WindowManager.BadTokenException / SecurityException when the permission is gone.
            false
        }
    }

    private fun openKyra() {
        startActivity(
            Intent(this, MainActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT),
        )
    }

    private fun removeOrb() {
        orbView?.let {
            try {
                windowManager?.removeView(it)
            } catch (_: Exception) {
            }
        }
        orbView = null
    }

    private fun disableAndStop() {
        (application as? KyraApp)?.container?.settings?.setFloatingOrbEnabled(false)
        removeOrb()
        _running.value = false
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        removeOrb()
        _running.value = false
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL_ID = "kyra_orb"
        private const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.kyra.assistant.action.STOP_ORB"

        private val _running = MutableStateFlow(false)
        val running: StateFlow<Boolean> = _running.asStateFlow()

        fun start(context: Context) {
            ContextCompat.startForegroundService(context, Intent(context, FloatingOrbService::class.java))
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, FloatingOrbService::class.java))
        }
    }
}
