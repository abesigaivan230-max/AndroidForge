package com.kyra.assistant.domain

/** Real device actions. Implementations must report what actually happened, never assume success. */
interface PhoneActions {
    suspend fun setFlashlight(on: Boolean): ActionResult
    suspend fun openApp(target: String): ActionResult
}
