package com.kyra.assistant.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kyra.assistant.ui.AssistantPhase
import com.kyra.assistant.ui.KyraViewModel
import com.kyra.assistant.ui.components.KyraOrb
import com.kyra.assistant.ui.components.MessageBubble
import com.kyra.assistant.ui.components.MicButton
import com.kyra.assistant.ui.theme.KyraColors

@Composable
fun ChatScreen(
    vm: KyraViewModel,
    onOpenSettings: () -> Unit,
    onOpenMemory: () -> Unit,
) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val device by vm.device.collectAsStateWithLifecycle()
    var input by rememberSaveable { mutableStateOf("") }
    val context = LocalContext.current

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        vm.onMicPermissionResult()
    }
    val onMic: () -> Unit = {
        val granted = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) ==
            PackageManager.PERMISSION_GRANTED
        if (granted) vm.toggleListening() else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }

    val listState = rememberLazyListState()
    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.lastIndex)
    }

    Column(
        Modifier
            .fillMaxSize()
            .systemBarsPadding()
            .imePadding(),
    ) {
        // Top bar
        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 20.dp, end = 8.dp, top = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("Kyra", color = KyraColors.TextPrimary, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (device.aiConfigured) "Online AI connected" else "Built-in offline mode · no AI model connected",
                    color = KyraColors.TextDim,
                    fontSize = 12.sp,
                )
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onOpenMemory) { Text("Memory", color = KyraColors.Cyan) }
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Settings, contentDescription = "Settings", tint = KyraColors.TextPrimary)
                }
            }
        }

        // Banner
        AnimatedVisibility(
            visible = ui.banner != null,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically(),
        ) {
            Surface(
                color = KyraColors.CardPurple,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, KyraColors.Amber.copy(alpha = 0.6f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
            ) {
                Row(
                    Modifier.padding(start = 14.dp, top = 4.dp, bottom = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(ui.banner.orEmpty(), color = KyraColors.TextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    TextButton(onClick = vm::dismissBanner) { Text("OK", color = KyraColors.Amber) }
                }
            }
        }

        // Orb
        Column(
            Modifier
                .fillMaxWidth()
                .padding(top = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            KyraOrb(
                phase = ui.phase,
                level = ui.micLevel,
                modifier = Modifier
                    .size(168.dp)
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null,
                    ) {
                        if (ui.phase == AssistantPhase.SPEAKING) vm.stopSpeaking() else onMic()
                    },
            )
            Text(
                text = when (ui.phase) {
                    AssistantPhase.IDLE -> "Tap the orb to talk"
                    AssistantPhase.LISTENING -> ui.partialSpeech.ifBlank { "Listening…" }
                    AssistantPhase.THINKING -> "Working on it…"
                    AssistantPhase.SPEAKING -> "Speaking · tap the orb to stop"
                },
                color = if (ui.phase == AssistantPhase.LISTENING) KyraColors.Cyan else KyraColors.TextDim,
                fontSize = 13.sp,
                maxLines = 2,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 4.dp),
            )
        }

        // Messages
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            items(ui.messages, key = { it.id }) { message -> MessageBubble(message) }
        }

        // Input
        Row(
            Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
        ) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                placeholder = { Text("Message Kyra…", color = KyraColors.TextDim) },
                shape = RoundedCornerShape(26.dp),
                maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = {
                    vm.send(input)
                    input = ""
                }),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = KyraColors.TextPrimary,
                    unfocusedTextColor = KyraColors.TextPrimary,
                    cursorColor = KyraColors.Cyan,
                    focusedBorderColor = KyraColors.NeonPurple,
                    unfocusedBorderColor = KyraColors.NeonPurple.copy(alpha = 0.3f),
                    focusedContainerColor = KyraColors.CardPurple,
                    unfocusedContainerColor = KyraColors.CardPurple,
                ),
            )
            MicButton(listening = ui.phase == AssistantPhase.LISTENING, onClick = onMic)
            IconButton(
                onClick = {
                    vm.send(input)
                    input = ""
                },
                enabled = input.isNotBlank(),
            ) {
                Icon(
                    Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Send",
                    tint = if (input.isNotBlank()) KyraColors.Cyan else KyraColors.TextDim,
                )
            }
        }
    }
}
