package com.kyra.assistant.domain

import java.time.ZonedDateTime
import java.time.format.DateTimeFormatter
import java.util.Locale

/**
 * Interprets text and executes the matching action. Returns null when the text is not a
 * built-in command, so the caller can decide whether an AI provider may answer instead.
 */
class CommandRouter(
    private val interpreter: CommandInterpreter,
    private val actions: PhoneActions,
    private val memory: MemoryRepository,
    private val settings: SettingsRepository,
    private val local: LocalResponseEngine,
    private val now: () -> ZonedDateTime = { ZonedDateTime.now() },
) {
    suspend fun route(input: String): AssistantReply? = when (val command = interpreter.interpret(input)) {
        Command.FlashlightOn -> actions.setFlashlight(true).toReply()
        Command.FlashlightOff -> actions.setFlashlight(false).toReply()
        is Command.OpenApp -> actions.openApp(command.target).toReply()
        Command.ShowTime -> AssistantReply("It's ${timeText()}.", ReplySource.PHONE_ACTION)
        Command.ShowDate -> AssistantReply("Today is ${dateText()}.", ReplySource.PHONE_ACTION)
        Command.ShowDateTime ->
            AssistantReply("It's ${timeText()} on ${dateText()}.", ReplySource.PHONE_ACTION)
        is Command.Remember -> remember(command.text)
        Command.ListMemories -> listMemories()
        Command.Greeting -> AssistantReply(local.greeting(), ReplySource.BUILT_IN)
        Command.Help -> AssistantReply(local.help(), ReplySource.BUILT_IN)
        Command.About -> AssistantReply(local.about(), ReplySource.BUILT_IN)
        is Command.Unknown -> null
    }

    private suspend fun remember(text: String): AssistantReply {
        if (!settings.settings.value.memoryEnabled) {
            return AssistantReply(
                "Memory is turned off, so I did not save that. You can turn it on in Settings.",
                ReplySource.SYSTEM,
                isError = true,
            )
        }
        return try {
            memory.save(text)
            AssistantReply(
                "Saved to memory: \"$text\". You can view or delete it any time on the Memory screen.",
                ReplySource.PHONE_ACTION,
            )
        } catch (e: Exception) {
            AssistantReply("I couldn't save that memory: ${e.message ?: "unknown error"}.", ReplySource.SYSTEM, isError = true)
        }
    }

    private suspend fun listMemories(): AssistantReply {
        if (!settings.settings.value.memoryEnabled) {
            return AssistantReply("Memory is turned off in Settings, so I'm not using saved memories.", ReplySource.SYSTEM)
        }
        val items = memory.snapshot()
        if (items.isEmpty()) {
            return AssistantReply("I have nothing saved. Say \"remember that ...\" and I'll keep it.", ReplySource.PHONE_ACTION)
        }
        val body = items.take(10).joinToString("\n") { "• ${it.text}" }
        val more = if (items.size > 10) "\n…and ${items.size - 10} more on the Memory screen." else ""
        return AssistantReply("Here's what you asked me to save:\n$body$more", ReplySource.PHONE_ACTION)
    }

    private fun timeText(): String =
        now().format(DateTimeFormatter.ofPattern("h:mm a", Locale.getDefault()))

    private fun dateText(): String =
        now().format(DateTimeFormatter.ofPattern("EEEE, d MMMM yyyy", Locale.getDefault()))

    private fun ActionResult.toReply() =
        AssistantReply(message, ReplySource.PHONE_ACTION, isError = !success)
}
