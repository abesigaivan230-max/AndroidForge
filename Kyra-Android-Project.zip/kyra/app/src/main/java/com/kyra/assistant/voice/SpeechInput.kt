package com.kyra.assistant.voice

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/**
 * Thin wrapper around Android's SpeechRecognizer. Must be used from the main thread.
 * Whether recognition runs on-device or via a cloud service depends on the installed recognition
 * service and language packs; [isOnDeviceAvailable] only reports whether an on-device recognizer exists (Android 13+).
 */
class SpeechInput(context: Context) {
    interface Listener {
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onLevel(level: Float)
        fun onError(message: String)
    }

    private val appContext = context.applicationContext
    private var recognizer: SpeechRecognizer? = null
    private var cancelledByUs = false

    val isAvailable: Boolean
        get() = SpeechRecognizer.isRecognitionAvailable(appContext)

    val isOnDeviceAvailable: Boolean
        get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            SpeechRecognizer.isOnDeviceRecognitionAvailable(appContext)

    fun start(listener: Listener) {
        release()
        if (!isAvailable) {
            listener.onError("Speech recognition isn't available on this phone.")
            return
        }
        cancelledByUs = false
        val r = try {
            SpeechRecognizer.createSpeechRecognizer(appContext)
        } catch (e: Exception) {
            listener.onError("Couldn't start speech recognition: ${e.message ?: "unknown error"}.")
            return
        }
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = Unit
            override fun onBeginningOfSpeech() = Unit
            override fun onRmsChanged(rmsdB: Float) {
                listener.onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f))
            }
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = Unit
            override fun onEvent(eventType: Int, params: Bundle?) = Unit

            override fun onPartialResults(partialResults: Bundle?) {
                firstResult(partialResults)?.let(listener::onPartial)
            }

            override fun onResults(results: Bundle?) {
                val text = firstResult(results)
                release()
                if (text.isNullOrBlank()) listener.onError("I didn't catch that. Try again?") else listener.onResult(text)
            }

            override fun onError(error: Int) {
                if (cancelledByUs) return
                release()
                listener.onError(describe(error))
            }
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, appContext.packageName)
        }
        recognizer = r
        try {
            r.startListening(intent)
        } catch (e: Exception) {
            release()
            listener.onError("Couldn't start listening: ${e.message ?: "unknown error"}.")
        }
    }

    /** Stop capturing audio and let the recognizer deliver what it has heard so far. */
    fun stop() {
        try {
            recognizer?.stopListening()
        } catch (_: Exception) {
            release()
        }
    }

    /** Abort without delivering a result. */
    fun cancel() {
        cancelledByUs = true
        release()
    }

    fun release() {
        recognizer?.let {
            try {
                it.cancel()
                it.destroy()
            } catch (_: Exception) {
            }
        }
        recognizer = null
    }

    private fun firstResult(bundle: Bundle?): String? =
        bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()

    private fun describe(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Try again?"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT, SpeechRecognizer.ERROR_SERVER ->
            "Speech recognition needs an internet connection on this phone right now, and it isn't working."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again in a moment."
        SpeechRecognizer.ERROR_AUDIO -> "There was a problem capturing audio from the microphone."
        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE ->
            "The speech language pack isn't available. Check your phone's speech recognition settings."
        else -> "Speech recognition failed (code $error)."
    }
}
