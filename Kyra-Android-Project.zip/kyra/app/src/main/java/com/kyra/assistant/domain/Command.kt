package com.kyra.assistant.domain

/** Everything the local engine understands. Anything else becomes [Unknown]. */
sealed interface Command {
    data object FlashlightOn : Command
    data object FlashlightOff : Command
    data class OpenApp(val target: String) : Command
    data object ShowTime : Command
    data object ShowDate : Command
    data object ShowDateTime : Command
    data class Remember(val text: String) : Command
    data object ListMemories : Command
    data object Greeting : Command
    data object Help : Command
    data object About : Command
    data class Unknown(val raw: String) : Command
}
