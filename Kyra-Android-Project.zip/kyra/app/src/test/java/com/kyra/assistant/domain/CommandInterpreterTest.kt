package com.kyra.assistant.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandInterpreterTest {
    private val interpreter = CommandInterpreter()

    @Test fun flashlightOn() {
        assertEquals(Command.FlashlightOn, interpreter.interpret("Turn on the flashlight"))
        assertEquals(Command.FlashlightOn, interpreter.interpret("switch on the torch please"))
        assertEquals(Command.FlashlightOn, interpreter.interpret("Hey Kyra, flashlight on"))
    }

    @Test fun flashlightOff() {
        assertEquals(Command.FlashlightOff, interpreter.interpret("turn off the flashlight"))
        assertEquals(Command.FlashlightOff, interpreter.interpret("Can you switch the torch off?"))
    }

    @Test fun flashlightWithoutDirectionIsUnknown() {
        assertTrue(interpreter.interpret("flashlight") is Command.Unknown)
    }

    @Test fun openApp() {
        assertEquals(Command.OpenApp("youtube"), interpreter.interpret("open YouTube"))
        assertEquals(Command.OpenApp("whatsapp"), interpreter.interpret("Launch the WhatsApp app"))
        assertEquals(Command.OpenApp("com.whatsapp"), interpreter.interpret("open com.whatsapp"))
    }

    @Test fun timeAndDate() {
        assertEquals(Command.ShowTime, interpreter.interpret("What time is it?"))
        assertEquals(Command.ShowDate, interpreter.interpret("what's the date today"))
        assertEquals(Command.ShowDate, interpreter.interpret("What day is it?"))
        assertEquals(Command.ShowDateTime, interpreter.interpret("what is the date and time"))
    }

    @Test fun rememberKeepsOriginalCasing() {
        assertEquals(Command.Remember("My sister is called Amina"), interpreter.interpret("Remember that My sister is called Amina"))
        assertEquals(Command.Remember("I like tea"), interpreter.interpret("remember I like tea"))
    }

    @Test fun listMemories() {
        assertEquals(Command.ListMemories, interpreter.interpret("What do you remember?"))
        assertEquals(Command.ListMemories, interpreter.interpret("show my memories"))
    }

    @Test fun greetingHelpAbout() {
        assertEquals(Command.Greeting, interpreter.interpret("hello"))
        assertEquals(Command.Greeting, interpreter.interpret("Hey Kyra"))
        assertEquals(Command.Help, interpreter.interpret("help"))
        assertEquals(Command.About, interpreter.interpret("Are you human?"))
    }

    @Test fun unknownAndBlank() {
        assertTrue(interpreter.interpret("explain quantum physics") is Command.Unknown)
        assertTrue(interpreter.interpret("   ") is Command.Unknown)
        // "update" contains "date" but is not a date question
        assertTrue(interpreter.interpret("update my profile") is Command.Unknown)
    }
}
