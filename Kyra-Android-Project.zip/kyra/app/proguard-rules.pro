# Release minification is disabled in this first version.
