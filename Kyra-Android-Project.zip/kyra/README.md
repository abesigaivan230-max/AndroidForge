# Kyra — Your AI Companion (v0.1.0)

Native Android app (Kotlin + Jetpack Compose). Package `com.kyra.assistant`. Target: Android 14, minSdk 26, Java 17.

**Honest status of this build:** Kyra v0.1 is a *built-in command assistant*, not an AI. It understands a fixed set of
phrases and runs real phone actions. No AI model is connected. Every reply is labelled in the UI as
"Built-in reply", "Phone action · real result", "AI-generated" or "System message".

## Build the APK

### GitHub Actions (recommended)
1. Create a new GitHub repo and push the contents of this folder (the folder that contains `settings.gradle.kts`).
2. Open the **Actions** tab → **Build Kyra APK** (runs on every push, or press *Run workflow*).
3. When it finishes, download the **kyra-debug-apk** artifact, unzip it, and install `app-debug.apk` on the phone
   (allow "Install unknown apps" for your file manager/browser).

The workflow runs the unit tests first, then `assembleDebug`. The result is a *debug-signed* APK, which is fine for
installing on your own phone. A Play Store release would need a release keystore (not included).

### Android Studio
Open the folder, let Gradle sync, run on a device. Requires JDK 17 (Android Studio's bundled JDK works).
Command line: `./gradlew testDebugUnitTest assembleDebug`.

Versions: Gradle 8.7, AGP 8.5.2, Kotlin 1.9.24 (+ Compose compiler 1.5.14), Compose BOM 2024.06.00, Room 2.6.1 (KSP).

## What works

| Feature | Notes |
|---|---|
| Flashlight on/off | `CameraManager.setTorchMode`. Waits for Android's torch callback and reports the *confirmed* state, or the failure (camera in use, no flash, etc.). No camera permission needed. |
| Open apps | "open YouTube", "open com.whatsapp". Matches installed launcher apps by name; says so if none found or if several match. Success means Android accepted the launch request. |
| Time / date | From the device clock. |
| Memory | "remember that …", "what do you remember?", plus the Memory screen (add, view, delete one, clear all, on/off switch). Stored in Room on the phone only. Conversations are **not** stored. |
| Voice input | Android `SpeechRecognizer`. The Settings screen reports whether recognition is available and whether an on-device recognizer exists. Whether it works offline depends on your phone's speech service and language pack. |
| Spoken replies | Android `TextToSpeech`, on/off switch, selectable voice. Android does not expose voice gender, so Kyra cannot filter "female" voices; you choose from the list. |
| Floating orb | Separate switch. Needs "Display over other apps" (opened in system settings). Draggable; tap opens Kyra. Runs as a foreground service with a persistent notification and a "Turn off" action. It is only a shortcut and does **not** listen to the microphone. |

## Permissions

| Permission | Why | When requested |
|---|---|---|
| `RECORD_AUDIO` | Voice input | First time you use the mic |
| `SYSTEM_ALERT_WINDOW` | Floating orb | You grant it in system settings after enabling the orb |
| `FOREGROUND_SERVICE`, `FOREGROUND_SERVICE_SPECIAL_USE` | Orb service (Android 14 requires a declared type) | Declared only |
| `POST_NOTIFICATIONS` | The orb's persistent notification | When the orb is enabled (Android 13+) |

Not requested: INTERNET (nothing implemented uses the network), CAMERA, contacts, SMS, call log, accessibility.
No `AccessibilityService`, no shell commands, no code execution from AI text.

If overlay permission is revoked, the orb is removed and stops; Settings shows "Waiting for permission".
The orb is restarted when you open Kyra if the switch is still on and the permission is back.

## Not implemented (by design in v0.1)

- **Online AI / web research** — `AiProvider` interface exists; the default `UnconfiguredAiProvider` does nothing and makes no network calls.
- **"Hey Kyra" wake word** — only the `WakeWordEngine` interface and a `NotImplementedWakeWordEngine`. Settings shows "Not implemented yet".
- Conversation history is kept in memory for the current session only.

### What a real wake-word feature needs
- A dedicated on-device keyword-spotting library with a trained "Hey Kyra" model (not repeated `SpeechRecognizer` calls).
- A **foreground service** (type `microphone`) with `FOREGROUND_SERVICE_MICROPHONE` and `RECORD_AUDIO`, started while the app is visible (Android 14 blocks starting mic services from the background).
- A persistent notification the user can see. Android also shows the mic privacy indicator; this must never be hidden.
- Battery cost: continuous audio capture is the biggest drain, so it must be opt-in and easy to switch off.
- Privacy: audio processed on-device only, nothing recorded or sent unless the wake word fires.

### Adding online AI later (secure pattern)
Never put an API key in the app (APKs can be decompiled). Instead:
1. Run a small backend (your own server/cloud function) that holds the provider key.
2. The app sends the user's message to *your* backend over HTTPS, authenticated per user/device (and rate-limited).
3. The backend calls the AI provider, optionally does web search, and returns text.
4. Implement `AiProvider` with that HTTPS call, add the `INTERNET` permission at that point, and return `ReplySource.AI`.
Show the user clearly when a reply left the phone.

## Project layout
```
app/src/main/java/com/kyra/assistant/
  domain/   Command, CommandInterpreter (pure Kotlin), CommandRouter, PhoneActions, LocalResponseEngine,
            AiProvider, repository interfaces, DefaultAssistantRepository
  data/     Room memory, SharedPreferences settings, AndroidPhoneActions (flashlight / open app)
  voice/    SpeechInput, TtsManager, WakeWordEngine (+ not-implemented stub)
  overlay/  FloatingOrbService, OrbOverlayView
  ui/       KyraViewModel, KyraRoot, screens (Chat / Settings / Memory), components, theme
app/src/test/  CommandInterpreterTest
```

## Verification status (please read)
- `CommandInterpreter`, `CommandRouter` and the other domain classes were compiled with Kotlin 1.9.24 and the 9 unit tests were run: all passed.
- The voice, overlay, phone-action and settings code was type-checked against the real Android 34 `android.jar` (with stubs for coroutines/androidx): no errors.
- **Not verified here:** the Compose UI, ViewModel, Room/KSP, Gradle sync and manifest/resource merging. No Android SDK was available. The first CI run may surface small errors; paste the log and they will be quick fixes.
- Nothing has been tested on a physical device yet (flashlight, speech, TTS voices, overlay behaviour vary by phone).

## Known limitations
- Phrase matching is literal: "turn on the flashlight" works, loose paraphrases may not.
- App launching depends on Android's background-activity rules; it is intended to be used while Kyra is on screen.
- Speech recognition on many phones uses a Google cloud service; offline use is not guaranteed.
